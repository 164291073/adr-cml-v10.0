"""Repair may learn, but must never consume the planner's random stream."""
import random

import numpy as np
import pytest

torch = pytest.importorskip("torch")

from adrcml.buffer import ReplayBuffer
from adrcml.repair import LocalMechanismRepair


class RandomConsumer(torch.nn.Module):
    state_dim = 1

    def __init__(self, device, fail=False):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.tensor(1.0, device=device))
        self.members = torch.nn.ModuleList()
        self.calls = 0
        self.fail = fail

    def prediction_error(self, batch):
        return self.weight.square().reshape(1)

    def prediction_mse(self, batch):
        return self.weight.square().reshape(1)

    def loss(self, batch, node_mask=None, **weights):
        random.random()
        np.random.random(7)
        torch.rand(7)
        noise = torch.rand(7, device=self.weight.device).mean()
        self.calls += 1
        if self.fail and self.calls == 2:
            raise RuntimeError("injected after first optimizer step")
        return self.weight.square() + 0.1 * noise * self.weight, {}


def replay():
    result = ReplayBuffer(32, 1, action_dim=2)
    for step in range(28):
        result.add(np.ones(1, dtype=np.float32), step % 2, 0., np.zeros(1, dtype=np.float32), False, step=step)
    return result


def snapshot():
    return (random.getstate(), np.random.get_state(), torch.get_rng_state(),
            torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [])


def assert_same_rng(before, after):
    assert before[0] == after[0]
    assert before[1][0] == after[1][0]
    np.testing.assert_array_equal(before[1][1], after[1][1])
    assert before[1][2:] == after[1][2:]
    assert torch.equal(before[2], after[2])
    assert len(before[3]) == len(after[3])
    for left, right in zip(before[3], after[3]):
        assert torch.equal(left, right)


@pytest.mark.parametrize("outcome", ["accepted", "rejected", "error"])
@pytest.mark.parametrize("device", ["cpu", pytest.param("cuda", marks=pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA unavailable"))])
def test_repair_restores_rng_and_model_mode_for_every_outcome(device, outcome):
    model = RandomConsumer(device, fail=outcome == "error").eval()
    repair = LocalMechanismRepair(
        model, torch.optim.SGD(model.parameters(), lr=.1), device,
        repair_steps=3, local=False, rng_seed=128,
        min_relative_improvement=1.0 if outcome == "rejected" else .005,
    )
    model.weight.grad = torch.full_like(model.weight, 7.)
    before = snapshot()
    if outcome == "error":
        with pytest.raises(RuntimeError, match="injected"):
            repair.repair(replay(), [0], 4, 27, target_action=1)
    else:
        report = repair.repair(replay(), [0], 4, 27, target_action=1)
        assert report.applied == (outcome == "accepted")
        assert report.rng_isolated
        assert report.steps == 3
    assert_same_rng(before, snapshot())
    assert not model.training
    assert model.weight.grad.item() == pytest.approx(7.)
    if outcome != "accepted":
        assert model.weight.item() == pytest.approx(1.)


class VarianceOnly(RandomConsumer):
    """Only log variance can move; the predictive mean never improves."""
    def __init__(self):
        super().__init__("cpu")
        with torch.no_grad():
            self.weight.fill_(0.)

    def prediction_error(self, batch):
        return (.5 * (4. * torch.exp(-self.weight) + self.weight)).reshape(1)

    def prediction_mse(self, batch):
        return torch.full((1,), 4.)

    def loss(self, batch, node_mask=None, **weights):
        return self.prediction_error(batch).sum(), {}


def test_variance_inflation_without_mean_improvement_cannot_pass_repair():
    model = VarianceOnly()
    repair = LocalMechanismRepair(model, torch.optim.SGD(model.parameters(), lr=.1), "cpu", repair_steps=3, local=False)
    report = repair.repair(replay(), [0], 4, 27, target_action=1)
    assert report.final_loss < report.initial_loss  # NLL-only v0.8 rule could pass.
    assert report.final_target_mse == report.initial_target_mse == 4.
    assert not report.applied and report.rejected
    assert report.skip_reason == "insufficient_holdout_mse_improvement"
    assert model.weight.item() == pytest.approx(0.)


class BadCalibration(RandomConsumer):
    def prediction_error(self, batch):
        return (2. - self.weight).square().reshape(1)


def test_mean_improvement_does_not_override_nll_calibration_guard():
    model = BadCalibration("cpu")
    repair = LocalMechanismRepair(model, torch.optim.SGD(model.parameters(), lr=.1), "cpu", repair_steps=3, local=False)
    report = repair.repair(replay(), [0], 4, 27, target_action=1)
    assert report.final_target_mse < report.initial_target_mse
    assert report.final_loss > report.initial_loss
    assert report.rejected and report.skip_reason == "nll_calibration_guard"
    assert model.weight.item() == pytest.approx(1.)


def test_event_local_repair_stream_does_not_depend_on_caller_rng_position():
    final_weights = []
    for caller_seed in [32, 917]:
        random.seed(caller_seed)
        np.random.seed(caller_seed)
        torch.manual_seed(caller_seed)
        model = RandomConsumer("cpu")
        repair = LocalMechanismRepair(
            model, torch.optim.SGD(model.parameters(), lr=.1), "cpu",
            repair_steps=3, local=False, rng_seed=128,
        )
        report = repair.repair(replay(), [0], 4, 27, target_action=1)
        assert report.applied
        final_weights.append(model.weight.detach().clone())
    assert torch.equal(*final_weights)
