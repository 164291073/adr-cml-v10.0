import copy
import json
from pathlib import Path

import numpy as np
import pytest

from adrcml.evidence_report import build_evidence_report, _fingerprint, _hash_file, _inference_supports, render_text


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


def session(root: Path, seed=1):
    modes = ["full", "global_repair", "diagnose_no_repair", "frozen", "no_active"]
    spec = {"modes": modes, "environment_profile": "train"}
    model = f"{seed:064x}"
    hashes = {name: model for name in ("model", "optimizer", "detector", "replay_contents")}
    data = {
        "software_version": "10.0.0", "protocol": "fixed_regime_support_query_independent_probes_v2",
        "training_seed": seed, "evaluation_seed": seed + 100, "protocol_spec": spec,
        "protocol_sha256": _fingerprint(spec), "checkpoint_sha256": model, "model_sha256": model,
        "training_source_hash": "a" * 64, "evaluation_source_hash": "a" * 64,
        "environment_profile": "train", "sessions": 2, "support_episodes_per_session": 1,
        "query_episodes_per_session": 1, "active_budget_per_task": 1,
        "active_budget_interpretation": "equal_maximum_allowance_not_equal_realized_action_counts", "mode_sessions": {},
    }
    rows, raw = [], []
    for i in range(2):
        bank = {"state": np.ones((2, 3), dtype=np.float32) * i}
        bank_path = root / f"probe_bank_session_{i:04}.npz"
        root.mkdir(parents=True, exist_ok=True)
        np.savez(bank_path, **bank)
        cost = {"tasks": 1, "environment_steps": 3, "active_actions": 1,
                "online_optimizer_steps": 0, "repair_optimizer_steps": 0,
                "mean_return": 1, "success_rate": 1}
        probe = {"readonly_audit_passed": True, "mse": .1, "samples": 2}
        rows.append({"session": i, "regime": "coupled_lock", "support_seeds": [10 + i],
                     "query_seeds": [20 + i], "probe_rollout_seeds": [30 + i], "mechanism_parameters": {"x": 1},
                     "probe_bank_file": bank_path.name, "probe_bank_hash": _fingerprint(bank),
                     "probe_bank_sha256": _hash_file(bank_path), "support": cost, "query": cost,
                     "model_hash_before_support": model, "model_hash_after_support": model,
                     "model_hash_after_query": model, "query_learning_audit_passed": True,
                     "probe_before": probe, "probe_after": probe})
    for mode in modes:
        data["mode_sessions"][mode] = copy.deepcopy(rows)
        for i in range(2):
            raw.append({"mode": mode, "session": i, "episode_seed": 20 + i, "phase": "query", "query_learning_audit_passed": True,
                        "return": 1.0, "success": True, "length": 3,
                        "learning_hashes_before": hashes, "learning_hashes_after": hashes,
                        "learning_observations_before": 100, "learning_observations_after": 100})
    for mode in modes:
        for i in range(2):
            raw.append({"mode": mode, "session": i, "episode_seed": 10 + i, "phase": "support",
                        "return": 1.0, "success": True, "length": 3})
    save(root / "session_episodes.json", raw)
    save(root / "session_evaluation.json", data)
    return data


def codes(report):
    return {issue["code"] for row in report["artifacts"] for issue in row["issues"]}


def test_empty_evidence_never_means_publication_ready(tmp_path):
    result = build_evidence_report(tmp_path)
    assert result["decision"] == "requires_research_review"
    assert result["paper_claims_supported"] is False
    assert all(c["status"] == "incomplete" for c in result["claims"].values())
    assert "never certifies" in render_text(result)


def test_nonfinite_and_historical_results_are_visible_not_used(tmp_path):
    save(tmp_path / "old/summary.json", {"software_version": "0.9.0", "seed": 9, "total_steps": 100})
    save(tmp_path / "bad/summary.json", {"software_version": "10.0.0", "seed": 3, "total_steps": float("nan")})
    result = build_evidence_report(tmp_path)
    assert result["artifact_count"] == 2
    assert {"not_v10_evidence", "unreadable_or_nonfinite"}.issubset(codes(result))
    assert not result["paper_claims_supported"]


def test_one_training_seed_does_not_become_many_seeds(tmp_path):
    session(tmp_path / "run")
    result = build_evidence_report(tmp_path)
    assert result["independent_training_seed_count"] == 1
    assert result["auditable_session_run_count"] == 1
    assert result["claims"]["local_predictive_benefit"]["status"] == "incomplete"


def test_query_parameter_changes_invalidate_run(tmp_path):
    data = session(tmp_path)
    data["mode_sessions"]["full"][0]["model_hash_after_query"] = "f" * 64
    save(tmp_path / "session_evaluation.json", data)
    result = build_evidence_report(tmp_path)
    assert "query_freeze_not_verified" in codes(result)
    assert result["auditable_session_run_count"] == 0


def test_raw_optimizer_mutation_cannot_pass_summary_boolean(tmp_path):
    session(tmp_path)
    path = tmp_path / "session_episodes.json"
    raw = json.loads(path.read_text())
    raw[0]["learning_hashes_after"]["optimizer"] = "f" * 64
    save(path, raw)
    result = build_evidence_report(tmp_path)
    assert "raw_query_hash_audit_missing" in codes(result)


def test_overlapping_support_probe_data_invalidates_run(tmp_path):
    data = session(tmp_path)
    data["mode_sessions"]["full"][0]["probe_rollout_seeds"] = [10]
    save(tmp_path / "session_evaluation.json", data)
    assert "probe_independence_not_verified" in codes(build_evidence_report(tmp_path))


def test_missing_queries_not_silently_excluded(tmp_path):
    session(tmp_path)
    path = tmp_path / "session_episodes.json"
    rows = json.loads(path.read_text())
    save(path, rows[1:])
    assert "raw_query_count_mismatch" in codes(build_evidence_report(tmp_path))


def test_same_model_across_seeds_is_not_independent_replication(tmp_path):
    session(tmp_path / "a", 1)
    data = session(tmp_path / "b", 2)
    data["model_sha256"] = f"{1:064x}"
    for rows in data["mode_sessions"].values():
        for row in rows:
            row["model_hash_before_support"] = f"{1:064x}"
    save(tmp_path / "b/session_evaluation.json", data)
    assert "same_model_different_seed" in codes(build_evidence_report(tmp_path))


def test_quarantined_failure_remains_in_inventory(tmp_path):
    session(tmp_path / "incomplete_attempts/run")
    result = build_evidence_report(tmp_path)
    assert result["artifact_count"] == 1
    assert result["auditable_session_run_count"] == 0
    assert "quarantined_incomplete_attempt" in codes(result)


def test_significance_alone_cannot_prove_improvement():
    harm = {"holm_pvalue": .001, "ci95": [.01, .05], "mean_difference": .03}
    benefit = {"holm_pvalue": .01, "ci95": [-.05, -.01], "mean_difference": -.03}
    assert not _inference_supports(harm, smaller_is_better=True)
    assert _inference_supports(benefit, smaller_is_better=True)
    assert not _inference_supports({**benefit, "holm_pvalue": None}, smaller_is_better=True)
    assert not _inference_supports({**benefit, "ci95": [-.05, .01]}, smaller_is_better=True)


def test_aggregate_with_unknown_sources_cannot_claim_support(tmp_path):
    data = session(tmp_path / "run")
    aggregate = {"schema": "session_multiseed_v1", "software_version": "10.0.0", "protocol_sha256": data["protocol_sha256"],
                 "training_seeds": [1, 2], "bootstrap_unit": "training_seed_then_paired_session_within_regime"}
    save(tmp_path / "session_aggregate.json", aggregate)
    result = build_evidence_report(tmp_path)
    assert "aggregate_inputs_unverified" in codes(result)
    assert result["claims"]["local_predictive_benefit"]["status"] == "incomplete"


def test_pipeline_aggregate_filename_and_privileged_training_are_detected(tmp_path):
    data = session(tmp_path / "run")
    data["training_used_oracle_diagnosis"] = True
    save(tmp_path / "run/session_evaluation.json", data)
    save(tmp_path / "sparse_train_sessions.json", {
        "schema": "session_multiseed_v1", "software_version": "10.0.0",
        "protocol_sha256": data["protocol_sha256"], "training_seeds": [1],
    })
    result = build_evidence_report(tmp_path)
    assert result["artifact_count"] == 2
    assert "privileged_training" in codes(result)
    assert "no_between_training_inference" in codes(result)


def test_pipeline_status_marker_is_not_architecture_evidence(tmp_path):
    marker = {"completed": True, "stage": "architecture_comparison_train"}
    save(tmp_path / "stage_status/architecture_comparison_train.json", marker)
    save(tmp_path / "stage_status/architecture_comparison_heldout_v1.json", marker)
    save(tmp_path / "architecture_comparison_train.json", {
        "schema": "paired_independently_trained_architecture_comparison_v1", "software_version": "10.0.0",
    })
    result = build_evidence_report(tmp_path)
    assert result["artifact_count"] == 1
    assert "not_v10_evidence" not in codes(result)
    assert Path(result["artifacts"][0]["path"]).parent == tmp_path


def test_text_report_contains_positive_and_negative_protocol_scopes(tmp_path):
    result = build_evidence_report(tmp_path)
    result["claims"]["local_predictive_benefit"]["protocol_findings"] = [
        {"status": "supported_in_this_protocol", "scope": "Synthetic component only: linear", "reason": "Positive contrast"},
        {"status": "insufficient", "scope": "Synthetic component only: nonlinear", "reason": "Negative contrast retained"},
    ]
    text = render_text(result)
    assert "Synthetic component only: linear" in text
    assert "Synthetic component only: nonlinear" in text
    assert "Negative contrast retained" in text
