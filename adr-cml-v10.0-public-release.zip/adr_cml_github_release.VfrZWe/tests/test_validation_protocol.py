"""Checks of evidence separation and reporting, not evidence of effectiveness."""
from __future__ import annotations

import importlib.util
from pathlib import Path
import sys

import numpy as np
import pytest
import torch


_path = Path(__file__).resolve().parents[1] / "scripts" / "validate_mechanism_learning.py"
_spec = importlib.util.spec_from_file_location("mechanism_validation", _path)
validation = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = validation
_spec.loader.exec_module(validation)


def test_data_streams_are_reproducible_disjoint_and_balanced():
    first = validation.draw_data(11, 3, 64, True, 0.02)
    repeated = validation.draw_data(11, 3, 64, True, 0.02)
    acceptance = validation.draw_data(11, 4, 64, True, 0.02)
    query = validation.draw_data(11, 5, 64, True, 0.02)
    assert validation.data_digest(first) == validation.data_digest(repeated)
    assert len({validation.data_digest(x) for x in (first, acceptance, query)}) == 3
    assert np.bincount(first["action"]).tolist() == [32, 32]
    assert not set(map(tuple, first["state"])) & set(map(tuple, query["state"]))


def test_shift_changes_exactly_one_child_under_one_action():
    before = validation.draw_data(23, 3, 64, False, 0.02)
    after = validation.draw_data(23, 3, 64, True, 0.02)
    np.testing.assert_array_equal(before["state"], after["state"])
    np.testing.assert_array_equal(before["action"], after["action"])
    difference = after["next_state"] - before["next_state"]
    np.testing.assert_array_equal(difference[:, [0, 1, 3]], 0)
    np.testing.assert_array_equal(difference[before["action"] == 0], 0)
    assert np.all(difference[before["action"] == 1, 2] != 0)
    np.testing.assert_array_equal(validation.coefficients(False) != 0, validation.coefficients(True) != 0)


def test_diagnosis_can_return_empty_without_true_label_input():
    protocol = validation.Protocol()
    errors = np.full((64, 4), 0.01)
    assert validation.diagnose_children(errors, errors.copy(), protocol)["nodes"] == []
    shifted_errors = errors.copy()
    shifted_errors[:, 1] = 1.0
    decision = validation.diagnose_children(errors, shifted_errors, protocol)
    assert decision["nodes"] == [1]
    assert decision["uses_true_change_labels"] is False


def test_repair_cannot_optimize_acceptance_or_query_records():
    protocol = validation.Protocol()
    support = validation.draw_data(11, 3, 64, True, 0.02)
    acceptance = validation.draw_data(11, 4, 32, True, 0.02)
    query = validation.draw_data(11, 5, 1024, True, 0.02)
    replay = validation.build_evidence(support, acceptance, 11)
    model = validation.EnsembleWorldModel(4, 2, hidden_dim=8, ensemble_size=1)
    optimizer = torch.optim.Adam(model.parameters())
    repair = validation.LocalMechanismRepair(
        model, optimizer, "cpu", validation_fraction=1 / 3,
        min_train_samples=64, min_validation_samples=32,
        min_target_action_train=1, min_target_action_validation=1,
    )
    training, holdout, _ = repair._split_evidence(replay, np.arange(96), [0, 1])
    np.testing.assert_array_equal(training, np.arange(64))
    np.testing.assert_array_equal(holdout, np.arange(64, 96))
    np.testing.assert_array_equal(replay.states[training], support["state"])
    np.testing.assert_array_equal(replay.states[holdout], acceptance["state"])
    assert not set(map(tuple, replay.states)) & set(map(tuple, query["state"]))


def test_summary_retains_negative_seeds_and_never_claims_full_agent_proof():
    protocol = validation.Protocol()
    records = []
    for seed in protocol.seeds:
        for scenario in validation.SCENARIOS:
            records.append({
                "seed": seed, "scenario": scenario,
                "diagnosis": {"nodes": [2] if scenario == "single_child_shift" else []},
                "offline_true_changed_children": [2] if scenario == "single_child_shift" else [],
                "modes": {
                    mode: {"query_mse": 2.0 if mode == "diagnosed_local" else 1.0, "repair": {"applied": False}}
                    for mode in validation.MODES
                },
            })
    summary = validation.summarize(records, protocol)
    assert summary["primary_component_gate_passed"] is False
    assert summary["negative_control_gate_passed"] is True
    assert summary["full_agent_effectiveness_proven"] is False
    differences = summary["scenarios"]["single_child_shift"]["diagnosed_local_mse_reduction_vs_frozen"]
    assert differences["per_seed_difference"] == [-1.0] * 5
    assert differences["seed_count"] == 5


def test_refuses_to_replace_prior_validation_evidence(tmp_path):
    evidence = tmp_path / "protocol.json"
    evidence.write_text("original")
    with pytest.raises(FileExistsError, match="Refusing to overwrite"):
        validation.run_experiment(tmp_path, validation.Protocol())
    assert evidence.read_text() == "original"


def test_single_seed_does_not_report_zero_width_uncertainty():
    result = validation.paired_effect([1.0], validation.Protocol())
    assert result["paired_seed_bootstrap_ci95"] is None
