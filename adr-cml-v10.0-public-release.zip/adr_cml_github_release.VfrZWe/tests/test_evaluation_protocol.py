from adrcml.evaluate import EVALUATION_MODES, balanced_regime_schedule


def test_balanced_regime_schedule_is_deterministic_and_balanced():
    first = balanced_regime_schedule(10, ("a", "b", "c"), seed=7)
    second = balanced_regime_schedule(10, ("a", "b", "c"), seed=7)
    assert first == second
    counts = [first.count(name) for name in ("a", "b", "c")]
    assert max(counts) - min(counts) <= 1


def test_oracle_repair_is_an_explicit_evaluation_upper_bound():
    assert "oracle_repair" in EVALUATION_MODES
    assert "matched_active" in EVALUATION_MODES


def test_random_shift_schedule_is_paired_balanced_and_bounded():
    from adrcml.evaluate import evaluation_schedule

    arguments = dict(episodes=31, regimes=("a", "b", "c"), base_seed=5,
                     schedule_seed=41, protocol="random_shift", eval_shift_min=5,
                     eval_shift_max=20)
    first = evaluation_schedule(**arguments)
    second = evaluation_schedule(**arguments)
    assert first == second
    assert all(5 <= row["forced_shift_step"] <= 20 for row in first)
    assert len({row["forced_shift_step"] for row in first}) > 1
    counts = [sum(row["assigned_regime"] == name for row in first) for name in ("a", "b", "c")]
    assert max(counts) - min(counts) <= 1
    assert [row["episode_seed"] for row in first] == list(range(5, 36))


def test_no_shift_schedule_forces_none_without_exposing_change_time():
    from adrcml.evaluate import evaluation_schedule

    rows = evaluation_schedule(3, ("a", "b"), 10, 4, "no_shift")
    assert all(row["assigned_regime"] == "none" for row in rows)
    assert all(row["forced_shift_step"] is None for row in rows)


def test_active_budget_audits_combined_active_actions():
    import pytest
    from adrcml.evaluate import validate_active_budget

    assert validate_active_budget({"counterfactual_probe": 1, "designed_intervention": 2, "planner": 20}, 3) == 3
    assert validate_active_budget({"planner": 20}, 0) == 0
    with pytest.raises(RuntimeError, match="exceeds cap"):
        validate_active_budget({"counterfactual_probe": 2, "designed_intervention": 2}, 3)


def test_graph_delta_excludes_self_edges_and_counts_changed_directed_edges():
    import numpy as np
    from adrcml.evaluate import _graph_delta

    before = np.zeros((2, 3, 3))
    after = before.copy()
    after[:, 0, 0] = 1.0
    after[0, 1, 2] = 0.8
    actual = _graph_delta(before, after)
    assert actual["threshold_edge_changes"] == 1
    assert actual["max_absolute_probability_change"] == 0.8


def test_random_schedule_rejects_invalid_bounds():
    import pytest
    from adrcml.evaluate import evaluation_schedule

    with pytest.raises(ValueError, match="bounds"):
        evaluation_schedule(3, ("a",), 10, 4, "random_shift", eval_shift_min=20, eval_shift_max=5)


def test_diagnosis_by_regime_excludes_unactivated_episodes_and_labels_repair_proxy():
    import pytest
    from adrcml.evaluate import _diagnosis_metrics_by_regime

    rows = [
        {
            "assigned_regime": "fragile_bridge", "mechanism_activated": True,
            "diagnosis_f1": 0.5, "first_diagnosis_f1": 0.25,
            "consensus_diagnosis_f1": 0.75,
            "activated_affected_nodes": [0, 3, 5], "repair_attempts": 1,
            "accepted_repairs": 1,
            "repair_records": [{"applied": True, "affected_nodes": [2]},
                               {"skip_reason": "insufficient_action_samples"}],
        },
        {"assigned_regime": "fragile_bridge", "mechanism_activated": False,
         "diagnosis_f1": 0.0},
        {"assigned_regime": "none", "mechanism_activated": False},
    ]
    result = _diagnosis_metrics_by_regime(rows)
    fragile = result["fragile_bridge"]
    assert fragile["episodes"] == 2
    assert fragile["mechanism_activated_episodes"] == 1
    assert fragile["diagnosis_evaluated_episodes"] == 1
    assert fragile["diagnosis_f1"] == pytest.approx(0.5)
    assert fragile["first_diagnosis_f1"] == pytest.approx(0.25)
    assert fragile["consensus_diagnosis_f1"] == pytest.approx(0.75)
    assert fragile["repair"]["attempts"] == 1
    assert fragile["repair"]["accepted"] == 1
    assert fragile["repair"]["skip_reasons"] == {"insufficient_action_samples": 1}
    assert fragile["repair"]["accepted_repair_episode_union_proxy"]["diagnosis_f1"] == 0.0
    assert "not_event_correctness" in fragile["repair"]["proxy_interpretation"]
    assert result["none"]["diagnosis_evaluated_episodes"] == 0
    assert "diagnosis_f1" not in result["none"]


def test_no_active_disables_all_information_exploration_without_removing_shield():
    from types import SimpleNamespace
    from adrcml.config import AgentConfig
    from adrcml.envs.mechanism_maze import MechanismMazeEnv
    from adrcml.evaluate import configure_evaluation_mode

    assert "no_active" in EVALUATION_MODES
    for mode in EVALUATION_MODES:
        agent = SimpleNamespace(agent_config=AgentConfig(),
                                planner=SimpleNamespace(active_weight=.25),
                                repairer=SimpleNamespace(local=True))
        agent.agent_config.oracle_diagnosis = True
        configure_evaluation_mode(agent, mode)
        assert not agent.agent_config.oracle_diagnosis
        env = MechanismMazeEnv()
        _, info = env.reset()
        assert info["valid_action_mask"][9] and info["task_action_mask"][9]
        if mode == "no_active":
            assert agent.agent_config.active_weight == agent.planner.active_weight == 0
            assert agent.agent_config.intervention_probability == 0
            assert agent.agent_config.counterfactual_probe_probability == 0
            assert agent.agent_config.repair_enabled


def test_real_agent_planner_can_execute_shield_in_every_evaluation_mode():
    from adrcml.config import ExperimentConfig
    from adrcml.envs.mechanism_maze import MechanismMazeEnv
    from adrcml.evaluate import configure_evaluation_mode
    from adrcml.train import build_agent

    for mode in EVALUATION_MODES:
        config = ExperimentConfig(device="cpu")
        config.model.hidden_dim = 8
        config.model.ensemble_size = 1
        config.agent.random_steps = 0
        config.agent.active_warmup_steps = 0
        config.agent.exploration_epsilon_start = config.agent.exploration_epsilon_end = 0
        config.agent.intervention_probability = config.agent.counterfactual_probe_probability = 0
        env = MechanismMazeEnv(observation_noise=0, stochasticity=0)
        agent = build_agent(config, env.state_dim, env.action_dim)
        configure_evaluation_mode(agent, mode)
        observed = {}

        def plan(state, valid_mask, future_action_mask, active_multiplier):
            observed["active_multiplier"] = active_multiplier
            assert valid_mask[9] and future_action_mask[9]
            return 9

        agent.planner.plan = plan
        state, info = env.reset(options={"initial_regime": "fragile_bridge"})
        action = agent.act(state, info["valid_action_mask"], info["task_action_mask"], info["intervention_action_mask"])
        assert action == 9
        env.step(action)
        assert env.state[7] == 1
        assert agent.last_action_kind == "planned"
        if mode == "no_active":
            assert observed["active_multiplier"] == 0


def test_checkpoint_evaluation_migration_is_explicit_and_protocol_labelled():
    import pytest
    from adrcml.evaluate import evaluation_config

    old = {"software_version": "0.9.0", "config": {"environment": {}}}
    with pytest.raises(ValueError, match="allow-legacy-checkpoint"):
        evaluation_config(old)
    legacy = evaluation_config(old, allow_legacy_checkpoint=True)
    assert legacy.environment.task_action_access == "legacy_probe_only"
    migrated = evaluation_config(old, allow_legacy_checkpoint=True, task_action_access="shared_shield")
    assert migrated.environment.task_action_access == "shared_shield"
    assert old["config"]["environment"] == {}  # Never modify checkpoint config.
    current = evaluation_config({"software_version": "10.0.0", "config": {}}, environment_profile="heldout_v1")
    assert current.environment.environment_profile == "heldout_v1"
    assert current.environment.task_action_access == "shared_shield"


def test_matched_schedule_key_rejects_different_action_access_or_profile():
    from adrcml.evaluate import _paired_schedule_key
    base = {"episode_seed": 1, "assigned_regime": "fragile_bridge", "protocol": "balanced_shift",
            "forced_shift_step": 2, "environment_profile": "train", "task_action_access": "shared_shield"}
    assert _paired_schedule_key(base) != _paired_schedule_key({**base, "environment_profile": "heldout_v1"})
    assert _paired_schedule_key(base) != _paired_schedule_key({**base, "task_action_access": "legacy_probe_only"})
