import copy
import json

import numpy as np
import pytest

from adrcml.aggregate_sessions import aggregate_session_results, seed_signflip
from adrcml.evaluate_sessions import SESSION_PROTOCOL, SESSION_STATISTICAL_PLAN, _fingerprint


def fake_result(seed):
    spec = {"modes": ["full", "frozen"], "regimes": ["fragile_bridge"], "environment_profile": "heldout_v1", "statistical_plan": copy.deepcopy(SESSION_STATISTICAL_PLAN)}
    costs = {name: 0 for name in ("environment_steps", "active_actions", "online_optimizer_steps",
                                 "repair_optimizer_steps", "repair_attempts", "accepted_repairs")}
    result = {"protocol": SESSION_PROTOCOL, "software_version": "10.0.0", "protocol_spec": spec,
              "protocol_sha256": _fingerprint(spec), "sessions": 2, "training_seed": seed,
              "evaluation_seed": seed + 100, "model_sha256": f"model{seed}",
              "checkpoint_sha256": f"checkpoint{seed}", "probe_samples_per_session": 2,
              "mode_sessions": {}}
    for mode in spec["modes"]:
        rows = []
        for i in range(2):
            probe = {"samples": 2, "mse": .1 if mode == "full" else .2,
                     "changed_child_mse": .1 if mode == "full" else .2,
                     "unchanged_child_mse": .03, "readonly_audit_passed": True}
            rows.append({"session": i, "regime": "fragile_bridge", "support_seeds": [seed * 1000 + i],
                         "query_seeds": [seed * 1000 + i + 10], "environment_profile": "heldout_v1",
                         "mechanism_parameters": {"x": .8}, "probe_bank_hash": str(i),
                         "probe_bank_sha256": str(i), "probe_rollout_seeds": [seed * 1000 + i + 100],
                         "query_learning_audit_passed": True, "model_hash_before_support": f"model{seed}",
                         "model_hash_after_support": mode, "model_hash_after_query": mode,
                         "probe_before": {**probe, "mse": .2}, "probe_after": probe, "support": costs,
                         "query": {"success_rate": 1 if mode == "full" else .5,
                                   "mean_return": 1 if mode == "full" else .5}})
        result["mode_sessions"][mode] = rows
    return result


def write_results(tmp_path, values):
    paths = []
    for i, value in enumerate(values):
        path = tmp_path / f"input{i}.json"
        path.write_text(json.dumps(value))
        paths.append(path)
    return paths


def test_nested_aggregation_uses_training_seeds_and_reports_holm(tmp_path):
    inputs = write_results(tmp_path, [fake_result(11), fake_result(12)])
    out = aggregate_session_results(inputs, output=tmp_path / "out.json", bootstrap_samples=100)
    assert out["n_training_seeds"] == 2 and out["intervals_available"]
    comparison = out["comparisons"]["full_vs_frozen"]
    assert comparison["query_success"]["mean_difference"] == .5
    assert comparison["query_success"]["ci95"] == [.5, .5]
    assert comparison["query_success"]["signflip"]["pvalue"] == .5
    assert comparison["query_success"]["holm_pvalue"] == 1
    assert comparison["probe_mse"]["mean_difference"] == pytest.approx(-.1)
    assert out["holm_hypotheses"] == 25
    assert out["inference_families"]["primary_task_return"]["family_size"] == 2
    assert out["inference_families"]["primary_task_return"]["hypotheses"]["full_vs_global_repair/query_return"]["pvalue"] is None
    assert len(out["inputs"]) == 2


def test_one_training_seed_never_reports_between_seed_interval(tmp_path):
    inputs = write_results(tmp_path, [fake_result(11)])
    out = aggregate_session_results(inputs, output=tmp_path / "out.json", bootstrap_samples=10)
    assert not out["intervals_available"]
    assert out["comparisons"]["full_vs_frozen"]["query_success"]["ci95"] is None
    assert out["comparisons"]["full_vs_frozen"]["query_success"]["signflip"]["pvalue"] is None


@pytest.mark.parametrize("field", ("training_seed", "evaluation_seed", "model_sha256", "checkpoint_sha256"))
def test_aggregation_rejects_duplicate_run_lineage(tmp_path, field):
    left, right = fake_result(11), fake_result(12)
    right[field] = left[field]
    if field == "model_sha256":
        for rows in right["mode_sessions"].values():
            for row in rows:
                row["model_hash_before_support"] = left[field]
    paths = write_results(tmp_path, [left, right])
    with pytest.raises(ValueError, match="Distinct"):
        aggregate_session_results(paths, output=tmp_path / "out.json", bootstrap_samples=10)


@pytest.mark.parametrize("violation", ("profile", "query_seed", "query_mutation", "probe_overlap"))
def test_aggregation_rejects_protocol_or_audit_violations(tmp_path, violation):
    left, right = fake_result(11), fake_result(12)
    if violation == "profile":
        right["protocol_spec"]["environment_profile"] = "train"
        right["protocol_sha256"] = _fingerprint(right["protocol_spec"])
    elif violation == "query_seed":
        right["mode_sessions"]["frozen"][0]["query_seeds"] = [99]
    elif violation == "query_mutation":
        right["mode_sessions"]["frozen"][0]["model_hash_after_query"] = "corrupted"
    else:
        for rows in right["mode_sessions"].values():
            rows[0]["probe_rollout_seeds"] = [right["training_seed"] * 1000]
    paths = write_results(tmp_path, [left, right])
    with pytest.raises(ValueError):
        aggregate_session_results(paths, output=tmp_path / "out.json", bootstrap_samples=10)


def test_five_seed_exact_signflip_cannot_claim_p_less_than_point05():
    result = seed_signflip(np.ones(5))
    assert result["pvalue"] == .0625
    assert seed_signflip(np.zeros(5))["pvalue"] == 1


def test_fixed_holm_family_retains_undefined_endpoints():
    from adrcml.aggregate_sessions import _holm
    assert _holm({"measured": .03, "undefined": None}) == {"measured": .06, "undefined": None}


def test_reused_task_seeds_reject_nested_bootstrap_even_with_unique_eval_seed(tmp_path):
    left, right = fake_result(11), fake_result(12)
    for rows in right["mode_sessions"].values():
        rows[0]["query_seeds"] = left["mode_sessions"]["full"][0]["query_seeds"]
    paths = write_results(tmp_path, [left, right])
    with pytest.raises(ValueError, match="crossed"):
        aggregate_session_results(paths, output=tmp_path / "out.json", bootstrap_samples=10)


def test_train_profile_does_not_label_endpoints_confirmatory(tmp_path):
    left, right = fake_result(11), fake_result(12)
    for result in (left, right):
        result["protocol_spec"]["environment_profile"] = "train"
        result["protocol_sha256"] = _fingerprint(result["protocol_spec"])
    paths = write_results(tmp_path, [left, right])
    out = aggregate_session_results(paths, output=tmp_path / "out.json", bootstrap_samples=10)
    assert not out["inference_families"]["primary_task_return"]["is_confirmatory_profile"]
    assert not out["inference_families"]["secondary_prediction"]["is_confirmatory_profile"]
