"""Behavioral checks for the v0.8 online integration and evaluation controls."""
import copy

import numpy as np
import pytest
import torch

from adrcml.agent import ADRCMLAgent
from adrcml.config import AgentConfig, DetectorConfig, ModelConfig, PlannerConfig
from adrcml.detection import DetectionResult


def make_agent(**agent_overrides):
    options = dict(
        replay_capacity=64, learning_starts=1000, batch_size=2,
        active_warmup_steps=0, random_steps=0, repair_delay_steps=8,
        repair_max_wait_steps=32,
    )
    options.update(agent_overrides)
    return ADRCMLAgent(
        4, 5,
        ModelConfig(hidden_dim=8, ensemble_size=1, context_hidden_dim=8),
        AgentConfig(**options),
        DetectorConfig(warmup=1, max_affected_nodes=0),
        PlannerConfig(horizon=2, population=2, elites=1, iterations=1),
        seed=17,
    )


@pytest.mark.parametrize("budget", [0, 3])
def test_active_allowance_cannot_be_exceeded_by_repeated_alarm_boosts(monkeypatch, budget):
    agent = make_agent(
        intervention_probability=1.0, counterfactual_probe_probability=1.0,
        exploration_epsilon_start=1.0, exploration_epsilon_end=1.0,
        alarm_active_boost=100.0,
    )
    agent.set_active_budget(budget)
    monkeypatch.setattr(
        agent.planner, "select_intervention",
        lambda state, mask: int(np.flatnonzero(mask)[0]),
    )
    valid = np.array([True, True, False, False, False])
    tasks = np.array([True, True, True, False, False])
    interventions = np.array([False, False, False, True, True])
    seen_active = 0
    for _ in range(100):
        agent.trigger_active_boost()
        action = agent.act(np.zeros(4), valid, tasks, interventions)
        if agent.last_action_kind in {"counterfactual_probe", "designed_intervention"}:
            seen_active += 1
        else:
            assert valid[action]
        assert agent.active_actions_used <= budget
    assert seen_active == agent.active_actions_used == budget


def test_replay_context_cannot_depend_on_transition_own_outcome():
    first, second = make_agent(), make_agent()
    initial = np.zeros(4, dtype=np.float32)
    past_outcome = np.array([0.1, 0.2, 0.3, 0.4], dtype=np.float32)
    for agent in (first, second):
        agent.observe(initial, 0, 0.1, past_outcome, False, step=0)
        np.testing.assert_array_equal(agent.replay.contexts[0], 0.0)
    shared_past_context = first.history_context.vector().copy()
    first.observe(past_outcome, 1, 1.0, np.ones(4), False, step=1)
    second.observe(past_outcome, 1, -1.0, -np.ones(4), False, step=1)
    np.testing.assert_array_equal(first.replay.contexts[1], shared_past_context)
    np.testing.assert_array_equal(second.replay.contexts[1], shared_past_context)
    assert not np.array_equal(first.history_context.vector(), second.history_context.vector())
    # Later updates also must not mutate already stored context rows.
    first.observe(np.ones(4), 2, 5.0, np.full(4, 10.0), False, step=2)
    np.testing.assert_array_equal(first.replay.contexts[1], shared_past_context)


def test_episode_reset_removes_history_without_deleting_training_replay():
    agent = make_agent()
    agent.observe(np.zeros(4), 1, 0.3, np.ones(4), False, step=1)
    agent.force_repair([1], step=1, action=1)
    agent.set_active_budget(4)
    agent.active_actions_used = 3
    assert np.any(agent.history_context.vector())
    agent.on_episode_reset()
    np.testing.assert_array_equal(agent.history_context.vector(), 0.0)
    assert len(agent.replay) == 1
    assert agent.pending_repairs == {}
    assert agent.last_observed_action is None
    assert agent.active_actions_used == 0 and agent.active_budget == 4
    assert agent.alarm_active_countdown == 0
    agent.observe(np.zeros(4), 2, 1.0, np.ones(4), False, step=2)
    np.testing.assert_array_equal(agent.replay.contexts[1], 0.0)


def inject_detection_results(monkeypatch, agent, results):
    outcomes = iter(results)
    monkeypatch.setattr(agent.model, "prediction_error", lambda batch: torch.zeros(4))
    monkeypatch.setattr(agent.detector, "update", lambda *args, **kwargs: next(outcomes))
    monkeypatch.setattr(agent, "_update_model", lambda: None)


def event(nodes, scores, alarm=True):
    scores = np.asarray(scores, dtype=np.float64)
    return DetectionResult(alarm, nodes, scores, scores, float(scores.max()), scores.copy())


def test_pending_key_and_bridge_hypotheses_stay_separate(monkeypatch):
    agent = make_agent(learning_starts=0, repair_delay_steps=100, repair_max_wait_steps=1000)
    inject_detection_results(monkeypatch, agent, [
        event([1], [0.0, 10.0, 0.0, 0.0]),
        event([0, 2, 3], [9.0, 0.0, 10.0, 9.0]),
        event([], [0.0, 10.0, 0.0, 0.0], alarm=False),
    ])
    state = np.zeros(4)
    agent.observe(state, 0, 0.0, state, False, step=1)
    agent.observe(state, 1, 0.0, state, False, step=2)
    agent.observe(state, 0, 0.0, state, False, step=3)
    assert set(agent.pending_repairs) == {0, 1}
    assert agent.pending_repairs[0]["affected_nodes"] == [1]
    assert set(agent.pending_repairs[1]["affected_nodes"]) == {0, 2, 3}
    assert agent.pending_repairs[0]["target_actions"] == [0]
    assert agent.pending_repairs[1]["target_actions"] == [1]
    assert len(agent.pending_repairs[0]["localization_history"]) == 2
    assert len(agent.pending_repairs[1]["localization_history"]) == 1


def test_expired_pending_hypothesis_is_dropped_without_repair(monkeypatch):
    agent = make_agent(learning_starts=0, repair_delay_steps=1, repair_max_wait_steps=2)
    inject_detection_results(monkeypatch, agent, [
        event([1], [0.0, 10.0, 0.0, 0.0]),
        event([], [0.0, 0.0, 0.0, 0.0], alarm=False),
    ])
    def forbidden_repair(*args, **kwargs):
        raise AssertionError("Expired evidence must not be optimized")
    monkeypatch.setattr(agent.repairer, "repair", forbidden_repair)
    state = np.zeros(4)
    agent.observe(state, 0, 0.0, state, False, step=1)
    report = agent.observe(state, 1, 0.0, state, False, step=5)
    assert not agent.pending_repairs
    assert report.repair["skip_reason"] == "expired_evidence_window"


def test_checkpoint_restores_pending_hypotheses_context_and_allowance(monkeypatch):
    original = make_agent(learning_starts=0, repair_delay_steps=100)
    inject_detection_results(monkeypatch, original, [event([1], [0.0, 10.0, 0.0, 0.0])])
    original.observe(np.zeros(4), 0, 0.5, np.ones(4), False, step=1)
    original.set_active_budget(4)
    original.active_actions_used = 2
    checkpoint = copy.deepcopy(original.checkpoint())
    restored = make_agent(learning_starts=0, repair_delay_steps=100)
    restored.load_checkpoint(checkpoint)
    assert restored.pending_repairs[0]["affected_nodes"] == [1]
    assert restored.pending_repairs[0]["alarm_step"] == 1
    assert restored.active_budget == 4 and restored.active_actions_used == 2
    np.testing.assert_array_equal(restored.history_context.vector(), original.history_context.vector())
    restored.pending_repairs[0]["localization_history"][0].fill(999)
    assert checkpoint["pending_repairs"][0]["localization_history"][0][0] != 999
    restored.observe_context_only(np.ones(4), 1, -10.0, np.zeros(4))
    assert not np.array_equal(restored.history_context.vector(), original.history_context.vector())


def test_repair_waits_for_independent_consensus_even_after_delay(monkeypatch):
    agent = make_agent(
        learning_starts=0, repair_delay_steps=1, repair_retry_interval=1,
        repair_consensus_min_samples=4,
    )
    inject_detection_results(monkeypatch, agent, [
        event([1], [0.0, 10.0, 0.0, 0.0]),
        event([], [0.0, 10.0, 0.0, 0.0], alarm=False),
    ])
    def forbidden_repair(*args, **kwargs):
        raise AssertionError("Delay alone is not diagnostic consensus")
    monkeypatch.setattr(agent.repairer, "repair", forbidden_repair)
    state = np.zeros(4)
    agent.observe(state, 0, 0.0, state, False, step=1)
    report = agent.observe(state, 0, 0.0, state, False, step=4)
    assert 0 in agent.pending_repairs
    assert report.repair["skip_reason"] == "insufficient_diagnostic_consensus"
    assert report.repair["consensus_samples"] == 2


def test_normal_same_action_evidence_cancels_spurious_pending_repair(monkeypatch):
    agent = make_agent(
        learning_starts=0, repair_delay_steps=100, repair_consensus_min_samples=4,
    )
    inject_detection_results(monkeypatch, agent, [
        event([1], [0.0, 10.0, 0.0, 0.0]),
        *[event([], [0.0, 0.0, 0.0, 0.0], alarm=False) for _ in range(3)],
    ])
    state = np.zeros(4)
    for step in range(4):
        report = agent.observe(state, 0, 0.0, state, False, step=step)
    assert not agent.pending_repairs
    assert report.repair["skip_reason"] == "diagnostic_evidence_resolved"


def test_oracle_deduplicates_nodes_per_action_and_survives_resume():
    agent = make_agent()
    first = agent.force_repair([0], step=1, action=0)
    second = agent.force_repair([0], step=2, action=1)
    repeated = agent.force_repair([0], step=3, action=0)
    assert first["queued"] and second["queued"]
    assert not repeated["queued"]
    assert set(agent.pending_repairs) == {0, 1}
    restored = make_agent()
    restored.load_checkpoint(copy.deepcopy(agent.checkpoint()))
    assert not restored.force_repair([0], step=4, action=0)["queued"]
    assert restored.force_repair([2], step=4, action=0)["queued"]
    assert restored.pending_repairs[0]["affected_nodes"] == [0, 2]


def test_failed_oracle_request_does_not_consume_valid_future_event():
    agent = make_agent()
    with pytest.raises(ValueError):
        agent.force_repair([0], step=1)
    assert not agent.pending_repairs
    assert agent.force_repair([0], step=2, action=0)["queued"]
