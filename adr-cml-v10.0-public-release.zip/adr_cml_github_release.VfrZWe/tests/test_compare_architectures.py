import copy
import json

import numpy as np
import pytest

from adrcml.aggregate_sessions import COSTS
from adrcml.compare_architectures import compare_architectures, _normalized_config
from adrcml.config import ExperimentConfig
from adrcml.evaluate_sessions import SESSION_MODES, SESSION_PROTOCOL, SESSION_STATISTICAL_PLAN, _fingerprint, _sha256_file
from adrcml.provenance import config_hash


def make_pipeline(root, seeds=(11, 12), profile="heldout_v1", manifest=False):
    records = {}
    planned = {}
    for seed in seeds:
        for arch in ("sparse", "dense"):
            directory = root / f"seed_{seed}" / arch / "sessions" / profile
            directory.mkdir(parents=True)
            config = ExperimentConfig().to_dict()
            config["seed"] = seed
            config["model"]["dense_graph"] = arch == "dense"
            if arch == "dense":
                for key in ("sparsity_weight", "parent_budget_weight", "action_gate_regularization", "edge_entropy_weight"):
                    config["model"][key] = 0.0
            config["agent"]["total_steps"] = 100
            planned[f"seed_{seed}/{arch}"] = config
            spec = {"training_config": _normalized_config(config), "training_steps": 100,
                    "modes": list(SESSION_MODES), "regimes": ["fragile_bridge"], "environment_profile": profile,
                    "statistical_plan": copy.deepcopy(SESSION_STATISTICAL_PLAN),
                    "training_source_hash": "source", "evaluation_source_hash": "source"}
            result = {"protocol": SESSION_PROTOCOL, "software_version": "10.0.0", "protocol_spec": spec,
                      "protocol_sha256": _fingerprint(spec), "training_config": config,
                      "training_config_hash": config_hash(config), "training_steps": 100,
                      "training_source_hash": "source", "evaluation_source_hash": "source",
                      "sessions": 2, "training_seed": seed, "evaluation_seed": seed + 100,
                      "environment_profile": profile, "model_sha256": f"model{seed}{arch}",
                      "checkpoint_sha256": f"checkpoint{seed}{arch}", "probe_samples_per_session": 2,
                      "support_episodes_per_session": 1, "query_episodes_per_session": 1,
                      "active_budget_per_task": 3, "mode_sessions": {}}
            for mode in SESSION_MODES:
                rows = []
                for i in range(2):
                    bank = {"action": np.array([0, 1]), "rollout_seed": np.array([seed * 1000 + i + 100] * 2)}
                    name = f"probe_bank_session_{i:04d}.npz"
                    np.savez_compressed(directory / name, **bank)
                    probe = {"samples": 2, "mse": .1 if arch == "sparse" else .2,
                             "changed_child_mse": .1, "unchanged_child_mse": .03, "readonly_audit_passed": True}
                    costs = {name: 0 for name in COSTS}
                    costs["environment_steps"] = 10 if arch == "sparse" else 15
                    rows.append({"session": i, "regime": "fragile_bridge", "support_seeds": [seed * 1000 + i],
                                 "query_seeds": [seed * 1000 + i + 10], "environment_profile": profile,
                                 "mechanism_parameters": {"x": .8}, "probe_bank_file": name,
                                 "probe_bank_hash": _fingerprint(bank), "probe_bank_sha256": _sha256_file(directory / name),
                                 "probe_rollout_seeds": [seed * 1000 + i + 100],
                                 "query_learning_audit_passed": True, "model_hash_before_support": result["model_sha256"],
                                 "model_hash_after_support": mode, "model_hash_after_query": mode,
                                 "probe_before": dict(probe), "probe_after": dict(probe), "support": costs,
                                 "query": {"success_rate": 1.0, "mean_return": 1.0 if arch == "sparse" else .5}})
                result["mode_sessions"][mode] = rows
            path = directory / "session_evaluation.json"
            path.write_text(json.dumps(result))
            records[(seed, arch)] = (path, result)
    if manifest:
        (root / "protocol_manifest.json").write_text(json.dumps({
            "training_seeds": list(seeds), "architectures": ["sparse", "dense"], "environment_profiles": [profile],
            "resolved_training_configs": planned, "training_steps_per_architecture": 100, "sessions": 2,
            "support_episodes": 1, "query_episodes": 1, "probe_samples": 2, "active_budget": 3,
        }))
    return records


def test_paired_architectures_report_seed_effects_and_costs(tmp_path):
    make_pipeline(tmp_path, manifest=True)
    result = compare_architectures(tmp_path, profile="heldout_v1", output=tmp_path / "out.json", bootstrap_samples=50)
    assert result["manifest_audit"] == "verified"
    assert result["n_training_seeds"] == 2 and result["intervals_available"]
    entry = result["comparisons"]["sparse_full_vs_dense_full"]["query_return"]
    assert entry["mean_difference"] == .5 and entry["ci95"] == [.5, .5]
    assert entry["signflip"]["p_value"] == .5 and entry["holm_pvalue"] == 1
    assert result["comparisons"]["sparse_full_vs_dense_online_only"]["probe_mse"]["mean_difference"] == pytest.approx(-.1)
    assert result["statistical_plan"]["family_size"] == 4
    assert result["support_costs"]["dense"]["full"]["environment_steps"]["per_training_seed"] == [30, 30]
    assert "not_external_published_baseline" in result["baseline_interpretation"]


def test_single_seed_architecture_effect_has_null_inference(tmp_path):
    make_pipeline(tmp_path, seeds=(11,), profile="train")
    result = compare_architectures(tmp_path, profile="train", output=tmp_path / "out.json", bootstrap_samples=10)
    assert not result["is_confirmatory_profile"] and not result["intervals_available"]
    entry = result["comparisons"]["sparse_full_vs_dense_full"]["query_return"]
    assert entry["ci95"] is None and entry["signflip"]["p_value"] is None and entry["holm_pvalue"] is None


@pytest.mark.parametrize("violation", ["missing_arch", "missing_mode", "unpaired_parameter", "duplicate_model", "config_drift", "bank_corruption", "query_mutation"])
def test_architecture_comparison_rejects_uncontrolled_inputs(tmp_path, violation):
    records = make_pipeline(tmp_path)
    path, result = records[(12, "dense")]
    if violation == "missing_arch":
        path.unlink()
    elif violation == "missing_mode":
        del result["mode_sessions"]["frozen"]
    elif violation == "unpaired_parameter":
        for rows in result["mode_sessions"].values():
            rows[0]["mechanism_parameters"] = {"x": .9}
    elif violation == "duplicate_model":
        result["model_sha256"] = records[(12, "sparse")][1]["model_sha256"]
        for rows in result["mode_sessions"].values():
            for row in rows:
                row["model_hash_before_support"] = result["model_sha256"]
    elif violation == "config_drift":
        result["training_config"]["agent"]["batch_size"] += 1
        result["training_config_hash"] = config_hash(result["training_config"])
        result["protocol_spec"]["training_config"] = _normalized_config(result["training_config"])
        result["protocol_sha256"] = _fingerprint(result["protocol_spec"])
    elif violation == "bank_corruption":
        (path.parent / result["mode_sessions"]["full"][0]["probe_bank_file"]).write_bytes(b"broken")
    else:
        result["mode_sessions"]["full"][0]["model_hash_after_query"] = "mutated"
    if violation != "missing_arch":
        path.write_text(json.dumps(result))
    with pytest.raises((ValueError, FileNotFoundError)):
        compare_architectures(tmp_path, profile="heldout_v1", output=tmp_path / "out.json", bootstrap_samples=10)


def test_manifest_prevents_silently_dropping_unfavorable_training_seed(tmp_path):
    make_pipeline(tmp_path, seeds=(11,), manifest=True)
    path = tmp_path / "protocol_manifest.json"
    plan = json.loads(path.read_text())
    plan["training_seeds"].append(12)
    path.write_text(json.dumps(plan))
    with pytest.raises(ValueError, match="Missing or extra"):
        compare_architectures(tmp_path, profile="heldout_v1", output=tmp_path / "out.json", bootstrap_samples=10)
