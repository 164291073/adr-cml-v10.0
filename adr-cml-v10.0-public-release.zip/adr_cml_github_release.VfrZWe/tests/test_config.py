from adrcml.config import ExperimentConfig, _construct


def test_new_config_defaults_to_hard_concrete_but_legacy_checkpoint_does_not():
    assert ExperimentConfig().model.hard_concrete_gates
    legacy = _construct(
        {"model": {"hidden_dim": 16}},
        legacy_missing_hard_concrete=True,
    )
    assert not legacy.model.hard_concrete_gates
    current = _construct(
        {"model": {"hidden_dim": 16, "hard_concrete_gates": True}}
    )
    assert current.model.hard_concrete_gates
