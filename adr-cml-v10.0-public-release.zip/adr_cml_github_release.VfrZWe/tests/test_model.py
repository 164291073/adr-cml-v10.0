import pytest

torch = pytest.importorskip("torch")

from adrcml.buffer import TransitionBatch
from adrcml.models import EnsembleWorldModel


def test_model_shapes_and_backward():
    model = EnsembleWorldModel(8, 10, hidden_dim=16, ensemble_size=2)
    batch_size = 4
    batch = TransitionBatch(
        state=torch.rand(batch_size, 8),
        action=torch.randint(0, 10, (batch_size,)),
        reward=torch.rand(batch_size),
        next_state=torch.rand(batch_size, 8),
        done=torch.zeros(batch_size),
        valid_action_mask=torch.ones(batch_size, 10),
        valid_mask_known=torch.ones(batch_size, dtype=torch.bool),
    )
    loss, parts = model.loss(batch)
    loss.backward()
    assert loss.ndim == 0
    assert model.adjacency().shape == (8, 8)
    assert model.adjacency_by_action().shape == (10, 8, 8)
    assert "state_loss" in parts
    edge_gradients = [member.edge_logits.grad for member in model.members]
    assert all(gradient is not None for gradient in edge_gradients)
    assert any(torch.count_nonzero(gradient).item() > 0 for gradient in edge_gradients)
    action_edge_gradients = [member.action_edge_logits.grad for member in model.members]
    assert all(gradient is not None for gradient in action_edge_gradients)
    assert "feasibility_loss" in parts
    assert "parent_budget_loss" in parts
    assert "mean_parent_count" in parts


def test_hard_concrete_produces_exact_zero_off_diagonal_gates():
    model = EnsembleWorldModel(
        4,
        2,
        hidden_dim=8,
        ensemble_size=1,
        edge_init_logit=-10.0,
        hard_concrete_gates=True,
    )
    adjacency = model.adjacency()
    off_diagonal = ~torch.eye(4, dtype=torch.bool)
    assert torch.count_nonzero(adjacency[off_diagonal]).item() == 0
    assert torch.allclose(torch.diag(adjacency), torch.ones(4))


@pytest.mark.parametrize("transition_change_weight", [0.0, 2.0])
def test_mean_loss_masks_other_nodes_and_matches_reported_metric(transition_change_weight):
    torch.manual_seed(123)
    model = EnsembleWorldModel(3, 2, hidden_dim=8, ensemble_size=1).eval()
    member = model.members[0]
    batch = TransitionBatch(
        state=torch.rand(5, 3), action=torch.tensor([0, 1, 0, 1, 0]),
        reward=torch.zeros(5), next_state=torch.rand(5, 3), done=torch.zeros(5),
    )
    output = member(batch.state, batch.action, sample_edges=False)
    expected = (output.next_mean[:, 1] - batch.next_state[:, 1]).pow(2)
    change = (batch.next_state[:, 1] - batch.state[:, 1]).abs().clamp(0.0, 1.0)
    expected = (expected * (1.0 + transition_change_weight * change)).mean()
    kwargs = dict(
        state_loss_weight=0.0, state_mse_loss_weight=1.0,
        reward_loss_weight=0.0, done_loss_weight=0.0,
        feasibility_loss_weight=0.0, sparsity_weight=0.0,
        parent_budget_weight=0.0, action_gate_regularization=0.0,
        edge_entropy_weight=0.0, transition_change_weight=transition_change_weight,
        node_mask=torch.tensor([0.0, 1.0, 0.0]),
    )
    loss, parts = model.loss(batch, **kwargs)
    torch.testing.assert_close(loss, expected)
    torch.testing.assert_close(parts["state_mse_loss"], expected.detach())
    batch.next_state[:, [0, 2]] += 10.0
    changed_loss, changed_parts = model.loss(batch, **kwargs)
    torch.testing.assert_close(loss, changed_loss)
    torch.testing.assert_close(parts["state_mse_loss"], changed_parts["state_mse_loss"])
    loss.backward()
    for child in (0, 2):
        for parameter in member.node_heads[child].parameters():
            assert parameter.grad is None or torch.count_nonzero(parameter.grad) == 0
    assert any(torch.count_nonzero(p.grad) > 0 for p in member.node_heads[1].parameters())
