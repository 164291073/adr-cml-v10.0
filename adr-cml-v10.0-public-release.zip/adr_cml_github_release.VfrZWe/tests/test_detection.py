import numpy as np
import pytest

from adrcml.detection import NodewiseCUSUMDetector


def test_detector_localizes_changed_node():
    detector = NodewiseCUSUMDetector(
        n_nodes=4,
        warmup=8,
        ema_rate=0.01,
        drift=0.1,
        threshold=3.0,
        decay=1.0,
        cooldown=2,
        confirmation_steps=1,
    )
    for _ in range(8):
        result = detector.update(np.full(4, 0.1))
        assert not result.alarm
    result = detector.update(np.array([0.1, 0.1, 20.0, 0.1]))
    assert result.alarm
    assert result.affected_nodes == [2]


def test_detector_rejects_wrong_dimension():
    detector = NodewiseCUSUMDetector(3)
    try:
        detector.update(np.zeros(2))
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError")


def test_episode_boundary_clears_only_transient_evidence():
    detector = NodewiseCUSUMDetector(2, warmup=1, drift=0.0, threshold=100.0)
    detector.update(np.array([0.1, 0.1]))
    detector.update(np.array([5.0, 0.1]))
    count = detector.count
    mean = detector.mean.copy()
    detector.start_episode()
    assert detector.count == count
    assert np.allclose(detector.mean, mean)
    assert np.all(detector.cusum == 0.0)


def test_localization_keeps_only_dominant_nodes():
    detector = NodewiseCUSUMDetector(
        4,
        warmup=1,
        drift=0.0,
        threshold=1.0,
        decay=1.0,
        localization_ratio=0.8,
        max_affected_nodes=2,
        confirmation_steps=1,
    )
    detector.update(np.zeros(4))
    result = detector.update(np.array([2.0, 10.0, 9.0, 1.1]))
    assert result.alarm
    assert result.affected_nodes == [1, 2]


def test_windowed_detector_confirms_sustained_change_and_keeps_baseline():
    detector = NodewiseCUSUMDetector(
        3,
        warmup=4,
        ema_rate=0.1,
        drift=0.1,
        threshold=2.0,
        decay=1.0,
        cooldown=1,
        localization_ratio=0.5,
        localization_window=4,
        confirmation_steps=2,
        baseline_guard_z=2.0,
    )
    for _ in range(4):
        detector.update(np.full(3, 0.1))
    baseline = detector.mean.copy()
    first = detector.update(np.array([0.1, 8.0, 7.0]))
    second = detector.update(np.array([0.1, 8.0, 7.0]))
    assert not first.alarm
    assert second.alarm
    assert second.affected_nodes == [1, 2]
    assert np.allclose(detector.mean[1:], baseline[1:])


def test_detector_loads_v04_state_without_window_fields():
    detector = NodewiseCUSUMDetector(2)
    detector.load_state_dict(
        {
            "count": 10,
            "mean": np.zeros(2),
            "var": np.ones(2),
            "cusum": np.zeros(2),
            "cooldown_left": 0,
        }
    )
    assert detector.confirmation_count == 0
    assert len(detector.recent_positive_z) == 0


def test_robust_reference_rejects_outlier_contamination():
    detector = NodewiseCUSUMDetector(
        2,
        warmup=4,
        robust_window=16,
        robust_min_samples=4,
        robust_scale_floor=0.05,
        baseline_guard_z=3.0,
        drift=0.0,
        threshold=1.0,
        confirmation_steps=1,
    )
    for value in (0.10, 0.11, 0.09, 0.10):
        detector.update(np.array([value, value]))
    baseline_size = len(detector.robust_history)
    result = detector.update(np.array([10.0, 0.1]))
    assert result.alarm
    assert result.affected_nodes == [0]
    assert len(detector.robust_history) == baseline_size


def test_robust_reference_round_trips_in_checkpoint():
    detector = NodewiseCUSUMDetector(2, warmup=2, robust_min_samples=2)
    detector.update(np.array([0.1, 0.2]))
    detector.update(np.array([0.2, 0.3]))
    restored = NodewiseCUSUMDetector(2, warmup=2, robust_min_samples=2)
    restored.load_state_dict(detector.state_dict())
    assert len(restored.robust_history) == 2
    assert np.allclose(restored.robust_history[1], [0.2, 0.3])


def test_action_conditioned_reference_does_not_confuse_action_scale():
    detector = NodewiseCUSUMDetector(
        1,
        n_actions=2,
        warmup=2,
        action_min_samples=2,
        robust_min_samples=8,
        drift=0.0,
        threshold=2.0,
        confirmation_steps=1,
    )
    detector.update(np.array([0.1]), action=0)
    detector.update(np.array([0.1]), action=0)
    detector.update(np.array([10.0]), action=1)
    result = detector.update(np.array([10.0]), action=1)
    assert not result.alarm
    result = detector.update(np.array([10.0]), action=0)
    assert result.alarm


def test_ineligible_probe_does_not_contaminate_detector_reference():
    detector = NodewiseCUSUMDetector(2, n_actions=3, warmup=1)
    detector.update(np.array([0.1, 0.1]), action=0)
    count = detector.count
    result = detector.update(np.array([100.0, 100.0]), action=2, eligible=False)
    assert not result.alarm
    assert detector.count == count


def test_normal_evidence_erases_cusum_without_decay():
    detector = NodewiseCUSUMDetector(
        1, warmup=1, drift=0.5, threshold=100.0, decay=1.0
    )
    detector.update(np.zeros(1))
    detector.update(np.array([2.0]))
    evidence = detector.cusum.copy()
    assert evidence[0] > 0.0
    detector.update(np.zeros(1))
    assert detector.cusum[0] < evidence[0]
    for _ in range(10):
        detector.update(np.zeros(1))
    assert detector.cusum[0] == 0.0


def test_new_nodes_can_alarm_during_another_nodes_cooldown():
    detector = NodewiseCUSUMDetector(
        3, warmup=1, threshold=3.0, cooldown=20, confirmation_steps=1,
        max_affected_nodes=0, drift=0.1,
    )
    detector.update(np.zeros(3))
    first = detector.update(np.array([9.0, 0.0, 0.0]))
    assert first.alarm and first.affected_nodes == [0]
    assert detector.node_cooldown_left[0] == 20
    second = detector.update(np.array([0.0, 9.0, 9.0]))
    assert second.alarm and set(second.affected_nodes) == {1, 2}
    assert detector.node_cooldown_left[0] == 19


def test_zero_cardinality_cap_can_select_three_changed_nodes():
    detector = NodewiseCUSUMDetector(4, max_affected_nodes=0, localization_ratio=0.8)
    assert detector.select_affected(np.array([10.0, 9.0, 8.0, 0.1])) == [0, 1, 2]


def test_localization_does_not_use_stale_cumulative_evidence():
    detector = NodewiseCUSUMDetector(
        3, warmup=1, threshold=3.0, confirmation_steps=1,
        max_affected_nodes=0, localization_ratio=0.8,
    )
    detector.update(np.zeros(3))
    detector.cusum[0] = 100.0
    result = detector.update(np.array([0.0, 9.0, 9.0]))
    assert result.alarm
    assert set(result.affected_nodes) == {1, 2}
    assert result.localization_scores[0] == 0.0


def _checkpoint_arrays(state):
    arrays = [value for value in state.values() if isinstance(value, np.ndarray)]
    arrays += list(state["recent_positive_z"])
    arrays += list(state["robust_history"])
    arrays += [item for history in state["action_robust_history"] for item in history]
    return arrays


def test_detector_state_is_detached_on_export_and_import():
    detector = NodewiseCUSUMDetector(2, n_actions=2, warmup=2, action_min_samples=2)
    detector.update(np.array([0.1, 0.2]), action=0)
    detector.update(np.array([0.2, 0.3]), action=0)
    detector.update(np.array([0.3, 0.4]), action=0)
    saved = detector.state_dict()
    snapshots = [array.copy() for array in _checkpoint_arrays(saved)]
    restored = NodewiseCUSUMDetector(2, n_actions=2, warmup=2, action_min_samples=2)
    restored.load_state_dict(saved)
    for name in (
        "mean", "var", "cusum", "node_cooldown_left", "node_confirmation_count",
        "action_counts", "action_mean", "action_var",
        "pair_armed", "pair_normal_count", "pair_cooldown_left",
    ):
        assert not np.shares_memory(saved[name], getattr(detector, name))
        assert not np.shares_memory(saved[name], getattr(restored, name))
        getattr(detector, name).fill(123)
        getattr(restored, name).fill(456)
    for model in (detector, restored):
        for value in model.recent_positive_z:
            value.fill(789)
        for value in model.robust_history:
            value.fill(789)
        for history in model.action_robust_history:
            for value in history:
                value.fill(789)
    for expected, actual in zip(snapshots, _checkpoint_arrays(saved)):
        np.testing.assert_array_equal(actual, expected)


def test_ineligible_probe_preserves_all_transient_state():
    detector = NodewiseCUSUMDetector(
        2, n_actions=2, warmup=1, action_min_samples=1,
        threshold=2.0, confirmation_steps=1,
    )
    detector.update(np.zeros(2), action=0)
    detector.update(np.array([10.0, 0.0]), action=0)
    before = detector.state_dict()
    detector.update(np.array([100.0, 100.0]), action=1, eligible=False)
    after = detector.state_dict()
    assert after["count"] == before["count"]
    assert after["cooldown_left"] == before["cooldown_left"]
    for expected, actual in zip(_checkpoint_arrays(before), _checkpoint_arrays(after)):
        np.testing.assert_array_equal(actual, expected)


@pytest.mark.parametrize("kwargs", [
    {"n_nodes": 0}, {"warmup": -1}, {"cooldown": -1},
    {"max_affected_nodes": -1}, {"threshold": 0.0},
    {"score_clip": float("nan")}, {"localization_ratio": 1.1},
    {"confirmation_steps": 0}, {"robust_min_samples": 300},
    {"rearm_steps": -1}, {"rearm_z_threshold": float("nan")},
    {"rearm_z_threshold": 0.5, "drift": 0.4},
])
def test_invalid_detector_configuration_is_rejected(kwargs):
    with pytest.raises(ValueError):
        NodewiseCUSUMDetector(**({"n_nodes": 2} | kwargs))


def _ready_rearm_detector(**kwargs):
    detector = NodewiseCUSUMDetector(**({
        "n_nodes": 2, "n_actions": 2, "warmup": 4,
        "action_min_samples": 2, "robust_min_samples": 2,
        "threshold": 2.0, "confirmation_steps": 1, "drift": 0.1,
        "cooldown": 1, "rearm_steps": 3,
    } | kwargs))
    for action in (0, 0, 1, 1):
        detector.update(np.zeros(2), action=action)
    return detector


def test_persistent_same_pair_anomaly_emits_one_alarm():
    detector = _ready_rearm_detector()
    alarms = [
        detector.update(np.array([10.0, 0.0]), action=0).alarm
        for _ in range(30)
    ]
    assert sum(alarms) == 1
    assert not detector.pair_armed[0, 0]
    assert detector.pair_armed[0, 1]


def test_other_action_same_node_can_alarm_during_pair_cooldown():
    detector = _ready_rearm_detector(cooldown=20)
    first = detector.update(np.array([10.0, 0.0]), action=0)
    second = detector.update(np.array([10.0, 0.0]), action=1)
    assert first.alarm and first.affected_nodes == [0]
    assert second.alarm and second.affected_nodes == [0]
    assert detector.pair_cooldown_left[0, 0] == 19
    assert detector.pair_cooldown_left[1, 0] == 20


def test_sustained_normal_same_action_rearms_new_change():
    detector = _ready_rearm_detector()
    assert detector.update(np.array([10.0, 0.0]), action=0).alarm
    detector.update(np.zeros(2), action=0)
    detector.update(np.zeros(2), action=0)
    assert not detector.pair_armed[0, 0]
    assert detector.pair_normal_count[0, 0] == 2
    detector.update(np.zeros(2), action=0)
    assert detector.pair_armed[0, 0]
    assert detector.update(np.array([10.0, 0.0]), action=0).alarm


def test_anomalous_evidence_resets_normal_recovery_streak():
    detector = _ready_rearm_detector()
    detector.update(np.array([10.0, 0.0]), action=0)
    for _ in range(2):
        detector.update(np.zeros(2), action=0)
    detector.update(np.array([10.0, 0.0]), action=0)
    assert detector.pair_normal_count[0, 0] == 0
    for _ in range(2):
        detector.update(np.zeros(2), action=0)
    assert not detector.pair_armed[0, 0]


def test_other_action_or_ineligible_samples_cannot_rearm_pair():
    detector = _ready_rearm_detector()
    detector.update(np.array([10.0, 0.0]), action=0)
    for _ in range(10):
        detector.update(np.zeros(2), action=1)
        detector.update(np.zeros(2), action=0, eligible=False)
    assert not detector.pair_armed[0, 0]
    assert detector.pair_normal_count[0, 0] == 0
    assert not detector.update(np.array([10.0, 0.0]), action=0).alarm


def test_pair_recovery_state_resumes_at_same_observation():
    detector = _ready_rearm_detector()
    detector.update(np.array([10.0, 0.0]), action=0)
    detector.update(np.zeros(2), action=0)
    restored = _ready_rearm_detector()
    restored.load_state_dict(detector.state_dict())
    for errors in (np.zeros(2), np.zeros(2), np.array([10.0, 0.0])):
        original_result = detector.update(errors, action=0)
        restored_result = restored.update(errors, action=0)
        assert original_result.alarm == restored_result.alarm
        assert original_result.affected_nodes == restored_result.affected_nodes
        np.testing.assert_array_equal(detector.pair_armed, restored.pair_armed)
        np.testing.assert_array_equal(
            detector.pair_normal_count, restored.pair_normal_count
        )
    assert original_result.alarm


@pytest.mark.parametrize("reset_method", ["start_episode", "reset"])
def test_episode_or_full_reset_clears_pair_latches(reset_method):
    detector = _ready_rearm_detector(cooldown=20)
    detector.update(np.array([10.0, 0.0]), action=0)
    assert not detector.pair_armed.all()
    getattr(detector, reset_method)()
    assert detector.pair_armed.all()
    assert not detector.pair_normal_count.any()
    assert not detector.pair_cooldown_left.any()


def test_rearm_ablation_zero_restores_repeated_cooldown_alarms():
    detector = _ready_rearm_detector(rearm_steps=0)
    alarms = [
        detector.update(np.array([10.0, 0.0]), action=0).alarm
        for _ in range(8)
    ]
    assert sum(alarms) > 1


def test_warmup_does_not_latch_or_count_recovery():
    detector = NodewiseCUSUMDetector(
        2, n_actions=2, warmup=8, action_min_samples=2,
        threshold=1.0, confirmation_steps=1, rearm_steps=3,
    )
    for index in range(8):
        result = detector.update(np.array([100.0 * index, 0.0]), action=0)
        assert not result.alarm
        assert detector.pair_armed.all()
        assert not detector.pair_normal_count.any()


def test_unknown_action_uses_separate_recovery_slot():
    detector = _ready_rearm_detector(action_conditioned_baseline=False)
    assert detector.update(np.array([10.0, 0.0]), action=None).alarm
    assert not detector.update(np.array([10.0, 0.0]), action=None).alarm
    assert detector.update(np.array([10.0, 0.0]), action=0).alarm
