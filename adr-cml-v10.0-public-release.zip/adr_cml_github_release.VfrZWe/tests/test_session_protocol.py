"""Support/query tests audit boundaries, not whether an algorithm wins."""
import copy

import numpy as np
import pytest
import torch

from adrcml.config import ExperimentConfig
from adrcml.envs import MechanismMazeEnv
from adrcml.evaluate_sessions import (
    _run_task,
    evaluate_sessions,
    paired_session_comparison,
    session_schedule,
)
from adrcml.train import build_agent


def tiny_config():
    config = ExperimentConfig()
    config.device = "cpu"
    config.environment.max_steps = 4
    config.environment.shift_step = 1
    config.environment.shift_step_min = None
    config.environment.shift_step_max = None
    config.environment.observation_noise = 0.0
    config.environment.stochasticity = 0.0
    config.model.hidden_dim = 8
    config.model.ensemble_size = 1
    config.model.context_hidden_dim = 4
    config.agent.replay_capacity = 64
    config.agent.learning_starts = 2
    config.agent.batch_size = 2
    config.agent.random_steps = 1000
    config.agent.active_warmup_steps = 1000
    config.detector.warmup = 1000
    config.planner.horizon = 2
    config.planner.population = 2
    config.planner.elites = 1
    config.planner.iterations = 1
    return config


def test_session_schedule_is_balanced_paired_and_has_no_support_query_overlap():
    first = session_schedule(7, 8, 4, ("a", "b", "c"), 123)
    assert first == session_schedule(7, 8, 4, ("a", "b", "c"), 123)
    seeds = [seed for row in first for name in ("support_seeds", "query_seeds") for seed in row[name]]
    assert len(seeds) == len(set(seeds)) == 84
    assert max(sum(r["regime"] == name for r in first) for name in ("a", "b", "c")) == 3
    with pytest.raises(ValueError):
        session_schedule(1, 0, 4, ("a",), 123)


@pytest.mark.parametrize("regime", ("base", *MechanismMazeEnv.shift_modes))
def test_fixed_regime_is_applied_before_first_action_and_never_shifts(regime):
    env = MechanismMazeEnv(max_steps=4, shift_step=1, observation_noise=0, stochasticity=0)
    observation, info = env.reset(seed=7, options={"initial_regime": regime})
    np.testing.assert_array_equal(observation, np.array([0.45, 0, 0, 0, 0, 0, 0, 0], dtype=np.float32))
    assert observation.shape == (8,)
    assert info["regime"] == regime
    initial_graph = info["true_adjacency"].copy()
    for _ in range(4):
        _, _, _, _, info = env.step(1)
        assert info["regime"] == regime and not info["shift_event"]
        np.testing.assert_array_equal(info["true_adjacency"], initial_graph)


def test_fixed_regime_rejects_conflicting_shift_assignment():
    env = MechanismMazeEnv()
    with pytest.raises(ValueError, match="cannot be combined"):
        env.reset(options={"initial_regime": "fragile_bridge", "shift_step": 2})
    with pytest.raises(ValueError, match="Unknown initial"):
        env.reset(options={"initial_regime": "imaginary"})


def test_session_comparison_resamples_session_not_individual_query_tasks():
    def row(i, regime, value):
        return {"session": i, "regime": regime, "query_seeds": [i * 10, i * 10 + 1],
                "query": {"success_rate": value, "mean_return": 2 * value}}
    left = [row(1, "a", 1.0), row(2, "a", 0.5)]
    right = [row(1, "a", 0.0), row(2, "a", 0.5)]
    result = paired_session_comparison(left, right, bootstrap_samples=100)
    assert result["sessions"] == 2
    assert result["success_rate_difference"] == 0.5
    assert result["mean_return_difference"] == 1.0
    assert result["success_rate_ci95"] is not None
    one = paired_session_comparison(left[:1], right[:1], bootstrap_samples=100)
    assert one["success_rate_ci95"] is None
    assert "at_least_two" in one["interval_unavailable_reason"]
    wrong = copy.deepcopy(right)
    wrong[0]["query_seeds"] = [99]
    with pytest.raises(ValueError, match="not paired"):
        paired_session_comparison(left, wrong)


def test_frozen_query_audit_rejects_accidental_replay_write(monkeypatch):
    config = tiny_config()
    agent = build_agent(config, 8, 10)
    env = MechanismMazeEnv(max_steps=4, shift_step=1, observation_noise=0, stochasticity=0)
    original = agent.observe_context_only
    def corrupt(state, action, reward, next_state):
        original(state, action, reward, next_state)
        agent.replay.add(state, action, reward, next_state, False)
    monkeypatch.setattr(agent, "observe_context_only", corrupt)
    with pytest.raises(RuntimeError, match="Frozen task modified"):
        _run_task(agent, env, seed=10, regime="fragile_bridge", phase="query", adapt=False,
                  keep_adaptation_state=False, active_budget=0, step=0)


def test_sessions_keep_support_evidence_and_freeze_disjoint_query(tmp_path, monkeypatch):
    import adrcml.evaluate_sessions as module
    config = tiny_config()
    agent = build_agent(config, 8, 10)
    checkpoint = copy.deepcopy(agent.checkpoint())
    checkpoint.update(config=config.to_dict(), software_version="10.0.0", step=100)
    path = tmp_path / "checkpoint.pt"
    torch.save(checkpoint, path)
    constructed = []
    def tracked_builder(*args):
        built = build_agent(*args)
        original_observe = built.observe
        original_reset = built.on_episode_reset
        built.test_support_steps = []
        built.test_reset_flags = []
        def observe(*args, **kwargs):
            built.test_support_steps.append(kwargs["step"])
            return original_observe(*args, **kwargs)
        def reset(*args, **kwargs):
            built.test_reset_flags.append(kwargs.get("keep_adaptation_state", False))
            return original_reset(*args, **kwargs)
        built.observe = observe
        built.on_episode_reset = reset
        constructed.append(built)
        return built
    monkeypatch.setattr(module, "build_agent", tracked_builder)
    output = evaluate_sessions(str(path), output_dir=str(tmp_path / "results"),
                               sessions=1, support_episodes=2, query_episodes=2,
                               active_budget=0, modes=("full", "global_repair", "diagnose_no_repair", "frozen"),
                               regimes=("fragile_bridge",), bootstrap_samples=10, probe_samples=16)
    assert len(constructed) == 5  # independent baseline plus each mode
    baseline, full, global_repair, diagnose, frozen = constructed
    assert full.agent_config.local_repair and full.repairer.local
    assert global_repair.agent_config.diagnosis_enabled and global_repair.agent_config.repair_enabled
    assert not global_repair.agent_config.local_repair and not global_repair.repairer.local
    assert baseline.test_support_steps == frozen.test_support_steps == []
    assert full.test_support_steps == global_repair.test_support_steps == diagnose.test_support_steps == list(range(101, 109))
    assert full.test_reset_flags == [False, True, False, False]
    assert len(full.replay) == len(global_repair.replay) == len(diagnose.replay) == 8
    assert len(frozen.replay) == 0
    assert output["mode_sessions"]["full"][0]["query"]["online_optimizer_steps"] == 0
    assert output["mode_sessions"]["global_repair"][0]["query"]["online_optimizer_steps"] == 0
    assert output["mode_sessions"]["global_repair"][0]["query"]["repair_optimizer_steps"] == 0
    assert "full_vs_global_repair" in output["comparisons"]
    assert output["mode_sessions"]["full"][0]["support"]["online_optimizer_steps"] > 0
    comparison = output["comparisons"]["frozen_vs_initial_checkpoint"]
    assert comparison["success_rate_difference"] == comparison["mean_return_difference"] == 0
    assert output["effective_repair_max_wait_steps"] >= 8
    assert (tmp_path / "results" / "session_evaluation.json").exists()
    assert (tmp_path / "results" / "session_episodes.json").exists()
    with pytest.raises(FileExistsError):
        evaluate_sessions(str(path), output_dir=str(tmp_path / "results"))


def test_independent_probe_bank_is_reproducible_disjoint_and_pretransition():
    from dataclasses import asdict
    from adrcml.evaluate_sessions import build_probe_bank, score_probe_bank, _fingerprint
    config = tiny_config()
    env = MechanismMazeEnv(max_steps=4, shift_step=1, environment_profile="heldout_v1")
    _, info = env.reset(seed=25, options={"initial_regime": "fragile_bridge"})
    assignment = {"session": 1, "regime": "fragile_bridge", "support_seeds": [2, 3],
                  "query_seeds": [4, 5], "environment_profile": "heldout_v1",
                  "mechanism_parameters": info["mechanism_parameters"]}
    args = dict(environment_args=asdict(config.environment), assignment=assignment,
                samples=17, context_window=config.model.context_window, context_enabled=True, seed=991)
    bank = build_probe_bank(**args)
    duplicate = build_probe_bank(**args)
    assert _fingerprint(bank) == _fingerprint(duplicate)
    assert not set(bank["rollout_seed"]) & {2, 3, 4, 5}
    assert not bank["context"][0].any()
    for i in range(1, len(bank["action"])):
        if bank["rollout_seed"][i] == bank["rollout_seed"][i - 1]:
            np.testing.assert_array_equal(bank["context"][i][-27:-19], bank["state"][i - 1])
        else:
            assert not bank["context"][i].any()
    agent = build_agent(config, 8, 10)
    before = _fingerprint(agent.checkpoint())
    scored = score_probe_bank(agent, bank)
    assert before == _fingerprint(agent.checkpoint())
    assert scored["samples"] == 17 and scored["readonly_audit_passed"]
    assert scored["changed_child_mse"] is not None
    # Scoring consumes targets only to report errors, not to alter the model.
    modified = copy.deepcopy(bank)
    modified["next_state"] += 1
    assert score_probe_bank(agent, modified)["mse"] != scored["mse"]
    assert before == _fingerprint(agent.checkpoint())


def test_independent_probe_audit_rejects_accidental_model_write(monkeypatch):
    from dataclasses import asdict
    from adrcml.evaluate_sessions import build_probe_bank, score_probe_bank
    config = tiny_config()
    assignment = {"session": 1, "regime": "base", "support_seeds": [2], "query_seeds": [3],
                  "environment_profile": "train", "mechanism_parameters": {}}
    bank = build_probe_bank(asdict(config.environment), assignment, samples=2, context_window=8,
                            context_enabled=True, seed=55)
    agent = build_agent(config, 8, 10)
    original = agent.model.predict_members
    def corrupt(*args, **kwargs):
        result = original(*args, **kwargs)
        next(agent.model.parameters()).add_(1)
        return result
    monkeypatch.setattr(agent.model, "predict_members", corrupt)
    with pytest.raises(RuntimeError, match="modified learning"):
        score_probe_bank(agent, bank)


def test_heldout_sessions_freeze_parameters_and_share_probe_banks(tmp_path):
    config = tiny_config()
    checkpoint = copy.deepcopy(build_agent(config, 8, 10).checkpoint())
    checkpoint.update(config=config.to_dict(), software_version="10.0.0", step=100)
    path = tmp_path / "checkpoint.pt"
    torch.save(checkpoint, path)
    result = evaluate_sessions(str(path), output_dir=str(tmp_path / "heldout"), sessions=1,
                               support_episodes=1, query_episodes=1, probe_samples=8,
                               modes=("full", "no_active", "frozen"), regimes=("coupled_lock",),
                               environment_profile="heldout_v1", bootstrap_samples=10)
    full = result["mode_sessions"]["full"][0]
    for mode in result["mode_sessions"]:
        row = result["mode_sessions"][mode][0]
        assert row["mechanism_parameters"] == full["mechanism_parameters"]
        assert row["probe_bank_hash"] == full["probe_bank_hash"]
        assert row["probe_before"] == full["probe_before"]
        assert row["model_hash_after_support"] == row["model_hash_after_query"]
        assert row["query_learning_audit_passed"]
    assert result["mode_sessions"]["no_active"][0]["support"]["active_actions"] == 0
    import json
    episodes = json.loads((tmp_path / "heldout" / "session_episodes.json").read_text())
    for row in episodes:
        assert row["mechanism_parameters"] == full["mechanism_parameters"]
        if row["phase"] != "support":
            assert row["learning_hashes_before"] == row["learning_hashes_after"]
            assert row["learning_observations_before"] == row["learning_observations_after"]
