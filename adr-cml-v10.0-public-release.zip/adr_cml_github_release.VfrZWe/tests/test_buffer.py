import numpy as np

from adrcml.buffer import ReplayBuffer


def test_ring_buffer_keeps_latest_transitions():
    replay = ReplayBuffer(capacity=3, state_dim=2, seed=0)
    for i in range(5):
        state = np.array([i, i + 1], dtype=np.float32)
        replay.add(state, i % 2, float(i), state + 1, False, step=i)
    assert len(replay) == 3
    ordered = replay._physical_indices()
    assert replay.steps[ordered].tolist() == [2, 3, 4]
    sampled = replay.sample_indices(3, recent=True)
    assert set(replay.steps[sampled]).issubset({2, 3, 4})


def test_time_window_and_informative_sampling():
    replay = ReplayBuffer(capacity=10, state_dim=2, seed=1)
    for step in range(8):
        state = np.array([0.0, 0.0], dtype=np.float32)
        next_state = state.copy()
        if step in {2, 5}:
            next_state[1] = 1.0
        replay.add(state, 0, 0.0, next_state, False, step=step)
    selected = replay.sample_indices(
        4,
        after_step=2,
        before_step=6,
        informative_fraction=1.0,
    )
    assert set(replay.steps[selected]).issubset({2, 5})


def test_replay_round_trip():
    replay = ReplayBuffer(capacity=4, state_dim=2, seed=2, action_dim=3)
    for step in range(6):
        state = np.array([step, step + 1], dtype=np.float32)
        replay.add(
            state,
            step % 2,
            float(step),
            state + 1,
            step == 5,
            step=step,
            valid_action_mask=np.array([True, step % 2 == 0, False]),
        )
    restored = ReplayBuffer(capacity=4, state_dim=2, seed=3, action_dim=3)
    restored.load_state_dict(replay.state_dict())
    ordered = restored._physical_indices()
    assert restored.steps[ordered].tolist() == [2, 3, 4, 5]
    assert restored.dones[ordered].tolist() == [0.0, 0.0, 0.0, 1.0]
    assert restored.valid_mask_known[ordered].all()
    assert restored.valid_action_masks[ordered[-1]].tolist() == [1.0, 0.0, 0.0]


def test_exact_batch_preserves_requested_holdout_indices():
    replay = ReplayBuffer(capacity=5, state_dim=1, seed=4, action_dim=2)
    for step in range(5):
        state = np.array([step], dtype=np.float32)
        replay.add(state, step % 2, 0.0, state + 1, False, step=step)
    batch = replay.batch_from_indices(np.array([3, 4]), device="cpu")
    assert batch.state[:, 0].tolist() == [3.0, 4.0]
