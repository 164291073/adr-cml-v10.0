"""Falsifiable one-step information-path contracts, not causal-effect claims."""
import pytest

torch = pytest.importorskip("torch")

from adrcml.context import HistoryContext
from adrcml.models import EnsembleWorldModel


def _model(ensemble_size=2):
    torch.manual_seed(47)
    context_dim = HistoryContext(3, 2).context_dim
    model = EnsembleWorldModel(
        3, 2, hidden_dim=12, ensemble_size=ensemble_size,
        context_dim=context_dim, context_hidden_dim=8,
    )
    with torch.no_grad():
        for member in model.members:
            # Block source 0 -> target 1 for every action and gate sample.
            member.edge_logits[0, 1] = -1e6
            member.action_edge_logits[:, 0, 1] = 0
    return model


def _alter_blocked_parent_and_rewards(context):
    changed = context.clone()
    # Each half is [3 states, 2 action slots, 3 deltas, reward].
    for offset in (0, 9):
        changed[..., offset + 0] += 123.0
        changed[..., offset + 5] -= 241.0
        changed[..., offset + 8] += 997.0
    return changed


@pytest.mark.parametrize("train,sample_edges", [(False, False), (True, False), (True, True)])
@pytest.mark.parametrize("shared_context", [False, True])
def test_zero_edge_blocks_present_history_and_reward_paths(train, sample_edges, shared_context):
    model = _model().train(train)
    state = torch.randn(7, 3)
    changed_state = state.clone()
    changed_state[:, 0] += 17.0
    action = torch.tensor([0, 1, 0, 1, 1, 0, 0])
    context = torch.randn(18) if shared_context else torch.randn(7, 18)
    changed_context = _alter_blocked_parent_and_rewards(context)
    for member in model.members:
        torch.manual_seed(319)
        first = member(state, action, sample_edges=sample_edges, context=context)
        torch.manual_seed(319)
        second = member(changed_state, action, sample_edges=sample_edges, context=changed_context)
        assert torch.count_nonzero(first.adjacency[:, 0, 1]) == 0
        assert torch.equal(first.adjacency, second.adjacency)
        torch.testing.assert_close(first.next_mean[:, 1], second.next_mean[:, 1], rtol=0, atol=0)
        torch.testing.assert_close(first.next_logvar[:, 1], second.next_logvar[:, 1], rtol=0, atol=0)


def test_ensemble_predictions_and_input_gradients_obey_closed_gate():
    model = _model().eval()
    state = torch.randn(4, 3, requires_grad=True)
    context = torch.randn(4, 18, requires_grad=True)
    action = torch.tensor([0, 1, 1, 0])
    means, _, _, variances = model.predict_members(state, action, context=context)
    (means[:, :, 1].sum() + variances[:, :, 1].sum()).backward()
    assert torch.count_nonzero(state.grad[:, 0]) == 0
    for offset in (0, 9):
        assert torch.count_nonzero(context.grad[:, offset + 0]) == 0
        assert torch.count_nonzero(context.grad[:, offset + 5]) == 0
        assert torch.count_nonzero(context.grad[:, offset + 8]) == 0
    # Own-node history is deliberately available; this is not a no-memory model.
    assert torch.count_nonzero(context.grad[:, [1, 6, 10, 15]]) > 0


def test_reward_history_never_changes_any_transition_mean_or_variance():
    model = _model().eval()
    state = torch.randn(5, 3)
    context = torch.randn(5, 18)
    changed_context = context.clone()
    changed_context[:, [8, 17]] += 1000
    action = torch.tensor([1, 0, 0, 1, 0])
    first = model.predict_members(state, action, context=context)
    second = model.predict_members(state, action, context=changed_context)
    for first_value, second_value in zip(first, second):
        torch.testing.assert_close(first_value, second_value, rtol=0, atol=0)


def test_parent_mask_uses_correct_layout_for_mean_and_latest_transition():
    member = _model(1).members[0]
    gates = torch.tensor([[0.0, 1.0, 0.25]])
    expected_row = torch.tensor([[0.0, 1.0, 0.25, 1.0, 1.0, 0.0, 1.0, 0.25, 0.0]])
    assert torch.equal(member._context_mask(gates), expected_row.repeat(1, 2))


def test_unknown_history_layout_is_rejected_instead_of_silently_unmasked():
    with pytest.raises(ValueError, match="HistoryContext layout"):
        EnsembleWorldModel(3, 2, context_dim=4)
