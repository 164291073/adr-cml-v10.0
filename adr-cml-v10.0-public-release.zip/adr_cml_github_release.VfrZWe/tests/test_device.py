from __future__ import annotations

import pytest
import torch

from adrcml.config import load_config
from adrcml.utils import configure_torch_runtime, resolve_device


def test_explicit_cpu_is_preserved() -> None:
    assert resolve_device("cpu") == "cpu"


def test_auto_falls_back_to_cpu_without_accelerators(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)
    monkeypatch.setattr(torch.backends.mps, "is_available", lambda: False)
    assert resolve_device("auto") == "cpu"


def test_explicit_cuda_fails_fast_when_unavailable(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)
    with pytest.raises(RuntimeError, match="CUDA was requested"):
        resolve_device("cuda")


def test_cuda_runtime_uses_high_matmul_precision(monkeypatch: pytest.MonkeyPatch) -> None:
    selected: list[str] = []
    monkeypatch.setattr(torch, "set_float32_matmul_precision", selected.append)
    configure_torch_runtime("cuda")
    assert selected == ["high"]


def test_rtx4090_override_requires_cuda_and_separate_output() -> None:
    config = load_config("configs/main.yaml", "configs/rtx4090.yaml")
    assert config.device == "cuda"
    assert config.output_dir.startswith("outputs/v10/")
    assert config.output_dir != load_config("configs/main.yaml").output_dir
    assert config.agent.total_steps == 100_000
