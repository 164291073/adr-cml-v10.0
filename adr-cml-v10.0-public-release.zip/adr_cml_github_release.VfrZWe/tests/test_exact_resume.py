from pathlib import Path

import torch
import pytest

from adrcml.config import (
    AgentConfig,
    DetectorConfig,
    EnvironmentConfig,
    ExperimentConfig,
    LoggingConfig,
    ModelConfig,
    PlannerConfig,
)
from adrcml.train import run_experiment


def _config(output: Path, total_steps: int) -> ExperimentConfig:
    return ExperimentConfig(
        seed=31,
        device="cpu",
        output_dir=str(output),
        environment=EnvironmentConfig(
            max_steps=6,
            shift_step=2,
            shift_mode="none",
            observation_noise=0.0,
            stochasticity=0.0,
        ),
        model=ModelConfig(
            hidden_dim=8,
            ensemble_size=1,
            sparsity_warmup_steps=2,
            sparsity_anneal_steps=2,
        ),
        agent=AgentConfig(
            total_steps=total_steps,
            learning_starts=2,
            random_steps=10,
            batch_size=2,
            replay_capacity=32,
            updates_per_step=1,
            diagnosis_enabled=False,
            repair_enabled=False,
        ),
        detector=DetectorConfig(warmup=2),
        planner=PlannerConfig(horizon=2, population=2, elites=1, iterations=1),
        logging=LoggingConfig(log_interval=2, checkpoint_interval=2),
    )


def test_resume_reproduces_uninterrupted_model_state(tmp_path):
    uninterrupted_dir = tmp_path / "uninterrupted"
    resumed_dir = tmp_path / "resumed"
    run_experiment(_config(uninterrupted_dir, 4))
    run_experiment(_config(resumed_dir, 2))
    checkpoint = resumed_dir / "checkpoint_2.pt"
    run_experiment(_config(resumed_dir, 4), resume_checkpoint=str(checkpoint))

    uninterrupted = torch.load(
        uninterrupted_dir / "checkpoint_final.pt",
        map_location="cpu",
        weights_only=False,
    )
    resumed = torch.load(
        resumed_dir / "checkpoint_final.pt",
        map_location="cpu",
        weights_only=False,
    )
    assert uninterrupted["step"] == resumed["step"] == 4
    for name, expected in uninterrupted["model"].items():
        assert torch.equal(expected, resumed["model"][name]), name
    assert len(uninterrupted["replay"]["states"]) == len(resumed["replay"]["states"])
    assert not (resumed_dir / ".train.lock").exists()


def test_resume_rejects_changed_environment_without_overwriting_config(tmp_path):
    run = tmp_path / "run"
    run_experiment(_config(run, 2))
    before = (run / "config_resolved.yaml").read_bytes()
    modified = _config(run, 4)
    modified.environment.stochasticity = 0.25
    with pytest.raises(ValueError, match="Resume configuration differs"):
        run_experiment(modified, resume_checkpoint=str(run / "checkpoint_final.pt"))
    assert (run / "config_resolved.yaml").read_bytes() == before
