import numpy as np
import pytest

from adrcml.metrics import (
    RegimeGraphTracker,
    action_structural_metrics,
    change_detection_metrics,
    detection_delay,
    node_set_metrics,
    scalar_confidence_intervals,
    structural_metrics,
    average_precision_ties,
)


def test_structural_metrics_exact_graph():
    graph = np.array([[1, 1], [0, 1]], dtype=float)
    metrics = structural_metrics(graph, graph)
    assert metrics["graph_f1"] == 1.0
    assert metrics["shd"] == 0.0
    assert metrics["graph_average_precision"] == 1.0
    assert metrics["graph_topk_f1"] == 1.0


def test_action_structural_metrics_scores_each_action_without_union_leakage():
    target = np.stack(
        [
            np.array([[1, 1], [0, 1]], dtype=float),
            np.array([[1, 0], [1, 1]], dtype=float),
        ]
    )
    metrics = action_structural_metrics(target, target)
    assert metrics["macro"]["graph_f1"] == 1.0
    assert metrics["by_action"]["0"]["shd"] == 0.0


def test_detection_delay():
    result = detection_delay([10, 30], [4, 13, 35], horizon=100)
    assert result["mean_detection_delay"] == 4.0
    assert result["false_alarms"] == 1.0


def test_episode_windows_do_not_credit_late_alarm_to_earlier_change():
    result = change_detection_metrics(
        [(1, 5, 10), (11, 15, 20)],
        [3, 16, 18],
        total_steps=20,
    )
    assert result["detected_changes"] == 1.0
    assert result["missed_changes"] == 1.0
    assert result["mean_detection_delay"] == 1.0
    assert result["false_alarms"] == 2.0


def test_node_set_and_regime_aligned_graph_metrics():
    diagnosis = node_set_metrics([1, 2], [2, 3])
    assert diagnosis["diagnosis_precision"] == 0.5
    assert diagnosis["diagnosis_recall"] == 0.5
    tracker = RegimeGraphTracker(window=2)
    graph_a = np.array([[1, 1], [0, 1]], dtype=float)
    graph_b = np.array([[1, 0], [1, 1]], dtype=float)
    tracker.update("a", graph_a, graph_a)
    tracker.update("b", graph_b, graph_b)
    summary = tracker.summary()
    assert summary["macro"]["graph_f1"] == 1.0
    assert np.array_equal(tracker.union_target(), np.ones((2, 2)))


def test_scalar_confidence_intervals_are_bounded():
    metrics = scalar_confidence_intervals([1.0] * 20, [1.0] * 16 + [0.0] * 4)
    assert metrics["mean_return_ci95_low"] == 1.0
    assert metrics["mean_return_ci95_high"] == 1.0
    assert 0.0 <= metrics["success_rate_ci95_low"] < 0.8
    assert 0.8 < metrics["success_rate_ci95_high"] <= 1.0


def test_average_precision_constant_scores_equals_prevalence():
    assert average_precision_ties(np.ones(6), np.array([1, 0, 0, 1, 0, 0])) == pytest.approx(1 / 3)


def test_average_precision_ties_is_permutation_invariant():
    scores = np.array([0.9, 0.9, 0.5, 0.5, 0.5, 0.1])
    labels = np.array([1, 0, 0, 1, 0, 1])
    expected = (0.5 + 0.4 + 0.5) / 3
    rng = np.random.default_rng(3)
    for _ in range(30):
        order = rng.permutation(len(scores))
        assert average_precision_ties(scores[order], labels[order]) == pytest.approx(expected)


def test_topk_reports_oracle_budget_and_tie_uncertainty():
    target = np.zeros((3, 3))
    target[0, 1] = target[1, 2] = 1
    metrics = structural_metrics(np.full((3, 3), 0.7), target)
    assert metrics["graph_topk_oracle_k"] == 2
    assert metrics["graph_topk_boundary_tie_size"] == 6
    assert metrics["graph_topk_boundary_selected"] == 2
    assert metrics["graph_topk_f1"] == 0.5  # Explicit stable row-major choice.
    assert metrics["graph_topk_f1_tie_expected"] == pytest.approx(1 / 3)
    assert metrics["graph_topk_f1_tie_min"] == 0
    assert metrics["graph_topk_f1_tie_max"] == 1
    permutation = np.array([2, 0, 1])
    permuted = structural_metrics(np.full((3, 3), 0.7), target[np.ix_(permutation, permutation)])
    assert permuted["graph_average_precision"] == metrics["graph_average_precision"]
    assert permuted["graph_topk_f1_tie_expected"] == metrics["graph_topk_f1_tie_expected"]


def test_graph_metrics_reject_nonfinite_and_nonbinary_inputs():
    with pytest.raises(ValueError, match="finite"):
        structural_metrics(np.array([[0, np.nan], [0, 0]]), np.zeros((2, 2)))
    with pytest.raises(ValueError, match="binary"):
        structural_metrics(np.zeros((2, 2)), np.full((2, 2), 0.3))


def test_graph_null_target_convention_is_explicit():
    graph = np.zeros((2, 2))
    metrics = structural_metrics(np.ones((2, 2)), graph)
    assert metrics["graph_average_precision"] == 0
    assert metrics["graph_topk_oracle_k"] == 0
    assert metrics["graph_target_edges"] == 0
    assert metrics["graph_predicted_edges"] == 2
    action = action_structural_metrics(np.ones((1, 2, 2)), graph[None])
    assert action["macro"]["null_action_predicted_edges"] == 2
    assert "zero_by_convention" in action["metric_metadata"]["average_precision_null_target"]


def test_recompute_graph_snapshots_preserves_inputs_and_aligns_keys(tmp_path):
    from adrcml.recompute_graph_metrics import recompute_graph_metrics

    predicted_path, target_path = tmp_path / "predicted.npz", tmp_path / "target.npz"
    np.savez(predicted_path, regime_a=np.full((2, 2), 0.7))
    np.savez(target_path, regime_a=np.array([[0, 1], [0, 0]]))
    before = predicted_path.read_bytes()
    report = recompute_graph_metrics(predicted_path, target_path)
    assert report["by_array"]["regime_a"]["graph_average_precision"] == 0.5
    assert report["interpretation"].endswith("not_mean_over_evaluation_episodes")
    assert predicted_path.read_bytes() == before
    np.savez(target_path, wrong_regime=np.zeros((2, 2)))
    with pytest.raises(ValueError, match="same array keys"):
        recompute_graph_metrics(predicted_path, target_path)
