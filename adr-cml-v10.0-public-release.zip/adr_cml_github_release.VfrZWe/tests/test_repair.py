import numpy as np
import pytest

torch = pytest.importorskip("torch")

from adrcml.buffer import ReplayBuffer
from adrcml.repair import LocalMechanismRepair


class _DivergingModel(torch.nn.Module):
    state_dim = 1

    def __init__(self):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.tensor(1.0))
        self.members = torch.nn.ModuleList()

    def prediction_error(self, batch):
        return self.weight.square().reshape(1)

    def prediction_mse(self, batch):
        return self.prediction_error(batch)

    def loss(self, batch, node_mask=None, **weights):
        loss = self.weight.square()
        return loss, {"loss": loss.detach()}


class _OptimizerIsolationModel(torch.nn.Module):
    state_dim = 1

    def __init__(self):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.tensor(1.0))
        self.untouched = torch.nn.Parameter(torch.tensor(3.0))
        self.members = torch.nn.ModuleList()

    def prediction_error(self, batch):
        return self.weight.square().reshape(1)

    def prediction_mse(self, batch):
        return self.prediction_error(batch)

    def loss(self, batch, node_mask=None, **weights):
        # Give ``untouched`` a zero gradient. AdamW would still change it via
        # decoupled weight decay if repair reused the outer optimizer.
        loss = self.weight.square() + 0.0 * self.untouched
        return loss, {"loss": loss.detach()}


def test_repair_rolls_back_when_validation_loss_worsens():
    replay = ReplayBuffer(capacity=8, state_dim=1, seed=0, action_dim=1)
    for step in range(8):
        state = np.array([float(step)], dtype=np.float32)
        replay.add(
            state,
            0,
            0.0,
            state + 1,
            False,
            step=step,
            valid_action_mask=np.array([True]),
        )
    model = _DivergingModel()
    optimizer = torch.optim.SGD(model.parameters(), lr=10.0)
    repair = LocalMechanismRepair(
        model=model,
        optimizer=optimizer,
        device="cpu",
        repair_steps=1,
        repair_batch_size=2,
        anchor_batch_size=2,
        local=False,
        min_train_samples=2,
        min_validation_samples=2,
    )
    report = repair.repair(replay, [0], change_step=2, current_step=7)
    assert not report.applied
    assert report.rejected
    assert report.training_size > 0
    assert report.validation_size > 0
    assert model.weight.item() == pytest.approx(1.0)


def test_repair_optimizer_does_not_decay_untouched_parameter():
    replay = ReplayBuffer(capacity=8, state_dim=1, seed=0, action_dim=1)
    for step in range(8):
        state = np.array([float(step)], dtype=np.float32)
        replay.add(
            state,
            0,
            0.0,
            state + 1,
            False,
            step=step,
            valid_action_mask=np.array([True]),
        )
    model = _OptimizerIsolationModel()
    outer_optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=0.1,
        weight_decay=0.5,
    )
    repair = LocalMechanismRepair(
        model=model,
        optimizer=outer_optimizer,
        device="cpu",
        repair_steps=2,
        repair_batch_size=2,
        anchor_batch_size=2,
        local=False,
        min_train_samples=2,
        min_validation_samples=2,
        min_relative_improvement=0.0,
    )
    report = repair.repair(replay, [0], change_step=2, current_step=7)
    assert report.applied
    assert model.weight.item() < 1.0
    assert model.untouched.item() == pytest.approx(3.0)


def _replay(actions, state_dim=1):
    replay = ReplayBuffer(capacity=len(actions) + 4, state_dim=state_dim, seed=0, action_dim=2)
    for step, action in enumerate(actions):
        replay.add(
            np.full(state_dim, step, dtype=np.float32), action, 0.0,
            np.zeros(state_dim, dtype=np.float32), False, step=step,
        )
    return replay


class _TrackedModel(_OptimizerIsolationModel):
    def __init__(self):
        super().__init__()
        self.training_observations = []

    def loss(self, batch, node_mask=None, **weights):
        self.training_observations.append(batch.state[:, 0].detach().cpu().tolist())
        return super().loss(batch, node_mask, **weights)

    def prediction_error(self, batch):
        return self.weight.square().reshape(1)


def test_repair_requires_real_evidence_and_does_not_modify_model():
    replay = _replay([0] * 3 + [1] * 6)
    model = _TrackedModel()
    repair = LocalMechanismRepair(model, torch.optim.SGD(model.parameters(), lr=0.1), "cpu", local=False)
    before = model.weight.detach().clone()
    report = repair.repair(replay, [0], 3, 8, target_action=1)
    assert report.steps == report.accepted_steps == 0
    assert report.skip_reason == "insufficient_total_evidence"
    assert report.eligible_size == 6
    assert report.training_size + report.validation_size == 6
    assert model.training_observations == []
    assert torch.equal(before, model.weight)


def test_repair_requires_triggering_action_in_both_partitions():
    replay = _replay([0] * 22 + [1])
    model = _TrackedModel()
    repair = LocalMechanismRepair(model, torch.optim.SGD(model.parameters(), lr=0.1), "cpu", local=False)
    report = repair.repair(replay, [0], 2, 22, target_actions=[1])
    assert report.skip_reason == "insufficient_target_action_evidence"
    assert report.steps == 0
    assert report.action_counts["1"]["eligible"] == 1
    assert report.action_counts["1"]["training"] < 2 or report.action_counts["1"]["validation"] < 1


def test_chronological_action_constrained_holdout_excludes_future_history():
    replay = _replay([0, 1] * 14)
    model = _TrackedModel()
    repair = LocalMechanismRepair(
        model, torch.optim.SGD(model.parameters(), lr=0.1), "cpu",
        repair_steps=3, repair_batch_size=128, local=False,
    )
    report = repair.repair(replay, [0], 2, 27, target_actions=[0, 1], evidence_start_step=4)
    assert report.applied
    assert report.accepted_steps == 3
    assert report.eligible_size == 24
    assert set(report.training_indices).isdisjoint(report.validation_indices)
    assert len(set(report.training_indices)) == report.training_size
    assert len(set(report.validation_indices)) == report.validation_size
    assert min(replay.steps[report.training_indices]) >= 4
    assert min(replay.steps[report.validation_indices]) >= 4
    assert max(replay.steps[report.training_indices]) < min(replay.steps[report.validation_indices])
    for action in [0, 1]:
        training = [i for i in report.training_indices if replay.actions[i] == action]
        validation = [i for i in report.validation_indices if replay.actions[i] == action]
        assert max(replay.steps[training]) < min(replay.steps[validation])
        assert report.target_action_relative_improvement[str(action)] > 0
    observed = {int(step) for batch in model.training_observations for step in batch}
    assert observed == set(replay.steps[report.training_indices].tolist())
    assert observed.isdisjoint(replay.steps[report.validation_indices].tolist())
    assert model.untouched.item() == pytest.approx(3.0)


class _CollateralModel(torch.nn.Module):
    state_dim = 2

    def __init__(self):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.tensor(1.0))
        self.members = torch.nn.ModuleList()

    def loss(self, batch, node_mask=None, **weights):
        loss = self.weight.square()
        return loss, {"loss": loss.detach()}

    def prediction_error(self, batch):
        # The flawed shared parameter improves child0 but worsens child1.
        return torch.stack([self.weight.square(), (2.0 - self.weight).square()])

    def prediction_mse(self, batch):
        return self.prediction_error(batch)

    def incoming_parameters(self, affected_nodes):
        return list(self.parameters())


def test_repair_rejects_collateral_degradation_and_restores_weights():
    model = _CollateralModel()
    replay = _replay([0, 1] * 14, state_dim=2)
    repair = LocalMechanismRepair(
        model, torch.optim.SGD(model.parameters(), lr=0.1), "cpu",
        repair_steps=3, distill_weight=0.0,
    )
    report = repair.repair(replay, [0], 4, 27, target_actions=[1])
    assert report.rejected and not report.applied
    assert report.relative_improvement > 0
    assert report.skip_reason == "collateral_degradation"
    assert report.unaffected_relative_degradation > 0.01
    assert report.accepted_steps == 0
    assert model.weight.item() == pytest.approx(1.0)


class _WrongActionModel(_TrackedModel):
    def prediction_error(self, batch):
        # Trigger action1 does not improve; aggregate action0 does improve.
        errors = torch.where(batch.action == 1, 1.0, self.weight.square())
        return errors.mean().reshape(1)


def test_repair_requires_improvement_on_triggering_action_not_just_aggregate():
    model = _WrongActionModel()
    replay = _replay([0, 1] * 14)
    repair = LocalMechanismRepair(
        model, torch.optim.SGD(model.parameters(), lr=0.1), "cpu",
        repair_steps=3, local=False,
    )
    report = repair.repair(replay, [0], 4, 27, target_actions=[1])
    assert report.relative_improvement > 0
    assert report.rejected
    assert report.skip_reason == "insufficient_target_action_mse_improvement"
    assert model.weight.item() == pytest.approx(1.0)


@pytest.mark.parametrize("context_dim", [0, 18])
def test_local_update_preserves_unselected_mechanisms_and_context_modules(context_dim):
    from adrcml.models import EnsembleWorldModel

    model = EnsembleWorldModel(
        state_dim=3, action_dim=2, hidden_dim=8, ensemble_size=1,
        context_dim=context_dim, context_hidden_dim=8,
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=0.1)
    repair = LocalMechanismRepair(model, optimizer, "cpu")
    member = model.members[0]
    before = {name: parameter.detach().clone() for name, parameter in member.named_parameters()}
    states = torch.randn(12, 3)
    actions = torch.arange(12) % 2
    context = torch.randn(12, context_dim) if context_dim else None
    with torch.no_grad():
        prediction_before = model.predict_members(states, actions, context=context)[0].clone()
    for parameter in model.parameters():
        parameter.grad = torch.ones_like(parameter)
    repair._mask_local_gradients(torch.tensor([0.0, 1.0, 0.0]))
    optimizer.step()
    with torch.no_grad():
        prediction_after = model.predict_members(states, actions, context=context)[0]
    assert torch.equal(prediction_after[..., [0, 2]], prediction_before[..., [0, 2]])
    assert not torch.equal(prediction_after[..., 1], prediction_before[..., 1])
    for child in [0, 2]:
        for name, parameter in member.named_parameters():
            if name.startswith(tuple(f"{module}.{child}." for module in (
                "self_mechanisms", "node_heads", "context_encoders", "context_gate_heads",
            ))):
                assert torch.equal(parameter, before[name])
    for name, parameter in member.named_parameters():
        if name.startswith(("action_embedding.", "reward_head.", "done_head.", "validity_head.")):
            assert torch.equal(parameter, before[name])
    assert torch.equal(member.edge_logits[:, 0], before["edge_logits"][:, 0])
    assert torch.equal(member.edge_logits[:, 2], before["edge_logits"][:, 2])
    assert not torch.equal(member.edge_logits[:, 1], before["edge_logits"][:, 1])
    if context_dim:
        name = next(name for name, _ in member.named_parameters() if name.startswith("context_encoders.1."))
        assert not torch.equal(dict(member.named_parameters())[name], before[name])


def test_global_cutoff_moves_earlier_to_cover_actions_without_history_leakage():
    replay = ReplayBuffer(capacity=32, state_dim=1, action_dim=2, context_dim=3)
    for step in range(28):
        replay.add(
            np.array([step], dtype=np.float32),
            0 if step in [4, 8, 12, 18] else 1,
            0.0, np.zeros(1, dtype=np.float32), False, step=step,
            # Encode the identities of prior outcomes in the context. The old
            # per-action split could place outcome18 in a later training row.
            context=np.array([step - 3, step - 2, step - 1], dtype=np.float32),
        )
    model = _TrackedModel()
    repair = LocalMechanismRepair(
        model, torch.optim.SGD(model.parameters(), lr=0.1), "cpu",
        repair_steps=1, local=False,
    )
    report = repair.repair(replay, [0], 4, 27, target_actions=[0, 1])
    assert report.applied
    training_steps = replay.steps[report.training_indices]
    validation_steps = replay.steps[report.validation_indices]
    assert max(training_steps) < min(validation_steps)
    assert min(validation_steps) == 18
    assert report.training_size >= 8 and report.validation_size >= 4
    for counts in report.action_counts.values():
        assert counts["training"] >= 2 and counts["validation"] >= 1
    training_history_outcomes = set(replay.contexts[report.training_indices].ravel().tolist())
    assert training_history_outcomes.isdisjoint(validation_steps.tolist())


def test_repair_defers_when_no_chronological_split_can_cover_target_action():
    replay = _replay([0] * 5 + [1] * 23)
    model = _TrackedModel()
    repair = LocalMechanismRepair(model, torch.optim.SGD(model.parameters(), lr=0.1), "cpu", local=False)
    report = repair.repair(replay, [0], 0, 27, target_actions=[0, 1])
    assert report.steps == 0
    assert report.skip_reason.startswith("insufficient_")
    assert model.training_observations == []
    if report.training_indices and report.validation_indices:
        assert max(replay.steps[report.training_indices]) < min(replay.steps[report.validation_indices])


class _IndependentChildrenModel(torch.nn.Module):
    state_dim = 2

    def __init__(self):
        super().__init__()
        self.weights = torch.nn.Parameter(torch.tensor([1.0, 3.0]))
        self.members = torch.nn.ModuleList()
        self.training_masks = []

    def loss(self, batch, node_mask=None, **kwargs):
        self.training_masks.append(node_mask.detach().tolist())
        loss = (self.weights.square() * node_mask).sum()
        return loss, {"loss": loss.detach()}

    def prediction_error(self, batch):
        return self.weights.square()

    def prediction_mse(self, batch):
        return self.weights.square()

    def incoming_parameters(self, affected_nodes):
        return list(self.parameters())


def test_local_and_global_repair_share_acceptance_target_but_different_training_scope():
    replay = _replay([0, 1] * 14, state_dim=2)
    reports = []
    for local in (True, False):
        model = _IndependentChildrenModel()
        repair = LocalMechanismRepair(
            model, torch.optim.SGD(model.parameters(), lr=.1), "cpu",
            local=local, repair_steps=3, distill_weight=0,
        )
        report = repair.repair(replay, [0], 4, 27, target_actions=[1])
        assert report.applied
        assert report.acceptance_target_nodes == [0]
        assert report.trained_nodes == ([0] if local else [0, 1])
        assert report.initial_target_mse == pytest.approx(1)
        assert report.initial_unaffected_mse == pytest.approx(9)
        assert report.target_action_initial_mse == {"1": pytest.approx(1)}
        assert all(mask == ([1, 0] if local else [1, 1]) for mask in model.training_masks)
        reports.append(report)
    assert reports[0].final_target_mse == pytest.approx(reports[1].final_target_mse)
    assert reports[0].final_unaffected_mse == pytest.approx(9)
    assert reports[1].final_unaffected_mse < 9


def test_global_repair_has_same_collateral_guard_as_local_repair():
    model = _CollateralModel()
    before = model.weight.detach().clone()
    repair = LocalMechanismRepair(
        model, torch.optim.SGD(model.parameters(), lr=.1), "cpu",
        local=False, repair_steps=3, distill_weight=0,
    )
    report = repair.repair(_replay([0, 1] * 14, state_dim=2), [0], 4, 27, target_actions=[1])
    assert report.rejected and not report.applied
    assert report.skip_reason == "collateral_degradation"
    assert report.mse_relative_improvement > 0
    assert report.unaffected_mse_relative_degradation > .01
    assert report.acceptance_target_nodes == [0] and report.trained_nodes == [0, 1]
    assert torch.equal(model.weight, before)
