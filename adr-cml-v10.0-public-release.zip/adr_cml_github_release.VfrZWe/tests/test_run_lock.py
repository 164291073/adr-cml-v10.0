import json

import pytest

from adrcml.utils import OutputRunLock


def test_output_lock_refuses_second_writer(tmp_path):
    first = OutputRunLock(tmp_path)
    first.acquire()
    try:
        metadata = json.loads((tmp_path / ".train.lock").read_text(encoding="utf-8"))
        assert metadata["pid"] > 0
        assert "process_start_ticks" in metadata
        with pytest.raises(RuntimeError, match="already locked"):
            OutputRunLock(tmp_path).acquire()
        with pytest.raises(RuntimeError, match="active training lock"):
            OutputRunLock(tmp_path, force_stale=True).acquire()
    finally:
        first.release()
    assert not (tmp_path / ".train.lock").exists()
