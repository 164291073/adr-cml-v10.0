"""Boundary tests for the independently scoped SCM component experiment."""
from dataclasses import replace

import numpy as np
import pytest
import torch

from adrcml.scm_benchmark import (
    Protocol, ModularRegressor, SCENARIOS, accept_candidate, adapt,
    average_precision_ties, diagnose, draw_data, fingerprint, fit,
    make_simulator, shift_simulator, paired_seed_effect, run_seed, summarize,
)


def tiny_protocol():
    return replace(Protocol(), seeds=(17,), families=("linear",),
                   state_dim=4, action_dim=2, train_samples=256,
                   calibration_samples=128, diagnosis_samples=128,
                   support_samples=96, acceptance_samples=128,
                   query_samples=64, query_trajectories=12,
                   pretrain_iterations=100, repair_iterations=80,
                   bootstrap_samples=100)


@pytest.mark.parametrize("family", ("linear", "nonlinear"))
def test_shifts_have_declared_locality_and_stable_recursive_dynamics(family):
    p = tiny_protocol()
    base = make_simulator(17, family, p)
    for scenario in SCENARIOS:
        shifted = shift_simulator(base, 17, scenario)
        actual = np.any(shifted.coefficients != base.coefficients, axis=1)
        expected = np.zeros(actual.shape, dtype=bool)
        for pair in shifted.changed_pairs:
            expected[pair] = True
        np.testing.assert_array_equal(actual, expected)
        assert shifted.contraction_bound() < 1
        if scenario == "coefficient_shift":
            np.testing.assert_array_equal(base.graph(), shifted.graph())
        if scenario == "edge_addition":
            assert np.sum(shifted.graph() & ~base.graph()) == 1
            assert not np.any(base.graph() & ~shifted.graph())


def test_data_streams_reproducible_and_disjoint():
    p = tiny_protocol()
    sim = make_simulator(17, "nonlinear", p)
    streams = [draw_data(sim, 17, name, 80, .03) for name in
               ("base_train", "base_calibration", "shift/diagnosis", "shift/support", "shift/acceptance", "shift/query")]
    assert len({fingerprint(data) for data in streams}) == len(streams)
    assert fingerprint(streams[0]) == fingerprint(draw_data(sim, 17, "base_train", 80, .03))
    states = np.concatenate([data["state"] for data in streams])
    assert np.unique(states, axis=0).shape[0] == len(states)


def test_sparse_fit_identifies_clean_linear_predictions_and_locality():
    torch.set_num_threads(1)
    p = replace(tiny_protocol(), group_penalty=0.00001, ridge_penalty=0.000001)
    sim = make_simulator(17, "linear", p)
    base = ModularRegressor.empty(p, "linear", "cpu")
    train = draw_data(sim, 17, "train", 512, 0)
    fit(base, train, 120, p.group_penalty, p.ridge_penalty)
    query = draw_data(sim, 17, "query", 128, 0)
    assert np.mean((base.predict(query) - query["next_state"]) ** 2) < 1e-6
    before = base.coefficients.clone()
    shifted = shift_simulator(sim, 17, "edge_addition")
    support = draw_data(shifted, 17, "support", 256, 0)
    fit(base, support, 120, p.group_penalty, p.ridge_penalty, list(shifted.changed_pairs))
    mask = torch.ones(p.action_dim, p.state_dim, dtype=torch.bool)
    for pair in shifted.changed_pairs:
        mask[pair] = False
    assert torch.equal(before.permute(0, 2, 1)[mask], base.coefficients.permute(0, 2, 1)[mask])
    assert not torch.equal(before, base.coefficients)


def test_no_change_control_and_shift_diagnosis_have_no_true_label_input():
    p = tiny_protocol()
    sim = make_simulator(17, "linear", p)
    # Exact base model isolates detector logic from an optimization failure.
    model = ModularRegressor(torch.tensor(sim.coefficients), "linear")
    calibration = draw_data(sim, 17, "calibration", 256, 0)
    stationary = draw_data(sim, 17, "stationary", 256, 0)
    assert diagnose(model, calibration, stationary, p)["pairs"] == []
    shifted = shift_simulator(sim, 17, "coefficient_shift")
    evidence = draw_data(shifted, 17, "evidence", 256, 0)
    result = diagnose(model, calibration, evidence, p)
    assert set(map(tuple, result["pairs"])) == set(shifted.changed_pairs)
    assert result["uses_true_change_labels"] is False


def test_rejected_candidate_does_not_modify_pretrained_model():
    p = tiny_protocol()
    sim = make_simulator(17, "linear", p)
    base = ModularRegressor(torch.tensor(sim.coefficients), "linear")
    support = draw_data(sim, 17, "support", 96, .2)
    validation = draw_data(sim, 17, "validation", 128, 0)
    before = base.coefficients.clone()
    adapted, report = adapt(base, support, validation, [(0, 0)], p)
    assert report["accepted"] is False
    assert torch.equal(base.coefficients, before)
    assert torch.equal(adapted.coefficients, before)
    assert report["uses_query"] is False


def test_average_precision_ties_permutation_invariant():
    labels = np.array([1, 0, 1, 0])
    scores = np.array([.5, .5, .5, .5])
    assert average_precision_ties(labels, scores) == .5
    assert average_precision_ties(labels[::-1], scores) == .5
    assert average_precision_ties([0, 0], [.1, .2]) is None


def test_small_seed_uncertainty_is_not_episode_pseudoreplication():
    p = tiny_protocol()
    effect = paired_seed_effect([.1], p)
    assert effect["paired_seed_bootstrap_ci95"] is None
    assert effect["two_sided_sign_flip_p"] is None
    assert effect["n_independent_seeds"] == 1
    two = paired_seed_effect([.1, .2], p)
    assert two["two_sided_sign_flip_p"] == .5


def test_end_to_end_audit_retains_baselines_and_matched_work_budget():
    torch.set_num_threads(1)
    p = tiny_protocol()
    rows = run_seed(17, p, "cpu")
    assert len(rows) == 3
    for row in rows:
        assert len(set(row["stream_sha256"].values())) == 7
        local_budget = row["modes"]["diagnosed_local"]["repair"]["fit"]["coefficient_update_budget"]
        global_budget = row["modes"]["global_matched_parameter_work"]["repair"]["fit"]["coefficient_update_budget"]
        assert global_budget <= local_budget
        assert set(row["modes"]["diagnosed_local"]["recursive_noiseless_mse_by_horizon"]) == {"1", "8", "32"}
    result = summarize(rows, p, [])
    assert result["complete"] is True
    assert len(result["primary_contrasts"]) == 8
    failed = summarize(rows, p, [{"seed": 99, "error": "retained"}])
    assert failed["complete"] is False
    assert all(v["two_sided_sign_flip_p"] is None and v["paired_seed_bootstrap_ci95"] is None
               and v["inference_valid"] is False for v in failed["primary_contrasts"].values())
    for row in rows:
        for mode in ("diagnosed_local", "global_same_steps", "global_replay", "dense_global", "random_local"):
            assert row["modes"][mode]["repair"]["acceptance_pairs"] == row["diagnosis"]["pairs"]



@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA hardware unavailable in validation environment")
def test_cuda_component_fit_agrees_with_cpu():
    p = tiny_protocol()
    sim = make_simulator(17, "nonlinear", p)
    data = draw_data(sim, 17, "cuda_parity", 256, .03)
    cpu = ModularRegressor.empty(p, "nonlinear", "cpu")
    cuda = ModularRegressor.empty(p, "nonlinear", "cuda")
    fit(cpu, data, 80, p.group_penalty, p.ridge_penalty)
    fit(cuda, data, 80, p.group_penalty, p.ridge_penalty)
    np.testing.assert_allclose(cpu.predict(data), cuda.predict(data), atol=1e-8, rtol=1e-7)


def test_shared_acceptance_guard_rejects_collateral_damage():
    p = tiny_protocol()
    sim = make_simulator(17, "linear", p)
    truth = ModularRegressor(torch.tensor(sim.coefficients), "linear")
    validation = draw_data(sim, 17, "shared_guard", 256, 0)
    inaccurate = truth.copy()
    inaccurate.coefficients[0, -1, 0] += .3
    repaired_with_damage = truth.copy()
    repaired_with_damage.coefficients[1, -1, 1] += .1
    result = accept_candidate(inaccurate, repaired_with_damage, validation, [(0, 0)], .02)
    assert result["relative_validation_gain"] > .99
    assert result["accepted"] is False
    assert result["reason"] == "collateral_degradation"
    assert [1, 1] in result["collateral_violations"]


def test_replay_anchors_only_constrain_diagnosis_protected_targets():
    from adrcml.scm_benchmark import replay_data
    p = replace(tiny_protocol(), replay_anchor_samples=64)
    sim = make_simulator(17, "linear", p)
    train = draw_data(sim, 17, "train", 256, .03)
    support = draw_data(sim, 17, "support", 96, .03)
    data = replay_data(train, support, [(0, 1)], 17, "linear", "edge_addition", p)
    assert len(data["state"]) == 160
    np.testing.assert_array_equal(data["target_weight"][:96], 1.0)
    anchors = np.arange(160) >= 96
    masked = anchors & (data["action"] == 0)
    np.testing.assert_array_equal(data["target_weight"][masked, 1], 0.0)
    np.testing.assert_array_equal(data["target_weight"][anchors, 0], 1.0)
