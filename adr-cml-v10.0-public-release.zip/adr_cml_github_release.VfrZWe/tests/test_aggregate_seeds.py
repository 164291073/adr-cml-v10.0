import json

from adrcml.aggregate_seeds import aggregate_runs
from adrcml.aggregate_seeds import _bootstrap_summary
import numpy as np
import pytest


def test_multiseed_aggregation_uses_seed_level_differences(tmp_path):
    for seed, full_return, frozen_return in ((1, 1.0, 0.5), (2, 0.8, 0.6)):
        run = tmp_path / f"seed_{seed}"
        run.mkdir()
        (run / "evaluation_full.json").write_text(
            json.dumps(
                {
                    "seed": seed,
                    "mean_return": full_return,
                    "success_rate": 1.0,
                }
            ),
            encoding="utf-8",
        )
        (run / "evaluation_frozen.json").write_text(
            json.dumps(
                {
                    "seed": seed,
                    "mean_return": frozen_return,
                    "success_rate": 0.5,
                }
            ),
            encoding="utf-8",
        )
    result = aggregate_runs(tmp_path, bootstrap_samples=100)
    comparison = result["paired_seed_level"]["full_vs_frozen"]
    assert abs(comparison["return_difference"]["mean"] - 0.35) < 1e-12
    assert (tmp_path / "multiseed_results.csv").exists()
    assert (tmp_path / "multiseed_summary.json").exists()


def test_one_training_seed_does_not_report_zero_width_confidence_interval():
    result = _bootstrap_summary([0.98], np.random.default_rng(1), 100)
    assert result["mean"] == 0.98
    assert result["n_seeds"] == 1
    assert result["ci95_low"] is None and result["ci95_high"] is None
    assert result["std"] is None


def test_missing_baseline_for_one_seed_is_not_silently_excluded(tmp_path):
    for seed in (1, 2):
        run = tmp_path / f"seed_{seed}"
        run.mkdir()
        row = {"seed": seed, "mean_return": 1., "success_rate": 1.}
        (run / "evaluation_full.json").write_text(json.dumps(row))
        if seed == 1:
            (run / "evaluation_frozen.json").write_text(json.dumps(row))
    with pytest.raises(ValueError, match="Incomplete seed run"):
        aggregate_runs(tmp_path)


def test_nonfinite_seed_result_is_rejected(tmp_path):
    run = tmp_path / "seed_1"
    run.mkdir()
    (run / "evaluation_full.json").write_text(json.dumps(
        {"seed": 1, "mean_return": float("nan"), "success_rate": 1.}))
    with pytest.raises(ValueError, match="Nonfinite"):
        aggregate_runs(tmp_path)
