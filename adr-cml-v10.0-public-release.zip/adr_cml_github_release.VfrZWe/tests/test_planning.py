import pytest

torch = pytest.importorskip("torch")

from adrcml.planning import CategoricalCEMPlanner


class DummyModel:
    action_dim = 3
    ensemble_size = 2

    def __init__(self):
        self.seen_actions = []

    def predict_members(self, state, actions):
        self.seen_actions.append(actions.detach().cpu().clone())
        batch = actions.shape[0]
        next_states = state.unsqueeze(0).expand(self.ensemble_size, batch, -1).clone()
        rewards = actions.float().reshape(1, -1).expand(self.ensemble_size, -1)
        dones = torch.zeros_like(rewards)
        aleatoric = torch.zeros_like(next_states)
        return next_states, rewards, dones, aleatoric


def test_future_action_mask_applies_to_every_planning_step():
    model = DummyModel()
    planner = CategoricalCEMPlanner(
        model,
        horizon=4,
        population=64,
        elites=8,
        iterations=2,
        active_weight=0.0,
    )
    planner.plan(
        torch.zeros(2),
        valid_action_mask=[True, True, False],
        future_action_mask=[True, True, False],
    )
    assert model.seen_actions
    assert all(not torch.any(actions == 2) for actions in model.seen_actions)


def test_done_probability_suppresses_only_future_rewards():
    class TerminatingModel(DummyModel):
        action_dim = 1

        def predict_members(self, state, actions):
            batch = actions.shape[0]
            next_states = state.unsqueeze(0).expand(self.ensemble_size, batch, -1).clone()
            rewards = torch.ones(self.ensemble_size, batch)
            dones = torch.ones_like(rewards)
            aleatoric = torch.zeros_like(next_states)
            return next_states, rewards, dones, aleatoric

    planner = CategoricalCEMPlanner(
        TerminatingModel(),
        horizon=3,
        population=1,
        elites=1,
        iterations=1,
        discount=1.0,
        risk_weight=0.0,
        active_weight=0.0,
    )
    score = planner._score_sequences(
        torch.zeros(2),
        torch.zeros((1, 3), dtype=torch.long),
        active_weight=0.0,
    )
    assert torch.allclose(score, torch.ones_like(score))


def test_predicted_invalid_actions_receive_planning_penalty():
    class FeasibilityModel(DummyModel):
        action_dim = 2

        def predict_members(self, state, actions):
            batch = actions.shape[0]
            next_states = state.unsqueeze(0).expand(self.ensemble_size, batch, -1).clone()
            rewards = actions.float().reshape(1, -1).expand(self.ensemble_size, -1)
            dones = torch.zeros_like(rewards)
            aleatoric = torch.zeros_like(next_states)
            return next_states, rewards, dones, aleatoric

        def predict_validity_members(self, state):
            batch = state.shape[0]
            probabilities = torch.tensor([1.0, 0.0]).reshape(1, 1, 2)
            return probabilities.expand(self.ensemble_size, batch, -1)

    planner = CategoricalCEMPlanner(
        FeasibilityModel(),
        horizon=1,
        population=2,
        elites=1,
        iterations=1,
        risk_weight=0.0,
        active_weight=0.0,
        invalid_action_penalty=2.0,
    )
    sequences = torch.tensor([[0], [1]], dtype=torch.long)
    scores = planner._score_sequences(torch.zeros(2), sequences, active_weight=0.0)
    assert scores[0] > scores[1]
