import pytest

import json

from adrcml.compare_evaluations import compare_run, exact_mcnemar_p, holm_adjust, paired_comparison, paired_sign_flip_test


def _record(seed, regime, reward, success):
    return {
        "episode_seed": seed,
        "assigned_regime": regime,
        "return": reward,
        "success": success,
    }


def test_paired_comparison_uses_matched_schedule():
    reference = [
        _record(1, "a", 2.0, True),
        _record(2, "b", 1.0, True),
        _record(3, "a", 0.0, False),
    ]
    candidate = [
        _record(1, "a", 1.0, False),
        _record(2, "b", 0.5, True),
        _record(3, "a", 0.0, False),
    ]
    result = paired_comparison(reference, candidate, bootstrap_samples=100, seed=3)
    assert result["paired_return_difference"] == pytest.approx(0.5)
    assert result["success_rate_difference"] == pytest.approx(1 / 3)
    assert result["discordant_reference_wins"] == 1


def test_paired_comparison_rejects_different_schedule():
    with pytest.raises(ValueError):
        paired_comparison(
            [_record(1, "a", 1.0, True)],
            [_record(2, "a", 1.0, True)],
            bootstrap_samples=10,
        )


def test_exact_mcnemar_handles_no_discordance():
    assert exact_mcnemar_p(0, 0) == 1.0


def test_compare_run_emits_all_twenty_eight_eight_mode_pairs(tmp_path):
    rows = [_record(1, "a", 1.0, True), _record(2, "b", 0.0, False)]
    for mode in (
        "oracle_repair",
        "no_active",
        "full",
        "global_repair",
        "matched_active",
        "diagnose_no_repair",
        "online_only",
        "frozen",
    ):
        (tmp_path / f"evaluation_{mode}_episodes.json").write_text(
            json.dumps(rows),
            encoding="utf-8",
        )
    result = compare_run(tmp_path, bootstrap_samples=10)
    assert len(result["comparisons"]) == 7
    assert len(result["all_pairwise"]) == 28
    assert "full_vs_global_repair" in result["comparisons"]
    assert result["comparisons"]["full_vs_global_repair"]["overall"]["holm_family_size"] == 7
    for comparison in result["comparisons"].values():
        assert comparison["overall"]["holm_family_size"] == 7
        assert comparison["overall"]["exact_mcnemar_p_holm"] >= comparison["overall"]["exact_mcnemar_p"]
        assert comparison["overall"]["return_holm_family_size"] == 7
        assert comparison["overall"]["joint_endpoint_holm_family_size"] == 14
        assert comparison["overall"]["paired_return_sign_flip_p_holm"] == 1.0


def test_holm_adjustment_is_monotonic_and_label_preserving():
    from adrcml.compare_evaluations import holm_adjust

    actual = holm_adjust({"a": 0.01, "b": 0.04, "c": 0.03, "d": 0.50})
    assert actual == pytest.approx({"a": 0.04, "c": 0.09, "b": 0.09, "d": 0.50})


def test_paired_comparison_rejects_different_change_time_or_budget():
    left = {**_record(1, "a", 1.0, True), "forced_shift_step": 5, "active_budget_per_episode": 3}
    for changed in ({"forced_shift_step": 6}, {"active_budget_per_episode": 4}):
        with pytest.raises(ValueError, match="not paired"):
            paired_comparison([left], [{**left, **changed}], bootstrap_samples=10)


def test_pair_confidence_interval_is_labelled_episode_level():
    rows = [_record(1, "a", 1.0, True)]
    actual = paired_comparison(rows, rows, bootstrap_samples=10)
    assert actual["confidence_interval_unit"] == "paired_evaluation_episodes_conditional_on_one_training_seed"
    assert actual["paired_return_ci95_low"] is None
    assert actual["paired_return_sign_flip_p"] is None


def test_sign_flip_exact_enumeration_and_zero_pairs():
    positive = paired_sign_flip_test([0, 1, 1, 1, 1, 1])
    assert positive["method"] == "exact_sign_flip"
    assert positive["nonzero_pairs"] == 5
    assert positive["randomization_samples"] == 32
    assert positive["p_value"] == pytest.approx(2 / 32)
    assert paired_sign_flip_test([1, -1, 0])["p_value"] == 1.0
    assert paired_sign_flip_test([0, 0, 0])["p_value"] == 1.0


def test_sign_flip_monte_carlo_is_reproducible_and_never_zero():
    left = paired_sign_flip_test([1.0] * 21, samples=1000, seed=11)
    right = paired_sign_flip_test([1.0] * 21, samples=1000, seed=11)
    assert left == right
    assert left["method"] == "monte_carlo_sign_flip_plus_one"
    assert left["p_value"] >= 1 / 1001


def test_sign_flip_is_scale_and_sign_invariant():
    base = paired_sign_flip_test([1, 2, -1, 2])["p_value"]
    assert paired_sign_flip_test([1e-100, 2e-100, -1e-100, 2e-100])["p_value"] == base
    assert paired_sign_flip_test([-1, -2, 1, -2])["p_value"] == base


def test_holm_null_tests_remain_in_declared_family():
    actual = holm_adjust({"estimable": 0.02, "undefined": None})
    assert actual == {"estimable": 0.04, "undefined": None}
    with pytest.raises(ValueError):
        holm_adjust({"nan": float("nan")})


def test_paired_comparison_preserves_raw_outcomes_and_strata():
    reference = [_record(i, "a" if i < 2 else "b", float(i), i > 0) for i in range(4)]
    candidate = [_record(i, "a" if i < 2 else "b", float(i) / 2, i > 1) for i in range(4)]
    result = paired_comparison(reference, candidate, bootstrap_samples=100)
    assert len(result["paired_outcomes"]) == 4
    assert result["paired_outcomes"][2]["return_difference"] == 1.0
    assert result["confidence_interval_method"].endswith("stratified_by_assigned_regime")
    assert result["confidence_interval_status"] == "estimated"
    assert result["paired_return_ci95_low"] <= result["paired_return_difference"] <= result["paired_return_ci95_high"]


def test_paired_comparison_rejects_duplicate_and_invalid_outcomes():
    row = _record(1, "a", 1.0, True)
    with pytest.raises(ValueError, match="duplicate"):
        paired_comparison([row, row], [row, row], bootstrap_samples=10)
    with pytest.raises(ValueError, match="finite"):
        paired_comparison([row], [{**row, "return": float("nan")}], bootstrap_samples=10)
    with pytest.raises(ValueError, match="binary"):
        paired_comparison([row], [{**row, "success": 2}], bootstrap_samples=10)
    with pytest.raises(ValueError, match="require"):
        paired_comparison([{"return": 1, "success": True}], [{"return": 1, "success": True}], bootstrap_samples=10)


def test_mcnemar_remains_finite_for_large_pair_counts():
    value = exact_mcnemar_p(600, 600)
    assert value == 1.0
    with pytest.raises(ValueError):
        exact_mcnemar_p(-1, 2)


def test_paired_comparison_rejects_environment_profile_or_parameter_mismatch():
    row = {**_record(1, "a", 1.0, True), "environment_profile": "train", "task_action_access": "shared_shield", "mechanism_parameters": {"cost": 0.1}}
    for changed in ({"environment_profile": "heldout_v1"}, {"task_action_access": "legacy_probe_only"}, {"mechanism_parameters": {"cost": 0.2}}):
        with pytest.raises(ValueError, match="not paired"):
            paired_comparison([row], [{**row, **changed}], bootstrap_samples=10)


def test_compare_run_rejects_different_checkpoint_provenance(tmp_path):
    rows = [_record(1, "a", 1.0, True), _record(2, "a", 1.0, True)]
    for mode, checksum in (("full", "aaa"), ("frozen", "bbb")):
        (tmp_path / f"evaluation_{mode}_episodes.json").write_text(json.dumps(rows))
        (tmp_path / f"evaluation_{mode}.json").write_text(json.dumps({"checkpoint_sha256": checksum}))
    with pytest.raises(ValueError, match="checkpoint_sha256"):
        compare_run(tmp_path, candidate_modes=("frozen",), bootstrap_samples=10)
