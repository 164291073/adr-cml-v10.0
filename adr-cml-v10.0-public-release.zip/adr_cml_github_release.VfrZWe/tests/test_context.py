import numpy as np
import pytest

torch = pytest.importorskip("torch")

from adrcml.context import HistoryContext
from adrcml.buffer import ReplayBuffer, TransitionBatch
from adrcml.models import EnsembleWorldModel


def test_history_uses_only_observed_past_and_resets():
    history = HistoryContext(state_dim=2, action_dim=2, window=2)
    before = history.vector()
    assert before.shape == (14,)
    assert not before.any()
    state = np.array([0.2, 0.0], dtype=np.float32)
    history.update(state, 1, 0.5, np.array([0.3, 1.0], dtype=np.float32))
    expected = np.array([0.2, 0.0, 0.0, 1.0, 0.1, 1.0, 0.5], dtype=np.float32)
    assert np.allclose(history.vector(), np.concatenate([expected, expected]))
    # Mutating an external source or returned context cannot change past data.
    state[:] = 999
    context = history.vector()
    context[:] = 999
    assert np.allclose(history.vector()[:7], expected)
    assert not before.any()
    history.reset()
    assert not history.vector().any()


def test_history_window_resume_and_checkpoint_independence():
    history = HistoryContext(1, 2, window=2)
    for i in range(3):
        history.update(np.array([i]), i % 2, float(i), np.array([i + 1]))
    saved = history.state_dict()
    expected = history.vector().copy()
    assert saved["history"].shape == (2, 5)
    restored = HistoryContext(1, 2, window=2)
    restored.load_state_dict(saved)
    saved["history"][:] = -99
    assert np.allclose(restored.vector(), expected)
    restored.update(np.array([100]), 0, 100.0, np.array([101]))
    assert np.allclose(history.vector(), expected)


def test_replay_preserves_pretransition_contexts_through_wrap_and_resume():
    history = HistoryContext(1, 2, window=2)
    replay = ReplayBuffer(3, 1, action_dim=2, context_dim=history.context_dim)
    contexts = []
    for i in range(5):
        contexts.append(history.vector())
        state = np.array([i], dtype=np.float32)
        replay.add(state, i % 2, i, state + 1, False, step=i, context=contexts[-1])
        history.update(state, i % 2, i, state + 1)
    saved = replay.state_dict()
    restored = ReplayBuffer(3, 1, action_dim=2, context_dim=history.context_dim)
    restored.load_state_dict(saved)
    batch = restored.batch_from_indices([0, 2], "cpu")
    assert np.allclose(batch.context.numpy(), np.stack([contexts[2], contexts[4]]))
    saved["contexts"][:] = 999
    assert np.allclose(restored.contexts[0], contexts[2])
    replay.contexts[:] = -999
    assert np.allclose(restored.contexts[2], contexts[4])


def _context_model():
    return EnsembleWorldModel(3, 2, hidden_dim=8, ensemble_size=1,
                              context_dim=18, context_hidden_dim=4)


def test_graphs_do_not_change_with_history_but_do_change_with_action_weights():
    model = _context_model().eval()
    member = model.members[0]
    with torch.no_grad():
        model.set_context(torch.full((18,), -100.0))
        before = model.adjacency_by_action().clone()
        model.set_context(torch.full((18,), 100.0))
        after = model.adjacency_by_action().clone()
        assert torch.equal(before, after)
        member.action_edge_logits[1, 0, 1] = 2.0
        changed = model.adjacency_by_action()
    assert before.shape == (2, 3, 3)
    assert changed[1, 0, 1] > changed[0, 0, 1]
    assert not any("context_gate_heads" in name for name in model.state_dict())


def test_batched_context_training_does_not_read_or_overwrite_live_context():
    torch.manual_seed(3)
    model = _context_model().eval()
    model.set_context(torch.ones(18))
    batch = TransitionBatch(
        state=torch.rand(4, 3), action=torch.tensor([0, 1, 0, 1]),
        reward=torch.zeros(4), next_state=torch.rand(4, 3), done=torch.zeros(4),
        context=torch.randn(4, 18),
    )
    first = model.prediction_error(batch)
    model.set_context(torch.full((18,), 50.0))
    second = model.prediction_error(batch)
    assert torch.equal(first, second)
    loss, _ = model.loss(batch)
    loss.backward()
    assert torch.equal(model.members[0].current_context, torch.full((18,), 50.0))
    assert model.members[0].context_encoders[0][0].weight.grad is not None
    # Live context is managed by the agent history checkpoint, not model weights.
    assert not any("current_context" in name for name in model.state_dict())


def test_local_repair_parameters_include_only_target_history_modules():
    model = _context_model()
    member = model.members[0]
    params = {id(p) for p in model.incoming_parameters([1])}
    for p in member.context_encoders[1].parameters():
        assert id(p) in params
    for child in (0, 2):
        for p in member.context_encoders[child].parameters():
            assert id(p) not in params
    for p in member.action_embedding.parameters():
        assert id(p) not in params


def test_clipped_gate_can_receive_parameter_gradient_without_history_offset():
    model = _context_model().train()
    member = model.members[0]
    with torch.no_grad():
        member.edge_logits.fill_(-2.0)
    # A zero forward gate retains a surrogate adaptation gradient in the
    # gate parameter, but no history-to-gate dependency is allowed.
    context = torch.ones(1, 18, requires_grad=True)
    graph = member.adjacency(action=torch.tensor([0]), context=context, sample=False)
    assert graph[0, 0, 1].item() == 0.0
    graph[0, 0, 1].backward()
    assert member.edge_logits.grad[0, 1].abs() > 0
    assert context.grad is None


def test_agent_stores_pretransition_context_and_restores_live_memory():
    import copy

    from adrcml.agent import ADRCMLAgent
    from adrcml.config import AgentConfig, DetectorConfig, ModelConfig, PlannerConfig

    def make_agent():
        return ADRCMLAgent(
            state_dim=3, action_dim=2,
            model_config=ModelConfig(hidden_dim=8, ensemble_size=1, context_hidden_dim=4),
            agent_config=AgentConfig(replay_capacity=8, batch_size=4, learning_starts=4),
            detector_config=DetectorConfig(),
            planner_config=PlannerConfig(horizon=2, population=4, elites=2, iterations=1),
            device="cpu", seed=8,
        )

    agent = make_agent()
    state = np.array([0.1, 0.0, 0.0], dtype=np.float32)
    first_next = np.array([0.1, 1.0, 0.0], dtype=np.float32)
    agent.observe(state, 0, 0.5, first_next, False, step=1)
    assert not agent.replay.contexts[0].any()  # t=1 cannot see its own outcome.
    past = agent.history_context.vector().copy()
    assert past.any()
    agent.observe(first_next, 1, 0.2, state, False, step=2)
    assert np.array_equal(agent.replay.contexts[1], past)
    checkpoint = copy.deepcopy(agent.checkpoint())
    restored = make_agent()
    restored.load_checkpoint(checkpoint)
    expected = agent.history_context.vector()
    assert np.array_equal(restored.history_context.vector(), expected)
    assert np.array_equal(restored.model.members[0].current_context.numpy(), expected)
    # Frozen inference updates only history, matching the ordinary observation order.
    restored.observe_context_only(state, 0, 0.0, first_next)
    assert np.array_equal(agent.history_context.vector(), expected)
    agent.on_episode_reset()
    assert not agent.model.members[0].current_context.any()
    assert not agent.history_context.vector().any()


def test_shared_context_encodes_per_action_and_matches_batched_outputs_and_gradients():
    import copy

    torch.manual_seed(19)
    shared_model = _context_model().members[0].train()
    with torch.no_grad():
        shared_model.action_edge_logits.uniform_(-0.1, 0.1)
    repeated_model = copy.deepcopy(shared_model)
    observed_rows = []
    hook = shared_model.context_encoders[0].register_forward_pre_hook(
        lambda module, inputs: observed_rows.append(inputs[0].shape[0])
    )
    state = torch.rand(7, 3)
    action = torch.tensor([0, 1, 0, 1, 0, 1, 0])
    single_context = torch.randn(18, requires_grad=True)
    batch_context = single_context.detach().unsqueeze(0).repeat(7, 1).requires_grad_(True)
    single_out = shared_model(state, action, sample_edges=False, context=single_context)
    batch_out = repeated_model(state, action, sample_edges=False, context=batch_context)
    assert observed_rows == [shared_model.action_dim]
    hook.remove()
    fields = ["next_mean", "next_logvar", "reward_mean", "done_logit", "adjacency", "validity_logits"]
    for field in fields:
        torch.testing.assert_close(getattr(single_out, field), getattr(batch_out, field))
    sum(getattr(single_out, field).sum() for field in fields).backward()
    sum(getattr(batch_out, field).sum() for field in fields).backward()
    torch.testing.assert_close(single_context.grad, batch_context.grad.sum(dim=0), atol=1e-5, rtol=1e-5)
    for shared_parameter, repeated_parameter in zip(shared_model.parameters(), repeated_model.parameters()):
        torch.testing.assert_close(shared_parameter.grad, repeated_parameter.grad, atol=1e-5, rtol=1e-5)
    # The live-context planner path uses the same encode-per-action branch.
    shared_model.eval()
    shared_model.set_context(single_context.detach())
    live_out = shared_model(state, action, sample_edges=False)
    explicit_out = shared_model(state, action, sample_edges=False, context=batch_context.detach())
    for field in fields:
        torch.testing.assert_close(getattr(live_out, field), getattr(explicit_out, field))
