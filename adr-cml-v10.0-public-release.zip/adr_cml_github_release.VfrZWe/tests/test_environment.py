import numpy as np

from adrcml.envs.mechanism_maze import MechanismMazeEnv, scripted_solution


def test_scripted_policy_solves_every_regime():
    for mode in MechanismMazeEnv.shift_modes:
        env = MechanismMazeEnv(
            max_steps=20,
            shift_step=1,
            shift_mode=mode,
            observation_noise=0.0,
            stochasticity=0.0,
            seed=3,
        )
        env.reset()
        terminated = False
        for action in scripted_solution(mode):
            _, _, terminated, truncated, info = env.step(action)
            if terminated or truncated:
                break
        assert terminated, mode
        assert info["success"]


def test_shift_changes_only_local_graph():
    env = MechanismMazeEnv(max_steps=10, shift_step=2, shift_mode="coupled_lock", seed=1)
    _, before_info = env.reset()
    before = before_info["true_adjacency"]
    env.step(7)
    _, _, _, _, after_info = env.step(7)
    after = after_info["true_adjacency"]
    difference = np.argwhere(before != after)
    assert after_info["shift_event"]
    assert {tuple(edge) for edge in difference} == {
        (0, 4),  # energy -> door
        (3, 4),  # bridge -> door
    }


def test_mechanism_event_marks_execution_not_hidden_switch():
    env = MechanismMazeEnv(
        max_steps=10,
        shift_step=2,
        shift_mode="coupled_lock",
        observation_noise=0.0,
        stochasticity=0.0,
        seed=1,
    )
    env.reset()
    env.step(7)
    _, _, _, _, shifted = env.step(7)
    assert shifted["shift_event"]
    assert not shifted["mechanism_event"]
    env.state[2] = 1.0
    env.state[3] = 1.0
    env.state[0] = 0.4
    _, _, _, _, invoked = env.step(4)
    assert invoked["mechanism_event"]
    assert invoked["mechanism_nodes"] == [4]
    assert env.state[4] == 0.0


def test_draining_key_fires_once_on_transition_after_open():
    env = MechanismMazeEnv(
        max_steps=10,
        shift_step=1,
        shift_mode="draining_key",
        observation_noise=0.0,
        stochasticity=0.0,
        seed=2,
    )
    env.reset()
    env.state[2] = 1.0
    _, _, _, _, opened = env.step(4)
    assert opened["shift_event"]
    assert env.state[2] == 1.0
    _, _, _, _, drained = env.step(7)
    assert drained["mechanism_event"]
    assert drained["mechanism_nodes"] == [2]
    assert env.state[2] == 0.0
    _, _, _, _, later = env.step(7)
    assert not later["mechanism_event"]


def test_observations_are_normalized():
    env = MechanismMazeEnv(max_steps=12, shift_step=6, observation_noise=0.1, seed=9)
    obs, _ = env.reset()
    assert obs.shape == (env.state_dim,)
    assert np.all((0 <= obs) & (obs <= 1))


def test_public_action_mask_does_not_reveal_hidden_regime():
    base = MechanismMazeEnv(
        max_steps=20,
        shift_step=5,
        shift_mode="coupled_lock",
        observation_noise=0.0,
        stochasticity=0.0,
        seed=1,
    )
    _, before = base.reset()
    for _ in range(5):
        _, _, _, _, after = base.step(7)
    assert after["regime"] == "coupled_lock"
    assert np.array_equal(before["valid_action_mask"], after["valid_action_mask"])
    assert not before["valid_action_mask"][7:9].any()
    assert before["valid_action_mask"][9]
    assert not before["intervention_action_mask"][7]
    assert before["intervention_action_mask"][8]
    assert not before["intervention_action_mask"][9]


def test_training_curriculum_delays_shift_modes():
    env = MechanismMazeEnv(
        max_steps=10,
        shift_step=2,
        shift_mode="coupled_lock",
        warmup_episodes=2,
        seed=4,
    )
    _, info0 = env.reset()
    _, info1 = env.reset()
    _, info2 = env.reset()
    assert info0["shift_mode"] == "none"
    assert info1["shift_mode"] == "none"
    assert info2["shift_mode"] == "coupled_lock"


def test_shift_step_can_be_randomized_per_episode():
    env = MechanismMazeEnv(
        max_steps=20,
        shift_step=8,
        shift_step_min=3,
        shift_step_max=6,
        shift_mode="coupled_lock",
        seed=8,
    )
    sampled = []
    for _ in range(10):
        _, info = env.reset()
        sampled.append(info["shift_step"])
    assert all(3 <= step <= 6 for step in sampled)
    assert len(set(sampled)) > 1


def test_evaluation_can_force_paired_regime_and_shift_step():
    env = MechanismMazeEnv(
        max_steps=20,
        shift_step=8,
        shift_mode="random",
        warmup_episodes=100,
        seed=8,
    )
    _, info = env.reset(
        seed=99,
        options={"shift_mode": "fragile_bridge", "shift_step": 2},
    )
    assert info["assigned_regime"] == "fragile_bridge"
    assert info["shift_step"] == 2
    env.step(7)
    _, _, _, _, shifted = env.step(7)
    assert shifted["shift_event"]
    assert shifted["regime"] == "fragile_bridge"
    assert shifted["experienced_shift"]


def test_action_conditioned_truth_includes_executed_prerequisite_edges():
    env = MechanismMazeEnv(
        max_steps=12,
        shift_step=1,
        shift_mode="fragile_bridge",
        observation_noise=0.0,
        stochasticity=0.0,
    )
    env.reset()
    env.step(7)
    by_action = env.true_adjacency_by_action()
    assert by_action.shape == (env.action_dim, env.state_dim, env.state_dim)
    assert by_action[5, 7, 5] == 1.0  # shield -> crossed under cross_bridge
    assert by_action[5, 1, 0] == 0.0  # no invented material -> energy edge here


def test_fragile_event_requires_an_observable_difference_from_base():
    env = MechanismMazeEnv(
        max_steps=12,
        shift_step=1,
        shift_mode="fragile_bridge",
        observation_noise=0.0,
        stochasticity=0.0,
    )
    env.reset()
    env.state[[0, 3, 4, 7]] = [0.5, 1.0, 1.0, 1.0]
    _, _, _, _, protected = env.step(5)
    assert protected["shift_event"]
    assert not protected["mechanism_event"]

    env.reset()
    env.state[[0, 3, 4, 7]] = [0.2, 1.0, 1.0, 0.0]
    _, _, _, _, failed = env.step(5)
    assert failed["mechanism_event"]
    assert failed["mechanism_nodes"] == [0, 3, 5]


def test_shield_is_a_shared_productive_task_action():
    env = MechanismMazeEnv(observation_noise=0.0, stochasticity=0.0)
    _, info = env.reset(options={"initial_regime": "fragile_bridge"})
    assert info["valid_action_mask"][9]
    assert info["task_action_mask"][9]
    assert not info["intervention_action_mask"][9]
    env.step(9)
    assert env.state[7] == 1
    assert not env.valid_action_mask[9]
    assert env.task_action_mask[9]  # Still available in hypothetical future states.
    assert env.action_names[9] == "shield_bridge"


def test_explicit_legacy_access_preserves_original_action_partition():
    env = MechanismMazeEnv(task_action_access="legacy_probe_only")
    _, info = env.reset()
    assert not info["valid_action_mask"][9]
    assert not info["task_action_mask"][9]
    assert info["intervention_action_mask"][9]
    assert env.action_names[9] == "probe_bridge"


def test_heldout_profile_is_reproducible_and_does_not_change_base_rng_or_masks():
    train = MechanismMazeEnv(observation_noise=0.02, stochasticity=0.1)
    heldout = MechanismMazeEnv(environment_profile="heldout_v1", observation_noise=0.02, stochasticity=0.1)
    first_obs, first = train.reset(seed=27)
    second_obs, second = heldout.reset(seed=27)
    np.testing.assert_array_equal(first_obs, second_obs)
    np.testing.assert_array_equal(first["valid_action_mask"], second["valid_action_mask"])
    np.testing.assert_array_equal(first["task_action_mask"], second["task_action_mask"])
    params = second["mechanism_parameters"]
    assert .65 <= params["coupled_energy_threshold"] <= .85
    assert .45 <= params["fragile_energy_threshold"] <= .65
    _, repeated = heldout.reset(seed=27)
    assert repeated["mechanism_parameters"] == params
    assert first["mechanism_parameters"] == {"coupled_energy_threshold": .55, "fragile_energy_threshold": .35}
    # Baseline trajectories use identical noise even though heldout parameters
    # were sampled. Parameter assignment is not hidden consumption of task RNG.
    for action in (0, 1, 0):
        a, ar, *_ = train.step(action)
        b, br, *_ = heldout.step(action)
        np.testing.assert_array_equal(a, b)
        assert ar == br


def test_heldout_threshold_changes_actual_mechanism_and_session_can_freeze_it():
    env = MechanismMazeEnv(environment_profile="heldout_v1", observation_noise=0, stochasticity=0)
    _, first = env.reset(seed=1, options={"initial_regime": "fragile_bridge"})
    params = first["mechanism_parameters"]
    env.state[[0, 3, 4, 7]] = [0.4, 1.0, 1.0, 1.0]
    _, _, _, _, failed = env.step(5)
    assert failed["mechanism_event"]
    assert env.state[5] == 0
    for seed in (33, 34, 35):
        _, same = env.reset(seed=seed, options={"initial_regime": "fragile_bridge", "mechanism_parameters": params})
        assert same["mechanism_parameters"] == params
    env.reset(seed=1, options={"initial_regime": "fragile_bridge", "environment_profile": "train"})
    env.state[[0, 3, 4, 7]] = [0.4, 1.0, 1.0, 1.0]
    env.step(5)
    assert env.state[5] == 1


def test_heldout_environment_resume_preserves_parameter_stream_and_state():
    env = MechanismMazeEnv(environment_profile="heldout_v1", seed=4)
    env.reset()
    env.step(0)
    snapshot = env.state_dict()
    target = MechanismMazeEnv(environment_profile="heldout_v1", seed=999)
    target.load_state_dict(snapshot)
    np.testing.assert_array_equal(env.state, target.state)
    assert env.mechanism_parameters == target.mechanism_parameters
    for _ in range(3):
        a, ai = env.reset()
        b, bi = target.reset()
        np.testing.assert_array_equal(a, b)
        assert ai["mechanism_parameters"] == bi["mechanism_parameters"]


def test_wrong_parameter_or_resume_action_protocol_is_rejected():
    import pytest
    env = MechanismMazeEnv()
    with pytest.raises(ValueError, match="Unknown mechanism_parameters"):
        env.reset(options={"mechanism_parameters": {"surprise": 1}})
    with pytest.raises(ValueError, match="thresholds"):
        env.reset(options={"mechanism_parameters": {"fragile_energy_threshold": float("nan")}})
    legacy = MechanismMazeEnv(task_action_access="legacy_probe_only")
    legacy.reset()
    with pytest.raises(ValueError, match="action-access protocol"):
        env.load_state_dict(legacy.state_dict())
