# ADR-CML v10.0

Act, Diagnose, Repair: Active Relational Causal Mechanism Learning for Long-Horizon Agents.

这是研究原型及可审计实验套件，不是某篇已发表论文的官方复现。v10 修复了任务动作与探测动作混合的实验设计，增加独立训练的稠密模型、冻结参数的独立查询评估、留出的机制参数分布和独立 SCM 基准。运行成功只证明程序完成；是否支持方法有效性，需要阅读实际对照、置信区间、失败记录和计算成本。

## Linux / RTX 4090

请在新目录解压 v10，勿覆盖 v0.9 或沿用旧检查点。

```bash
cd ~/adr-cml-v10.0
bash scripts/setup_linux_4090.sh
bash scripts/run_pipeline_v10.sh quick
bash scripts/run_pipeline_v10.sh pilot
```

安装器默认 Python 3.11、新项目 `.venv`、官方 `torch==2.11.0` CUDA 12.8 wheel。若所选环境已经能导入 PyTorch，则保留该安装，包括已有的 `2.11.0+cu128`。所有脚本定位自己的项目根目录，优先使用 `PYTHON_BIN`，其次使用本项目 `.venv/bin/python`。

CPU 快检检查数据链路，pilot 检查真实模型和预算。审查 pilot 后再决定正式运行：

```bash
bash scripts/run_pipeline_v10.sh paper
```

paper 默认 8 个新训练种子（11、23、37、51、71、89、101、113），每个种子分别训练 sparse/dense 各 100,000 步，单卡依次执行。8 种子不是功效或阳性结果保证。总共 16 次训练加评估，可能需要多天；不要把这条命令当成短测试。

详细操作、恢复和故障排查见 [V10_LINUX_4090_RUN_GUIDE.txt](V10_LINUX_4090_RUN_GUIDE.txt)，实验解释见 [docs/V10_EXPERIMENT_PROTOCOL.md](docs/V10_EXPERIMENT_PROTOCOL.md)。`docs` 中标注 historical 的旧指南仅供追溯。

运行产生的 `outputs/`、`validation_results/` 和检查点未随公开仓库上传；仓库仅包含源码、配置、测试、协议文档以及 `paper_analysis/` 中的聚合统计和分析产物。实测结论及限制见 [V10_VALIDATION_REPORT.txt](V10_VALIDATION_REPORT.txt)。快检未证明完整智能体优势；组件中也保留了 dense 更优的反例。当前公开版本不包含已完成的 4090 正式多种子结果。

## 固定协议与恢复

首次运行先写 `outputs/v10/<阶段>/protocol_manifest.json`：保存种子、完整配置、源文件 SHA256、模式、预算、数据规模和解释范围。重新执行同目录会拒绝覆盖。恢复必须显式使用：

```bash
bash scripts/run_pipeline_v10.sh pilot --resume
```

只有原协议、源码、运行时与已完成阶段产物哈希一致时才能复用阶段结果；未完成阶段重新执行或从 v10 训练检查点恢复。失败阶段不会被当作完成。已存在的未完成 session/SCM 输出保留在 `incomplete_attempts/`。

可在首次运行时覆盖规模，恢复时必须传入完全相同的设置：

```bash
OUTPUT_DIR=outputs/v10/pilot_custom TOTAL_STEPS=5000 EVAL_EPISODES=30 bash scripts/run_pipeline_v10.sh pilot
```

## 结果

每个种子包含独立 sparse/dense 检查点、8 模式短回合评估、train/heldout_v1 两类 support/query session 评估。SCM 基准及跨种子聚合位于同一结果根目录。最后运行：

```bash
python -m adrcml.evidence_report --root outputs/v10/paper
python scripts/pack_results.py --help
```

报告明确列出缺失证据，不输出“已达到发表标准”。主要问题是 full 是否相对 `diagnose_no_repair` 和 `global_repair` 提升独立查询结果，并减少对未改变机制的损伤。普通 episode 成功率、修复接纳率、图 F1 和执行退出码不能替代这项判断。

`heldout_v1` 留出的是机制阈值分布，不是全新机制类型。MechanismMaze 的图是可观测依赖代理标注；完整因果结构恢复只在显式、完全观察的 SCM 范围内评估。SCM 的模块化估计器结论不能直接转化成神经规划智能体结论。
