#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_common.sh"
echo "Single-checkpoint diagnostic launcher. For paired sparse/dense, independent queries and a fixed manifest use run_pipeline_v10.sh."
if [[ $# -gt 1 ]]; then
  echo "Usage: bash scripts/run_linux_4090.sh [RESUME_CHECKPOINT]" >&2
  exit 2
fi
output_dir="${OUTPUT_DIR:-outputs/v10/rtx4090_single}"
total_steps="${TOTAL_STEPS:-100000}"
eval_episodes="${EVAL_EPISODES:-100}"
adrcml_require_integer TOTAL_STEPS "$total_steps"
python -m adrcml.device_info --require-cuda
train_args=(--config configs/main.yaml --override configs/rtx4090.yaml --output "$output_dir" --total-steps "$total_steps")
if [[ "${FORCE_STALE_LOCK:-0}" == "1" ]]; then
  train_args+=(--force-stale-lock)
fi
if [[ $# -eq 1 ]]; then
  train_args+=(--resume "$1")
fi
python -m adrcml.train "${train_args[@]}"
adrcml_evaluate_modes "$output_dir/checkpoint_final.pt" "$eval_episodes" "$output_dir" balanced_shift
echo "Completed training and eight-mode evaluation: $output_dir"
