#!/usr/bin/env bash
# Every launcher resolves this checkout and one explicit Python interpreter.
set -euo pipefail
project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_root"
if [[ -n "${PYTHON_BIN:-}" ]]; then
  selected_python="$PYTHON_BIN"
elif [[ -x "$project_root/.venv/bin/python" ]]; then
  selected_python="$project_root/.venv/bin/python"
else
  selected_python="python3"
fi
if ! ADRCML_PYTHON="$(command -v "$selected_python")"; then
  echo "Python not found: $selected_python" >&2
  exit 1
fi
export ADRCML_PYTHON
# A function keeps legacy launchers on the same interpreter without changing PATH.
python() { "$ADRCML_PYTHON" "$@"; }
if ! python -c 'import adrcml; from pathlib import Path; assert Path(adrcml.__file__).resolve().parent == (Path.cwd() / "src/adrcml").resolve()' >/dev/null 2>&1; then
  echo "The selected interpreter does not import ADR-CML from this checkout: $ADRCML_PYTHON" >&2
  echo "Run bash scripts/setup_linux_4090.sh, or install this project in that interpreter with: python -m pip install -e '.[test]'" >&2
  exit 1
fi
export PYTHONUNBUFFERED=1
export MPLBACKEND=Agg

adrcml_require_integer() {
  local name="$1" value="$2" minimum="${3:-1}"
  if [[ ! "$value" =~ ^[0-9]+$ ]] || (( 10#$value < minimum )); then
    echo "$name must be an integer >= $minimum (received: $value)." >&2
    exit 2
  fi
}

adrcml_evaluate_modes() {
  local checkpoint="$1" episodes="$2" output_dir="$3" protocol="${4:-balanced_shift}" profile="${5:-train}"
  local active_budget="${ACTIVE_BUDGET:-3}"
  adrcml_require_integer EVAL_EPISODES "$episodes"
  adrcml_require_integer ACTIVE_BUDGET "$active_budget" 0
  if [[ ! -f "$checkpoint" ]]; then
    echo "Checkpoint not found: $checkpoint" >&2
    exit 2
  fi
  for mode in full global_repair matched_active oracle_repair diagnose_no_repair online_only frozen no_active; do
    python -m adrcml.evaluate \
      --checkpoint "$checkpoint" --episodes "$episodes" --mode "$mode" \
      --protocol "$protocol" --eval-shift-step 2 \
      --environment-profile "$profile" --task-action-access shared_shield \
      --active-budget "$active_budget" --output-dir "$output_dir"
  done
  python -m adrcml.compare_evaluations --run "$output_dir" \
    --candidates global_repair matched_active oracle_repair diagnose_no_repair online_only frozen no_active
  python -m adrcml.visualize_results --run "$output_dir"
}
