#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_common.sh"
echo "Single-checkpoint diagnostic launcher. For paired sparse/dense, independent queries and a fixed manifest use run_pipeline_v10.sh."
if [[ $# -gt 1 ]]; then
  echo "Usage: bash scripts/run_main.sh [RESUME_CHECKPOINT]" >&2
  exit 2
fi
output_dir="${OUTPUT_DIR:-outputs/v10/main_single}"
total_steps="${TOTAL_STEPS:-100000}"
eval_episodes="${EVAL_EPISODES:-100}"
adrcml_require_integer TOTAL_STEPS "$total_steps"
train_args=(--config configs/main.yaml --output "$output_dir" --total-steps "$total_steps")
if [[ $# -eq 1 ]]; then train_args+=(--resume "$1"); fi
python -m adrcml.train "${train_args[@]}"
adrcml_evaluate_modes "$output_dir/checkpoint_final.pt" "$eval_episodes" "$output_dir" balanced_shift
