#!/usr/bin/env python3
"""Create a shareable results archive without model weights or caches."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import tempfile
import zipfile


EXCLUDED_DIRS = {"__pycache__", ".pytest_cache", ".venv", ".git", "node_modules"}
EXCLUDED_SUFFIXES = {".pt", ".pth", ".ckpt", ".pyc", ".pyo"}


def package_results(run_dir: Path, output: Path) -> dict[str, int]:
    run_dir = run_dir.expanduser().resolve()
    output = output.expanduser().resolve()
    if not run_dir.is_dir():
        raise ValueError(f"Run directory does not exist: {run_dir}")
    if output.suffix.lower() != ".zip":
        raise ValueError("--output must end with .zip")
    if output.exists():
        raise FileExistsError(f"Archive already exists: {output}. Choose a new --output filename.")
    output.parent.mkdir(parents=True, exist_ok=True)
    included: list[Path] = []
    excluded_count = 0
    for directory, subdirs, filenames in os.walk(run_dir, followlinks=False):
        directory_path = Path(directory)
        subdirs[:] = sorted(
            name for name in subdirs
            if name not in EXCLUDED_DIRS and not (directory_path / name).is_symlink()
        )
        for name in sorted(filenames):
            path = directory_path / name
            if (
                path.is_symlink()
                or path.suffix.lower() in EXCLUDED_SUFFIXES
                or name == ".train.lock"
                or path.resolve() == output
            ):
                excluded_count += 1
                continue
            included.append(path)
    if not included:
        raise ValueError("No result files remain after excluding weights and caches.")
    # Atomic finalization: an interrupted copy cannot leave a plausible final archive.
    handle = tempfile.NamedTemporaryFile(prefix=".adrcml_results_", suffix=".tmp", dir=output.parent, delete=False)
    temporary = Path(handle.name)
    handle.close()
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for path in included:
                archive.write(path, arcname=str(Path(run_dir.name) / path.relative_to(run_dir)))
        # Do not replace an archive that appeared while compression was running.
        os.link(temporary, output)
    finally:
        temporary.unlink(missing_ok=True)
    return {"files": len(included), "excluded": excluded_count, "bytes": output.stat().st_size}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_dir", type=Path, help="Completed run directory, for example outputs/rtx4090")
    parser.add_argument("--output", type=Path, required=True, help="New .zip filename")
    args = parser.parse_args()
    try:
        result = package_results(args.run_dir, args.output)
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        parser.exit(2, f"Cannot package results: {exc}\n")
    size_mib = result["bytes"] / (1024 * 1024)
    print(f"Saved {args.output.resolve()} ({size_mib:.2f} MiB, {result['files']} files)")
    print(f"Excluded {result['excluded']} weight/cache/lock files. Original results were not changed.")
    if size_mib > 30:
        print("WARNING: archive exceeds 30 MiB; the upload channel may have a 32 MiB limit.")
        print("Package one run at a time, or upload summary.json, evaluation_*.json and config_resolved.yaml separately.")


if __name__ == "__main__":
    main()
