#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_common.sh"
echo "Single-checkpoint diagnostic launcher. For paired sparse/dense, independent queries and a fixed manifest use run_pipeline_v10.sh."
if [[ $# -lt 1 || $# -gt 3 ]]; then
  echo "Usage: bash scripts/run_paper_seed_4090.sh SEED [OUTPUT_DIR] [RESUME_CHECKPOINT]" >&2
  exit 2
fi
seed="$1"
output_dir="${2:-${OUTPUT_DIR:-outputs/v10/paper/seed_${seed}}}"
resume_checkpoint="${3:-}"
total_steps="${TOTAL_STEPS:-100000}"
eval_episodes="${EVAL_EPISODES:-100}"
adrcml_require_integer SEED "$seed" 0
adrcml_require_integer TOTAL_STEPS "$total_steps"
python -m adrcml.device_info --require-cuda
train_args=(--config configs/main.yaml --override configs/rtx4090.yaml --seed "$seed" --output "$output_dir" --total-steps "$total_steps")
if [[ -n "$resume_checkpoint" ]]; then train_args+=(--resume "$resume_checkpoint"); fi
if [[ "${FORCE_STALE_LOCK:-0}" == "1" ]]; then train_args+=(--force-stale-lock); fi
python -m adrcml.train "${train_args[@]}"
adrcml_evaluate_modes "$output_dir/checkpoint_final.pt" "$eval_episodes" "$output_dir" balanced_shift
