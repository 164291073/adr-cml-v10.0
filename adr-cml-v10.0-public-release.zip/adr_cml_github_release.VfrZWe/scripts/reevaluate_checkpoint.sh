#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_common.sh"
if [[ $# -lt 1 || $# -gt 2 ]]; then
  echo "Usage: bash scripts/reevaluate_checkpoint.sh CHECKPOINT [EPISODES]" >&2
  exit 2
fi
checkpoint="$1"
episodes="${2:-${EVAL_EPISODES:-100}}"
output_dir="${EVAL_OUTPUT_DIR:-$(dirname "$checkpoint")/reevaluation_$(date +%Y%m%d_%H%M%S)}"
adrcml_evaluate_modes "$checkpoint" "$episodes" "$output_dir" "${EVAL_PROTOCOL:-balanced_shift}"
echo "Evaluation saved to: $output_dir"
