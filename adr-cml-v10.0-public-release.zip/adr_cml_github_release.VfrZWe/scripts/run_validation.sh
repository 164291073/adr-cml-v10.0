#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_common.sh"
if [[ $# -ne 0 ]]; then echo "Usage: bash scripts/run_validation.sh" >&2; exit 2; fi
python -m pytest -q
# The v0.9 linear component demonstration is historical; it is not a v10 benchmark.
echo "Software tests complete. Run the v10 quick pipeline for SCM and agent evidence."
