#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_common.sh"
if [[ $# -ne 1 ]]; then
  echo "Usage: bash scripts/run_sessions.sh V10_CHECKPOINT" >&2
  exit 2
fi
checkpoint="$1"
if [[ ! -f "$checkpoint" ]]; then echo "Checkpoint not found: $checkpoint" >&2; exit 2; fi
sessions="${SESSIONS:-12}"
support="${SUPPORT_EPISODES:-8}"
queries="${QUERY_EPISODES:-4}"
probes="${PROBE_SAMPLES:-512}"
active_budget="${ACTIVE_BUDGET:-3}"
seed="${SESSION_SEED:-41001}"
profile="${ENVIRONMENT_PROFILE:-heldout_v1}"
output_dir="${SESSION_OUTPUT_DIR:-$(dirname "$checkpoint")/sessions_${profile}_$(date +%Y%m%d_%H%M%S)}"
for name in sessions support queries probes; do adrcml_require_integer "$name" "${!name}"; done
adrcml_require_integer ACTIVE_BUDGET "$active_budget" 0
adrcml_require_integer SESSION_SEED "$seed" 0
python -m adrcml.evaluate_sessions --checkpoint "$checkpoint" --output-dir "$output_dir" \
  --environment-profile "$profile" --sessions "$sessions" \
  --support-episodes "$support" --query-episodes "$queries" --probe-samples "$probes" \
  --active-budget "$active_budget" --seed "$seed" --device "${SESSION_DEVICE:-cuda}" \
  --modes full global_repair diagnose_no_repair online_only frozen no_active
echo "Completed support/query evaluation: $output_dir"
