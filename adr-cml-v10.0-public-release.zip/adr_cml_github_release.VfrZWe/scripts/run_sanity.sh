#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_common.sh"
output_dir="${OUTPUT_DIR:-outputs/v10/sanity}"
total_steps="${TOTAL_STEPS:-2000}"
eval_episodes="${EVAL_EPISODES:-20}"
adrcml_require_integer TOTAL_STEPS "$total_steps"
adrcml_require_integer EVAL_EPISODES "$eval_episodes"
python -m adrcml.train --config configs/sanity.yaml --output "$output_dir" --total-steps "$total_steps"
python -m adrcml.evaluate --checkpoint "$output_dir/checkpoint_final.pt" --episodes "$eval_episodes" --mode frozen --protocol no_shift --active-budget 0 --output-dir "$output_dir"
python -m adrcml.visualize_results --run "$output_dir"
