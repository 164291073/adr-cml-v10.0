#!/usr/bin/env bash
set -euo pipefail
# Set SEEDS="11 23 ..." before this command to change the fixed seed list.
exec bash "$(dirname "${BASH_SOURCE[0]}")/run_pipeline_v10.sh" paper "$@"
