#!/usr/bin/env bash
set -euo pipefail
project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_root"
bootstrap_python="${PYTHON_BIN:-python3.11}"
if ! command -v "$bootstrap_python" >/dev/null 2>&1; then
  echo "Install Python 3.11 or set PYTHON_BIN=/absolute/path/to/python." >&2
  exit 1
fi
if [[ "${USE_EXISTING_ENV:-0}" == "1" ]]; then
  install_python="$(command -v "$bootstrap_python")"
else
  if [[ ! -x .venv/bin/python ]]; then
    "$bootstrap_python" -m venv .venv
  fi
  install_python="$project_root/.venv/bin/python"
fi
"$install_python" -m pip install --upgrade pip setuptools wheel
if "$install_python" -c 'import torch' >/dev/null 2>&1; then
  echo "Keeping the existing PyTorch installation."
else
  "$install_python" -m pip install 'torch==2.11.0' --index-url https://download.pytorch.org/whl/cu128
fi
"$install_python" -m pip install -e '.[test]'
"$install_python" -m adrcml.device_info --require-cuda
"$install_python" -m pytest -q
echo "Setup completed. Interpreter: $install_python"
echo "Next: bash scripts/run_pipeline_v10.sh quick"
echo "For USE_EXISTING_ENV=1, keep setting PYTHON_BIN to that interpreter in launch commands."
