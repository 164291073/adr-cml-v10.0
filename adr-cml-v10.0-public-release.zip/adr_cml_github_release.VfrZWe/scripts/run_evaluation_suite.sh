#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_common.sh"
if [[ $# -lt 1 || $# -gt 2 ]]; then
  echo "Usage: bash scripts/run_evaluation_suite.sh CHECKPOINT [EPISODES]" >&2
  exit 2
fi
checkpoint="$1"
episodes="${2:-${EVAL_EPISODES:-100}}"
suite_dir="${EVAL_OUTPUT_DIR:-$(dirname "$checkpoint")/suite_$(date +%Y%m%d_%H%M%S)}"
# Optional: this performs 3 protocols x 7 modes; standard training does not call it.
for protocol in balanced_shift no_shift random_shift; do
  adrcml_evaluate_modes "$checkpoint" "$episodes" "$suite_dir/$protocol" "$protocol"
done
echo "Three-protocol evaluation saved to: $suite_dir"
