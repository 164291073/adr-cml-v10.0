#!/usr/bin/env bash
# Reproducible, fail-fast sequence for one GPU. No successful result is assumed.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_common.sh"
if [[ $# -lt 1 || $# -gt 2 ]]; then
  echo "Usage: bash scripts/run_pipeline_v10.sh quick|pilot|paper [--resume]" >&2
  exit 2
fi
phase="$1"
resume=0
if [[ $# -eq 2 ]]; then
  [[ "$2" == "--resume" ]] || { echo "Second argument must be --resume" >&2; exit 2; }
  resume=1
fi
case "$phase" in
  quick)
    default_seeds="7"; default_steps=800; default_eval=6; default_sessions=3
    default_support=2; default_query=1; default_probes=32; default_device=cpu
    base_config=configs/quick.yaml; protocols=(balanced_shift)
    ;;
  pilot)
    default_seeds="2027"; default_steps=5000; default_eval=30; default_sessions=6
    default_support=8; default_query=2; default_probes=128; default_device=cuda
    base_config=configs/main.yaml; protocols=(balanced_shift no_shift)
    ;;
  paper)
    default_seeds="11 23 37 51 71 89 101 113"; default_steps=100000; default_eval=100; default_sessions=12
    default_support=12; default_query=4; default_probes=512; default_device=cuda
    base_config=configs/main.yaml; protocols=(balanced_shift no_shift random_shift)
    ;;
  *) echo "Unknown phase: $phase (choose quick, pilot, paper)" >&2; exit 2 ;;
esac
run_root="${OUTPUT_DIR:-outputs/v10/$phase}"
read -r -a seeds <<< "${SEEDS:-$default_seeds}"
total_steps="${TOTAL_STEPS:-$default_steps}"
episodes="${EVAL_EPISODES:-$default_eval}"
sessions="${SESSIONS:-$default_sessions}"
support="${SUPPORT_EPISODES:-$default_support}"
queries="${QUERY_EPISODES:-$default_query}"
probe_samples="${PROBE_SAMPLES:-$default_probes}"
device="${DEVICE:-$default_device}"
export ACTIVE_BUDGET="${ACTIVE_BUDGET:-3}"
mkdir -p "$(dirname "$run_root")"
exec 9>"${run_root}.pipeline.lock"
if ! flock -n 9; then echo "Another pipeline owns $run_root" >&2; exit 2; fi
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-4}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-4}"
for name in total_steps episodes sessions support queries probe_samples; do
  adrcml_require_integer "$name" "${!name}"
done
adrcml_require_integer ACTIVE_BUDGET "$ACTIVE_BUDGET" 0
for seed in "${seeds[@]}"; do adrcml_require_integer SEED "$seed" 0; done
if [[ "$device" == cuda* ]]; then python -m adrcml.device_info --require-cuda; fi

# Write the complete plan before the first optimizer update. An existing plan
# can only be reused explicitly and only if its source/config/settings match.
python - "$run_root" "$phase" "$resume" "$base_config" "$device" "$total_steps" "$episodes" "$sessions" "$support" "$queries" "$probe_samples" "$ACTIVE_BUDGET" "${seeds[*]}" "${protocols[*]}" <<'PY'
import hashlib, json, platform, sys
from pathlib import Path
import torch, yaml
from adrcml import __version__
from adrcml.config import load_config
from adrcml.evaluate_sessions import SESSION_STATISTICAL_PLAN
(root,phase,resume,base,device,steps,episodes,sessions,support,queries,probes,budget,seeds,protocols)=sys.argv[1:]
root=Path(root).resolve()
seed_values=[int(s) for s in seeds.split()]
if len(set(seed_values))!=len(seed_values):
    raise SystemExit('SEEDS must be unique independent training seeds')
paths=sorted([*Path('src/adrcml').rglob('*.py'),*Path('configs').rglob('*.yaml'),*Path('scripts').glob('*.sh'),Path('pyproject.toml')])
source={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
plan={'schema':'adrcml-v10-pipeline-v1','software_version':__version__,'phase':phase,
      'training_seeds':seed_values,'training_steps_per_architecture':int(steps),'architectures':['sparse','dense'],
      'device':device,'evaluation_episodes':int(episodes),'evaluation_protocols':protocols.split(),
      'environment_profiles':['train','heldout_v1'],'active_budget':int(budget),
      'scm_preset':'paper' if phase=='paper' else 'quick','scm_device':'cpu',
      'scm_seeds':[11,23,37,51,71,89,101,127,149,173] if phase=='paper' else [11,23,37],
      'sessions':int(sessions),'support_episodes':int(support),'query_episodes':int(queries),'probe_samples':int(probes),
      'session_seed_rule':'41001 + 100003 * training_seed; same paired task seeds across sparse/dense',
      'evaluation_modes':['full','global_repair','matched_active','oracle_repair','diagnose_no_repair','online_only','frozen','no_active'],
      'session_modes':['full','global_repair','diagnose_no_repair','online_only','frozen','no_active'],
      'statistical_plan':SESSION_STATISTICAL_PLAN,
      'interpretation':'execution completion is not effectiveness, causal identification, or publication readiness',
      'source_sha256':source,'python':platform.python_version(),'pytorch':torch.__version__,
      'cuda_runtime':torch.version.cuda,'resolved_training_configs':{}}
for seed in seed_values:
    for arch in plan['architectures']:
        config=load_config(base,'configs/ablations/dense_graph.yaml' if arch=='dense' else None)
        config.seed=seed; config.device=device; config.agent.total_steps=int(steps)
        if phase=="quick": config.logging.checkpoint_interval=min(config.logging.checkpoint_interval,200)
        elif phase=="pilot": config.logging.checkpoint_interval=min(config.logging.checkpoint_interval,1000)
        config.output_dir=str(root/f'seed_{seed}'/arch)
        plan['resolved_training_configs'][f'seed_{seed}/{arch}']=config.to_dict()
manifest=root/'protocol_manifest.json'
if manifest.exists():
    if resume!='1': raise SystemExit(f'Existing pipeline: {root}. Choose a new OUTPUT_DIR or pass --resume.')
    if json.loads(manifest.read_text())!=plan:
        raise SystemExit('Resume refused: protocol, resolved configuration, software source, or runtime differs from the fixed manifest. Use a new OUTPUT_DIR.')
else:
    if resume=='1': raise SystemExit('Resume refused: protocol_manifest.json is missing.')
    if root.exists() and any(root.iterdir()): raise SystemExit(f'Refusing nonempty output directory without a manifest: {root}')
    root.mkdir(parents=True,exist_ok=True)
    manifest.write_text(json.dumps(plan,indent=2,ensure_ascii=False)+'\n')
for rel,config in plan['resolved_training_configs'].items():
    destination=root/rel/'config_planned.yaml'
    destination.parent.mkdir(parents=True,exist_ok=True)
    content=yaml.safe_dump(config,sort_keys=False)
    if destination.exists() and destination.read_text()!=content:
        raise SystemExit(f'Planned configuration was modified: {destination}')
    if not destination.exists(): destination.write_text(content)
print(f'Fixed protocol: {manifest}')
PY

# A completed stage is skipped only with an explicit --resume and matching
# hashes of its expected result artifacts. Partial stages rerun; errors stop.
stage_done() {
  if [[ ! -f "$run_root/stage_status/$1.json" ]]; then return 1; fi
  python - "$run_root" "$1" "$resume" <<'PY' || exit $?
import hashlib,json,sys
from pathlib import Path
root,key,resume=Path(sys.argv[1]),sys.argv[2],sys.argv[3]
marker=root/'stage_status'/f'{key}.json'
if not marker.exists(): sys.exit(1)
if resume!='1': raise SystemExit(f'Completed stage already exists: {key}; use --resume')
data=json.loads(marker.read_text())
manifest_hash=hashlib.sha256((root/'protocol_manifest.json').read_bytes()).hexdigest()
if data['manifest_sha256']!=manifest_hash: raise SystemExit(f'Stage manifest mismatch: {key}')
for name,digest in data['artifacts'].items():
    p=root/name
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
        raise SystemExit(f'Completed stage artifact missing/modified: {p}')
print(f'Reusing verified completed stage: {key}')
PY
}
stage_record() {
  local key="$1"
  shift
  python - "$run_root" "$key" "$@" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]).resolve(); key=sys.argv[2]
artifacts={}
for name in sys.argv[3:]:
    p=Path(name).resolve()
    if not p.is_file(): raise SystemExit(f'Stage expected result is missing: {p}')
    artifacts[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
marker=root/'stage_status'/f'{key}.json';marker.parent.mkdir(parents=True,exist_ok=True)
marker.write_text(json.dumps({'completed':True,'manifest_sha256':hashlib.sha256((root/'protocol_manifest.json').read_bytes()).hexdigest(),'artifacts':artifacts},indent=2)+'\n')
PY
}

retain_partial() {
  local directory="$1" key="$2"
  if [[ -e "$directory" ]]; then
    if [[ "$resume" != 1 ]]; then echo "Unexpected preexisting stage output: $directory" >&2; exit 2; fi
    local retained="$run_root/incomplete_attempts/${key}_$(date +%Y%m%d_%H%M%S)_$$"
    mkdir -p "$run_root/incomplete_attempts"
    mv "$directory" "$retained"
    echo "Retained incomplete stage at $retained; rerunning it."
  fi
}

for seed in "${seeds[@]}"; do
  for arch in sparse dense; do
    train_dir="$run_root/seed_$seed/$arch"
    key="seed_${seed}_${arch}_train"
    if ! stage_done "$key"; then
      args=(--config "$train_dir/config_planned.yaml")
      if [[ "$resume" == 1 ]]; then
        checkpoint="$(python - "$train_dir" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]); final=p/'checkpoint_final.pt'
if final.exists(): print(final)
else:
    checkpoints=[x for x in p.glob('checkpoint_*.pt') if re.fullmatch(r'checkpoint_[0-9]+\.pt',x.name)]
    if checkpoints: print(max(checkpoints,key=lambda x:int(x.stem.split('_')[-1])))
PY
)"
        if [[ -n "$checkpoint" ]]; then
          args+=(--resume "$checkpoint")
        elif [[ -f "$train_dir/train.jsonl" || -f "$train_dir/config_resolved.yaml" ]]; then
          echo "Training stopped before its first recoverable checkpoint: $train_dir" >&2
          echo "The incomplete run is preserved. Inspect it, then start a new OUTPUT_DIR; no training data will be overwritten." >&2
          exit 2
        fi
      fi
      if [[ "${FORCE_STALE_LOCK:-0}" == 1 ]]; then args+=(--force-stale-lock); fi
      python -m adrcml.train "${args[@]}"
      training_artifacts=("$train_dir/checkpoint_final.pt" "$train_dir/summary.json" "$train_dir/config_resolved.yaml")
      for filename in train.jsonl repairs.jsonl run_metadata.json; do
        if [[ -f "$train_dir/$filename" ]]; then training_artifacts+=("$train_dir/$filename"); fi
      done
      stage_record "$key" "${training_artifacts[@]}"
    fi
    checkpoint="$train_dir/checkpoint_final.pt"
    for profile in train heldout_v1; do
      for protocol in "${protocols[@]}"; do
        key="seed_${seed}_${arch}_eval_${profile}_${protocol}"
        evaluation_dir="$train_dir/evaluation/$profile/$protocol"
        if ! stage_done "$key"; then
          retain_partial "$evaluation_dir" "$key"
          adrcml_evaluate_modes "$checkpoint" "$episodes" "$evaluation_dir" "$protocol" "$profile"
          stage_record "$key" "$evaluation_dir/evaluation_comparison.json" \
            "$evaluation_dir"/evaluation_{full,global_repair,matched_active,oracle_repair,diagnose_no_repair,online_only,frozen,no_active}{,_episodes}.json
        fi
      done
      key="seed_${seed}_${arch}_sessions_${profile}"
      session_dir="$train_dir/sessions/$profile"
      if ! stage_done "$key"; then
        retain_partial "$session_dir" "$key"
        python -m adrcml.evaluate_sessions --checkpoint "$checkpoint" --output-dir "$session_dir" \
          --environment-profile "$profile" --sessions "$sessions" \
          --support-episodes "$support" --query-episodes "$queries" --probe-samples "$probe_samples" \
          --active-budget "$ACTIVE_BUDGET" --seed "$((41001 + 100003 * seed))" --device "$device" \
          --modes full global_repair diagnose_no_repair online_only frozen no_active
        stage_record "$key" "$session_dir/session_evaluation.json" "$session_dir/session_episodes.json" "$session_dir"/probe_bank_session_*.npz
      fi
    done
  done
done
scm_preset=quick
scm_seeds=(11 23 37)
if [[ "$phase" == paper ]]; then scm_preset=paper; scm_seeds=(11 23 37 51 71 89 101 127 149 173); fi
if ! stage_done scm; then
  retain_partial "$run_root/scm" scm
  python -m adrcml.scm_benchmark --preset "$scm_preset" --device cpu --seeds "${scm_seeds[@]}" --output "$run_root/scm"
  stage_record scm "$run_root/scm/summary.json" "$run_root/scm/protocol.json" "$run_root/scm"/seed_*.json
fi
if (( ${#seeds[@]} >= 2 )); then
  for arch in sparse dense; do
    for profile in train heldout_v1; do
      inputs=()
      for seed in "${seeds[@]}"; do inputs+=("$run_root/seed_$seed/$arch/sessions/$profile/session_evaluation.json"); done
      key="aggregate_${arch}_${profile}_sessions"
      aggregate_path="$run_root/aggregate/${arch}_${profile}_sessions.json"
      if ! stage_done "$key"; then
        retain_partial "$aggregate_path" "$key"
        python -m adrcml.aggregate_sessions --inputs "${inputs[@]}" --output "$aggregate_path"
        stage_record "$key" "$aggregate_path"
      fi
      for protocol in "${protocols[@]}"; do
        key="aggregate_${arch}_${profile}_${protocol}"
        aggregate_dir="$run_root/aggregate/${arch}_${profile}_${protocol}"
        if ! stage_done "$key"; then
          retain_partial "$aggregate_dir" "$key"
          python -m adrcml.aggregate_seeds --root "$run_root" \
            --run-glob "seed_*/$arch/evaluation/$profile/$protocol" \
            --output-dir "$aggregate_dir"
          stage_record "$key" "$aggregate_dir/multiseed_summary.json"
        fi
      done
    done
  done
fi
for profile in train heldout_v1; do
  key="architecture_comparison_${profile}"
  architecture_output="$run_root/${key}.json"
  if ! stage_done "$key"; then
    retain_partial "$architecture_output" "$key"
    python -m adrcml.compare_architectures --root "$run_root" --profile "$profile" --output "$architecture_output"
    stage_record "$key" "$architecture_output"
  fi
done
python -m adrcml.evidence_report --root "$run_root"
echo "v10 pipeline completed: $run_root"
echo "Completion is not a positive research result. Read evidence_report and raw comparisons."
