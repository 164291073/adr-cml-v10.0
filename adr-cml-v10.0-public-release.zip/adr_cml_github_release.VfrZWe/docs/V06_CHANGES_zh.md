# ADR-CML v0.6 改进说明

## 1. 为什么需要 v0.6

v0.5 的 10 万步结果说明任务策略已经有效：在 100 个配对强制切换回合中，
`full`、`diagnose_no_repair`、`online_only`、`frozen` 的成功率约为
1.00、0.98、0.93、0.89。`full` 相比 `online_only` 和 `frozen` 的差异显著，
但相比 `diagnose_no_repair` 仅增加 2 个百分点，McNemar 检验不显著。因此旧结果
支持“诊断驱动的整体适应有效”，还不能单独验证“局部修复有效”。

另外还发现三个实现/度量问题：

1. `train.jsonl` 出现重复 step 和 episode，说明两个进程曾同时写同一输出目录；
2. 学习图有高召回、低精度，动作条件软门的 union 接近饱和；
3. 训练检测误报较高，而旧指标从隐藏图切换时刻开始计时，即使改变后的条件机制
   尚未执行，代理也会被当作应该立刻检测到。

v0.6 的目标是修复这些问题并增强可证伪性，不预先保证实验数值一定提升。

## 2. 训练完整性和精确续训

- 每个输出目录使用 `.train.lock` 独占锁；第二个训练进程会直接失败，而不会继续
  写入同一日志。
- 新训练拒绝覆盖已有 `train.jsonl`、summary 或 checkpoint。重复实验必须使用
  新输出目录；续训必须显式传入 `--resume`。
- checkpoint 采用临时文件加原子替换，避免中断留下半个 checkpoint。
- 内置 MechanismMaze 的 v0.6 checkpoint 保存模型、优化器、检测器、回放池内容及采样 RNG、环境内部
  状态、当前 episode、Python/NumPy/PyTorch CPU/CUDA RNG、滚动统计和图追踪器。
- 续训前会删除日志中晚于 checkpoint 的 crash tail。自动测试验证：同一随机种子
  的中断续训和不中断训练得到逐参数完全一致的最终模型。

正常的 Ctrl-C 会释放锁。只有进程被 SIGKILL 或机器断电时才可能留下 stale lock；
确认旧 PID 已退出后，使用 `--force-stale-lock`。

## 3. 可观测的改变时刻

环境仍在隐藏的 `shift_step` 切换结构，但离线 harness 额外记录
`mechanism_event`：改变后的条件机制第一次真正参与状态转移的时刻。这个字段不会
传给代理、回放池或规划器，只用于离线打分。

v0.6 的检测延迟、检测率从 `mechanism_event` 开始计算，定位指标只以该回合已经
实际激活的 changed child 为目标。切换后、激活前
发生的报警算误报；从未触发改变机制的 episode 不算作可检测真阳性机会，并单独
记录。这避免奖励代理猜测一个尚未产生任何观测后果的隐藏事件。

## 4. 更有行为差异的三种机制

- `coupled_lock`：门同时依赖 key、bridge 和最低 energy；真图新增
  `bridge -> door` 与 `energy -> door`。
- `fragile_bridge`：保持 energy + shield 的跨桥条件和失败后桥损坏。
- `draining_key`：开门后的下一步只排空 key 一次，且收集 artifact 必须持有新 key；
  真图新增 `door -> key` 与 `key -> artifact`。

每种机制现在都能在成功轨迹中真正执行其改变条件。`scripted_solution` 和单元测试
覆盖三种机制。

## 5. 稀疏因果图目标

v0.5 对多个动作的软 union 容易因许多小概率相乘而饱和。v0.6 改为：

1. hard-concrete 门，确定性推理时可产生精确的 0/1 边界；
2. 互斥动作上的 max-union，而不是把动作当作独立同时发生事件；
3. union 稀疏与逐动作稀疏各占一半；
4. 每个 child 的软 parent budget，默认最多 3 个非对角父节点；
5. action-specific residual logit 正则，避免十个动作各自随意打开边。

新增 `soft_gates` 和 `no_parent_budget` 消融。稀疏项和 parent budget 都在 warmup 后
渐进启用，防止训练初期把门压到 hard-concrete 的零梯度区。

## 6. 检测和修复

- 检测器增加有界 median/MAD 参考窗口，并设置最小尺度，降低极小 EMA 方差造成的
  尖峰误报；疑似异常样本不写入稳健基线。
- 检查点保存并恢复稳健参考窗口。
- 默认修复等待从 16 步降到 4 步。修复器仍要求至少 2 个训练样本和 2 个时间上
  更晚的验证样本；不足时不会伪造一次修复。
- `oracle_repair` 评估模式在隐藏切换时仅提供真实受影响 child 集合，之后仍使用
  相同延迟、在线数据、局部优化和接受/回滚标准。它是修复能力上界，不是主方法。

## 7. 五模式、全配对统计

主评估现在包含：

1. `oracle_repair`；
2. `full`；
3. `diagnose_no_repair`；
4. `online_only`；
5. `frozen`。

五种模式共享 episode seed、机制、切换时刻和预算。输出既保留以 `full` 为参照的
比较，也生成所有模式两两之间的总体和分机制 paired bootstrap 区间及精确
McNemar 检验。重点判断：

- `oracle_repair - diagnose_no_repair`：当前修复器的潜在上界；
- `full - diagnose_no_repair`：学习诊断触发的修复实际贡献；
- `full - online_only`：诊断、报警探索和修复的联合贡献；
- `online_only - frozen`：普通持续学习贡献。

## 8. 检查点兼容性

- v0.6 可以按 v0.5 的 sigmoid 门语义加载旧 checkpoint 做诊断性评估；
- v0.5 checkpoint 缺少环境、当前 episode 和回放采样 RNG，不能进行 v0.6 的
  精确续训；训练器会明确拒绝，而不是静默近似恢复；
- 测试 v0.6 算法改动必须重新训练，旧 checkpoint 重评不能替代。

## 9. 论文级通过标准

一次 4090、10 万步、单随机种子仍然只是工程验证。至少检查：

1. 日志中 `(type, step)` 无重复，运行结束后 `.train.lock` 已消失；
2. 五种模式使用相同 schedule，`experienced_shift_rate == 1.0`；
3. 报告 `mechanism_activation_rate`，检测指标只解释已激活机制；
4. `full` 相比 `diagnose_no_repair` 的回报差 CI、成功率差和 McNemar p 值；
5. `oracle_repair` 是否明显优于无修复，从而判断瓶颈在诊断还是修复器；
6. union/per-regime 图 precision、recall、F1、AP、top-k F1、SHD；
7. 至少 5 个开发种子、建议 10 个最终种子；
8. 完成消融、强基线、外部环境、计算成本和失败案例。

若 hard-concrete 只让图更稀疏却降低任务表现，或 `full` 仍未优于
`diagnose_no_repair`，应如实报告为负结果并继续定位，而不能据此宣称论文结论已经
成立。
