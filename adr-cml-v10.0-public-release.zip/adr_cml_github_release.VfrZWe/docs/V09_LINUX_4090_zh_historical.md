# ADR-CML v0.9 Linux / RTX 4090

当前完整指南：[V09_LINUX_4090_RUN_GUIDE.txt](../V09_LINUX_4090_RUN_GUIDE.txt)。

按“安装与测试 → 组件验证 → 快速流程 → 5000 步试验 → 审查结果 → 完整训练”运行：

```bash
bash scripts/setup_linux_4090.sh
source .venv/bin/activate
bash scripts/run_validation.sh
bash scripts/run_quick.sh
bash scripts/run_pilot_4090.sh
```

先审查试验输出，再决定是否执行：

```bash
bash scripts/run_linux_4090.sh
bash scripts/run_sessions.sh outputs/rtx4090/checkpoint_final.pt
```

使用新项目目录重新训练；不读取 v0.8 检查点，不自动删除旧输出。
本版是验证候选，组件结果、完整智能体收益与 GPU 运行情况以实际记录为准。
