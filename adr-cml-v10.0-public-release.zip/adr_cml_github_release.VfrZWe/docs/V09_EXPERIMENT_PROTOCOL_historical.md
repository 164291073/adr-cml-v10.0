# ADR-CML v0.9 experiment contract

Freeze hypotheses, budgets, thresholds and validation choices before the final
experiments. v0.9 is a validation candidate, not positive evidence by its version
number. Historical v0.7/v0.8 runs were development diagnostics.

## Separate evidence levels

1. Implementation invariants: structural paths, RNG isolation, rollback,
   detector rearming, checkpoint isolation and query freezing. Passing proves
   only the behavior exercised by each test.
2. Controlled component experiment: fixed five seeds and synthetic graph/shift
   family, equal adaptation data, declared optimizer budget and held-out query.
   Results support only the tested component and conditions.
3. GPU pilot: verifies the integrated agent with 5,000 training steps. It can
   reveal failures but is not a converged comparison.
4. Full-agent experiments: independent trained seeds, paired evaluations,
   stronger baselines, cost reporting and held-out conditions. Only these can
   support an appropriately scoped agent-performance claim.

Read actual runs and limitations in `VALIDATION.md`. Never turn a unit-test count,
a completed script or an accepted repair into a full-method effectiveness claim.

## Fixed component experiment

`python scripts/validate_mechanism_learning.py` uses seeds 11, 23, 37, 51 and 71.
It does not expose seed selection or a query-driven tuning loop. The fixed
protocol is written before training. It tests a single-child mechanism shift
and a no-change negative control with the actual model and repair implementation,
with history context disabled to isolate this component.

Comparisons are frozen, diagnosed_local, oracle_local and
global_repair_same_budget. All use the same adaptation observations and a declared
64-update ceiling for adaptation. Include all seeds and all methods; oracle
information is privileged and must be labeled. A locally accepted update may be
worse on fresh query data: report both rather than replacing query results with
repair acceptance. Extra support-data validation is not the final query set.

Files: `protocol.json`, ten per-seed/per-condition JSON files, and `summary.json`.
Exit status 0 means the run completed, not that the hypothesis passed. Inspect
`primary_component_gate_passed`, `negative_control_gate_passed` and
`both_component_gates_passed`; `full_agent_effectiveness_proven` remains false.
Do not relax thresholds or choose successful seeds after inspecting query data.
The test provides an explicit adaptation phase and IID fresh queries; it does
not establish online change-detector performance or long-task gains. Local
repair need not beat global repair; that comparison is reported independently.
The test is not a new external benchmark or a complete causal-identification
proof. More than one positive synthetic test would be needed for broader claims.

## Original episode evaluation

Retain full, global_repair, matched_active, oracle_repair, diagnose_no_repair, online_only and
frozen, evaluated from the same v0.9 checkpoint on paired seeds and assignments.
Restore the checkpoint before each episode. Full precedes matched_active, which
replays its alarm timing for the same seeds/protocol.

Use balanced_shift, no_shift and random_shift in separate directories. Main
training runs balanced_shift only; the other protocols are opt-in. Random change
times are not unseen mechanisms or unseen mechanism combinations.

All modes share a cap on designated active interventions (default 3 per episode).
This is not equal realized actions or identical experience. Report actual counts,
lengths and planning/optimization costs. Matched active is an alarm-timing/cap
control; oracle is a privileged localization reference, not an assured upper
bound on return. `global_repair` follows the same diagnosis/interaction rules while updating all
model parameters during extra repair. Include it as a stronger locality control,
particularly because it outperformed local repair in the component experiment.
Full vs diagnose_no_repair is the primary repair ablation, and
full vs matched_active is the alarm-timed-exploration comparison.

## Additional persistent-mechanism sessions

The new protocol addresses a specific mismatch: a short episode may end before
8 training + 4 validation transitions with action coverage have accumulated.
It keeps a mechanism fixed across several tasks rather than lowering those
sample requirements. This is a different task/adaptation protocol and must be
reported separately, including the extra interaction cost.

Defaults: 12 sessions, 8 support tasks and 4 frozen-query tasks per session;
regimes coupled_lock, fragile_bridge and draining_key; full, global_repair,
diagnose_no_repair, online_only and frozen. Each session restores the checkpoint.
Support observations may update the learner; transient episode history resets
between tasks, while adaptation evidence can persist within the support stage.
The evidence/expiry window is extended to the support horizon, with the actual
value explicitly saved. Candidate validation quotas are unchanged.

Query seeds are disjoint from support seeds and paired across modes. Query uses
the adapted weights and freezes gradient, replay and detector updates; observed
history still updates. Query task counters are aligned from the checkpoint to
avoid mode-dependent exploration schedules. A clean-checkpoint pre-adaptation
baseline is evaluated on the same query seeds. None of the query information is
used to accept a repair, tune a threshold or choose a checkpoint.

Report both adapted-query performance and change from the baseline. Compare full
with diagnose_no_repair on paired sessions; also include global_repair, online_only and frozen.
Sessions from one checkpoint are not independent trained models, and extra query
tasks do not substitute for multiple training seeds. Session intervals should
resample paired sessions, not pretend every within-session task is independent.

Output files are `session_evaluation.json` and `session_episodes.json`; keep them
separate from original-protocol files. Default wrapper `run_sessions.sh` targets
CUDA; `SESSION_DEVICE=cpu` supports small local checks.

## Structural and repair integrity

A child mechanism's current parent value and that parent's state/delta history
must be subject to the corresponding gate. Reward history is masked, and history
cannot drive a separate gate-head bypass. Hard-masking a parent must eliminate
its direct state/history influence on the child prediction. This says nothing
about indirect statistical proxies among the other observed variables.

The full agent cannot consume hidden regime labels, shift events, true graphs or
future observations. The hidden one-time key-drain flag makes the eight observed
factors partially observed. Reference graphs are observable transition-dependency
proxy annotations, not an exact fully observed Markov SCM. Report this graph
interpretation with structural scores.

Main/quick training use state MSE weight 1.0 and Gaussian NLL weight 0.1. The
controlled component configuration fixes the same weights before inspecting
query results. Report these as a joint accuracy/calibration objective, not an
unchanged objective from v0.8.

Repair sampling/optimization uses isolated randomness. Rejected proposals restore
parameters and preserve caller RNG state; accepted parameter changes may affect
later behavior. MSE must improve on target nodes and diagnosed actions, with NLL
calibration and unaffected-node guards. Sufficient evidence means at least 8
training and 4 chronological validation transitions, including at least 2/1 of
each diagnosed action. Repair validation excludes extra repair gradients only;
ordinary online training may already have used these transitions. It is not a
globally untouched test set. Fresh query tasks provide a stronger separate test.

The action/node detector disarms after an alarm and requires consecutive normal
evidence before rearming. It suppresses repeated reports of continuing evidence;
it does not establish a calibrated false-alarm probability. Back-to-back changes
without residual recovery can be missed. Include `rearm_steps=0` as a detector
ablation, and measure delay/misses alongside reductions in repeat alarms.

## Required reporting and decision criteria

- Task success and return overall and by mechanism, especially fragile_bridge.
- Observable activations, detection/miss rate, delay, no-shift alarms, pre-event
  alarms and post-event repeats separately; node F1 and exact localization.
- Off-diagonal graph precision/recall/F1, SHD and AP by action/mechanism. A union
  score alone cannot establish mechanism-specific recovery.
- Repair candidates, evidence deferrals, attempts, rejections and acceptances;
  per-action sample coverage, MSE/NLL changes and collateral degradation.
- Actual interactions, active actions, optimization steps, time and memory.
- Full vs no-repair and other prespecified paired effects with intervals; null
  or negative results are retained. A gain vs frozen alone is insufficient.

Use at least five independent training seeds for a main paper claim; freeze the
comparison family and multiplicity handling before final tests. One-checkpoint
episode/session uncertainty is conditional on that checkpoint. Stronger
model-based/adaptive baselines and held-out mechanisms/compositions remain
additional experiments. The preliminary pilot is not a substitute.
