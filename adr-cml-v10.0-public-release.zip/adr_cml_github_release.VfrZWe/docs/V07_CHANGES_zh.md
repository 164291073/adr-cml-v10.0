# ADR-CML v0.7 改进说明

## 1. 为什么需要 v0.7

v0.6 已经解决日志重复、稀疏门饱和和评估日程不配对等工程问题，但单种子
100000 步结果仍暴露出四个科学问题：

1. `full` 与 `diagnose_no_repair` 的回报差只有 0.010，置信区间跨过 0，不能证明
   Repair 产生独立收益。
2. `full` 每回合约使用 2.41 个主动探测动作，而 `online_only` 约为 1.36 个，
   因此性能提升可能来自额外探测预算。
3. 变化检测率约为 0.34，假告警率约为 41.36/1000 步，诊断精确匹配率只有
   0.06；原检测器容易把不同动作固有的误差尺度误认为机制变化。
4. v0.6 的 Oracle 在隐藏图切换时触发，而不是在变化机制产生可观测后果时触发，
   因此不是可靠上界。人工 true graph 也没有完整覆盖动作前置条件造成的状态依赖。

## 2. v0.7 的核心修改

### 2.1 可观测机制事件

`mechanism_event` 现在只在当前转移结果与 base 机制的结果实际不同时出现。例如，
fragile bridge 在能量和 shield 已满足时不会被记作可检测变化；失败时才把
`energy`、`bridge` 和 `crossed` 标记为受影响 child。

### 2.2 正确的 Oracle 时机

`oracle_repair` 在首次可观测机制事件上触发，并只提供该事件真实受影响的 child。
同一 child 在一个 episode 中只触发一次 Oracle，避免重复失败动作被计为大量
Oracle 告警。

### 2.3 独立 episode 适应

平衡评估默认在每个 episode 开始时重新加载同一个训练 checkpoint。这样一个
regime 的在线更新不会污染下一个 regime，能够测量单次长任务内的适应收益。
如需研究跨 episode 持续学习，可显式使用 `--continual-eval`。

### 2.4 matched_active 预算对照

新增 `matched_active`：先运行 `full`，记录其每个配对 episode 的告警时刻；随后
在同一时刻重放相同的主动探索 boost，但关闭诊断与修复。它用于区分：

- `full - matched_active`：诊断和 Repair 超出纯探测预算的贡献；
- `matched_active - online_only`：增加探测预算本身的贡献；
- `full - diagnose_no_repair`：Repair 的直接贡献。

### 2.5 动作条件检测基线

检测器为每个 action 分别维护 median/MAD 和 EMA 误差基线。主动 intervention
与 counterfactual probe 不更新检测参考，也不会直接触发告警。这样可减少
forge/open/cross 等动作之间误差尺度差异造成的假告警和 `key` 节点偏置。

### 2.6 延迟共识定位与严格修复验证

Repair 等待 8 个环境步，并使用窗口内归一化定位分数的中位数重新选择节点。
Oracle 节点不被学习定位覆盖。验证集由固定、无重复的最新 post-change 转移组成；
仅当目标节点损失至少改善 2%，且非目标节点退化不超过 1% 时接受修复，否则恢复
教师模型。

### 2.7 与转移方程一致的真值图

环境现在输出 `[action, parent, child]` action-conditioned SCM。前置条件控制的
资源变化也属于真实依赖，例如 build/forge 中的 `material -> energy`，以及
fragile cross 中的 `shield -> crossed`。结果同时报告 union graph 和
action-conditioned graph，避免 union 指标掩盖动作图错误。

### 2.8 多随机种子汇总

新增：

- `scripts/run_paper_seed_4090.sh`
- `scripts/run_multiseed_4090.sh`
- `python -m adrcml.aggregate_seeds`

最终论文应至少运行 5 个独立训练种子。episode bootstrap 只反映固定 checkpoint
的测试不确定性，不能替代训练种子方差。

## 3. v0.7 成功标准

不应预先保证数值一定提高。建议至少检查：

1. `full` 是否显著优于 `matched_active` 和 `diagnose_no_repair`；
2. `oracle_repair` 是否不再显著差于 `full`；
3. 假告警率是否明显低于 v0.6 的约 41/1000 步；
4. diagnosis F1 和 exact match 是否提升，特别是 `fragile_bridge`；
5. action-conditioned graph F1 是否随训练增加；
6. 五种子层面的 `full - candidate` 置信区间是否排除 0。

如果 `full` 仍不优于 `matched_active` 或 `diagnose_no_repair`，应把论文主张调整为
“检测触发的主动探索”，不能宣称局部因果修复是性能提升来源。
