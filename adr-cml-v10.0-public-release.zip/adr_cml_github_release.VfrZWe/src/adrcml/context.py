"""History features formed exclusively from already observed transitions.

Call ``vector`` before acting/storing a transition and ``update`` only after its
outcome arrives. No regime labels, true graphs, or current transition outcomes
are needed when making a prediction.

The stable row layout is [state, action one-hot, next_state - state, reward].
The vector is [window mean, most recent row]. A v0.9 world model masks both
state and delta history with each child's parent gates and excludes reward
history. The reward slot is retained in this raw record for layout continuity;
it must never be passed into an unconstrained transition mechanism.
"""
from __future__ import annotations

from collections import deque
from typing import Any

import numpy as np


class HistoryContext:
    def __init__(self, state_dim: int, action_dim: int, window: int = 8) -> None:
        self.state_dim = int(state_dim)
        self.action_dim = int(action_dim)
        self.window = int(window)
        if min(self.state_dim, self.action_dim, self.window) < 1:
            raise ValueError("state_dim, action_dim, and window must be positive")
        self.feature_dim = 2 * self.state_dim + self.action_dim + 1
        self.context_dim = 2 * self.feature_dim
        self._history: deque[np.ndarray] = deque(maxlen=self.window)

    def reset(self) -> None:
        self._history.clear()

    def vector(self) -> np.ndarray:
        if not self._history:
            return np.zeros(self.context_dim, dtype=np.float32)
        rows = np.stack(self._history)
        return np.concatenate([rows.mean(axis=0), rows[-1]]).astype(np.float32)

    def update(
        self, state: np.ndarray, action: int, reward: float, next_state: np.ndarray
    ) -> None:
        state = np.asarray(state, dtype=np.float32)
        next_state = np.asarray(next_state, dtype=np.float32)
        if state.shape != (self.state_dim,) or next_state.shape != (self.state_dim,):
            raise ValueError("transition state shape does not match history state_dim")
        if not 0 <= int(action) < self.action_dim:
            raise ValueError("action is outside the history action space")
        one_hot = np.zeros(self.action_dim, dtype=np.float32)
        one_hot[int(action)] = 1.0
        row = np.concatenate([state, one_hot, next_state - state, [reward]]).astype(np.float32)
        if not np.isfinite(row).all():
            raise ValueError("history transitions must be finite")
        self._history.append(row.copy())

    def state_dict(self) -> dict[str, Any]:
        return {
            "state_dim": self.state_dim,
            "action_dim": self.action_dim,
            "window": self.window,
            "history": np.stack(self._history).copy() if self._history else np.empty((0, self.feature_dim), dtype=np.float32),
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        if int(state["state_dim"]) != self.state_dim or int(state["action_dim"]) != self.action_dim:
            raise ValueError("saved history dimensions do not match")
        if int(state["window"]) != self.window:
            raise ValueError("saved history window does not match")
        rows = np.asarray(state["history"], dtype=np.float32)
        if rows.ndim != 2 or rows.shape[1] != self.feature_dim or not np.isfinite(rows).all():
            raise ValueError("saved history has invalid shape or values")
        self.reset()
        for row in rows[-self.window:]:
            self._history.append(row.copy())
