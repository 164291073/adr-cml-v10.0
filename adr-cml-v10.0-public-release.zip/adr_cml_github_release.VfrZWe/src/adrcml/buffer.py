from __future__ import annotations

from dataclasses import dataclass
import copy
from typing import Any

import numpy as np


@dataclass
class TransitionBatch:
    state: Any
    action: Any
    reward: Any
    next_state: Any
    done: Any
    valid_action_mask: Any | None = None
    valid_mask_known: Any | None = None
    context: Any | None = None


class ReplayBuffer:
    def __init__(
        self,
        capacity: int,
        state_dim: int,
        seed: int = 0,
        action_dim: int | None = None,
        context_dim: int = 0,
    ) -> None:
        self.capacity = int(capacity)
        self.state_dim = int(state_dim)
        self.action_dim = None if action_dim is None else int(action_dim)
        self.context_dim = int(context_dim)
        if self.context_dim < 0:
            raise ValueError("context_dim must be nonnegative")
        self.contexts = np.zeros((capacity, self.context_dim), dtype=np.float32)
        self.rng = np.random.default_rng(seed)
        self.states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.actions = np.zeros(capacity, dtype=np.int64)
        self.rewards = np.zeros(capacity, dtype=np.float32)
        self.next_states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.dones = np.zeros(capacity, dtype=np.float32)
        self.regimes = np.full(capacity, "unknown", dtype=object)
        self.steps = np.zeros(capacity, dtype=np.int64)
        self.valid_action_masks = (
            None
            if self.action_dim is None
            else np.zeros((capacity, self.action_dim), dtype=np.float32)
        )
        self.valid_mask_known = np.zeros(capacity, dtype=bool)
        self.position = 0
        self.size = 0

    def __len__(self) -> int:
        return self.size

    def add(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        regime: str = "unknown",
        step: int = 0,
        valid_action_mask: np.ndarray | None = None,
        context: np.ndarray | None = None,
    ) -> None:
        i = self.position
        self.states[i] = state
        self.actions[i] = action
        self.rewards[i] = reward
        self.next_states[i] = next_state
        self.dones[i] = float(done)
        self.regimes[i] = regime
        self.steps[i] = step
        if context is None:
            self.contexts[i].fill(0.0)
        else:
            row_context = np.asarray(context, dtype=np.float32)
            if row_context.shape != (self.context_dim,):
                raise ValueError("context does not match replay context_dim")
            self.contexts[i] = row_context
        if valid_action_mask is not None:
            mask = np.asarray(valid_action_mask, dtype=np.float32)
            if self.valid_action_masks is None or mask.shape != (self.action_dim,):
                raise ValueError("valid_action_mask does not match replay action_dim")
            self.valid_action_masks[i] = mask
            self.valid_mask_known[i] = True
        else:
            if self.valid_action_masks is not None:
                self.valid_action_masks[i].fill(0.0)
            self.valid_mask_known[i] = False
        self.position = (self.position + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def _physical_indices(self) -> np.ndarray:
        if self.size < self.capacity:
            return np.arange(self.size)
        return np.concatenate([np.arange(self.position, self.capacity), np.arange(0, self.position)])

    def sample_indices(
        self,
        batch_size: int,
        recent: bool = False,
        before_step: int | None = None,
        after_step: int | None = None,
        informative_fraction: float = 0.0,
    ) -> np.ndarray:
        if self.size == 0:
            raise ValueError("Cannot sample an empty replay buffer")
        count = min(int(batch_size), self.size)
        physical = self._physical_indices()
        if before_step is not None:
            physical = physical[self.steps[physical] < int(before_step)]
        if after_step is not None:
            physical = physical[self.steps[physical] >= int(after_step)]
        if physical.size == 0:
            raise ValueError("No replay transitions satisfy the requested time window")
        if recent:
            pool = physical[-min(len(physical), max(count * 4, count)) :]
        else:
            pool = physical
        fraction = float(np.clip(informative_fraction, 0.0, 1.0))
        informative_count = min(count, int(round(count * fraction)))
        delta = np.max(np.abs(self.next_states[pool] - self.states[pool]), axis=1)
        informative_pool = pool[delta > 1e-6]
        if informative_count > 0 and informative_pool.size > 0:
            selected_info = self.rng.choice(
                informative_pool,
                size=informative_count,
                replace=informative_pool.size < informative_count,
            )
        else:
            selected_info = np.empty(0, dtype=np.int64)
        remaining = count - selected_info.size
        selected_rest = self.rng.choice(pool, size=remaining, replace=len(pool) < remaining)
        selected = np.concatenate([selected_info, selected_rest])
        self.rng.shuffle(selected)
        return selected

    def sample(
        self,
        batch_size: int,
        device: str,
        recent: bool = False,
        before_step: int | None = None,
        after_step: int | None = None,
        informative_fraction: float = 0.0,
    ) -> TransitionBatch:
        import torch

        idx = self.sample_indices(
            batch_size,
            recent=recent,
            before_step=before_step,
            after_step=after_step,
            informative_fraction=informative_fraction,
        )
        return self.batch_from_indices(idx, device)

    def batch_from_indices(
        self,
        indices: np.ndarray | list[int],
        device: str,
    ) -> TransitionBatch:
        """Create a deterministic batch from exact physical buffer indices."""

        import torch

        idx = np.asarray(indices, dtype=np.int64).reshape(-1)
        if idx.size == 0:
            raise ValueError("indices must be non-empty")
        if np.any(idx < 0) or np.any(idx >= self.capacity):
            raise IndexError("replay index out of range")
        valid_masks = None
        known = None
        if self.valid_action_masks is not None:
            valid_masks = torch.as_tensor(self.valid_action_masks[idx], device=device)
            known = torch.as_tensor(self.valid_mask_known[idx], device=device)
        return TransitionBatch(
            state=torch.as_tensor(self.states[idx], device=device),
            action=torch.as_tensor(self.actions[idx], device=device),
            reward=torch.as_tensor(self.rewards[idx], device=device),
            next_state=torch.as_tensor(self.next_states[idx], device=device),
            done=torch.as_tensor(self.dones[idx], device=device),
            valid_action_mask=valid_masks,
            valid_mask_known=known,
            context=(torch.as_tensor(self.contexts[idx], device=device) if self.context_dim else None),
        )

    def state_dict(self) -> dict[str, Any]:
        idx = self._physical_indices()
        return {
            "capacity": self.capacity,
            "state_dim": self.state_dim,
            "action_dim": self.action_dim,
            "context_dim": self.context_dim,
            "contexts": self.contexts[idx].copy(),
            "states": self.states[idx],
            "actions": self.actions[idx],
            "rewards": self.rewards[idx],
            "next_states": self.next_states[idx],
            "dones": self.dones[idx],
            "regimes": self.regimes[idx].tolist(),
            "steps": self.steps[idx],
            "valid_action_masks": (
                None if self.valid_action_masks is None else self.valid_action_masks[idx]
            ),
            "valid_mask_known": self.valid_mask_known[idx],
            "rng_state": copy.deepcopy(self.rng.bit_generator.state),
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        states = np.asarray(state.get("states", []), dtype=np.float32)
        if states.ndim != 2 or (states.size and states.shape[1] != self.state_dim):
            raise ValueError("Replay state dimension does not match the current agent")
        keep = min(len(states), self.capacity)
        start = len(states) - keep
        saved_context_dim = int(state.get("context_dim", 0))
        if saved_context_dim != self.context_dim:
            raise ValueError("Replay context dimension does not match the current agent")
        self.contexts.fill(0.0)
        self.states.fill(0.0)
        self.actions.fill(0)
        self.rewards.fill(0.0)
        self.next_states.fill(0.0)
        self.dones.fill(0.0)
        self.regimes[:] = "unknown"
        self.steps.fill(0)
        if self.valid_action_masks is not None:
            self.valid_action_masks.fill(0.0)
        self.valid_mask_known.fill(False)
        if keep:
            self.states[:keep] = states[start:]
            if self.context_dim:
                saved_contexts = np.asarray(state["contexts"], dtype=np.float32)
                if saved_contexts.shape != (len(states), self.context_dim):
                    raise ValueError("Saved replay contexts have incorrect shape")
                self.contexts[:keep] = saved_contexts[start:]
            self.actions[:keep] = np.asarray(state["actions"], dtype=np.int64)[start:]
            self.rewards[:keep] = np.asarray(state["rewards"], dtype=np.float32)[start:]
            self.next_states[:keep] = np.asarray(state["next_states"], dtype=np.float32)[start:]
            self.dones[:keep] = np.asarray(state["dones"], dtype=np.float32)[start:]
            regimes = list(state.get("regimes", ["unknown"] * len(states)))[start:]
            self.regimes[:keep] = regimes
            self.steps[:keep] = np.asarray(state["steps"], dtype=np.int64)[start:]
            saved_masks = state.get("valid_action_masks")
            if saved_masks is not None and self.valid_action_masks is not None:
                saved_masks = np.asarray(saved_masks, dtype=np.float32)
                if saved_masks.shape[1] != self.action_dim:
                    raise ValueError("Replay action dimension does not match the current agent")
                self.valid_action_masks[:keep] = saved_masks[start:]
                known = np.asarray(
                    state.get("valid_mask_known", np.ones(len(states), dtype=bool)),
                    dtype=bool,
                )
                self.valid_mask_known[:keep] = known[start:]
        self.size = keep
        self.position = keep % self.capacity
        if "rng_state" in state:
            self.rng.bit_generator.state = copy.deepcopy(state["rng_state"])


class EpisodeReplay:
    """Small pure-Python trajectory store used by benchmark adapters."""

    def __init__(self) -> None:
        self.episodes: list[list[dict[str, Any]]] = []
        self.current: list[dict[str, Any]] = []

    def add(self, transition: dict[str, Any], done: bool) -> None:
        self.current.append(transition)
        if done:
            self.episodes.append(self.current)
            self.current = []
