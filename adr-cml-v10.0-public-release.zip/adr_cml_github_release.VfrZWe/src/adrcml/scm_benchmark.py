"""Independent modular-regression component audit, NOT the ADR-CML neural agent.

The learner knows the separable feature dictionary but neither its nonzero
parents nor which mechanism changed. Randomized state/action interventions
make this a deliberately identifiable synthetic setting. The simulator and
true changes are used for generation/scoring and the explicitly named oracle.
No diagnostic, solver or acceptance API receives a simulator or query set.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import platform
import time
import traceback
from dataclasses import asdict, dataclass, replace
from pathlib import Path

import numpy as np
import torch

from adrcml import __version__

SCOPE = "synthetic_modular_regression_component_not_full_agent"
SCENARIOS = ("no_change", "coefficient_shift", "edge_addition")
MODES = ("no_repair", "diagnosed_local", "global_same_steps",
         "global_matched_parameter_work", "global_replay", "dense_global", "random_local", "oracle_local")


@dataclass(frozen=True)
class Protocol:
    name: str = "v10_independent_scm_component_v2"
    scope: str = SCOPE
    seeds: tuple[int, ...] = (11, 23, 37)
    families: tuple[str, ...] = ("linear", "nonlinear")
    state_dim: int = 8
    action_dim: int = 3
    train_samples: int = 1536
    calibration_samples: int = 384
    diagnosis_samples: int = 192
    support_samples: int = 96
    acceptance_samples: int = 192
    query_samples: int = 512
    query_trajectories: int = 128
    horizons: tuple[int, ...] = (1, 8, 32)
    pretrain_iterations: int = 400
    repair_iterations: int = 160
    group_penalty: float = 0.002
    ridge_penalty: float = 0.0001
    noise_std: float = 0.03
    diagnosis_z: float = 3.5
    diagnosis_absolute_floor: float = 0.0002
    acceptance_relative_gain: float = 0.02
    collateral_relative_tolerance: float = 0.01
    collateral_absolute_tolerance: float = 0.0001
    replay_anchor_samples: int = 512
    edge_threshold: float = 0.04
    bootstrap_samples: int = 10000
    bootstrap_seed: int = 93027
    primary_horizon: int = 8

    @classmethod
    def preset(cls, name: str) -> "Protocol":
        if name == "quick":
            return cls()
        if name != "paper":
            raise ValueError(name)
        return cls(seeds=(11, 23, 37, 51, 71, 89, 101, 127, 149, 173),
                   train_samples=6144, calibration_samples=1536,
                   diagnosis_samples=384, support_samples=192,
                   acceptance_samples=768, query_samples=4096,
                   query_trajectories=512, pretrain_iterations=800,
                   repair_iterations=320, replay_anchor_samples=1024)

    def validate(self) -> None:
        if not self.seeds or len(set(self.seeds)) != len(self.seeds):
            raise ValueError("Provide distinct independent seeds")
        if self.state_dim < 4 or self.action_dim < 1:
            raise ValueError("state_dim >= 4 and action_dim >= 1 required")
        if not self.families or any(f not in ("linear", "nonlinear") for f in self.families):
            raise ValueError("Unknown or empty simulator family")
        for name in ("train_samples", "calibration_samples", "diagnosis_samples", "support_samples", "acceptance_samples"):
            if getattr(self, name) < 2 * self.action_dim:
                raise ValueError(f"{name} needs at least two samples per action")
        if self.primary_horizon not in self.horizons or min(self.horizons) < 1:
            raise ValueError("Invalid horizons")
        if min(self.pretrain_iterations, self.repair_iterations, self.query_samples,
               self.query_trajectories, self.bootstrap_samples) < 1:
            raise ValueError("Counts/iterations must be positive")
        if not 0 < self.acceptance_relative_gain < 1 or self.noise_std < 0:
            raise ValueError("Invalid gain/noise")


def stream_rng(seed: int, *labels: str) -> np.random.Generator:
    tag = hashlib.sha256("/".join(labels).encode()).digest()
    words = np.frombuffer(tag[:16], dtype="<u4").tolist()
    return np.random.default_rng(np.random.SeedSequence([seed, *words]))


def canonical_hash(value: dict) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def features_np(state: np.ndarray, family: str) -> np.ndarray:
    second = np.zeros_like(state) if family == "linear" else np.tanh(2.0 * state)
    return np.concatenate((np.stack((state, second), -1).reshape(len(state), -1),
                           np.ones((len(state), 1))), 1)


@dataclass(frozen=True)
class Simulator:
    """Exact fully observable Markov transition with known action-parent graph."""
    coefficients: np.ndarray  # [action, 2 * parent + intercept, child]
    family: str
    changed_pairs: tuple[tuple[int, int], ...] = ()

    def mean(self, state: np.ndarray, action: np.ndarray) -> np.ndarray:
        return np.einsum("bf,bfc->bc", features_np(state, self.family), self.coefficients[action])

    def graph(self) -> np.ndarray:
        a, f, d = self.coefficients.shape
        return np.linalg.norm(self.coefficients[:, :-1].reshape(a, d, 2, d), axis=2) > 1e-12

    def contraction_bound(self) -> float:
        a, f, d = self.coefficients.shape
        groups = np.abs(self.coefficients[:, :-1].reshape(a, d, 2, d))
        return float((groups[:, :, 0] + 2 * groups[:, :, 1]).sum(1).max())


def make_simulator(seed: int, family: str, protocol: Protocol) -> Simulator:
    rng = stream_rng(seed, family, "simulator")
    d, a = protocol.state_dim, protocol.action_dim
    coef = np.zeros((a, 2 * d + 1, d), dtype=np.float64)
    for action in range(a):
        for child in range(d):
            parents = rng.choice(np.delete(np.arange(d), child), 2, replace=False)
            coef[action, 2 * child, child] = 0.25
            for parent in parents:
                sign = float(rng.choice((-1, 1)))
                coef[action, 2 * parent, child] = sign * rng.uniform(0.12, 0.18)
                if family == "nonlinear":
                    coef[action, 2 * parent + 1, child] = sign * rng.uniform(0.025, 0.045)
            coef[action, -1, child] = rng.uniform(-0.15, 0.15)
    result = Simulator(coef, family)
    assert result.contraction_bound() < 1
    return result


def shift_simulator(base: Simulator, seed: int, scenario: str) -> Simulator:
    if scenario == "no_change":
        return base
    if scenario not in SCENARIOS:
        raise ValueError(scenario)
    rng = stream_rng(seed, base.family, scenario, "shift")
    coef = base.coefficients.copy()
    a, _, d = coef.shape
    action, child = int(rng.integers(a)), int(rng.integers(d))
    graph = base.graph()[action, :, child]
    if scenario == "coefficient_shift":
        candidates = np.flatnonzero(graph & (np.arange(d) != child))
        parent = int(rng.choice(candidates))
        coef[action, 2 * parent:2 * parent + 2, child] *= -1
        # A real transition mechanism change; graph itself stays identical.
    else:
        parent = int(rng.choice(np.flatnonzero(~graph & (np.arange(d) != child))))
        # Maximum previous contraction 0.79 + new 0.16 = 0.95 < 1.
        coef[action, 2 * parent, child] = float(rng.choice((-1, 1))) * 0.16
    result = Simulator(coef, base.family, ((action, child),))
    assert result.contraction_bound() < 1
    return result


def draw_data(simulator: Simulator, seed: int, stream: str, count: int, noise: float) -> dict:
    rng = stream_rng(seed, simulator.family, stream)
    d = simulator.coefficients.shape[-1]
    a = simulator.coefficients.shape[0]
    state = rng.uniform(-1, 1, (count, d))
    # Balanced random actions independent of each coordinate intervention.
    action = rng.permutation(np.arange(count) % a)
    mean = simulator.mean(state, action)
    target = mean + rng.normal(0, noise, mean.shape)
    return {"state": state, "action": action, "next_state": target}


def fingerprint(data: dict) -> str:
    digest = hashlib.sha256()
    for key in sorted(data):
        value = np.ascontiguousarray(data[key])
        digest.update(key.encode())
        digest.update(str(value.shape).encode())
        digest.update(value.tobytes())
    return digest.hexdigest()


@dataclass
class ModularRegressor:
    coefficients: torch.Tensor
    family: str

    @classmethod
    def empty(cls, protocol: Protocol, family: str, device: str) -> "ModularRegressor":
        # Double precision prevents solver tolerance becoming the benchmark.
        return cls(torch.zeros(protocol.action_dim, 2 * protocol.state_dim + 1,
                               protocol.state_dim, dtype=torch.float64, device=device), family)

    def copy(self) -> "ModularRegressor":
        return ModularRegressor(self.coefficients.clone(), self.family)

    def predict(self, data: dict) -> np.ndarray:
        x = torch.as_tensor(features_np(data["state"], self.family),
                            dtype=self.coefficients.dtype, device=self.coefficients.device)
        act = torch.as_tensor(data["action"], dtype=torch.long, device=x.device)
        return torch.einsum("bf,bfc->bc", x, self.coefficients[act]).cpu().numpy()

    def graph_scores(self) -> np.ndarray:
        a, _, d = self.coefficients.shape
        return torch.linalg.vector_norm(self.coefficients[:, :-1].reshape(a, d, 2, d), dim=2).cpu().numpy()


def fit(model: ModularRegressor, data: dict, iterations: int, group_penalty: float,
        ridge_penalty: float, target_pairs: list[tuple[int, int]] | None = None) -> dict:
    """FISTA on squared error + group lasso; targets cannot share parameters.

    Each action/child is one mechanism. Non-target coefficients remain bitwise
    unchanged. Iterations and number of target groups are recorded separately;
    equal sample counts/iterations are NOT claimed to mean equal GPU FLOPs.
    """
    start = time.perf_counter()
    coef = model.coefficients
    a, f, d = coef.shape
    selected = [(i, j) for i in range(a) for j in range(d)] if target_pairs is None else list(target_pairs)
    if not selected:
        return {"iterations": 0, "target_pairs": 0, "coefficient_update_budget": 0, "seconds": 0.0}
    if len(set(selected)) != len(selected) or any(i < 0 or i >= a or j < 0 or j >= d for i, j in selected):
        raise ValueError("Invalid or duplicate target pairs")
    device, dtype = coef.device, coef.dtype
    x = torch.as_tensor(features_np(data["state"], model.family), device=device, dtype=dtype)
    y = torch.as_tensor(data["next_state"], device=device, dtype=dtype)
    masks = [np.asarray(data["action"]) == action for action in range(a)]
    if any(mask.sum() < 2 for mask in masks):
        raise ValueError("At least two observations per action required")
    cov = torch.stack([x[m].T @ x[m] / int(m.sum()) for m in masks])
    cross = torch.stack([x[m].T @ y[m] / int(m.sum()) for m in masks])
    ridge = torch.eye(f, device=device, dtype=dtype) * ridge_penalty
    ridge[-1, -1] = 0
    hess = cov + ridge
    # Use action-specific Lipschitz constants for 1/2 mean squared error.
    step = 1.0 / torch.linalg.eigvalsh(hess).amax(-1).clamp_min(1e-12)
    actions = torch.as_tensor([p[0] for p in selected], device=device)
    children = torch.as_tensor([p[1] for p in selected], device=device)
    h = hess[actions]
    c = cross[actions, :, children]
    lr = step[actions, None]
    if "target_weight" in data:
        # Replay anchors retain only diagnosis-protected mechanisms. Weighted
        # covariances are per mechanism, never use a true changed-node label.
        w = torch.as_tensor(data["target_weight"], device=device, dtype=dtype)
        if w.shape != y.shape or bool((w < 0).any()):
            raise ValueError("Invalid per-target sample weights")
        hs, cs = [], []
        for action, child in selected:
            mask = masks[action]
            weights = w[mask, child]
            denom = weights.sum().clamp_min(1e-12)
            hs.append(x[mask].T @ (weights[:, None] * x[mask]) / denom + ridge)
            cs.append(x[mask].T @ (weights * y[mask, child]) / denom)
        h, c = torch.stack(hs), torch.stack(cs)
        lr = 1 / torch.linalg.eigvalsh(h).amax(-1).clamp_min(1e-12)[:, None]
    current = coef[actions, :, children].clone()
    extrapolated = current.clone()
    momentum = 1.0
    for _ in range(iterations):
        next_coef = extrapolated - lr * (torch.bmm(h, extrapolated.unsqueeze(-1)).squeeze(-1) - c)
        groups = next_coef[:, :-1].reshape(len(selected), d, 2)
        norm = torch.linalg.vector_norm(groups, dim=-1, keepdim=True)
        shrink = (1 - group_penalty * lr[:, :, None] / norm.clamp_min(1e-30)).clamp_min(0)
        next_coef[:, :-1] = (groups * shrink).reshape(len(selected), -1)
        if model.family == "linear":
            next_coef[:, 1:-1:2] = 0
        next_momentum = (1 + math.sqrt(1 + 4 * momentum * momentum)) / 2
        extrapolated = next_coef + (momentum - 1) / next_momentum * (next_coef - current)
        current, momentum = next_coef, next_momentum
    if not bool(torch.isfinite(current).all()):
        raise FloatingPointError("Nonfinite fit; retain failed seed")
    model.coefficients[actions, :, children] = current
    return {"iterations": iterations, "target_pairs": len(selected),
            "coefficient_update_budget": iterations * len(selected) * f,
            "fit_rows": len(data["state"]),
            "effective_scalar_targets": float(sum(np.asarray(data.get("target_weight", np.ones_like(data["next_state"])))[masks[action], child].sum() for action, child in selected)),
            "seconds": time.perf_counter() - start,
            "budget_definition": "solver_iterations_times_updated_action_child_parameters_not_measured_FLOPs"}


def errors(model: ModularRegressor, data: dict) -> np.ndarray:
    return (model.predict(data) - data["next_state"]) ** 2


def diagnose(model: ModularRegressor, calibration: dict, evidence: dict, protocol: Protocol) -> dict:
    """Fixed action-conditioned residual mean shift test; only observed data."""
    old, new = errors(model, calibration), errors(model, evidence)
    a, _, d = model.coefficients.shape
    selected, increase, thresholds = [], np.zeros((a, d)), np.zeros((a, d))
    for action in range(a):
        left = old[calibration["action"] == action]
        right = new[evidence["action"] == action]
        if min(len(left), len(right)) < 2:
            raise ValueError("Insufficient diagnostic sample count")
        increase[action] = right.mean(0) - left.mean(0)
        se = np.sqrt(left.var(0, ddof=1) / len(left) + right.var(0, ddof=1) / len(right))
        thresholds[action] = np.maximum(protocol.diagnosis_absolute_floor, protocol.diagnosis_z * se)
        selected += [(action, int(child)) for child in np.flatnonzero(increase[action] > thresholds[action])]
    return {"pairs": [list(pair) for pair in selected], "mean_error_increase": increase.tolist(),
            "thresholds": thresholds.tolist(), "uses_true_change_labels": False,
            "rule": "fixed_residual_mean_increase_gt_max_absolute_floor_or_z_times_empirical_SE",
            "calibration_caveat": "heuristic_normal_approximation_not_finite_sample_FWER_guarantee"}


def accept_candidate(base: ModularRegressor, candidate: ModularRegressor, validation: dict,
                     pairs: list[tuple[int, int]], minimum_gain: float,
                     collateral_relative_tolerance: float = 0.01,
                     collateral_absolute_tolerance: float = 0.0001) -> dict:
    if not pairs:
        return {"accepted": False, "reason": "no_diagnosed_targets", "acceptance_pairs": [], "uses_query": False}
    before, after = errors(base, validation), errors(candidate, validation)
    a, _, d = base.coefficients.shape
    initial, final, counts = [], [], []
    for action, child in pairs:
        mask = validation["action"] == action
        if mask.sum() < 2:
            raise ValueError("Insufficient acceptance data")
        initial.append(float(before[mask, child].mean()))
        final.append(float(after[mask, child].mean()))
        counts.append(int(mask.sum()))
    gain = 1 - float(np.mean(final)) / max(float(np.mean(initial)), 1e-30)
    protected = [(action, child) for action in range(a) for child in range(d) if (action, child) not in pairs]
    before_protected, after_protected, violations = [], [], []
    for action, child in protected:
        mask = validation["action"] == action
        old, new = float(before[mask, child].mean()), float(after[mask, child].mean())
        before_protected.append(old)
        after_protected.append(new)
        if new > old * (1 + collateral_relative_tolerance) + collateral_absolute_tolerance:
            violations.append([action, child])
    gain_ok = math.isfinite(gain) and gain >= minimum_gain
    accepted = gain_ok and not violations
    return {"accepted": bool(accepted),
            "reason": "heldout_gain_and_collateral_guard" if accepted else
                      ("insufficient_heldout_gain" if not gain_ok else "collateral_degradation"),
            "relative_validation_gain": gain, "before_target_mse": initial,
            "after_target_mse": final, "validation_counts_per_pair": counts,
            "acceptance_pairs": [list(p) for p in pairs], "protected_pairs": [list(p) for p in protected],
            "before_protected_mse": before_protected, "after_protected_mse": after_protected,
            "collateral_violations": violations,
            "collateral_guard": {"relative": collateral_relative_tolerance,
                                 "absolute": collateral_absolute_tolerance,
                                 "scope": "per_protected_action_child_heuristic_not_confidence_bound"},
            "uses_query": False}


def adapt(base: ModularRegressor, support: dict, validation: dict, pairs: list[tuple[int, int]],
          protocol: Protocol, iterations: int | None = None, dense: bool = False,
          acceptance_pairs: list[tuple[int, int]] | None = None) -> tuple[ModularRegressor, dict]:
    candidate = base.copy()
    fit_report = fit(candidate, support, protocol.repair_iterations if iterations is None else iterations,
                     0.0 if dense else protocol.group_penalty, protocol.ridge_penalty, pairs)
    tested_pairs = pairs if acceptance_pairs is None else acceptance_pairs
    decision = accept_candidate(base, candidate, validation, tested_pairs, protocol.acceptance_relative_gain,
                                protocol.collateral_relative_tolerance, protocol.collateral_absolute_tolerance)
    return (candidate if decision["accepted"] else base.copy()), {**decision, "fit": fit_report,
                                                                "requested_pairs": [list(p) for p in pairs]}


def replay_data(train: dict, support: dict, diagnosed_pairs: list[tuple[int, int]],
                seed: int, family: str, scenario: str, protocol: Protocol) -> dict:
    rng = stream_rng(seed, family, scenario, "replay_anchor_selection")
    count = min(protocol.replay_anchor_samples, len(train["state"]))
    indices = rng.choice(len(train["state"]), count, replace=False)
    result = {key: np.concatenate([support[key], train[key][indices]]) for key in support}
    weights = np.ones_like(result["next_state"])
    for action, child in diagnosed_pairs:
        mask = (result["action"] == action) & (np.arange(len(weights)) >= len(support["state"]))
        weights[mask, child] = 0.0
    result["target_weight"] = weights
    return result


def average_precision_ties(labels: np.ndarray, scores: np.ndarray) -> float | None:
    labels, scores = np.asarray(labels).astype(bool).ravel(), np.asarray(scores).ravel()
    if labels.sum() == 0:
        return None
    order = np.argsort(-scores, kind="stable")
    labels, scores = labels[order], scores[order]
    ends = np.r_[np.flatnonzero(scores[:-1] != scores[1:]), len(scores) - 1]
    tp = np.cumsum(labels)[ends]
    recall = tp / labels.sum()
    precision = tp / (ends + 1)
    return float(np.sum(np.diff(np.r_[0.0, recall]) * precision))


def graph_metrics(model: ModularRegressor, truth: np.ndarray, threshold: float) -> dict:
    score = model.graph_scores()
    d = score.shape[-1]
    mask = np.broadcast_to(~np.eye(d, dtype=bool), score.shape)
    actual, prediction = truth[mask], score[mask] >= threshold
    tp, fp, fn = int((actual & prediction).sum()), int((~actual & prediction).sum()), int((actual & ~prediction).sum())
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    return {"precision": precision, "recall": recall,
            "f1": 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.0,
            "directed_edge_hamming": fp + fn, "average_precision": average_precision_ties(actual, score[mask]),
            "threshold": threshold, "scope": "action_conditioned_off_diagonal_exact_simulator_graph"}


def rollout_queries(simulator: Simulator, seed: int, scenario: str, protocol: Protocol) -> dict:
    rng = stream_rng(seed, simulator.family, scenario, "query_rollout")
    d, a = simulator.coefficients.shape[-1], simulator.coefficients.shape[0]
    state = rng.uniform(-1, 1, (protocol.query_trajectories, d))
    actions = rng.integers(a, size=(max(protocol.horizons), len(state)))
    current, truth = state.copy(), []
    for action in actions:
        current = simulator.mean(current, action)
        truth.append(current.copy())
    return {"initial_state": state, "actions": actions, "truth": np.stack(truth)}


def evaluate_model(model: ModularRegressor, simulator: Simulator, query: dict,
                   rollouts: dict, protocol: Protocol) -> dict:
    prediction = model.predict(query)
    truth_mean = simulator.mean(query["state"], query["action"])
    per_pair = np.stack([((prediction - truth_mean)[query["action"] == a] ** 2).mean(0)
                         for a in range(protocol.action_dim)])
    change_mask = np.zeros_like(per_pair, dtype=bool)
    for pair in simulator.changed_pairs:
        change_mask[pair] = True
    current = rollouts["initial_state"].copy()
    rollout = {}
    for step, action in enumerate(rollouts["actions"], 1):
        current = model.predict({"state": current, "action": action})
        if step in protocol.horizons:
            sq = (current - rollouts["truth"][step - 1]) ** 2
            rollout[str(step)] = float(sq.mean())
    return {"query_noiseless_mse": float(((prediction - truth_mean) ** 2).mean()),
            "query_observed_mse": float(((prediction - query["next_state"]) ** 2).mean()),
            "query_changed_mechanisms_mse": float(per_pair[change_mask].mean()) if change_mask.any() else None,
            "query_unchanged_mechanisms_mse": float(per_pair[~change_mask].mean()),
            "recursive_noiseless_mse_by_horizon": rollout,
            "graph": graph_metrics(model, simulator.graph(), protocol.edge_threshold),
            "forecast_scope": "open_loop_conditional_mean_rollout_not_agent_task_success_or_return"}


def run_seed(seed: int, protocol: Protocol, device: str) -> list[dict]:
    rows = []
    for family in protocol.families:
        base_simulator = make_simulator(seed, family, protocol)
        train = draw_data(base_simulator, seed, "base_train", protocol.train_samples, protocol.noise_std)
        calibration = draw_data(base_simulator, seed, "base_calibration", protocol.calibration_samples, protocol.noise_std)
        sparse = ModularRegressor.empty(protocol, family, device)
        dense = ModularRegressor.empty(protocol, family, device)
        sparse_fit = fit(sparse, train, protocol.pretrain_iterations, protocol.group_penalty, protocol.ridge_penalty)
        dense_fit = fit(dense, train, protocol.pretrain_iterations, 0.0, protocol.ridge_penalty)
        all_pairs = list(itertools.product(range(protocol.action_dim), range(protocol.state_dim)))
        for scenario in SCENARIOS:
            simulator = shift_simulator(base_simulator, seed, scenario)
            streams = {
                "diagnosis": draw_data(simulator, seed, scenario + "/diagnosis", protocol.diagnosis_samples, protocol.noise_std),
                "support": draw_data(simulator, seed, scenario + "/support", protocol.support_samples, protocol.noise_std),
                "acceptance": draw_data(simulator, seed, scenario + "/acceptance", protocol.acceptance_samples, protocol.noise_std),
            }
            diagnosis = diagnose(sparse, calibration, streams["diagnosis"], protocol)
            selected = [tuple(pair) for pair in diagnosis["pairs"]]
            random_rng = stream_rng(seed, family, scenario, "random_localization")
            random_pairs = [all_pairs[i] for i in random_rng.choice(len(all_pairs), len(selected), replace=False)]
            # The matched-work arm rounds DOWN, never exceeding local coefficient updates.
            matched_iterations = protocol.repair_iterations * len(selected) // len(all_pairs)
            models, repairs = {"no_repair": sparse.copy()}, {"no_repair": {"accepted": False, "reason": "frozen"}}
            specifications = {
                "diagnosed_local": (sparse, selected, protocol.repair_iterations, False),
                "global_same_steps": (sparse, all_pairs, protocol.repair_iterations, False),
                "global_matched_parameter_work": (sparse, all_pairs, matched_iterations, False),
                "global_replay": (sparse, all_pairs, protocol.repair_iterations, False),
                "dense_global": (dense, all_pairs, protocol.repair_iterations, True),
                "random_local": (sparse, random_pairs, protocol.repair_iterations, False),
                "oracle_local": (sparse, list(simulator.changed_pairs), protocol.repair_iterations, False),
            }
            anchored_support = replay_data(train, streams["support"], selected, seed, family, scenario, protocol)
            for mode, (initial, pairs, iterations, is_dense) in specifications.items():
                if iterations == 0:
                    models[mode], repairs[mode] = initial.copy(), {"accepted": False, "reason": "zero_matched_budget",
                                                                "fit": {"iterations": 0, "coefficient_update_budget": 0}}
                else:
                    fit_data = anchored_support if mode == "global_replay" else streams["support"]
                    acceptance_targets = list(simulator.changed_pairs) if mode == "oracle_local" else selected
                    models[mode], repairs[mode] = adapt(initial, fit_data, streams["acceptance"], pairs,
                                                       protocol, iterations, is_dense, acceptance_targets)
                    repairs[mode]["acceptance_label_source"] = "true_labels_privileged_oracle" if mode == "oracle_local" else "common_residual_diagnosis"
                    repairs[mode]["support_rows"] = len(streams["support"]["state"])
                    repairs[mode]["additional_reused_base_train_anchor_rows"] = len(fit_data["state"]) - len(streams["support"]["state"])

            # Query values are materialized only AFTER all learner updates/acceptance.
            query = draw_data(simulator, seed, scenario + "/query", protocol.query_samples, protocol.noise_std)
            rollouts = rollout_queries(simulator, seed, scenario, protocol)
            stream_hashes = {"base_train": fingerprint(train), "base_calibration": fingerprint(calibration),
                             **{key: fingerprint(value) for key, value in streams.items()}, "query": fingerprint(query),
                             "query_rollout": fingerprint(rollouts)}
            if len(set(stream_hashes.values())) != len(stream_hashes):
                raise AssertionError("Data stream fingerprint collision")
            modes = {mode: {**evaluate_model(model, simulator, query, rollouts, protocol), "repair": repairs[mode]}
                     for mode, model in models.items()}
            rows.append({"seed": seed, "family": family, "scenario": scenario,
                         "diagnosis": diagnosis, "true_changed_pairs_evaluation_only": [list(p) for p in simulator.changed_pairs],
                         "stream_sha256": stream_hashes, "simulator_contraction_bound": simulator.contraction_bound(),
                         "pretraining": {"sparse": sparse_fit, "dense": dense_fit},
                         "modes": modes, "oracle_only_privileged_labels": True})
    return rows


def paired_seed_effect(differences: list[float], protocol: Protocol) -> dict:
    values = np.asarray(differences, dtype=float)
    if len(values) < 2:
        interval, p = None, None
    else:
        rng = stream_rng(protocol.bootstrap_seed, "seed_bootstrap")
        sampled = values[rng.integers(len(values), size=(protocol.bootstrap_samples, len(values)))].mean(1)
        interval = np.quantile(sampled, [0.025, 0.975]).tolist()
        if len(values) <= 16:
            signs = np.asarray(list(itertools.product((-1, 1), repeat=len(values))))
            p = float((np.abs((signs * values).mean(1)) >= abs(values.mean()) - 1e-15).mean())
        else:
            signs = rng.choice((-1, 1), size=(100000, len(values)))
            p = float((1 + (np.abs((signs * values).mean(1)) >= abs(values.mean()) - 1e-15).sum()) / (len(signs) + 1))
    return {"mean_baseline_minus_local": float(values.mean()) if len(values) else None,
            "per_seed_baseline_minus_local": values.tolist(), "paired_seed_bootstrap_ci95": interval,
            "two_sided_sign_flip_p": p, "positive_seed_count": int((values > 0).sum()),
            "n_independent_seeds": len(values), "unit": "independent_simulator_and_data_seed",
            "test_assumption": "paired_null_difference_symmetry_for_sign_flip",
            "ci_caveat": "descriptive_seed_bootstrap_small_n_not_a_publication_guarantee"}


def summarize(rows: list[dict], protocol: Protocol, failures: list[dict]) -> dict:
    summaries, primary = {}, {}
    for family in protocol.families:
        for scenario in SCENARIOS:
            subset = [row for row in rows if row["family"] == family and row["scenario"] == scenario]
            key = family + "/" + scenario
            if not subset:
                continue
            per_mode = {}
            for mode in MODES:
                m = [row["modes"][mode] for row in subset]
                per_mode[mode] = {"query_noiseless_mse_mean": float(np.mean([v["query_noiseless_mse"] for v in m])),
                                  "graph_f1_mean": float(np.mean([v["graph"]["f1"] for v in m])),
                                  "accepted_seed_count": sum(v["repair"]["accepted"] for v in m),
                                  "recursive_mse_mean": {str(h): float(np.mean([v["recursive_noiseless_mse_by_horizon"][str(h)] for v in m]))
                                                         for h in protocol.horizons}}
            comparisons = {}
            for baseline in MODES:
                if baseline == "diagnosed_local":
                    continue
                differences = [row["modes"][baseline]["recursive_noiseless_mse_by_horizon"][str(protocol.primary_horizon)]
                               - row["modes"]["diagnosed_local"]["recursive_noiseless_mse_by_horizon"][str(protocol.primary_horizon)] for row in subset]
                comparisons[baseline] = paired_seed_effect(differences, protocol)
                if scenario != "no_change" and baseline in ("no_repair", "global_matched_parameter_work", "global_replay", "dense_global"):
                    primary[key + "/vs_" + baseline] = comparisons[baseline]
            summaries[key] = {"per_mode": per_mode, "horizon_8_paired_effects": comparisons,
                              "seeds": [row["seed"] for row in subset]}
    valid = sorted(((key, val["two_sided_sign_flip_p"]) for key, val in primary.items()
                    if val["two_sided_sign_flip_p"] is not None), key=lambda item: item[1])
    expected = len(protocol.seeds) * len(protocol.families) * len(SCENARIOS)
    inference_valid = len(rows) == expected and not failures
    full_family_size = len(protocol.families) * 2 * 4
    previous = 0.0
    for index, (key, p) in enumerate(valid):
        previous = max(previous, min(1.0, (full_family_size - index) * p))
        primary[key]["holm_adjusted_p"] = previous if inference_valid else None
    for item in primary.values():
        item["inference_valid"] = inference_valid
    if not inference_valid:
        for result in summaries.values():
            for item in result["horizon_8_paired_effects"].values():
                item["paired_seed_bootstrap_ci95"] = None
                item["two_sided_sign_flip_p"] = None
                item["holm_adjusted_p"] = None
                item["inference_valid"] = False
    return {"scope": SCOPE, "complete": len(rows) == expected and not failures,
            "expected_seed_scenario_rows": expected, "completed_rows": len(rows), "failures": failures,
            "by_family_scenario": summaries,
            "primary_contrasts": primary, "primary_metric": f"recursive_noiseless_mse_at_horizon_{protocol.primary_horizon}",
            "multiplicity": "Holm_over_16_prespecified_family_shift_baseline_contrasts_in_default_protocol",
            "positive_effect_definition": "baseline_error_minus_diagnosed_local_error_greater_than_zero",
            "limitations": ["Independent modular estimator, not the shipping neural full agent.",
                            "Learner knows the separable feature dictionary and receives randomized intervention samples.",
                            "Fully observed stable synthetic Markov SCM; no hidden confounding or task rewards.",
                            "Horizon metrics are open-loop forecasts, not evidence of long-horizon task success.",
                            "Global matched parameter updates is a proxy budget, not measured equal FLOPs or wall time.",
                            "No claims of novelty or publication readiness follow automatically from these tests."]}


def protocol_document(protocol: Protocol, device: str) -> dict:
    return {"protocol": asdict(protocol), "software_version": __version__, "requested_device": device,
            "data_isolation": "base_train/base_calibration/diagnosis/support/acceptance/query/rollout distinct deterministic streams",
            "model_selection": "fixed hyperparameters; no outcome-adaptive tuning or seed exclusion",
            "revision_reason": "v2 fixes unequal local/global acceptance targets, adds identical collateral guard and replay-anchored global baseline; v1 retained as pre-audit evidence",
            "acceptance_rule": "same residual-diagnosed targets and per-protected-mechanism guard for every nonoracle mode; oracle alone true targets",
            "fairness": {"nonoracle_acceptance_targets": "shared_residual_diagnosis",
                         "same_nonoracle_collateral_guard": True,
                         "collateral_relative_tolerance": protocol.collateral_relative_tolerance,
                         "collateral_absolute_tolerance": protocol.collateral_absolute_tolerance,
                         "global_replay_anchor_targets": "diagnosis_protected_only_no_true_labels",
                         "global_replay_anchor_count": protocol.replay_anchor_samples,
                         "failed_seed_inference": "invalid_no_p_values_or_confidence_intervals"},
            "primary_contrasts": "diagnosed_local vs no_repair, global_matched_parameter_work, global_replay, dense_global; two families x two shifts",
            "mode_definitions": {
                "no_repair": "pretrained sparse regressor, frozen",
                "diagnosed_local": "residual diagnosis, targeted sparse fit, independent acceptance",
                "global_same_steps": "same support and iterations, all mechanisms; larger parameter-work budget",
                "global_matched_parameter_work": "all mechanisms, iterations rounded down to match local coefficient-update budget",
                "global_replay": "global fit with same support plus fixed-count reused pretraining anchors only for diagnosis-protected targets; same iterations, additional work reported",
                "dense_global": "dense pretraining/refit, same support and iterations; separate non-sparse baseline",
                "random_local": "same diagnosed target count, uniformly random pairs, same fit/acceptance",
                "oracle_local": "privileged true changed action-child pairs; not an upper bound"},
            "graph_target": "exact_simulator_action_conditioned_off_diagonal_graph",
            "scientific_scope": SCOPE}


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preset", choices=("quick", "paper"), default="quick")
    parser.add_argument("--seeds", type=int, nargs="+")
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    protocol = Protocol.preset(args.preset)
    if args.seeds:
        protocol = replace(protocol, seeds=tuple(args.seeds))
    protocol.validate()
    if args.device == "cuda" and not torch.cuda.is_available():
        parser.error("CUDA requested but unavailable; use --device cpu only intentionally")
    # Every invocation gets a new directory; completed or failed evidence is never overwritten.
    args.output.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(1)
    document = protocol_document(protocol, args.device)
    protocol_hash = canonical_hash(document)
    (args.output / "protocol.json").write_text(json.dumps({**document, "sha256": protocol_hash}, indent=2) + "\n")
    started = time.perf_counter()
    rows, failures = [], []
    for seed in protocol.seeds:
        try:
            seed_rows = run_seed(seed, protocol, args.device)
            rows.extend(seed_rows)
            (args.output / f"seed_{seed}.json").write_text(json.dumps(seed_rows, indent=2, allow_nan=False) + "\n")
            print(json.dumps({"seed": seed, "status": "complete", "scenario_rows": len(seed_rows)}), flush=True)
        except Exception as exc:
            failure = {"seed": seed, "error": repr(exc), "traceback": traceback.format_exc()}
            failures.append(failure)
            (args.output / f"seed_{seed}_FAILED.json").write_text(json.dumps(failure, indent=2) + "\n")
            print(json.dumps({"seed": seed, "status": "FAILED", "error": repr(exc)}), flush=True)
    summary = summarize(rows, protocol, failures)
    summary.update(protocol_sha256=protocol_hash, software_version=__version__, elapsed_seconds=time.perf_counter() - started,
                   runtime={"python": platform.python_version(), "torch": torch.__version__, "device": args.device,
                            "cuda_device_name": torch.cuda.get_device_name() if args.device == "cuda" else None})
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"scope": SCOPE, "complete": summary["complete"], "summary": str(args.output / "summary.json")}), flush=True)
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
