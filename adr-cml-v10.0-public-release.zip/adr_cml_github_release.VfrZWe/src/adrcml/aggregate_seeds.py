from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .evaluate import EVALUATION_MODES
from .compare_evaluations import holm_adjust, paired_sign_flip_test
from .utils import save_json


SUMMARY_FIELDS = (
    "mean_return",
    "success_rate",
    "active_actions_per_episode",
    "active_action_rate",
    "detection_rate",
    "false_alarms_per_1000_steps",
    "diagnosis_f1",
    "diagnosis_exact",
)


def _bootstrap_summary(
    values: list[float],
    rng: np.random.Generator,
    samples: int,
) -> dict[str, Any]:
    array = np.asarray(values, dtype=np.float64)
    if not array.size or not np.isfinite(array).all():
        raise ValueError("Seed summaries must contain nonempty finite observations")
    result = {
        "mean": float(array.mean()),
        "std": float(array.std(ddof=1)) if array.size > 1 else None,
        "n_seeds": float(array.size),
    }
    if array.size > 1:
        indices = rng.integers(0, array.size, size=(int(samples), array.size))
        means = array[indices].mean(axis=1)
        result["ci95_low"] = float(np.quantile(means, 0.025))
        result["ci95_high"] = float(np.quantile(means, 0.975))
    else:
        # One training seed cannot estimate between-training variability.
        result["ci95_low"] = None
        result["ci95_high"] = None
    return result


def aggregate_runs(
    root: str | Path,
    bootstrap_samples: int = 20_000,
    run_glob: str = "seed_*",
    output_dir: str | Path | None = None,
) -> dict[str, Any]:
    root = Path(root)
    if int(bootstrap_samples) < 1:
        raise ValueError("bootstrap_samples must be positive")
    run_dirs = sorted(
        path for path in root.glob(run_glob) if path.is_dir()
    )
    if not run_dirs:
        raise FileNotFoundError(f"No {run_glob} run directories found under {root}")

    expected_modes = {mode for run in run_dirs for mode in EVALUATION_MODES
                      if (run / f"evaluation_{mode}.json").exists()}
    if not expected_modes:
        raise FileNotFoundError("No evaluation results found")
    for run in run_dirs:
        missing = sorted(mode for mode in expected_modes if not (run / f"evaluation_{mode}.json").exists())
        if missing:
            raise ValueError(f"Incomplete seed run {run}: missing {missing}; failed runs cannot be silently dropped")

    rows: list[dict[str, Any]] = []
    protocols: set[tuple[Any, Any, Any]] = set()
    seen_seed_modes: set[tuple[str, str]] = set()
    checkpoint_seeds: dict[str, str] = {}
    for run_dir in run_dirs:
        for mode in EVALUATION_MODES:
            path = run_dir / f"evaluation_{mode}.json"
            if not path.exists():
                continue
            result = json.loads(path.read_text(encoding="utf-8"))
            protocols.add(tuple(result.get(key) for key in (
                "protocol", "active_budget_per_episode", "software_version", "episodes",
                "environment_profile", "task_action_access", "eval_shift_step",
                "eval_shift_min", "eval_shift_max", "model_dense_graph", "source_fingerprint")))
            seed_mode = (str(result.get("seed", run_dir.name.removeprefix("seed_"))), mode)
            if seed_mode in seen_seed_modes:
                raise ValueError(f"Duplicate training seed/mode in different directories: {seed_mode}")
            seen_seed_modes.add(seed_mode)
            digest = result.get("checkpoint_sha256")
            if digest:
                if digest in checkpoint_seeds and checkpoint_seeds[digest] != seed_mode[0]:
                    raise ValueError("Identical checkpoint attributed to different training seeds")
                checkpoint_seeds[digest] = seed_mode[0]
            row: dict[str, Any] = {
                "run": str(run_dir.relative_to(root)),
                "seed": result.get("seed", run_dir.name.removeprefix("seed_")),
                "mode": mode,
            }
            for field in SUMMARY_FIELDS:
                if field in result:
                    row[field] = float(result[field])
                    if not np.isfinite(row[field]):
                        raise ValueError(f"Nonfinite {field} in {path}")
            for field in ("graph_f1", "graph_average_precision", "graph_precision", "graph_recall"):
                aligned = result.get("graph_aligned", {}).get("macro", {})
                if field in aligned:
                    row["aligned_" + field] = float(aligned[field])
            action_macro = result.get("action_graph_aligned", {}).get("macro", {})
            if "graph_f1" in action_macro:
                row["action_graph_f1"] = float(action_macro["graph_f1"])
            rows.append(row)
    if not rows:
        raise FileNotFoundError("No evaluation_<mode>.json files were found")
    if len(protocols) > 1:
        raise ValueError("Cannot aggregate different evaluation protocols, active budgets or software versions")

    frame = pd.DataFrame(rows)
    rng = np.random.default_rng(2027)
    by_mode: dict[str, Any] = {}
    for mode, group in frame.groupby("mode", sort=False):
        by_mode[str(mode)] = {
            column: _bootstrap_summary(
                group[column].dropna().astype(float).tolist(),
                rng,
                bootstrap_samples,
            )
            for column in group.columns
            if column not in {"run", "seed", "mode"} and group[column].notna().any()
        }

    paired: dict[str, Any] = {}
    for candidate in EVALUATION_MODES:
        if candidate == "full":
            continue
        differences_return: list[float] = []
        differences_success: list[float] = []
        for run_dir in run_dirs:
            full_path = run_dir / "evaluation_full.json"
            candidate_path = run_dir / f"evaluation_{candidate}.json"
            if not full_path.exists() or not candidate_path.exists():
                continue
            full = json.loads(full_path.read_text(encoding="utf-8"))
            other = json.loads(candidate_path.read_text(encoding="utf-8"))
            differences_return.append(float(full["mean_return"] - other["mean_return"]))
            differences_success.append(float(full["success_rate"] - other["success_rate"]))
        if differences_return:
            paired[f"full_vs_{candidate}"] = {
                "return_difference": _bootstrap_summary(
                    differences_return,
                    rng,
                    bootstrap_samples,
                ),
                "success_difference": _bootstrap_summary(
                    differences_success,
                    rng,
                    bootstrap_samples,
                ),
                "return_sign_flip": paired_sign_flip_test(differences_return),
                "success_sign_flip": paired_sign_flip_test(differences_success),
                "raw_seed_return_differences": differences_return,
                "raw_seed_success_differences": differences_success,
            }

    family = {f"{key}:{endpoint}": comparison[f"{endpoint}_sign_flip"]["p_value"]
              for key, comparison in paired.items() for endpoint in ("return", "success")}
    for name, value in holm_adjust(family).items():
        key, endpoint = name.rsplit(":", 1)
        paired[key][f"{endpoint}_sign_flip_p_holm_joint"] = value

    output = {
        "bootstrap_unit": "independent_training_seed",
        "single_seed_interval": "undefined; null limits are not zero uncertainty",
        "root": str(root),
        "seed_runs": [str(path.relative_to(root)) for path in run_dirs],
        "observed_modes": sorted(expected_modes),
        "incomplete_run_policy": "raise_error_not_drop",
        "multiplicity": "Holm across all reported seed-level success and return contrasts",
        "scope": "descriptive_training_seed_uncertainty_not_publication_certification",
        "bootstrap_samples": int(bootstrap_samples),
        "by_mode": by_mode,
        "paired_seed_level": paired,
    }
    destination = Path(output_dir) if output_dir else root
    destination.mkdir(parents=True, exist_ok=True)
    frame.to_csv(destination / "multiseed_results.csv", index=False)
    save_json(destination / "multiseed_summary.json", output)
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description="Aggregate independent ADR-CML seeds")
    parser.add_argument("--root", required=True)
    parser.add_argument("--bootstrap-samples", type=int, default=20_000)
    parser.add_argument("--run-glob", default="seed_*")
    parser.add_argument("--output-dir")
    args = parser.parse_args()
    result = aggregate_runs(args.root, args.bootstrap_samples, args.run_glob, args.output_dir)
    print(json.dumps(result["paired_seed_level"], indent=2))


if __name__ == "__main__":
    main()
