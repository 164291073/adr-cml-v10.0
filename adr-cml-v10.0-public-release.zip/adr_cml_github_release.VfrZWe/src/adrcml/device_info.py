from __future__ import annotations

import argparse
import json
import platform

import torch

from .utils import configure_torch_runtime, resolve_device


def collect_device_info(requested: str = "auto") -> dict[str, object]:
    resolved = resolve_device(requested)
    configure_torch_runtime(resolved)
    report: dict[str, object] = {
        "python": platform.python_version(),
        "pytorch": torch.__version__,
        "pytorch_cuda_runtime": torch.version.cuda,
        "cuda_available": torch.cuda.is_available(),
        "requested_device": requested,
        "resolved_device": resolved,
    }
    if resolved.startswith("cuda"):
        index = torch.cuda.current_device() if resolved == "cuda" else torch.device(resolved).index
        index = 0 if index is None else index
        properties = torch.cuda.get_device_properties(index)
        report.update(
            {
                "cuda_device_count": torch.cuda.device_count(),
                "cuda_device_index": index,
                "cuda_device_name": properties.name,
                "cuda_memory_gib": round(properties.total_memory / (1024**3), 2),
                "compute_capability": f"{properties.major}.{properties.minor}",
                "float32_matmul_precision": torch.get_float32_matmul_precision(),
            }
        )
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description="Show the accelerator used by ADR-CML")
    parser.add_argument("--device", default="auto", help="auto, cpu, cuda, or cuda:N")
    parser.add_argument(
        "--require-cuda",
        action="store_true",
        help="Exit with an error unless CUDA is available",
    )
    args = parser.parse_args()
    requested = "cuda" if args.require_cuda else args.device
    try:
        report = collect_device_info(requested)
    except RuntimeError as error:
        parser.error(str(error))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
