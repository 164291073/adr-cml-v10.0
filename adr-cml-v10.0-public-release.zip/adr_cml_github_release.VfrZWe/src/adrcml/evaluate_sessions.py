"""A separate, explicitly budgeted fixed-regime support/query evaluation.

This protocol tests fixed-mechanism adaptation, optionally at held-out parameter
values; it does not establish unseen mechanism-family generalization. Each
independent session starts from the same checkpoint. Training/replay/detection
may change during support tasks only; disjoint query tasks are read-only probes
of the resulting weights. Regime labels remain in the environment harness.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import copy
from dataclasses import asdict
import json
import hashlib
from pathlib import Path
from typing import Any

import numpy as np
import torch

from . import __version__
from .config import _construct
from .context import HistoryContext
from .envs import make_env
from .evaluate import balanced_regime_schedule, validate_active_budget, configure_evaluation_mode
from .train import build_agent
from .provenance import source_fingerprint
from .utils import resolve_device, save_json, set_seed

SESSION_MODES = ("full", "global_repair", "diagnose_no_repair", "online_only", "frozen", "no_active")
SESSION_PROTOCOL = "fixed_regime_support_query_independent_probes_v2"
SESSION_STATISTICAL_PLAN = {
    "confirmatory_profile": "heldout_v1",
    "primary_task_return": ["full_vs_diagnose_no_repair/query_return", "full_vs_global_repair/query_return"],
    "secondary_prediction": ["full_vs_diagnose_no_repair/probe_mse", "full_vs_global_repair/probe_mse"],
    "exploratory_all_endpoints": [
        f"full_vs_{mode}/{metric}" for mode in SESSION_MODES if mode != "full"
        for metric in ("query_success", "query_return", "probe_mse", "probe_changed_child_mse", "probe_unchanged_child_mse")
    ],
    "multiplicity": "Holm_within_each_fixed_family_undefined_tests_retain_family_slots",
    "secondary_interpretation": "prediction_evidence_cannot_replace_failed_primary_task_return_claim",
    "train_profile_interpretation": "descriptive_development_evidence_not_confirmatory",
}


def session_schedule(sessions: int, support_episodes: int, query_episodes: int,
                     regimes: tuple[str, ...], seed: int) -> list[dict[str, Any]]:
    if sessions <= 0 or support_episodes <= 0 or query_episodes <= 0:
        raise ValueError("sessions, support_episodes and query_episodes must be positive")
    if not regimes or len(set(regimes)) != len(regimes):
        raise ValueError("regimes must be nonempty and unique")
    names = balanced_regime_schedule(sessions, regimes, seed)
    return [{
        "session": index + 1,
        "regime": regime,
        "support_seeds": [_derived_seed(seed, index + 1, "support_task", i) for i in range(support_episodes)],
        "query_seeds": [_derived_seed(seed, index + 1, "query_task", i) for i in range(query_episodes)],
    } for index, regime in enumerate(names)]


def _fingerprint(value: Any) -> str:
    """Content hash used to verify that query execution does not learn."""
    digest = hashlib.sha256()

    def visit(item):
        if torch.is_tensor(item):
            visit(item.detach().cpu().numpy())
        elif isinstance(item, np.ndarray):
            digest.update(str(item.dtype).encode())
            digest.update(str(item.shape).encode())
            if item.dtype.hasobject:
                visit(item.tolist())
            else:
                digest.update(np.ascontiguousarray(item).tobytes())
        elif isinstance(item, dict):
            for key in sorted(item, key=str):
                visit(key)
                visit(item[key])
        elif isinstance(item, (list, tuple)):
            digest.update(str(len(item)).encode())
            for child in item:
                visit(child)
        else:
            digest.update((type(item).__name__ + ":" + repr(item) + ";").encode())
    visit(value)
    return digest.hexdigest()


def _learning_fingerprints(agent) -> dict[str, str]:
    replay_state = agent.replay.state_dict()
    replay_state.pop("rng_state", None)  # task seeding may change this; contents cannot
    return {
        "model": _fingerprint(agent.model.state_dict()),
        "optimizer": _fingerprint(agent.optimizer.state_dict()),
        "detector": _fingerprint(agent.detector.state_dict()),
        "replay_contents": _fingerprint(replay_state),
    }


def _run_task(agent, env, *, seed: int, regime: str, phase: str,
              adapt: bool, keep_adaptation_state: bool, active_budget: int,
              step: int, reset_options: dict[str, Any] | None = None) -> tuple[dict[str, Any], int]:
    # Only public masks and observed transitions cross the agent interface.
    state, info = env.reset(seed=seed, options={**(reset_options or {}), "initial_regime": regime})
    agent.on_episode_reset(keep_adaptation_state=keep_adaptation_state)
    agent.set_active_budget(active_budget)
    agent.reseed(_derived_seed(seed, 0, "task_policy"))
    set_seed(_derived_seed(seed, 0, "task_global") % (2 ** 32))
    before = None if adapt else _learning_fingerprints(agent)
    before_observations = agent.total_observations
    actions: Counter[str] = Counter()
    repairs: list[dict[str, Any]] = []
    total_return, online_updates, alarms = 0.0, 0, 0
    for local_step in range(1, env.max_steps + 1):
        action = agent.act(state, info.get("valid_action_mask"),
                           info.get("task_action_mask"), info.get("intervention_action_mask"))
        actions[agent.last_action_kind] += 1
        next_state, reward, terminated, truncated, next_info = env.step(action)
        step += 1
        if adapt:
            report = agent.observe(state, action, reward, next_state,
                                   bool(terminated or truncated), step=step,
                                   valid_action_mask=info.get("valid_action_mask"))
            if report.training_loss is not None:
                online_updates += int(agent.agent_config.updates_per_step)
            alarms += int(report.alarm)
            if report.repair:
                repairs.append({"task_step": local_step, "session_step": step,
                                **copy.deepcopy(report.repair)})
        else:
            agent.observe_context_only(state, action, reward, next_state)
        total_return += float(reward)
        state, info = next_state, next_info
        if terminated or truncated:
            break
    after = None if adapt else _learning_fingerprints(agent)
    if not adapt:
        if before != after or agent.total_observations != before_observations:
            raise RuntimeError("Frozen task modified parameters, optimizer, detector, replay or learning counters")
    attempts = [r for r in repairs if int(r.get("steps", 0)) > 0 or r.get("attempted", False)]
    return {
        "phase": phase, "episode_seed": seed, "assigned_regime": regime,
        "environment_profile": info.get("environment_profile", "train"),
        "mechanism_parameters": copy.deepcopy(info.get("mechanism_parameters", {})),
        "return": total_return, "success": bool(info.get("success", False)),
        "length": local_step, "action_kinds": dict(actions),
        "active_actions": validate_active_budget(dict(actions), active_budget),
        "active_budget_per_task": active_budget, "online_optimizer_steps": online_updates,
        "alarm_count": alarms, "repair_attempts": len(attempts),
        "accepted_repairs": sum(bool(r.get("applied", False)) for r in attempts),
        "repair_optimizer_steps": sum(int(r.get("steps", 0)) for r in attempts),
        "repair_records": repairs, "pending_repairs_at_end": len(agent.pending_repairs),
        "query_learning_audit_passed": True if phase in ("query", "initial_query") else None,
        "learning_hashes_before": before, "learning_hashes_after": after,
        "learning_observations_before": before_observations,
        "learning_observations_after": agent.total_observations,
    }, step


def _session_metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "tasks": len(rows), "mean_return": float(np.mean([r["return"] for r in rows])),
        "success_rate": float(np.mean([r["success"] for r in rows])),
        "environment_steps": sum(r["length"] for r in rows),
        "active_actions": sum(r["active_actions"] for r in rows),
        "online_optimizer_steps": sum(r["online_optimizer_steps"] for r in rows),
        "repair_optimizer_steps": sum(r["repair_optimizer_steps"] for r in rows),
        "repair_attempts": sum(r["repair_attempts"] for r in rows),
        "accepted_repairs": sum(r["accepted_repairs"] for r in rows),
        "alarms": sum(r["alarm_count"] for r in rows),
        "repair_skip_reasons": dict(Counter(
            str(v["skip_reason"]) for r in rows for v in r["repair_records"]
            if v.get("skip_reason"))),
    }


def paired_session_comparison(reference: list[dict[str, Any]],
                              candidate: list[dict[str, Any]], *,
                              bootstrap_samples: int = 10000, seed: int = 0) -> dict[str, Any]:
    """Resample paired sessions within regime; never treat query tasks as seeds."""
    if not reference or len(reference) != len(candidate) or bootstrap_samples <= 0:
        raise ValueError("paired nonempty sessions and positive bootstrap_samples required")
    for left, right in zip(reference, candidate):
        if tuple(left[k] for k in ("session", "regime", "query_seeds")) != tuple(
            right[k] for k in ("session", "regime", "query_seeds")
        ):
            raise ValueError("session schedules are not paired")
    groups: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(reference):
        groups[row["regime"]].append(index)
    result = {"sessions": len(reference),
              "interval_unit": "paired_sessions_stratified_by_regime_conditional_on_one_training_seed",
              "inference": "exploratory_pointwise_intervals_no_multiple_comparison_claim"}
    rng = np.random.default_rng(seed)
    enough_replicates = all(len(indices) >= 2 for indices in groups.values())
    samples = None
    if enough_replicates:
        samples = np.concatenate([rng.choice(indices, size=(bootstrap_samples, len(indices)), replace=True)
                                  for indices in groups.values()], axis=1)
    fields = [("query", "success_rate", "success_rate"), ("query", "mean_return", "mean_return")]
    if all("probe_after" in row for row in reference + candidate):
        fields += [("probe_after", name, "probe_" + name) for name in
                   ("mse", "changed_child_mse", "unchanged_child_mse")]
    for section, field, output_name in fields:
        if any(row[section][field] is None for row in reference + candidate):
            result[f"{output_name}_difference"] = None
            result[f"{output_name}_ci95"] = None
            continue
        difference = np.asarray([a[section][field] - b[section][field]
                                 for a, b in zip(reference, candidate)], dtype=float)
        result[f"{output_name}_difference"] = float(difference.mean())
        result[f"{output_name}_ci95"] = (None if samples is None else
            np.quantile(difference[samples].mean(axis=1), [0.025, 0.975]).tolist())
    result["interval_unavailable_reason"] = (
        None if enough_replicates else "need_at_least_two_independent_sessions_per_regime")
    return result



def _derived_seed(seed: int, session: int, namespace: str, index: int = 0) -> int:
    # The generator namespaces isolate collection from policy/support/query RNGs.
    payload = f"{seed}:{session}:{namespace}:{index}".encode()
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "little")


def build_probe_bank(environment_args: dict[str, Any], assignment: dict[str, Any], *,
                     samples: int, context_window: int, context_enabled: bool,
                     seed: int) -> dict[str, np.ndarray]:
    """Collect once under a fixed random behavior policy, never under an agent.

    Histories are computed before their target transitions. Child masks are an
    evaluator-only *potential observable dependency change* annotation versus
    the base regime, not a claim of complete causal truth or an agent input.
    No support, query, diagnosis, replay or acceptance procedure sees this bank.
    """
    if samples < 1:
        raise ValueError("probe_samples must be positive")
    env = make_env(**environment_args, seed=_derived_seed(seed, assignment["session"], "probe_env"))
    reset_options = {"initial_regime": assignment["regime"],
                     "environment_profile": assignment["environment_profile"],
                     "mechanism_parameters": assignment["mechanism_parameters"]}
    base = make_env(**environment_args, seed=_derived_seed(seed, assignment["session"], "probe_base"))
    base.reset(seed=_derived_seed(seed, assignment["session"], "probe_base_reset"),
               options={**reset_options, "initial_regime": "base"})
    base_graph = base.true_adjacency_by_action()
    history = HistoryContext(env.state_dim, env.action_dim, window=context_window)
    behavior = np.random.default_rng(_derived_seed(seed, assignment["session"], "probe_behavior"))
    records: dict[str, list[Any]] = defaultdict(list)
    task = 0
    forbidden = set(assignment["support_seeds"] + assignment["query_seeds"])
    while len(records["action"]) < samples:
        reset_seed = _derived_seed(seed, assignment["session"], "probe_reset", task)
        if reset_seed in forbidden:
            raise RuntimeError("Probe/support/query seed collision")
        state, info = env.reset(seed=reset_seed, options=reset_options)
        # Union over actions is explicitly a potential-child annotation. Some
        # parameter changes have identical graph topology; mechanism events are
        # additionally recorded to expose whether collection activated a shift.
        changed = np.any(env.true_adjacency_by_action() != base_graph, axis=(0, 1))
        history.reset()
        for _ in range(env.max_steps):
            valid = np.asarray(info["valid_action_mask"], dtype=bool)
            interventions = np.asarray(info.get("intervention_action_mask", np.zeros_like(valid)), dtype=bool)
            choices = np.flatnonzero(valid | interventions)
            if choices.size == 0:
                raise RuntimeError("Probe behavior policy has no available action")
            action = int(behavior.choice(choices))
            context = history.vector() if context_enabled else np.empty(0, dtype=np.float32)
            next_state, reward, terminated, truncated, next_info = env.step(action)
            records["state"].append(state.copy())
            records["action"].append(action)
            records["next_state"].append(next_state.copy())
            records["context"].append(context)
            records["changed_child_mask"].append(changed.copy())
            records["mechanism_activated"].append(bool(next_info.get("mechanism_event", False)))
            records["rollout_seed"].append(reset_seed)
            history.update(state, action, reward, next_state)
            state, info = next_state, next_info
            if len(records["action"]) >= samples or terminated or truncated:
                break
        task += 1
    return {key: np.asarray(values, dtype=(np.uint64 if key == "rollout_seed" else
                np.int64 if key == "action" else bool if key in ("changed_child_mask", "mechanism_activated")
                else np.float32)) for key, values in records.items()}


def score_probe_bank(agent, bank: dict[str, np.ndarray], batch_size: int = 256) -> dict[str, Any]:
    """Prediction-only evaluation on identical pre-outcome contexts before/after.

    Explicit bank contexts replace live context only as forward arguments;
    neither historical state nor model context is mutated. No dropout/edge
    sampling, gradients, replay writes, detector updates or acceptance calls.
    """
    if batch_size < 1 or len(bank["action"]) == 0:
        raise ValueError("nonempty bank and positive batch_size required")
    before = _learning_fingerprints(agent)
    context_before = _fingerprint(agent.history_context.state_dict())
    live_before = _fingerprint([m.current_context for m in agent.model.members])
    modes = [(module, module.training) for module in agent.model.modules()]
    errors = []
    try:
        agent.model.eval()
        with torch.no_grad():
            for begin in range(0, len(bank["action"]), batch_size):
                end = begin + batch_size
                x = torch.as_tensor(bank["state"][begin:end], dtype=torch.float32, device=agent.device)
                a = torch.as_tensor(bank["action"][begin:end], dtype=torch.long, device=agent.device)
                context = (torch.as_tensor(bank["context"][begin:end], dtype=torch.float32,
                                           device=agent.device) if agent.context_enabled else None)
                predicted = agent.model.predict_members(x, a, context=context)[0].mean(0)
                target = torch.as_tensor(bank["next_state"][begin:end], dtype=torch.float32, device=agent.device)
                errors.append((predicted - target).square().cpu().numpy())
    finally:
        for module, training in modes:
            module.training = training
    if (before != _learning_fingerprints(agent) or
        context_before != _fingerprint(agent.history_context.state_dict()) or
        live_before != _fingerprint([m.current_context for m in agent.model.members])):
        raise RuntimeError("Independent probe scoring modified learning or context state")
    squared = np.concatenate(errors).astype(np.float64)
    if not np.isfinite(squared).all():
        raise ValueError("Nonfinite independent probe prediction errors")
    changed = bank["changed_child_mask"].astype(bool)
    return {
        "samples": len(squared), "mse": float(squared.mean()),
        "changed_child_mse": float(squared[changed].mean()) if changed.any() else None,
        "unchanged_child_mse": float(squared[~changed].mean()) if (~changed).any() else None,
        "per_child_mse": squared.mean(0).tolist(),
        "changed_child_values": int(changed.sum()), "unchanged_child_values": int((~changed).sum()),
        "mechanism_activated_transitions": int(bank["mechanism_activated"].sum()),
        "action_counts": {str(a): int((bank["action"] == a).sum()) for a in np.unique(bank["action"])},
        "readonly_audit_passed": True,
    }


def _sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def evaluate_sessions(checkpoint_path: str, *, output_dir: str,
                      sessions: int = 12, support_episodes: int = 8,
                      query_episodes: int = 4, active_budget: int = 3,
                      seed: int = 41001, device: str | None = None,
                      modes: tuple[str, ...] = SESSION_MODES,
                      regimes: tuple[str, ...] = ("coupled_lock", "fragile_bridge", "draining_key"),
                      bootstrap_samples: int = 10000, probe_samples: int = 512,
                      environment_profile: str = "train") -> dict[str, Any]:
    if not modes or len(set(modes)) != len(modes) or not set(modes).issubset(SESSION_MODES):
        raise ValueError(f"modes must be a unique nonempty subset of {SESSION_MODES}")
    if environment_profile not in ("train", "heldout_v1"):
        raise ValueError("environment_profile must be train or heldout_v1")
    if probe_samples <= 0:
        raise ValueError("probe_samples must be positive")
    if active_budget < 0 or bootstrap_samples <= 0:
        raise ValueError("active_budget must be nonnegative and bootstrap_samples positive")
    schedule = session_schedule(sessions, support_episodes, query_episodes, regimes, seed)
    destination = Path(output_dir)
    if any((destination / name).exists() for name in ("session_evaluation.json", "session_episodes.json")):
        raise FileExistsError("Choose a new session output directory; existing results are not overwritten")
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    if not str(checkpoint.get("software_version", "")).startswith("10.0"):
        raise ValueError("Session evaluation requires a newly trained v10.0 checkpoint")
    config = _construct(checkpoint["config"])
    training_config = copy.deepcopy(checkpoint["config"])
    model_hash = _fingerprint(checkpoint["model"])
    config.device = resolve_device(config.device if device is None else device)
    if "no_active" in modes and config.environment.task_action_access != "shared_shield":
        raise ValueError("no_active requires shared_shield task action access")
    config.environment.warmup_episodes = 0
    config.agent.oracle_diagnosis = False
    config.agent.repair_max_wait_steps = max(config.agent.repair_max_wait_steps,
                                            support_episodes * config.environment.max_steps)
    # The longer evidence allowance belongs to this protocol, not the checkpoint.
    environment_args = asdict(config.environment)
    environment_args["environment_profile"] = environment_profile
    probe_env = make_env(**environment_args, seed=seed)
    if not set(regimes).issubset({"base", *probe_env.shift_modes}):
        raise ValueError("Unknown fixed regime requested")
    trained_counter = int(checkpoint.get("total_observations", 0))
    stored_steps = np.asarray(checkpoint.get("replay", {}).get("steps", []))
    first_step = max(int(checkpoint.get("step", trained_counter)),
                     int(stored_steps.max(initial=0)))

    def clean_agent(mode):
        set_seed(seed)
        model_config = copy.deepcopy(config)
        model_config.agent.diagnosis_enabled = mode in ("full", "global_repair", "diagnose_no_repair", "no_active")
        model_config.agent.repair_enabled = mode in ("full", "global_repair", "no_active")
        # Match every support resource and acceptance rule; only the allowed
        # repair parameter set differs. Set before constructing the repairer.
        if mode == "global_repair":
            model_config.agent.local_repair = False
        if mode == "no_active":
            model_config.agent.active_weight = 0.0
            model_config.agent.intervention_probability = 0.0
            model_config.agent.counterfactual_probe_probability = 0.0
        agent = build_agent(model_config, probe_env.state_dim, probe_env.action_dim)
        agent.load_checkpoint(copy.deepcopy(checkpoint), load_optimizer=True)
        configure_evaluation_mode(agent, mode)
        return agent

    results: dict[str, list[dict[str, Any]]] = {mode: [] for mode in modes}
    initial_results: list[dict[str, Any]] = []
    episode_records: list[dict[str, Any]] = []
    destination.mkdir(parents=True, exist_ok=True)
    for assignment in schedule:
        _, assigned_info = probe_env.reset(
            seed=_derived_seed(seed, assignment["session"], "session_parameters"),
            options={"initial_regime": assignment["regime"], "environment_profile": environment_profile})
        assignment["environment_profile"] = environment_profile
        assignment["mechanism_parameters"] = copy.deepcopy(assigned_info.get("mechanism_parameters", {}))
        reset_options = {"environment_profile": environment_profile,
                         "mechanism_parameters": assignment["mechanism_parameters"]}
        bank = build_probe_bank(environment_args, assignment, samples=probe_samples,
                                context_window=config.model.context_window,
                                context_enabled=config.model.context_enabled, seed=seed)
        bank_name = f"probe_bank_session_{assignment['session']:04d}.npz"
        np.savez_compressed(destination / bank_name, **bank)
        assignment["probe_bank_file"] = bank_name
        assignment["probe_bank_hash"] = _fingerprint(bank)
        assignment["probe_bank_sha256"] = _sha256_file(destination / bank_name)
        assignment["probe_rollout_seeds"] = [int(x) for x in np.unique(bank["rollout_seed"])]
        # Read-only baseline uses separate agent state. Query trajectories are
        # never replayed as support data or exposed to checkpoint adaptation.
        baseline_agent = clean_agent("frozen")
        baseline_env = make_env(**environment_args, seed=seed)
        initial_probe = score_probe_bank(baseline_agent, bank)
        initial_rows = []
        for query_seed in assignment["query_seeds"]:
            row, _ = _run_task(baseline_agent, baseline_env, seed=query_seed,
                              regime=assignment["regime"], phase="initial_query", adapt=False,
                              keep_adaptation_state=False, active_budget=active_budget, step=first_step,
                              reset_options=reset_options)
            initial_rows.append(row)
            episode_records.append({"mode": "initial_checkpoint", "session": assignment["session"], **row})
        initial_summary = {**assignment, "query": _session_metrics(initial_rows),
                           "probe_before": initial_probe, "probe_after": initial_probe}
        initial_results.append(initial_summary)
        del baseline_agent
        for mode in modes:
            agent = clean_agent(mode)
            env = make_env(**environment_args, seed=seed)
            step = first_step
            before_probe = score_probe_bank(agent, bank)
            if before_probe != initial_probe:
                raise RuntimeError("Session modes do not begin from identical probe predictions")
            support_rows, query_rows = [], []
            for task_index, support_seed in enumerate(assignment["support_seeds"]):
                row, step = _run_task(agent, env, seed=support_seed, regime=assignment["regime"],
                                     phase="support", adapt=mode != "frozen",
                                     keep_adaptation_state=task_index > 0,
                                     active_budget=active_budget, step=step, reset_options=reset_options)
                support_rows.append(row)
                episode_records.append({"mode": mode, "session": assignment["session"], **row})
            pending_at_support_end = len(agent.pending_repairs)
            after_support_hash = _fingerprint(agent.model.state_dict())
            after_probe = score_probe_bank(agent, bank)
            # Equalize exploration decay/warmup counters during read-only query.
            # Any support gain must not be an artifact of unequal epsilon decay.
            agent.total_observations = trained_counter
            # no_active is a SUPPORT collection ablation. Restore the identical
            # checkpoint policy for query so downstream differences concern
            # adapted weights rather than unequal query action availability.
            if mode == "no_active":
                for name in ("active_weight", "intervention_probability", "counterfactual_probe_probability"):
                    setattr(agent.agent_config, name, getattr(config.agent, name))
                agent.planner.active_weight = config.agent.active_weight
            for query_seed in assignment["query_seeds"]:
                row, step = _run_task(agent, env, seed=query_seed, regime=assignment["regime"],
                                     phase="query", adapt=False, keep_adaptation_state=False,
                                     active_budget=active_budget, step=step, reset_options=reset_options)
                query_rows.append(row)
                episode_records.append({"mode": mode, "session": assignment["session"], **row})
            summary = {**assignment, "support": _session_metrics(support_rows),
                       "query": _session_metrics(query_rows),
                       "pending_repairs_after_support": pending_at_support_end,
                       "model_hash_before_support": model_hash,
                       "model_hash_after_support": after_support_hash,
                       "model_hash_after_query": _fingerprint(agent.model.state_dict()),
                       "query_learning_audit_passed": all(r["query_learning_audit_passed"] for r in query_rows),
                       "probe_before": before_probe, "probe_after": after_probe}
            results[mode].append(summary)
            print(f"session={assignment['session']}/{sessions} regime={assignment['regime']} "
                  f"mode={mode} query_success={summary['query']['success_rate']:.3f} "
                  f"support_steps={summary['support']['environment_steps']}", flush=True)
            del agent
    comparisons: dict[str, Any] = {}
    for mode, rows in results.items():
        comparisons[f"{mode}_vs_initial_checkpoint"] = paired_session_comparison(
            rows, initial_results, bootstrap_samples=bootstrap_samples, seed=seed + 1)
    if "full" in results:
        for mode in modes:
            if mode != "full":
                comparisons[f"full_vs_{mode}"] = paired_session_comparison(
                    results["full"], results[mode], bootstrap_samples=bootstrap_samples, seed=seed + 2)
    aggregate = {}
    for mode, rows in results.items():
        aggregate[mode] = {
            "query_success_rate": float(np.mean([r["query"]["success_rate"] for r in rows])),
            "query_mean_return": float(np.mean([r["query"]["mean_return"] for r in rows])),
            "probe_mse_before": float(np.mean([r["probe_before"]["mse"] for r in rows])),
            "probe_mse_after": float(np.mean([r["probe_after"]["mse"] for r in rows])),
            "support_environment_steps": sum(r["support"]["environment_steps"] for r in rows),
            "support_active_actions": sum(r["support"]["active_actions"] for r in rows),
            "support_online_optimizer_steps": sum(r["support"]["online_optimizer_steps"] for r in rows),
            "support_repair_optimizer_steps": sum(r["support"]["repair_optimizer_steps"] for r in rows),
            "support_repair_attempts": sum(r["support"]["repair_attempts"] for r in rows),
            "support_accepted_repairs": sum(r["support"]["accepted_repairs"] for r in rows),
        }
    by_regime = {}
    for regime in regimes:
        by_regime[regime] = {}
        for mode, rows in results.items():
            selected = [row for row in rows if row["regime"] == regime]
            if not selected:
                continue
            by_regime[regime][mode] = {
                "sessions": len(selected),
                "query_success_rate": float(np.mean([row["query"]["success_rate"] for row in selected])),
                "query_mean_return": float(np.mean([row["query"]["mean_return"] for row in selected])),
                "support_environment_steps": sum(row["support"]["environment_steps"] for row in selected),
                "support_repair_attempts": sum(row["support"]["repair_attempts"] for row in selected),
                "support_accepted_repairs": sum(row["support"]["accepted_repairs"] for row in selected),
            }
    frozen_agreement = None
    if "frozen" in results:
        frozen_agreement = all(
            all(frozen["query"][key] == initial["query"][key]
                for key in ("success_rate", "mean_return", "environment_steps", "active_actions"))
            for frozen, initial in zip(results["frozen"], initial_results)
        )
    output = {
        "software_version": __version__, "protocol": SESSION_PROTOCOL,
        "checkpoint": str(checkpoint_path), "training_seed": config.seed,
        "checkpoint_sha256": _sha256_file(checkpoint_path), "model_sha256": model_hash,
        "training_steps": int(checkpoint.get("step", trained_counter)),
        "training_config": training_config, "environment_profile": environment_profile,
        "training_used_oracle_diagnosis": bool(training_config.get("agent", {}).get("oracle_diagnosis", False)),
        "parameter_ood_regimes": ["coupled_lock", "fragile_bridge"] if environment_profile == "heldout_v1" else [],
        "parameter_ood_scope": "draining_key_is_an_unchanged_mechanism_control_in_heldout_v1",
        "training_source_hash": checkpoint.get("source_hash"),
        "evaluation_source_hash": source_fingerprint(),
        "training_config_hash": checkpoint.get("config_hash"),
        "no_active_scope": "support_only_query_uses_identical_checkpoint_exploration_settings",
        "probe_samples_per_session": probe_samples,
        "probe_protocol": "independent_random_public_mask_policy_same_bank_before_after_no_adaptation",
        "probe_context_policy": "fixed_pretransition_history_from_independent_rollouts_explicit_forward_argument",
        "probe_changed_child_definition": "potential_observable_dependency_proxy_children_differing_from_base_not_causal_truth",
        "probe_independence": "separate_hashed_rng_namespaces_and_disjoint_reset_seeds_not_support_or_query_samples",
        "evaluation_seed": seed, "sessions": sessions,
        "support_episodes_per_session": support_episodes, "query_episodes_per_session": query_episodes,
        "active_budget_per_task": active_budget,
        "active_budget_interpretation": "equal_maximum_allowance_not_equal_realized_action_counts",
        "effective_repair_max_wait_steps": config.agent.repair_max_wait_steps,
        "repair_sample_minima": {
            key: getattr(config.agent, key) for key in (
                "repair_min_train_samples", "repair_min_validation_samples",
                "repair_min_target_action_train", "repair_min_target_action_validation")},
        "query_policy_counter": trained_counter,
        "query_policy": "weights_frozen_context_evolves_no_alarm_boost_same_checkpoint_exploration_counter",
        "query_learning_audit": "model_optimizer_detector_replay_content_and_learning_counter_unchanged_each_task",
        "interpretation": ("heldout_parameter_adaptation_within_known_mechanism_families" if environment_profile == "heldout_v1" else
                           "known_fixed_mechanism_adaptation_with_task_resets"),
        "global_repair_control": "all_node_updates_same_diagnosed_child_validation_same_collateral_guard_and_step_allowance",
        "comparability": "separate_protocol_not_comparable_to_single_episode_balanced_shift",
        "statistical_unit": "independent_evaluation_session_conditional_on_one_training_seed",
        "schedule": schedule, "aggregate": aggregate, "by_regime": by_regime, "comparisons": comparisons,
        "frozen_control_matches_initial_checkpoint": frozen_agreement,
        "initial_checkpoint_sessions": initial_results, "mode_sessions": results,
    }
    # Fingerprint excludes paths, train/eval seeds and sampled parameters only;
    # every substantive training/evaluation budget and protocol setting stays.
    comparable_training = copy.deepcopy(training_config)
    for excluded in ("seed", "output_dir", "device", "logging"):
        comparable_training.pop(excluded, None)
    protocol_spec = {
        "protocol": SESSION_PROTOCOL, "software_version": __version__,
        "training_config": comparable_training, "training_steps": output["training_steps"],
        "environment_profile": environment_profile, "environment_args": environment_args,
        "regimes": list(regimes), "modes": list(modes), "sessions": sessions,
        "support_episodes": support_episodes, "query_episodes": query_episodes,
        "active_budget": active_budget, "probe_samples": probe_samples,
        "effective_repair_max_wait_steps": config.agent.repair_max_wait_steps,
        "statistical_plan": copy.deepcopy(SESSION_STATISTICAL_PLAN),
        "training_source_hash": output["training_source_hash"],
        "evaluation_source_hash": output["evaluation_source_hash"],
    }
    output["protocol_spec"] = protocol_spec
    output["protocol_sha256"] = _fingerprint(protocol_spec)
    save_json(destination / "session_episodes.json", episode_records)
    save_json(destination / "session_evaluation.json", output)
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--sessions", type=int, default=12)
    parser.add_argument("--support-episodes", type=int, default=8)
    parser.add_argument("--query-episodes", type=int, default=4)
    parser.add_argument("--active-budget", type=int, default=3)
    parser.add_argument("--seed", type=int, default=41001)
    parser.add_argument("--device", default=None)
    parser.add_argument("--modes", nargs="+", choices=SESSION_MODES, default=list(SESSION_MODES))
    parser.add_argument("--regimes", nargs="+", default=["coupled_lock", "fragile_bridge", "draining_key"])
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument("--probe-samples", type=int, default=512)
    parser.add_argument("--environment-profile", choices=("train", "heldout_v1"), default="train")
    args = parser.parse_args()
    evaluate_sessions(args.checkpoint, output_dir=args.output_dir, sessions=args.sessions,
                      support_episodes=args.support_episodes, query_episodes=args.query_episodes,
                      active_budget=args.active_budget, seed=args.seed, device=args.device,
                      modes=tuple(args.modes), regimes=tuple(args.regimes),
                      bootstrap_samples=args.bootstrap_samples, probe_samples=args.probe_samples,
                      environment_profile=args.environment_profile)


if __name__ == "__main__":
    main()
