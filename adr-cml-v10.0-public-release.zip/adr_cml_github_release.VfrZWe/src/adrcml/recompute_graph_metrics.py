"""Re-score saved graph snapshots; never infer an episode-average from NPZs."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np

from .metrics import GRAPH_METRIC_METADATA, action_structural_metrics, structural_metrics


def _load_arrays(path: Path) -> dict[str, np.ndarray]:
    loaded = np.load(path, allow_pickle=False)
    if isinstance(loaded, np.lib.npyio.NpzFile):
        with loaded:
            return {name: loaded[name].copy() for name in loaded.files}
    return {"array": np.asarray(loaded)}


def recompute_graph_metrics(
    predicted_path: str | Path,
    target_path: str | Path,
    threshold: float = 0.5,
) -> dict[str, Any]:
    """Match NPZ keys exactly; support [N,N] and [A,N,N] snapshots."""
    predicted_path, target_path = Path(predicted_path), Path(target_path)
    predicted, target = _load_arrays(predicted_path), _load_arrays(target_path)
    if set(predicted) != set(target):
        raise ValueError("predicted and target files must contain exactly the same array keys")
    if not predicted:
        raise ValueError("graph archives must contain at least one array")
    arrays: dict[str, Any] = {}
    kinds: set[int] = set()
    for key in sorted(predicted):
        values = predicted[key]
        kinds.add(values.ndim)
        if values.ndim == 2:
            arrays[key] = structural_metrics(values, target[key], threshold=threshold)
        elif values.ndim == 3:
            arrays[key] = action_structural_metrics(values, target[key], threshold=threshold)
        else:
            raise ValueError(f"array {key!r} must have [N,N] or [A,N,N] shape")
    result: dict[str, Any] = {
        "artifact_type": "recomputed_saved_graph_snapshots",
        "interpretation": "unweighted_summary_of_supplied_snapshots; not_mean_over_evaluation_episodes",
        "limitations": [
            "Regime NPZ files may mix snapshot collection stages; inspect the original export provenance.",
            "No causal identifiability or unpublished episode-level metrics can be recovered from these arrays.",
            "Top-K uses the number of true edges; it is an oracle-budget diagnostic, not a deployable threshold.",
        ],
        "metric_metadata": dict(GRAPH_METRIC_METADATA),
        "threshold": float(threshold),
        "predicted_file": str(predicted_path.resolve()),
        "target_file": str(target_path.resolve()),
        "predicted_sha256": hashlib.sha256(predicted_path.read_bytes()).hexdigest(),
        "target_sha256": hashlib.sha256(target_path.read_bytes()).hexdigest(),
        "by_array": arrays,
    }
    if len(kinds) == 1:
        summaries = list(arrays.values()) if next(iter(kinds)) == 2 else [value["macro"] for value in arrays.values()]
        common = set.intersection(*(set(value) for value in summaries))
        result["unweighted_snapshot_macro"] = {
            key: float(np.mean([value[key] for value in summaries]))
            for key in sorted(common)
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--predicted", required=True, help=".npy or .npz saved model graph")
    parser.add_argument("--target", required=True, help="matching .npy or .npz binary target")
    parser.add_argument("--output", required=True, help="new JSON report; raw arrays are not modified")
    parser.add_argument("--threshold", type=float, default=0.5)
    args = parser.parse_args()
    output = Path(args.output)
    if output.resolve() in {Path(args.predicted).resolve(), Path(args.target).resolve()}:
        raise ValueError("output must not replace an input graph")
    result = recompute_graph_metrics(args.predicted, args.target, args.threshold)
    output.parent.mkdir(parents=True, exist_ok=True)
    # Avoid accidentally replacing the original report during a metric audit.
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(output)


if __name__ == "__main__":
    main()
