from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def _rolling(values: list[float], window: int = 100) -> np.ndarray:
    array = np.asarray(values, dtype=float)
    if array.size == 0:
        return array
    result = np.empty_like(array)
    for index in range(array.size):
        result[index] = array[max(0, index - window + 1) : index + 1].mean()
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Plot ADR-CML learning diagnostics")
    parser.add_argument("--run", required=True, help="Run output directory")
    args = parser.parse_args()
    run = Path(args.run)
    train_path = run / "train.jsonl"
    records = ([json.loads(line) for line in train_path.read_text().splitlines() if line.strip()]
               if train_path.exists() else [])
    episodes = [row for row in records if row["type"] == "episode"]
    progress = [row for row in records if row["type"] == "progress"]
    labels_path = run / "labels.json"
    labels = json.loads(labels_path.read_text()) if labels_path.exists() else {}

    cmap = plt.get_cmap("viridis").copy()
    cmap.set_bad("#d9d9d9")
    node_names = labels.get("node_names")
    if train_path.exists() and (run / "learned_adjacency.npy").exists():
        figure, axes = plt.subplots(2, 2, figsize=(13, 9))
        episode_index = [r["episode"] for r in episodes]
        episode_return = [r["return"] for r in episodes]
        axes[0, 0].plot(episode_index, episode_return, alpha=0.15, linewidth=0.7)
        axes[0, 0].plot(
            episode_index,
            _rolling(episode_return),
            linewidth=2.0,
            label="rolling mean (100)",
        )
        axes[0, 0].legend()
        axes[0, 0].set(title="Episode return", xlabel="Episode", ylabel="Return")
        axes[0, 1].plot(
            [r["step"] for r in progress],
            [r["success_100"] for r in progress],
        )
        axes[0, 1].set(
            title="Rolling success",
            xlabel="Environment step",
            ylabel="Rate",
            ylim=(0, 1),
        )
        adjacency = np.load(run / "learned_adjacency.npy")
        diagonal = np.eye(adjacency.shape[0], dtype=bool)
        learned = np.ma.array(adjacency, mask=diagonal)
        image = axes[1, 0].imshow(learned, vmin=0, vmax=1, cmap=cmap)
        axes[1, 0].set(title="Learned gates (final model snapshot)", xlabel="Child", ylabel="Parent")
        figure.colorbar(image, ax=axes[1, 0], fraction=0.046)

        true_path = run / "true_adjacency.npy"
        if true_path.exists():
            truth = np.ma.array(np.load(true_path), mask=diagonal)
            truth_image = axes[1, 1].imshow(truth, vmin=0, vmax=1, cmap=cmap)
            axes[1, 1].set(title="True union graph", xlabel="Child", ylabel="Parent")
            figure.colorbar(truth_image, ax=axes[1, 1], fraction=0.046)
        else:
            offdiag = adjacency[~diagonal]
            axes[1, 1].hist(offdiag, bins=20, color="#2a6fbb", alpha=0.8)
            axes[1, 1].set(title="Off-diagonal gate distribution", xlabel="Gate probability", ylabel="Count")

        if node_names and len(node_names) == adjacency.shape[0]:
            ticks = np.arange(len(node_names))
            for axis in (axes[1, 0], axes[1, 1]):
                if axis.images:
                    axis.set_xticks(ticks, node_names, rotation=45, ha="right")
                    axis.set_yticks(ticks, node_names)
        figure.tight_layout()
        target = run / "diagnostics.png"
        figure.savefig(target, dpi=180)
        print(target)
        plt.close(figure)

    learned_regime_path = run / "learned_adjacency_by_regime.npz"
    true_regime_path = run / "true_adjacency_by_regime.npz"
    if learned_regime_path.exists() and true_regime_path.exists():
        learned_regimes = np.load(learned_regime_path)
        true_regimes = np.load(true_regime_path)
        regimes = sorted(set(learned_regimes.files) & set(true_regimes.files))
        if regimes:
            graph_figure, graph_axes = plt.subplots(
                len(regimes),
                2,
                figsize=(10, max(3.2, 3.0 * len(regimes))),
                squeeze=False,
            )
            for row, regime in enumerate(regimes):
                for column, (matrix, prefix) in enumerate(
                    (
                        (learned_regimes[regime], "Learned"),
                        (true_regimes[regime], "True"),
                    )
                ):
                    masked = np.ma.array(matrix, mask=np.eye(matrix.shape[0], dtype=bool))
                    plot = graph_axes[row, column].imshow(
                        masked,
                        vmin=0,
                        vmax=1,
                        cmap=cmap,
                    )
                    graph_axes[row, column].set(
                        title=f"{prefix}: {regime}",
                        xlabel="Child",
                        ylabel="Parent",
                    )
                    if node_names and len(node_names) == matrix.shape[0]:
                        ticks = np.arange(len(node_names))
                        graph_axes[row, column].set_xticks(
                            ticks,
                            node_names,
                            rotation=45,
                            ha="right",
                        )
                        graph_axes[row, column].set_yticks(ticks, node_names)
                    graph_figure.colorbar(
                        plot,
                        ax=graph_axes[row, column],
                        fraction=0.046,
                    )
            graph_figure.tight_layout()
            graph_target = run / "causal_graphs_by_regime.png"
            graph_figure.savefig(graph_target, dpi=180)
            print(graph_target)
            plt.close(graph_figure)

    mode_results = []
    for mode in (
        "full",
        "global_repair",
        "matched_active",
        "diagnose_no_repair",
        "oracle_repair",
        "online_only",
        "frozen",
    ):
        path = run / f"evaluation_{mode}.json"
        if path.exists():
            mode_results.append((mode, json.loads(path.read_text())))
    if mode_results:
        mode_figure, mode_axes = plt.subplots(1, 2, figsize=(11, 4))
        display_names = {
            "oracle_repair": "Oracle nodes",
            "full": "Full",
            "global_repair": "Global repair",
            "matched_active": "Replayed boost",
            "diagnose_no_repair": "Diagnose, no repair",
            "online_only": "Online only",
            "frozen": "Frozen",
        }
        names = [display_names.get(name, name) for name, _ in mode_results]
        success = np.asarray([row["success_rate"] for _, row in mode_results])
        success_low = np.asarray(
            [row.get("success_rate_ci95_low", value) for value, (_, row) in zip(success, mode_results)]
        )
        success_high = np.asarray(
            [row.get("success_rate_ci95_high", value) for value, (_, row) in zip(success, mode_results)]
        )
        mode_axes[0].bar(
            names,
            success,
            yerr=np.maximum(0.0, np.vstack((success - success_low, success_high - success))),
            capsize=4,
        )
        mode_axes[0].set(title="Evaluation success", ylabel="Rate", ylim=(0, 1))
        mean_return = np.asarray([row["mean_return"] for _, row in mode_results])
        return_low = np.asarray(
            [row.get("mean_return_ci95_low", value) for value, (_, row) in zip(mean_return, mode_results)]
        )
        return_high = np.asarray(
            [row.get("mean_return_ci95_high", value) for value, (_, row) in zip(mean_return, mode_results)]
        )
        mode_axes[1].bar(
            names,
            mean_return,
            yerr=np.vstack((mean_return - return_low, return_high - mean_return)),
            capsize=4,
        )
        mode_axes[1].set(title="Evaluation return", ylabel="Mean return")
        for axis in mode_axes:
            axis.tick_params(axis="x", rotation=15)
        mode_figure.tight_layout()
        mode_target = run / "evaluation_modes.png"
        mode_figure.savefig(mode_target, dpi=180)
        print(mode_target)
        plt.close(mode_figure)

        regimes = sorted(
            {
                regime
                for _, row in mode_results
                for regime in row.get("task_by_regime", {})
            }
        )
        if regimes:
            regime_figure, regime_axes = plt.subplots(1, 2, figsize=(12, 4.5))
            x = np.arange(len(regimes), dtype=float)
            width = 0.8 / len(mode_results)
            for index, (mode, row) in enumerate(mode_results):
                offset = (index - (len(mode_results) - 1) / 2) * width
                values = [
                    row.get("task_by_regime", {}).get(regime, {}).get(
                        "success_rate", 0.0
                    )
                    for regime in regimes
                ]
                returns = [
                    row.get("task_by_regime", {}).get(regime, {}).get(
                        "mean_return", 0.0
                    )
                    for regime in regimes
                ]
                label = display_names.get(mode, mode)
                regime_axes[0].bar(x + offset, values, width, label=label)
                regime_axes[1].bar(x + offset, returns, width, label=label)
            for axis in regime_axes:
                axis.set_xticks(x, regimes, rotation=20, ha="right")
                axis.legend(fontsize=8)
            regime_axes[0].set(
                title="Success by assigned mechanism",
                ylabel="Rate",
                ylim=(0, 1),
            )
            regime_axes[1].set(
                title="Return by assigned mechanism",
                ylabel="Mean return",
            )
            regime_figure.tight_layout()
            regime_target = run / "evaluation_by_regime.png"
            regime_figure.savefig(regime_target, dpi=180)
            print(regime_target)
            plt.close(regime_figure)


if __name__ == "__main__":
    main()
