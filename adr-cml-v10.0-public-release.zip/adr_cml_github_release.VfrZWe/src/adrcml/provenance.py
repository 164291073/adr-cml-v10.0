"""Small, deterministic provenance helpers; hashes do not certify scientific claims."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Any


def stable_hash(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"),
                         ensure_ascii=False, allow_nan=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def source_fingerprint(root: str | Path | None = None) -> str:
    """Hash installed package .py files including relative names, not caches."""
    root = Path(root) if root is not None else Path(__file__).resolve().parent
    return stable_hash({str(p.relative_to(root)): file_sha256(p)
                        for p in sorted(root.rglob("*.py"))})


def normalized_config(config: Any, *, resume: bool = False) -> dict:
    raw = config.to_dict() if hasattr(config, "to_dict") else copy.deepcopy(config)
    raw.pop("output_dir", None)
    raw.pop("device", None)
    if resume:
        # Extending a run and changing log frequency do not change its updates.
        raw.pop("logging", None)
        raw.get("agent", {}).pop("total_steps", None)
    return raw


def config_hash(config: Any, *, resume: bool = False) -> str:
    return stable_hash(normalized_config(config, resume=resume))
