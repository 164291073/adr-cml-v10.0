from __future__ import annotations

from typing import Any

from .mechanism_maze import MechanismMazeEnv


def make_env(name: str, **kwargs: Any):
    key = name.lower().replace("-", "_")
    if key in {"mechanism_maze", "mechanismmaze"}:
        return MechanismMazeEnv(**kwargs)
    if key in {"causal_world", "causalworld"}:
        from .causal_world_adapter import CausalWorldDiscreteAdapter

        return CausalWorldDiscreteAdapter(**kwargs)
    raise ValueError(f"Unknown environment {name!r}")

