from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass(frozen=True)
class DiscreteSpace:
    n: int

    def sample(self, rng: np.random.Generator | None = None) -> int:
        generator = rng if rng is not None else np.random.default_rng()
        return int(generator.integers(self.n))


class MechanismMazeEnv:
    """A compact factored POMDP with an unannounced mechanism change.

    The agent must gather two resources, forge a key, stabilize a bridge, open
    a lock, cross the bridge, and recover an artifact.  At ``shift_step`` one
    local structural mechanism changes.  The observation never includes the
    regime label; it is returned in ``info`` only for offline evaluation.

    State nodes (all normalized to [0, 1]):
      energy, material, key, bridge, door, crossed, artifact, shield.
    """

    node_names = (
        "energy",
        "material",
        "key",
        "bridge",
        "door",
        "crossed",
        "artifact",
        "shield",
    )
    action_names = (
        "gather",
        "charge",
        "forge_key",
        "build_bridge",
        "open_door",
        "cross_bridge",
        "collect_artifact",
        "wait",
        "probe_lock",
        "shield_bridge",
    )
    shift_modes = ("coupled_lock", "fragile_bridge", "draining_key")
    environment_profiles = ("train", "heldout_v1")
    task_action_access_modes = ("shared_shield", "legacy_probe_only")
    # Frozen protocol declaration, not fitted to evaluation outcomes. These
    # change parameter values inside known families, not mechanism identity.
    heldout_parameter_ranges = {
        "coupled_energy_threshold": (0.65, 0.85),
        "fragile_energy_threshold": (0.45, 0.65),
    }

    def __init__(
        self,
        max_steps: int = 64,
        shift_step: int = 28,
        shift_step_min: int | None = None,
        shift_step_max: int | None = None,
        shift_mode: str = "random",
        warmup_episodes: int = 0,
        observation_noise: float = 0.01,
        stochasticity: float = 0.03,
        coupled_energy_threshold: float = 0.55,
        fragile_energy_threshold: float = 0.35,
        draining_artifact_requires_key: bool = True,
        task_action_access: str = "shared_shield",
        environment_profile: str = "train",
        seed: int | None = None,
    ) -> None:
        if shift_mode not in (*self.shift_modes, "random", "none"):
            raise ValueError(f"Unknown shift_mode={shift_mode!r}")
        if not 0 < shift_step < max_steps:
            raise ValueError("shift_step must be inside the episode")
        self.max_steps = int(max_steps)
        self.shift_step_setting = int(shift_step)
        self.shift_step_min = None if shift_step_min is None else int(shift_step_min)
        self.shift_step_max = None if shift_step_max is None else int(shift_step_max)
        if (self.shift_step_min is None) != (self.shift_step_max is None):
            raise ValueError("shift_step_min and shift_step_max must be set together")
        if self.shift_step_min is not None and not (
            0 < self.shift_step_min <= self.shift_step_max < max_steps
        ):
            raise ValueError("shift step range must lie inside the episode")
        self.shift_step = self.shift_step_setting
        self.shift_mode_setting = shift_mode
        self.warmup_episodes = max(0, int(warmup_episodes))
        self.observation_noise = float(observation_noise)
        self.stochasticity = float(stochasticity)
        if task_action_access not in self.task_action_access_modes:
            raise ValueError(f"Unknown task_action_access={task_action_access!r}")
        if environment_profile not in self.environment_profiles:
            raise ValueError(f"Unknown environment_profile={environment_profile!r}")
        self.task_action_access = task_action_access
        self.environment_profile_setting = environment_profile
        self.environment_profile = environment_profile
        self._base_mechanism_parameters = {
            "coupled_energy_threshold": float(coupled_energy_threshold),
            "fragile_energy_threshold": float(fragile_energy_threshold),
        }
        if not all(0 < value <= 1 for value in self._base_mechanism_parameters.values()):
            raise ValueError("Mechanism energy thresholds must lie in (0, 1]")
        self.coupled_energy_threshold = float(coupled_energy_threshold)
        self.fragile_energy_threshold = float(fragile_energy_threshold)
        self.draining_artifact_requires_key = bool(draining_artifact_requires_key)
        self.rng = np.random.default_rng(seed)
        self.parameter_rng = np.random.default_rng(None if seed is None else int(seed) + 901_003)
        if task_action_access == "legacy_probe_only":
            self.action_names = (*self.action_names[:9], "probe_bridge")
        self.action_space = DiscreteSpace(len(self.action_names))
        self.state_dim = len(self.node_names)
        self.action_dim = len(self.action_names)
        self.state = np.zeros(self.state_dim, dtype=np.float32)
        self.step_count = 0
        self.regime = "base"
        self.episode_shift_mode = "coupled_lock"
        self._shifted = False
        self._drain_pending = False
        self.episode_index = -1

    def reset(
        self,
        seed: int | None = None,
        options: dict[str, Any] | None = None,
    ) -> tuple[np.ndarray, dict[str, Any]]:
        """Reset an episode, optionally forcing an offline evaluation scenario.

        ``options`` is deliberately handled only by the environment harness;
        it is never exposed to the agent.  It lets all evaluated methods face
        the same assigned regime and change time even when one policy would
        otherwise finish before a randomly sampled shift.
        """
        if seed is not None:
            self.rng = np.random.default_rng(seed)
            self.parameter_rng = np.random.default_rng(int(seed) + 901_003)
        options = options or {}
        self._configure_episode_parameters(options)
        initial_regime = options.get("initial_regime")
        if initial_regime is not None:
            if initial_regime not in ("base", *self.shift_modes):
                raise ValueError(f"Unknown initial_regime={initial_regime!r}")
            if "shift_step" in options or "shift_mode" in options:
                raise ValueError("initial_regime cannot be combined with a within-task shift")
        self.state = np.array([0.45, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32)
        self.step_count = 0
        self.regime = "base"
        self._shifted = False
        self._drain_pending = False
        self.episode_index += 1
        forced_shift_step = options.get("shift_step")
        if forced_shift_step is not None:
            forced_shift_step = int(forced_shift_step)
            if not 0 < forced_shift_step < self.max_steps:
                raise ValueError("forced shift_step must lie inside the episode")
            self.shift_step = forced_shift_step
        elif self.shift_step_min is None:
            self.shift_step = self.shift_step_setting
        else:
            self.shift_step = int(
                self.rng.integers(self.shift_step_min, self.shift_step_max + 1)
            )
        forced_mode = options.get("shift_mode")
        if forced_mode is not None:
            if forced_mode not in (*self.shift_modes, "none"):
                raise ValueError(f"Unknown forced shift_mode={forced_mode!r}")
            self.episode_shift_mode = str(forced_mode)
        elif self.episode_index < self.warmup_episodes:
            self.episode_shift_mode = "none"
        elif self.shift_mode_setting == "random":
            self.episode_shift_mode = str(self.rng.choice(self.shift_modes))
        elif self.shift_mode_setting == "none":
            self.episode_shift_mode = "none"
        else:
            self.episode_shift_mode = self.shift_mode_setting
        if initial_regime is not None:
            # Harness-only support/query protocol: the mechanism is already in
            # force and remains fixed across this task. No regime is in obs.
            self.regime = str(initial_regime)
            self.episode_shift_mode = "none" if initial_regime == "base" else str(initial_regime)
            self._shifted = initial_regime != "base"
        return self._observation(), self._info(
            shift_event=False,
            mechanism_event=False,
        )

    def _configure_episode_parameters(self, options: dict[str, Any]) -> None:
        """Harness-only parameter assignment, absent from observations/masks.

        Support/query callers must freeze the first reset's mechanism_parameters
        and pass them into every later reset in that session. Ordinary episodes
        sample their own profile parameters from an independent RNG stream.
        """
        profile = str(options.get("environment_profile", self.environment_profile_setting))
        if profile not in self.environment_profiles:
            raise ValueError(f"Unknown environment_profile={profile!r}")
        parameters = dict(self._base_mechanism_parameters)
        if profile == "heldout_v1":
            parameters.update({
                key: float(self.parameter_rng.uniform(low, high))
                for key, (low, high) in self.heldout_parameter_ranges.items()
            })
        overrides = options.get("mechanism_parameters", {})
        if not isinstance(overrides, dict) or set(overrides) - set(parameters):
            raise ValueError("Unknown mechanism_parameters override")
        parameters.update({key: float(value) for key, value in overrides.items()})
        if not all(np.isfinite(value) and 0 < value <= 1 for value in parameters.values()):
            raise ValueError("Mechanism energy thresholds must lie in (0, 1]")
        self.environment_profile = profile
        self.coupled_energy_threshold = parameters["coupled_energy_threshold"]
        self.fragile_energy_threshold = parameters["fragile_energy_threshold"]

    @property
    def mechanism_parameters(self) -> dict[str, float]:
        return {
            "coupled_energy_threshold": self.coupled_energy_threshold,
            "fragile_energy_threshold": self.fragile_energy_threshold,
        }

    def _observation(self) -> np.ndarray:
        obs = self.state.copy()
        if self.observation_noise > 0:
            obs += self.rng.normal(0.0, self.observation_noise, size=obs.shape).astype(np.float32)
        return np.clip(obs, 0.0, 1.0).astype(np.float32)

    @property
    def valid_action_mask(self) -> np.ndarray:
        # Mask actions whose public/base prerequisites are not met.  Hidden
        # regime-specific prerequisites are deliberately omitted so action
        # availability does not reveal the latent mechanism. Shielding is a
        # productive task action, available to every policy in the v10 protocol.
        energy, material, key, bridge, door, crossed, artifact, _ = range(self.state_dim)
        mask = np.ones(self.action_dim, dtype=bool)
        mask[0] = self.state[energy] >= 0.08 and self.state[material] < 1.0
        mask[1] = self.state[energy] < 1.0
        mask[2] = (
            self.state[material] >= 0.5
            and self.state[energy] >= 0.1
            and self.state[key] < 0.5
        )
        mask[3] = (
            self.state[material] >= 0.5
            and self.state[energy] >= 0.1
            and self.state[bridge] < 0.5
        )
        mask[4] = self.state[key] > 0.5 and self.state[door] < 0.5
        mask[5] = (
            self.state[bridge] > 0.5
            and self.state[door] > 0.5
            and self.state[crossed] < 0.5
        )
        mask[6] = (
            self.state[crossed] > 0.5
            and self.state[door] > 0.5
            and self.state[artifact] < 0.5
        )
        mask[7:] = False
        if self.task_action_access == "shared_shield":
            mask[9] = self.state[7] < 0.5
        return mask

    @property
    def intervention_action_mask(self) -> np.ndarray:
        mask = np.zeros(self.action_dim, dtype=bool)
        mask[8] = True  # probe_lock: no productive task-state gain
        if self.task_action_access == "legacy_probe_only":
            mask[9] = True
        return mask

    @property
    def task_action_mask(self) -> np.ndarray:
        mask = np.zeros(self.action_dim, dtype=bool)
        mask[:7] = True
        if self.task_action_access == "shared_shield":
            mask[9] = True
        return mask

    def _info(
        self,
        shift_event: bool,
        mechanism_event: bool = False,
        mechanism_nodes: list[int] | None = None,
    ) -> dict[str, Any]:
        return {
            "regime": self.regime,
            "environment_profile": self.environment_profile,
            "mechanism_parameters": self.mechanism_parameters,
            "task_action_access": self.task_action_access,
            "productive_shield_action": 9,
            "information_probe_actions": [8],
            "assigned_regime": self.episode_shift_mode,
            "shift_mode": self.episode_shift_mode,
            "shift_step": self.shift_step,
            "shift_event": shift_event,
            # Offline scoring only: the first transition that actually invokes
            # a changed conditional mechanism. The agent never receives this
            # field, preventing an unobservable graph switch from being scored
            # as an immediately detectable event.
            "mechanism_event": bool(mechanism_event),
            "mechanism_nodes": list(mechanism_nodes or []),
            "step": self.step_count,
            "episode_index": self.episode_index,
            "valid_action_mask": self.valid_action_mask.copy(),
            "task_action_mask": self.task_action_mask.copy(),
            "intervention_action_mask": self.intervention_action_mask.copy(),
            "true_adjacency": self.true_adjacency(),
            "true_adjacency_by_action": self.true_adjacency_by_action(),
            "node_names": self.node_names,
            "action_names": self.action_names,
            "success": bool(self.state[6] > 0.5),
            "experienced_shift": bool(self._shifted),
        }

    def state_dict(self) -> dict[str, Any]:
        """Exact simulator state used for interruption-safe training resume."""

        return {
            "state": self.state.copy(),
            "step_count": self.step_count,
            "regime": self.regime,
            "episode_shift_mode": self.episode_shift_mode,
            "shifted": self._shifted,
            "drain_pending": self._drain_pending,
            "episode_index": self.episode_index,
            "shift_step": self.shift_step,
            "rng_state": copy.deepcopy(self.rng.bit_generator.state),
            "parameter_rng_state": copy.deepcopy(self.parameter_rng.bit_generator.state),
            "environment_profile": self.environment_profile,
            "mechanism_parameters": self.mechanism_parameters,
            "task_action_access": self.task_action_access,
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        if state.get("task_action_access", "legacy_probe_only") != self.task_action_access:
            raise ValueError("Environment action-access protocol differs from saved state")
        values = np.asarray(state["state"], dtype=np.float32)
        if values.shape != (self.state_dim,):
            raise ValueError("Environment state dimension does not match")
        self.state = values.copy()
        self.step_count = int(state["step_count"])
        self.regime = str(state["regime"])
        self.episode_shift_mode = str(state["episode_shift_mode"])
        self._shifted = bool(state["shifted"])
        self._drain_pending = bool(state.get("drain_pending", False))
        self.episode_index = int(state["episode_index"])
        self.shift_step = int(state["shift_step"])
        self.rng.bit_generator.state = copy.deepcopy(state["rng_state"])
        if "parameter_rng_state" in state:
            self.parameter_rng.bit_generator.state = copy.deepcopy(state["parameter_rng_state"])
        self._configure_episode_parameters({
            "environment_profile": state.get("environment_profile", "train"),
            "mechanism_parameters": state.get("mechanism_parameters", self._base_mechanism_parameters),
        })
        # Configuration above must not advance the exact-resume parameter stream.
        if "parameter_rng_state" in state:
            self.parameter_rng.bit_generator.state = copy.deepcopy(state["parameter_rng_state"])

    def true_adjacency(self) -> np.ndarray:
        """Return the union of action-conditioned observable dependency annotations."""

        return self.true_adjacency_by_action().max(axis=0)

    def true_adjacency_by_action(self) -> np.ndarray:
        """Return potential observable parent->child annotations for each action.

        Prerequisite-controlled resource changes are included. The draining-key
        latch is hidden simulator state: its door->key annotation is an
        observable proxy, not a complete Markov SCM on the eight observations.
        History-conditioned gates are predictive structural hypotheses; graph
        scores against these annotations do not establish causal identification.
        """

        n = self.state_dim
        graphs = np.repeat(np.eye(n, dtype=np.float32)[None, :, :], self.action_dim, axis=0)
        energy, material, key, bridge, door, crossed, artifact, shield = range(n)

        def add(action: int, parent: int, child: int) -> None:
            graphs[action, parent, child] = 1.0

        # gather
        add(0, energy, material)
        # forge_key: both resources gate all three changed children.
        for parent, child in (
            (energy, material),
            (material, energy),
            (energy, key),
            (material, key),
        ):
            add(2, parent, child)
        # build_bridge
        for parent, child in (
            (energy, material),
            (material, energy),
            (energy, bridge),
            (material, bridge),
        ):
            add(3, parent, child)
        # open_door
        add(4, key, door)
        # cross_bridge: prerequisites control crossing and energy consumption.
        for parent, child in (
            (bridge, crossed),
            (door, crossed),
            (bridge, energy),
            (door, energy),
        ):
            add(5, parent, child)
        # collect_artifact
        add(6, crossed, artifact)
        add(6, door, artifact)

        if self.regime == "coupled_lock":
            add(4, bridge, door)
            add(4, energy, door)
        elif self.regime == "fragile_bridge":
            add(5, energy, crossed)
            add(5, shield, crossed)
            add(5, door, bridge)
            add(5, energy, bridge)
            add(5, shield, bridge)
            add(5, shield, energy)
        elif self.regime == "draining_key":
            # The one-step latch is internal simulator state.  Door is its
            # observable cause, so expose door->key for every possible action
            # on the following transition.
            graphs[:, door, key] = 1.0
            if self.draining_artifact_requires_key:
                add(6, key, artifact)
        return graphs

    def step(self, action: int) -> tuple[np.ndarray, float, bool, bool, dict[str, Any]]:
        if not 0 <= int(action) < self.action_dim:
            raise ValueError(f"action must be in [0, {self.action_dim})")

        self.step_count += 1
        shift_event = False
        if (
            not self._shifted
            and self.episode_shift_mode != "none"
            and self.step_count >= self.shift_step
        ):
            self.regime = self.episode_shift_mode
            self._shifted = True
            shift_event = True

        s = self.state.copy()
        energy, material, key, bridge, door, crossed, artifact, shield = range(self.state_dim)
        reward = -0.01
        success = False
        action = int(action)
        mechanism_event = False
        mechanism_nodes: list[int] = []

        if (
            shift_event
            and self.regime == "draining_key"
            and self.state[door] > 0.5
            and self.state[key] > 0.5
        ):
            self._drain_pending = True
        # The opened lock drains the key once on the following transition,
        # rather than on every later transition.
        if self.regime == "draining_key" and self._drain_pending:
            mechanism_event = bool(s[key] > 0.5)
            if mechanism_event:
                mechanism_nodes.append(key)
            s[key] = 0.0
            self._drain_pending = False

        # Small failures prevent the transition table from being perfectly deterministic.
        failed = self.rng.random() < self.stochasticity
        if action == 0 and s[energy] >= 0.08 and not failed:  # gather
            s[material] = min(1.0, s[material] + 0.5)
            s[energy] = max(0.0, s[energy] - 0.08)
            reward += 0.025
        elif action == 1 and not failed:  # charge
            s[energy] = min(1.0, s[energy] + 0.35)
        elif action == 2 and s[material] >= 0.5 and s[energy] >= 0.1 and not failed:
            s[key] = 1.0
            s[material] -= 0.5
            s[energy] -= 0.1
            reward += 0.04
        elif action == 3 and s[material] >= 0.5 and s[energy] >= 0.1 and not failed:
            s[bridge] = 1.0
            s[material] -= 0.5
            s[energy] -= 0.1
            reward += 0.04
        elif action == 4 and s[key] > 0.5 and not failed:
            coupled_ok = self.regime != "coupled_lock" or (
                s[bridge] > 0.5
                and s[energy] >= self.coupled_energy_threshold
            )
            if self.regime == "coupled_lock" and not coupled_ok:
                # Only score the first transition whose observable outcome
                # differs from the base mechanism.
                mechanism_event = True
                mechanism_nodes.append(door)
            if coupled_ok:
                was_closed = s[door] < 0.5
                s[door] = 1.0
                reward += 0.05
                if self.regime == "draining_key" and was_closed:
                    self._drain_pending = True
        elif action == 5 and s[bridge] > 0.5 and s[door] > 0.5 and not failed:
            fragile_ok = self.regime != "fragile_bridge" or (
                s[energy] >= self.fragile_energy_threshold and s[shield] > 0.5
            )
            if self.regime == "fragile_bridge" and not fragile_ok:
                mechanism_event = True
                mechanism_nodes.extend([energy, bridge, crossed])
            if fragile_ok:
                s[crossed] = 1.0
                s[energy] = max(0.0, s[energy] - 0.18)
                reward += 0.08
            elif self.regime == "fragile_bridge":
                s[bridge] = 0.0
                reward -= 0.08
        elif action == 6 and s[crossed] > 0.5 and s[door] > 0.5 and not failed:
            draining_ok = (
                self.regime != "draining_key"
                or not self.draining_artifact_requires_key
                or s[key] > 0.5
            )
            if (
                self.regime == "draining_key"
                and self.draining_artifact_requires_key
                and s[key] <= 0.5
            ):
                mechanism_event = True
                mechanism_nodes.append(artifact)
            if draining_ok:
                s[artifact] = 1.0
                reward += 1.0
                success = True
        elif action == 8:  # targeted lock intervention
            s[energy] = max(0.0, s[energy] - 0.025)
            if self.regime == "coupled_lock" and s[bridge] > 0.5:
                reward += 0.005
        elif action == 9:  # productive shielding, never an information-only probe
            s[energy] = max(0.0, s[energy] - 0.04)
            if not failed:
                s[shield] = 1.0
            if self.regime == "fragile_bridge":
                reward += 0.005

        self.state = np.clip(s, 0.0, 1.0).astype(np.float32)
        terminated = bool(success)
        truncated = bool(self.step_count >= self.max_steps and not terminated)
        return self._observation(), float(reward), terminated, truncated, self._info(
            shift_event,
            mechanism_event,
            sorted(set(mechanism_nodes)),
        )


def scripted_solution(shift_mode: str = "none") -> list[int]:
    """A diagnostic reference policy used in tests and upper-bound checks."""
    common = [1, 0, 0, 2, 3]
    if shift_mode == "coupled_lock":
        common += [1]
    common += [4]
    if shift_mode == "draining_key":
        common += [7, 0, 2]
    if shift_mode == "fragile_bridge":
        common += [1, 9]
    return common + [5, 6]
