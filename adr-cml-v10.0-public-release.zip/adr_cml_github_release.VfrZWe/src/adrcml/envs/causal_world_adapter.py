from __future__ import annotations

from typing import Any, Sequence

import numpy as np

from .mechanism_maze import DiscreteSpace


class CausalWorldDiscreteAdapter:
    """Optional discrete macro-action adapter for the official CausalWorld API.

    This bridge intentionally keeps benchmark installation separate because
    CausalWorld pins simulator dependencies. ``feature_indices`` should select
    semantically meaningful object/robot factors rather than raw pixels.
    """

    def __init__(
        self,
        task_generator_id: str = "pushing",
        feature_indices: Sequence[int] | None = None,
        action_magnitude: float = 0.35,
        skip_frame: int = 3,
        seed: int | None = None,
        **_: Any,
    ) -> None:
        try:
            from causal_world.envs import CausalWorld
            from causal_world.task_generators import generate_task
        except ImportError as exc:
            raise ImportError(
                "Install the optional simulator in a compatible environment: "
                "pip install -e '.[causalworld]'"
            ) from exc
        task = generate_task(task_generator_id=task_generator_id)
        self.env = CausalWorld(task=task, skip_frame=skip_frame, enable_visualization=False)
        self.rng = np.random.default_rng(seed)
        self.feature_indices = None if feature_indices is None else np.asarray(feature_indices, dtype=int)
        raw_action_dim = int(np.prod(self.env.action_space.shape))
        basis = np.eye(raw_action_dim, dtype=np.float32) * float(action_magnitude)
        self.macro_actions = np.concatenate(
            [np.zeros((1, raw_action_dim), dtype=np.float32), basis, -basis], axis=0
        )
        self.action_dim = len(self.macro_actions)
        self.action_space = DiscreteSpace(self.action_dim)
        raw = self.env.reset()
        self.state_dim = int(self._features(raw).size)
        self.node_names = tuple(f"factor_{i}" for i in range(self.state_dim))
        self.action_names = tuple(["noop"] + [f"joint_{i}_plus" for i in range(raw_action_dim)] + [f"joint_{i}_minus" for i in range(raw_action_dim)])

    def _features(self, observation: Any) -> np.ndarray:
        if isinstance(observation, tuple):
            observation = observation[0]
        vector = np.asarray(observation, dtype=np.float32).reshape(-1)
        if self.feature_indices is not None:
            vector = vector[self.feature_indices]
        scale = np.maximum(np.abs(vector).max(initial=1.0), 1.0)
        return np.clip((vector / scale + 1.0) / 2.0, 0.0, 1.0).astype(np.float32)

    def reset(self, seed: int | None = None):
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        obs = self.env.reset()
        return self._features(obs), {
            "valid_action_mask": np.ones(self.action_dim, dtype=bool),
            "task_action_mask": np.ones(self.action_dim, dtype=bool),
            "intervention_action_mask": np.zeros(self.action_dim, dtype=bool),
        }

    @property
    def valid_action_mask(self) -> np.ndarray:
        return np.ones(self.action_dim, dtype=bool)

    def step(self, action: int):
        result = self.env.step(self.macro_actions[int(action)])
        if len(result) == 4:
            obs, reward, done, info = result
            terminated, truncated = bool(done), False
        else:
            obs, reward, terminated, truncated, info = result
        info = dict(info)
        info["valid_action_mask"] = self.valid_action_mask
        info.setdefault("task_action_mask", np.ones(self.action_dim, dtype=bool))
        info.setdefault("intervention_action_mask", np.zeros(self.action_dim, dtype=bool))
        info.setdefault("shift_event", False)
        info.setdefault("success", bool(terminated))
        return self._features(obs), float(reward), bool(terminated), bool(truncated), info

    def close(self) -> None:
        self.env.close()
