"""ADR-CML: active relational causal mechanism learning for agents."""

__version__ = "10.0.0"

from .config import ExperimentConfig, load_config

__all__ = ["ExperimentConfig", "load_config", "__version__"]
