from __future__ import annotations

from collections import deque
from dataclasses import dataclass

import numpy as np


@dataclass
class DetectionResult:
    alarm: bool
    affected_nodes: list[int]
    z_scores: np.ndarray
    cusum: np.ndarray
    score: float
    localization_scores: np.ndarray | None = None


class NodewiseCUSUMDetector:
    """Online localized mechanism-change detector on node prediction NLLs."""

    def __init__(
        self,
        n_nodes: int,
        warmup: int = 300,
        ema_rate: float = 0.02,
        drift: float = 0.4,
        threshold: float = 8.0,
        decay: float = 0.98,
        cooldown: int = 50,
        localization_ratio: float = 0.8,
        max_affected_nodes: int = 0,
        localization_window: int = 8,
        confirmation_steps: int = 2,
        baseline_guard_z: float = 3.0,
        score_clip: float = 10.0,
        robust_window: int = 256,
        robust_min_samples: int = 64,
        robust_scale_floor: float = 0.05,
        action_conditioned_baseline: bool = True,
        action_min_samples: int = 16,
        n_actions: int | None = None,
        eps: float = 1e-5,
        rearm_steps: int = 3,
        rearm_z_threshold: float | None = None,
    ) -> None:
        self.n_nodes = int(n_nodes)
        self.warmup = int(warmup)
        self.ema_rate = float(ema_rate)
        self.drift = float(drift)
        self.threshold = float(threshold)
        self.decay = float(decay)
        self.cooldown = int(cooldown)
        self.localization_ratio = float(localization_ratio)
        self.max_affected_nodes = int(max_affected_nodes)
        self.localization_window = int(localization_window)
        self.confirmation_steps = int(confirmation_steps)
        self.baseline_guard_z = float(baseline_guard_z)
        self.score_clip = float(score_clip)
        self.robust_window = int(robust_window)
        self.robust_min_samples = int(robust_min_samples)
        self.robust_scale_floor = float(robust_scale_floor)
        self.action_conditioned_baseline = bool(action_conditioned_baseline)
        self.action_min_samples = int(action_min_samples)
        self.n_actions = None if n_actions is None else int(n_actions)
        self.eps = float(eps)
        self.rearm_steps = int(rearm_steps)
        self.rearm_z_threshold = (
            self.drift if rearm_z_threshold is None else float(rearm_z_threshold)
        )
        self._validate_configuration()
        self.count = 0
        self.mean = np.zeros(n_nodes, dtype=np.float64)
        self.var = np.ones(n_nodes, dtype=np.float64)
        self.cusum = np.zeros(n_nodes, dtype=np.float64)
        self.cooldown_left = 0
        self.confirmation_count = 0
        self.node_cooldown_left = np.zeros(n_nodes, dtype=np.int64)
        self.node_confirmation_count = np.zeros(n_nodes, dtype=np.int64)
        self.recent_positive_z: deque[np.ndarray] = deque(
            maxlen=self.localization_window
        )
        # A bounded, contamination-resistant reference window avoids the very
        # small EMA variance that made v0.5 fire repeatedly on harmless noise.
        self.robust_history: deque[np.ndarray] = deque(maxlen=self.robust_window)
        action_slots = 0 if self.n_actions is None else self.n_actions
        self.action_counts = np.zeros(action_slots, dtype=np.int64)
        self.action_mean = np.zeros((action_slots, n_nodes), dtype=np.float64)
        self.action_var = np.ones((action_slots, n_nodes), dtype=np.float64)
        self.action_robust_history: list[deque[np.ndarray]] = [
            deque(maxlen=self.robust_window) for _ in range(action_slots)
        ]
        # One extra slot handles calls without an action.  Rearming is based
        # solely on observed errors, never a hidden mechanism label.  An
        # alarmed pair must recover before another alarm on that pair, so a
        # persistent anomaly is one event rather than a cooldown-driven stream.
        pair_shape = (action_slots + 1, n_nodes)
        self.pair_armed = np.ones(pair_shape, dtype=bool)
        self.pair_normal_count = np.zeros(pair_shape, dtype=np.int64)
        self.pair_cooldown_left = np.zeros(pair_shape, dtype=np.int64)

    def _validate_configuration(self) -> None:
        if self.n_nodes < 1 or (self.n_actions is not None and self.n_actions < 1):
            raise ValueError("n_nodes and n_actions must be positive")
        if self.warmup < 0 or self.cooldown < 0 or self.max_affected_nodes < 0:
            raise ValueError("warmup, cooldown, and max_affected_nodes must be nonnegative")
        if self.localization_window < 1 or self.confirmation_steps < 1:
            raise ValueError("localization_window and confirmation_steps must be positive")
        if not 1 <= self.robust_min_samples <= self.robust_window:
            raise ValueError("robust_min_samples must be within [1, robust_window]")
        if not 1 <= self.action_min_samples <= self.robust_window:
            raise ValueError("action_min_samples must be within [1, robust_window]")
        for name in ("ema_rate", "decay", "localization_ratio"):
            value = getattr(self, name)
            if not np.isfinite(value) or not 0.0 < value <= 1.0:
                raise ValueError(f"{name} must be within (0, 1]")
        for name in ("threshold", "baseline_guard_z", "score_clip", "robust_scale_floor", "eps"):
            value = getattr(self, name)
            if not np.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if not np.isfinite(self.drift) or self.drift < 0.0:
            raise ValueError("drift must be finite and nonnegative")
        if self.rearm_steps < 0:
            raise ValueError("rearm_steps must be nonnegative")
        if not np.isfinite(self.rearm_z_threshold) or self.rearm_z_threshold > self.drift:
            raise ValueError("rearm_z_threshold must be finite and no greater than drift")

    def reset(self) -> None:
        self.count = 0
        self.mean.fill(0.0)
        self.var.fill(1.0)
        self.cusum.fill(0.0)
        self.cooldown_left = 0
        self.confirmation_count = 0
        self.node_cooldown_left.fill(0)
        self.node_confirmation_count.fill(0)
        self.pair_armed.fill(True)
        self.pair_normal_count.fill(0)
        self.pair_cooldown_left.fill(0)
        self.recent_positive_z.clear()
        self.robust_history.clear()
        self.action_counts.fill(0)
        self.action_mean.fill(0.0)
        self.action_var.fill(1.0)
        for history in self.action_robust_history:
            history.clear()

    def start_episode(self) -> None:
        """Clear transient evidence while retaining the learned error baseline."""
        self.cusum.fill(0.0)
        self.cooldown_left = 0
        self.confirmation_count = 0
        self.node_cooldown_left.fill(0)
        self.node_confirmation_count.fill(0)
        self.pair_armed.fill(True)
        self.pair_normal_count.fill(0)
        self.pair_cooldown_left.fill(0)
        self.recent_positive_z.clear()

    def reset_episode(self) -> None:
        """Alias for callers that name an episode boundary as a reset."""
        self.start_episode()

    def select_affected(self, scores: np.ndarray) -> list[int]:
        """Select nodes by relative evidence; zero cap means no cardinality cap."""

        values = np.asarray(scores, dtype=np.float64).reshape(-1)
        if values.size != self.n_nodes:
            raise ValueError(f"Expected {self.n_nodes} localization scores, got {values.size}")
        values = np.where(np.isfinite(values), np.maximum(values, 0.0), 0.0)
        maximum = float(values.max(initial=0.0))
        if maximum <= 0.0:
            return []
        cutoff = self.localization_ratio * maximum
        candidates = np.flatnonzero(values >= cutoff).astype(int)
        ranking = np.argsort(-values[candidates])
        if self.max_affected_nodes > 0:
            ranking = ranking[: self.max_affected_nodes]
        return candidates[ranking].tolist()

    def update(
        self,
        node_errors: np.ndarray,
        action: int | None = None,
        eligible: bool = True,
    ) -> DetectionResult:
        x = np.asarray(node_errors, dtype=np.float64).reshape(-1)
        if x.size != self.n_nodes:
            raise ValueError(f"Expected {self.n_nodes} node errors, got {x.size}")
        if not eligible:
            return DetectionResult(
                False,
                [],
                np.zeros(self.n_nodes, dtype=np.float64),
                self.cusum.copy(),
                float(self.cusum.max(initial=0.0)),
                np.zeros(self.n_nodes, dtype=np.float64),
            )
        if not np.all(np.isfinite(x)):
            raise ValueError("node_errors must contain only finite values")
        action_index: int | None = None
        if action is not None and self.n_actions is not None:
            action_index = int(action)
            if not 0 <= action_index < self.n_actions:
                raise ValueError(f"action must be in [0, {self.n_actions})")
        self.count += 1

        if self.count == 1:
            self.mean = x.copy()
            self.var.fill(1.0)
            z = np.zeros_like(x)
        else:
            old_mean = self.mean.copy()
            ema_z = (x - old_mean) / np.maximum(
                np.sqrt(self.var + self.eps),
                self.robust_scale_floor,
            )
            if len(self.robust_history) >= self.robust_min_samples:
                reference = np.stack(tuple(self.robust_history), axis=0)
                median = np.median(reference, axis=0)
                mad = np.median(np.abs(reference - median), axis=0)
                scale = np.maximum(1.4826 * mad, self.robust_scale_floor)
                z = (x - median) / scale
            else:
                z = ema_z
            rate = 1.0 / self.count if self.count <= self.warmup else self.ema_rate
            innovation = x - old_mean
            if self.count <= self.warmup:
                stable = np.ones(self.n_nodes, dtype=bool)
            else:
                # Do not absorb a suspected change into the reference model.
                # This makes sustained mechanism shifts remain detectable.
                stable = np.abs(z) < self.baseline_guard_z
            self.mean[stable] = (1.0 - rate) * self.mean[stable] + rate * x[stable]
            self.var[stable] = (
                (1.0 - rate) * self.var[stable]
                + rate * innovation[stable] ** 2
            )

        # Different actions naturally have very different prediction-error
        # distributions.  A single global reference made forge/key errors look
        # anomalous and dominated v0.6 localization.  Once enough samples are
        # available, normalize against an action-specific robust reference.
        if action_index is not None and self.action_conditioned_baseline:
            action_count = int(self.action_counts[action_index])
            action_mean = self.action_mean[action_index].copy()
            if action_count == 0:
                action_ema_z = np.zeros_like(x)
            else:
                action_ema_z = (x - action_mean) / np.maximum(
                    np.sqrt(self.action_var[action_index] + self.eps),
                    self.robust_scale_floor,
                )
            history = self.action_robust_history[action_index]
            if len(history) >= self.action_min_samples:
                reference = np.stack(tuple(history), axis=0)
                median = np.median(reference, axis=0)
                mad = np.median(np.abs(reference - median), axis=0)
                scale = np.maximum(1.4826 * mad, self.robust_scale_floor)
                z = (x - median) / scale
            elif action_count > 0:
                z = action_ema_z

            action_rate = 1.0 / (action_count + 1) if action_count < self.warmup else self.ema_rate
            action_stable = (
                np.ones(self.n_nodes, dtype=bool)
                if action_count < self.action_min_samples
                else np.abs(z) < self.baseline_guard_z
            )
            action_innovation = x - action_mean
            self.action_mean[action_index, action_stable] = (
                (1.0 - action_rate) * self.action_mean[action_index, action_stable]
                + action_rate * x[action_stable]
            )
            self.action_var[action_index, action_stable] = (
                (1.0 - action_rate) * self.action_var[action_index, action_stable]
                + action_rate * action_innovation[action_stable] ** 2
            )
            if (
                action_count < self.action_min_samples
                or float(np.max(np.abs(z), initial=0.0)) < self.baseline_guard_z
            ):
                history.append(x.copy())
            self.action_counts[action_index] += 1

        # The robust baseline is updated only with globally stable samples
        # after warmup, so the first observations from a new mechanism do not
        # immediately redefine normality.
        if self.count <= self.warmup or float(np.max(np.abs(z), initial=0.0)) < self.baseline_guard_z:
            self.robust_history.append(x.copy())

        action_ready = (
            action_index is None
            or not self.action_conditioned_baseline
            or self.action_counts[action_index] >= self.action_min_samples
        )
        if self.count <= self.warmup or not action_ready:
            self.cusum.fill(0.0)
            self.node_confirmation_count.fill(0)
            self.confirmation_count = 0
            return DetectionResult(
                False,
                [],
                z,
                self.cusum.copy(),
                0.0,
                np.zeros(self.n_nodes, dtype=np.float64),
            )

        pair_index = self.pair_armed.shape[0] - 1 if action_index is None else action_index
        if self.rearm_steps > 0:
            disarmed = ~self.pair_armed[pair_index]
            normal = z <= self.rearm_z_threshold
            self.pair_normal_count[pair_index] = np.where(
                disarmed & normal, self.pair_normal_count[pair_index] + 1, 0
            )
            recovered = disarmed & (
                self.pair_normal_count[pair_index] >= self.rearm_steps
            )
            self.pair_armed[pair_index, recovered] = True
            self.pair_normal_count[pair_index, recovered] = 0
            # A recovered event starts with no carried-over positive evidence.
            self.cusum[recovered] = 0.0
            self.node_confirmation_count[recovered] = 0
            for value in self.recent_positive_z:
                value[recovered] = 0.0

        # Signed increments are essential: ordinary observations must erase
        # evidence, instead of eventually accumulating harmless positive noise.
        increment = np.clip(z - self.drift, -self.score_clip, self.score_clip)
        positive_z = np.maximum(increment, 0.0)
        self.recent_positive_z.append(positive_z.copy())
        self.cusum = np.maximum(0.0, self.decay * self.cusum + increment)
        # Cooldown and recovery apply only to a reported action/node pair.
        # Another action can expose a separate mechanism at the same node.
        available = self.pair_cooldown_left[pair_index] == 0
        if self.rearm_steps > 0:
            available &= self.pair_armed[pair_index]
        self.pair_cooldown_left = np.maximum(0, self.pair_cooldown_left - 1)
        self.cusum[~available] = 0.0
        recent = np.stack(tuple(self.recent_positive_z), axis=0)
        localization = recent.mean(axis=0) * np.sqrt(len(recent))
        # Localize the current event, never stale cumulative evidence.  Current
        # evidence must agree with the recent window and the node be available.
        localization[~available | (positive_z <= 0.0)] = 0.0
        score = float(self.cusum.max(initial=0.0))
        exceeds = available & (self.cusum >= self.threshold) & (positive_z > 0.0)
        self.node_confirmation_count = np.where(
            exceeds, self.node_confirmation_count + 1, 0
        )
        confirmed = self.node_confirmation_count >= self.confirmation_steps
        alarm = bool(np.any(confirmed))
        affected = self.select_affected(localization) if alarm else []
        if alarm:
            self.cusum[affected] = 0.0
            self.pair_cooldown_left[pair_index, affected] = self.cooldown
            if self.rearm_steps > 0:
                self.pair_armed[pair_index, affected] = False
                self.pair_normal_count[pair_index, affected] = 0
            self.node_confirmation_count[affected] = 0
            # Keep independent nodes' evidence intact.
            for value in self.recent_positive_z:
                value[affected] = 0.0
        self.node_cooldown_left = self.pair_cooldown_left.max(axis=0)
        self.cooldown_left = int(self.node_cooldown_left.max(initial=0))
        self.confirmation_count = int(self.node_confirmation_count.max(initial=0))
        return DetectionResult(
            alarm,
            affected,
            z,
            self.cusum.copy(),
            score,
            localization.copy(),
        )

    def state_dict(self) -> dict:
        return {
            "count": self.count,
            "mean": self.mean.copy(),
            "var": self.var.copy(),
            "cusum": self.cusum.copy(),
            "cooldown_left": self.cooldown_left,
            "confirmation_count": self.confirmation_count,
            "node_cooldown_left": self.node_cooldown_left.copy(),
            "node_confirmation_count": self.node_confirmation_count.copy(),
            "pair_armed": self.pair_armed.copy(),
            "pair_normal_count": self.pair_normal_count.copy(),
            "pair_cooldown_left": self.pair_cooldown_left.copy(),
            "recent_positive_z": [value.copy() for value in self.recent_positive_z],
            "robust_history": [value.copy() for value in self.robust_history],
            "action_counts": self.action_counts.copy(),
            "action_mean": self.action_mean.copy(),
            "action_var": self.action_var.copy(),
            "action_robust_history": [
                [value.copy() for value in history]
                for history in self.action_robust_history
            ],
        }

    def load_state_dict(self, state: dict) -> None:
        self.count = int(state["count"])
        self.mean = np.asarray(state["mean"], dtype=np.float64).copy()
        self.var = np.asarray(state["var"], dtype=np.float64).copy()
        self.cusum = np.asarray(state["cusum"], dtype=np.float64).copy()
        for name in ("mean", "var", "cusum"):
            if getattr(self, name).shape != (self.n_nodes,):
                raise ValueError(f"Invalid detector checkpoint shape for {name}")
        self.cooldown_left = int(state["cooldown_left"])
        self.confirmation_count = int(state.get("confirmation_count", 0))
        # Old checkpoints only stored a global counter.  Preserve its meaning
        # on import, while every new v0.8 update operates node by node.
        self.node_cooldown_left = np.asarray(
            state.get("node_cooldown_left", np.full(self.n_nodes, self.cooldown_left)),
            dtype=np.int64,
        ).copy()
        self.node_confirmation_count = np.asarray(
            state.get("node_confirmation_count", np.full(self.n_nodes, self.confirmation_count)),
            dtype=np.int64,
        ).copy()
        for name in ("node_cooldown_left", "node_confirmation_count"):
            if getattr(self, name).shape != (self.n_nodes,):
                raise ValueError(f"Invalid detector checkpoint shape for {name}")
        pair_defaults = {
            "pair_armed": np.ones_like(self.pair_armed),
            "pair_normal_count": np.zeros_like(self.pair_normal_count),
            # Legacy node cooldown applies conservatively to every action.
            "pair_cooldown_left": np.broadcast_to(
                self.node_cooldown_left, self.pair_cooldown_left.shape
            ),
        }
        for name, default in pair_defaults.items():
            dtype = bool if name == "pair_armed" else np.int64
            values = np.asarray(state.get(name, default), dtype=dtype)
            if values.shape != getattr(self, name).shape:
                raise ValueError(f"Invalid detector checkpoint shape for {name}")
            if dtype is np.int64 and np.any(values < 0):
                raise ValueError(f"Invalid negative detector checkpoint value for {name}")
            setattr(self, name, values.copy())
        self.recent_positive_z.clear()
        for value in state.get("recent_positive_z", []):
            array = np.asarray(value, dtype=np.float64).reshape(-1)
            if array.size == self.n_nodes:
                self.recent_positive_z.append(array.copy())
        self.robust_history.clear()
        for value in state.get("robust_history", []):
            array = np.asarray(value, dtype=np.float64).reshape(-1)
            if array.size == self.n_nodes:
                self.robust_history.append(array.copy())
        if self.n_actions is not None:
            counts = np.asarray(
                state.get("action_counts", np.zeros(self.n_actions)),
                dtype=np.int64,
            )
            means = np.asarray(
                state.get("action_mean", np.zeros_like(self.action_mean)),
                dtype=np.float64,
            )
            variances = np.asarray(
                state.get("action_var", np.ones_like(self.action_var)),
                dtype=np.float64,
            )
            if counts.shape == self.action_counts.shape:
                self.action_counts = counts.copy()
            if means.shape == self.action_mean.shape:
                self.action_mean = means.copy()
            if variances.shape == self.action_var.shape:
                self.action_var = variances.copy()
            for history in self.action_robust_history:
                history.clear()
            raw_histories = state.get("action_robust_history", [])
            for index, values in enumerate(raw_histories[: self.n_actions]):
                for value in values:
                    array = np.asarray(value, dtype=np.float64).reshape(-1)
                    if array.size == self.n_nodes:
                        self.action_robust_history[index].append(array.copy())
