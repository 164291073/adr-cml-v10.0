"""Paired comparison of independently trained sparse and dense ablations.

The dense system is a within-project architectural control, not an external
published baseline. One trained seed yields descriptive effects with null
between-seed inference. Frozen-query audits do not establish causality.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any

import numpy as np

from . import __version__
from .aggregate_sessions import COSTS, _hierarchical_indices, _validate_result
from .compare_evaluations import holm_adjust, paired_sign_flip_test
from .evaluate_sessions import SESSION_MODES, _fingerprint, _sha256_file
from .provenance import config_hash


ALLOWED_MODEL_DIFFERENCES = (
    "dense_graph", "sparsity_weight", "parent_budget_weight",
    "action_gate_regularization", "edge_entropy_weight",
)
CONTRASTS = {"sparse_full_vs_dense_full": "full", "sparse_full_vs_dense_online_only": "online_only"}
ENDPOINTS = {"query_return": ("query", "mean_return", "higher"), "probe_mse": ("probe_after", "mse", "lower")}
ARCHITECTURE_STATISTICAL_PLAN = {
    "confirmatory_profile": "heldout_v1",
    "contrasts": list(CONTRASTS),
    "endpoints": list(ENDPOINTS),
    "holm_family": [f"{contrast}/{endpoint}" for contrast in CONTRASTS for endpoint in ENDPOINTS],
    "family_size": 4,
    "interpretation": "independently_trained_dense_ablation_not_external_published_baseline",
    "prediction_endpoint": "prediction_improvement_does_not_establish_task_return_improvement",
}


def _normalized_config(raw: dict[str, Any]) -> dict[str, Any]:
    value = copy.deepcopy(raw)
    for name in ("seed", "output_dir", "device", "logging"):
        value.pop(name, None)
    return value


def _without_architecture(spec: dict[str, Any]) -> dict[str, Any]:
    value = copy.deepcopy(spec)
    for key in ALLOWED_MODEL_DIFFERENCES:
        value["training_config"]["model"].pop(key, None)
    return value


def _audit_banks(result: dict[str, Any], directory: Path) -> list[dict[str, str]]:
    audits = []
    for row in result["mode_sessions"]["full"]:
        name = row.get("probe_bank_file")
        if not name or Path(name).name != name:
            raise ValueError("Probe bank must be a local named file in the session directory")
        path = directory / name
        if not path.is_file() or _sha256_file(path) != row.get("probe_bank_sha256"):
            raise ValueError("Probe bank file missing or SHA256 mismatch")
        with np.load(path, allow_pickle=False) as archive:
            bank = {key: archive[key] for key in archive.files}
        if _fingerprint(bank) != row.get("probe_bank_hash"):
            raise ValueError("Probe bank content fingerprint mismatch")
        if len(bank.get("action", [])) != result["probe_samples_per_session"]:
            raise ValueError("Probe bank sample count mismatch")
        rollout_seeds = [int(seed) for seed in np.unique(bank.get("rollout_seed", []))]
        if rollout_seeds != row["probe_rollout_seeds"]:
            raise ValueError("Probe bank rollout seed manifest mismatch")
        audits.append({"path": str(path.resolve()), "sha256": row["probe_bank_sha256"], "content_hash": row["probe_bank_hash"]})
    return audits


def compare_architectures(root: str | Path, *, profile: str, output: str | Path,
                          bootstrap_samples: int = 10000, seed: int = 202710) -> dict[str, Any]:
    if profile not in ("train", "heldout_v1"):
        raise ValueError("profile must be train or heldout_v1")
    if int(bootstrap_samples) != bootstrap_samples or bootstrap_samples < 1:
        raise ValueError("bootstrap_samples must be a positive integer")
    root, destination = Path(root), Path(output)
    if destination.exists():
        raise FileExistsError("Choose a new architecture comparison output")
    directories = sorted(path for path in root.glob("seed_*") if path.is_dir())
    if not directories:
        raise FileNotFoundError("No seed_* pipeline directories")
    try:
        directory_seeds = [int(path.name.removeprefix("seed_")) for path in directories]
    except ValueError as error:
        raise ValueError("All seed_* directories must identify an integer seed") from error
    if len(set(directory_seeds)) != len(directory_seeds):
        raise ValueError("Duplicate training seed directories")
    manifest_path = root / "protocol_manifest.json"
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else None
    if manifest is not None:
        expected = manifest.get("training_seeds", [])
        if len(set(expected)) != len(expected) or set(expected) != set(directory_seeds):
            raise ValueError("Missing or extra training seeds relative to fixed pipeline manifest")
        if set(manifest.get("architectures", [])) != {"sparse", "dense"}:
            raise ValueError("Manifest must prespecify sparse and dense architectures")
        if profile not in manifest.get("environment_profiles", []):
            raise ValueError("Requested profile is absent from pipeline manifest")

    by_arch: dict[str, list[dict[str, Any]]] = {"sparse": [], "dense": []}
    inputs = []
    checksums: set[str] = set()
    model_hashes: set[str] = set()
    evaluation_seeds: set[int] = set()
    seen_reset_seeds: set[int] = set()
    shared_specs = []
    for directory, training_seed in zip(directories, directory_seeds):
        pair = {}
        for architecture in ("sparse", "dense"):
            path = directory / architecture / "sessions" / profile / "session_evaluation.json"
            if not path.is_file():
                raise FileNotFoundError(f"Incomplete architecture/session result: {path}")
            result = json.loads(path.read_text(encoding="utf-8"))
            _validate_result(result)
            if set(result["mode_sessions"]) != set(SESSION_MODES):
                raise ValueError("Every prespecified session mode is required for architecture comparison")
            if result.get("training_seed") != training_seed or result.get("environment_profile") != profile:
                raise ValueError("Directory training seed or evaluation profile mismatch")
            config = result.get("training_config")
            if not isinstance(config, dict) or config.get("seed") != training_seed:
                raise ValueError("Full training configuration and matching seed are required")
            if result.get("training_config_hash") != config_hash(config):
                raise ValueError("Training configuration hash mismatch")
            if config["model"].get("dense_graph") is not (architecture == "dense"):
                raise ValueError("Architecture directory does not match trained model.dense_graph")
            spec = result["protocol_spec"]
            if spec.get("training_config") != _normalized_config(config):
                raise ValueError("Protocol configuration does not match the trained configuration")
            if result.get("training_steps") != config["agent"]["total_steps"] or spec.get("training_steps") != result["training_steps"]:
                raise ValueError("Training did not complete the planned step budget")
            for field in ("training_source_hash", "evaluation_source_hash"):
                if not result.get(field) or spec.get(field) != result[field]:
                    raise ValueError("Missing or inconsistent training/evaluation source provenance")
            if manifest is not None:
                planned = manifest.get("resolved_training_configs", {}).get(f"seed_{training_seed}/{architecture}")
                if planned is None or config_hash(planned) != config_hash(config):
                    raise ValueError("Trained configuration differs from fixed pipeline plan")
                expected_fields = {"training_steps": "training_steps_per_architecture", "sessions": "sessions",
                                   "support_episodes_per_session": "support_episodes", "query_episodes_per_session": "query_episodes",
                                   "probe_samples_per_session": "probe_samples", "active_budget_per_task": "active_budget"}
                if any(result.get(a) != manifest.get(b) for a, b in expected_fields.items()):
                    raise ValueError("Training/session budgets differ from fixed pipeline plan")
            for key, seen in (("checkpoint_sha256", checksums), ("model_sha256", model_hashes)):
                value = result.get(key)
                if not value or value in seen:
                    raise ValueError("Distinct checkpoint and model hashes required for independently trained architectures/seeds")
                seen.add(value)
            audits = _audit_banks(result, path.parent)
            inputs.append({"path": str(path.resolve()), "sha256": _sha256_file(path), "architecture": architecture,
                           "training_seed": training_seed, "checkpoint_sha256": result["checkpoint_sha256"],
                           "model_sha256": result["model_sha256"], "probe_banks": audits})
            pair[architecture] = result
            by_arch[architecture].append(result)
            shared_specs.append(_without_architecture(spec))
        sparse, dense = pair["sparse"], pair["dense"]
        if sparse["evaluation_seed"] != dense["evaluation_seed"] or sparse["evaluation_seed"] in evaluation_seeds:
            raise ValueError("Architectures need paired evaluation seeds, distinct between training seeds")
        evaluation_seeds.add(sparse["evaluation_seed"])
        identity = ("session", "regime", "support_seeds", "query_seeds", "environment_profile",
                    "mechanism_parameters", "probe_bank_hash", "probe_rollout_seeds")
        current_seeds: set[int] = set()
        for left, right in zip(sparse["mode_sessions"]["full"], dense["mode_sessions"]["full"]):
            if any(left.get(field) != right.get(field) for field in identity):
                raise ValueError("Architectures are not paired on sessions, parameters, tasks and probe bank content")
            current_seeds.update(value for name in ("support_seeds", "query_seeds", "probe_rollout_seeds") for value in left[name])
        if current_seeds & seen_reset_seeds:
            raise ValueError("Shared task/probe seeds between training seeds require a crossed bootstrap")
        seen_reset_seeds.update(current_seeds)
    if len({_fingerprint(spec) for spec in shared_specs}) != 1:
        raise ValueError("Architectures/seeds differ in settings beyond the permitted dense/regularizer ablation")

    sparse_results = by_arch["sparse"]
    intervals_available = len(directories) >= 2 and all(
        all(sum(row["regime"] == regime for row in result["mode_sessions"]["full"]) >= 2
            for regime in result["protocol_spec"]["regimes"]) for result in sparse_results)
    indices = _hierarchical_indices(sparse_results, bootstrap_samples, np.random.default_rng(seed)) if intervals_available else None
    pvalues = {name: None for name in ARCHITECTURE_STATISTICAL_PLAN["holm_family"]}
    comparisons = {}
    for contrast, dense_mode in CONTRASTS.items():
        comparisons[contrast] = {}
        for endpoint, (section, field, direction) in ENDPOINTS.items():
            raw = [[(left[section][field], right[section][field]) for left, right in zip(
                    sparse["mode_sessions"]["full"], dense["mode_sessions"][dense_mode])]
                   for sparse, dense in zip(by_arch["sparse"], by_arch["dense"])]
            if any(left is None or right is None for rows in raw for left, right in rows):
                comparisons[contrast][endpoint] = {"available": False, "reason": "undefined_endpoint", "holm_pvalue": None}
                continue
            effects = np.asarray([[left - right for left, right in rows] for rows in raw], dtype=float)
            means = effects.mean(axis=1)
            test = paired_sign_flip_test(means, seed=seed, samples=100000)
            ci = None
            if indices is not None:
                outer, inner = indices
                bootstrap = effects[outer[:, :, None], inner].mean(axis=(1, 2))
                ci = np.quantile(bootstrap, [0.025, 0.975]).tolist()
            comparisons[contrast][endpoint] = {
                "available": True, "difference": "sparse_full_minus_dense_comparator", "better_direction": direction,
                "mean_difference": float(means.mean()), "training_seed_mean_differences": means.tolist(),
                "session_differences_by_training_seed": effects.tolist(), "ci95": ci,
                "signflip": test, "positive_seed_count": int((means > 0).sum()), "negative_seed_count": int((means < 0).sum()),
                "paired_raw_values_by_training_seed": raw,
            }
            pvalues[f"{contrast}/{endpoint}"] = test["p_value"]
    adjusted = holm_adjust(pvalues)
    for contrast in CONTRASTS:
        for endpoint in ENDPOINTS:
            comparisons[contrast][endpoint]["holm_pvalue"] = adjusted[f"{contrast}/{endpoint}"]
    costs = {
        architecture: {
            mode: {
                cost: {"per_training_seed": [sum(row[phase][cost] for row in result["mode_sessions"][mode]) for result in results]}
                for cost in COSTS for phase in ("support",)
            } for mode in SESSION_MODES
        } for architecture, results in by_arch.items()
    }
    report = {
        "schema": "paired_independently_trained_architecture_comparison_v1", "software_version": __version__,
        "environment_profile": profile, "is_confirmatory_profile": profile == "heldout_v1",
        "baseline_interpretation": ARCHITECTURE_STATISTICAL_PLAN["interpretation"],
        "training_seeds": directory_seeds, "n_training_seeds": len(directory_seeds),
        "training_steps_per_model": sparse_results[0]["training_steps"],
        "statistical_plan": ARCHITECTURE_STATISTICAL_PLAN, "comparisons": comparisons,
        "bootstrap_unit": "paired_training_seed_then_paired_session_within_regime",
        "bootstrap_samples": bootstrap_samples, "statistics_seed": seed, "intervals_available": intervals_available,
        "interval_unavailable_reason": None if intervals_available else "need_two_training_seeds_and_two_sessions_per_regime_per_seed",
        "ci_multiplicity": "pointwise_unadjusted; Holm_controls_the_four_signflip_tests",
        "allowed_model_configuration_differences": list(ALLOWED_MODEL_DIFFERENCES),
        "shared_protocol_after_removing_architecture": shared_specs[0],
        "equal_budget_interpretation": "same_prespecified_caps_and_training_steps; realized_support_costs_reported_not_assumed_equal",
        "support_costs": costs, "inputs": inputs,
        "manifest_sha256": _sha256_file(manifest_path) if manifest is not None else None,
        "manifest_audit": "verified" if manifest is not None else "absent; all_discovered_seed_directories_required",
        "inference_limit": "heldout_parameters_of_known_mechanism_families_only; no_external_baseline_or_publication_guarantee",
    }
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True)
    parser.add_argument("--profile", choices=("train", "heldout_v1"), required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=202710)
    args = parser.parse_args()
    result = compare_architectures(args.root, profile=args.profile, output=args.output,
                                   bootstrap_samples=args.bootstrap_samples, seed=args.seed)
    print(json.dumps({"training_seeds": result["training_seeds"], "profile": args.profile, "output": args.output}))


if __name__ == "__main__":
    main()
