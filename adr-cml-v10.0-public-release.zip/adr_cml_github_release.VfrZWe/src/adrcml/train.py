from __future__ import annotations

import argparse
import json
import os
import random
import platform
import time
from collections import deque
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
import torch
import yaml

from . import __version__
from .agent import ADRCMLAgent
from .config import ExperimentConfig, load_config
from .envs import make_env
from .metrics import (
    GRAPH_METRIC_METADATA,
    RegimeGraphTracker,
    change_detection_metrics,
    node_set_metrics,
    structural_metrics,
)
from .provenance import config_hash, file_sha256, source_fingerprint
from .utils import (
    OutputRunLock,
    append_jsonl,
    configure_torch_runtime,
    device_description,
    resolve_device,
    save_json,
    set_seed,
)


def build_agent(config: ExperimentConfig, state_dim: int, action_dim: int) -> ADRCMLAgent:
    device = resolve_device(config.device)
    configure_torch_runtime(device)
    return ADRCMLAgent(
        state_dim=state_dim,
        action_dim=action_dim,
        model_config=config.model,
        agent_config=config.agent,
        detector_config=config.detector,
        planner_config=config.planner,
        device=device,
        seed=config.seed,
    )


def _save_checkpoint(
    path: Path,
    agent: ADRCMLAgent,
    config: ExperimentConfig,
    step: int,
    env: Any,
    experiment_state: dict[str, Any],
) -> None:
    """Atomically save every state required to continue the next transition."""

    path.parent.mkdir(parents=True, exist_ok=True)
    payload = agent.checkpoint()
    payload["config"] = config.to_dict()
    payload["software_version"] = __version__
    payload["source_hash"] = source_fingerprint()
    payload["config_hash"] = config_hash(config)
    payload["step"] = int(step)
    payload["environment_state"] = (
        env.state_dict() if hasattr(env, "state_dict") else None
    )
    payload["exact_environment_resume"] = payload["environment_state"] is not None
    payload["experiment_state"] = experiment_state
    payload["random_state"] = {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch_cpu": torch.get_rng_state(),
        "torch_cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
    }
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def _restore_random_state(state: dict[str, Any]) -> None:
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch_cpu"])
    cuda_state = state.get("torch_cuda")
    if cuda_state is not None and torch.cuda.is_available():
        torch.cuda.set_rng_state_all(cuda_state)


def _truncate_log_after_checkpoint(path: Path, checkpoint_step: int) -> None:
    """Discard crash-tail records newer than the state being resumed."""

    if not path.exists():
        return
    retained: list[str] = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError as error:
            raise RuntimeError(f"Invalid JSONL at {path}:{line_number}") from error
        if int(record.get("step", 0)) <= int(checkpoint_step):
            retained.append(json.dumps(record, ensure_ascii=False))
    temporary = path.with_name(f".{path.name}.resume-{os.getpid()}")
    with temporary.open("w", encoding="utf-8") as handle:
        if retained:
            handle.write("\n".join(retained) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def run_experiment(
    config: ExperimentConfig,
    resume_checkpoint: str | None = None,
    force_stale_lock: bool = False,
) -> dict[str, Any]:
    output = Path(config.output_dir)
    with OutputRunLock(output, force_stale=force_stale_lock):
        return _run_experiment_locked(config, resume_checkpoint)


def _run_experiment_locked(
    config: ExperimentConfig,
    resume_checkpoint: str | None,
) -> dict[str, Any]:
    set_seed(config.seed)
    output = Path(config.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    existing_training = [
        path
        for path in (
            output / "train.jsonl",
            output / "checkpoint_final.pt",
            output / "summary.json",
        )
        if path.exists()
    ]
    existing_training.extend(
        path for path in sorted(output.glob("checkpoint_*.pt"))
        if path not in existing_training
    )
    if resume_checkpoint is None and existing_training:
        names = ", ".join(path.name for path in existing_training)
        raise FileExistsError(
            f"Refusing to overwrite an existing run in {output}: {names}. "
            "Choose a new --output directory or pass --resume with a v10.0 checkpoint."
        )
    # Validate before touching any previous run's resolved configuration or logs.
    checkpoint = None
    if resume_checkpoint is not None:
        checkpoint = torch.load(resume_checkpoint, map_location="cpu", weights_only=False)
        if checkpoint.get("software_version") != __version__:
            raise RuntimeError("v10.0 requires a v10.0 checkpoint; use a fresh directory for older versions.")
        if config_hash(checkpoint.get("config", {}), resume=True) != config_hash(config, resume=True):
            raise ValueError("Resume configuration differs in seed, environment, model or learning settings. "
                             "Use the original config; only total steps, device, output and logging may change.")
        if checkpoint.get("source_hash") != source_fingerprint():
            raise ValueError("Resume source fingerprint differs; restore the exact v10.0 source used for training.")
        if int(config.agent.total_steps) < int(checkpoint["step"]):
            raise ValueError("total_steps cannot be less than the resumed checkpoint step")
        required = {"environment_state", "experiment_state", "random_state", "history_context"}
        missing = sorted(required.difference(checkpoint))
        if missing:
            raise RuntimeError("Exact resume checkpoint is incomplete: " + ", ".join(missing))
    run_metadata = {
        "software_version": __version__, "source_hash": source_fingerprint(),
        "config_hash": config_hash(config), "training_seed": config.seed,
        "training_used_oracle_diagnosis": config.agent.oracle_diagnosis,
        "python": platform.python_version(), "pytorch": torch.__version__,
        "numpy": np.__version__, "device_requested": config.device,
        "resume_checkpoint_hash": file_sha256(resume_checkpoint) if resume_checkpoint else None,
        "training_status": "started",
    }
    save_json(output / "run_metadata.json", run_metadata)
    with (output / "config_resolved.yaml").open("w", encoding="utf-8") as handle:
        yaml.safe_dump(config.to_dict(), handle, sort_keys=False)
    log_path = output / "train.jsonl"

    env = make_env(**asdict(config.environment), seed=config.seed)
    agent = build_agent(config, env.state_dim, env.action_dim)
    print(f"ADR-CML device: {device_description(agent.device)}")
    graph_tracker = RegimeGraphTracker(window=100)

    if resume_checkpoint is not None:
        assert checkpoint is not None
        if checkpoint["environment_state"] is None or not hasattr(env, "load_state_dict"):
            raise RuntimeError(
                "This environment adapter does not expose exact simulator state; "
                "start a new run instead of using --resume."
            )
        agent.load_checkpoint(checkpoint, load_optimizer=True)
        env.load_state_dict(checkpoint["environment_state"])
        saved = checkpoint["experiment_state"]
        start_step = int(checkpoint["step"]) + 1
        state = np.asarray(saved["state"], dtype=np.float32).copy()
        info = saved["info"]
        episode_return = float(saved["episode_return"])
        episode_length = int(saved["episode_length"])
        episode_start_step = int(saved["episode_start_step"])
        episode_shift_step = saved.get("episode_shift_step")
        episode_activation_step = saved.get("episode_activation_step")
        episode_activated_affected = list(
            saved.get("episode_activated_affected", [])
        )
        episode_action_counts = np.asarray(saved["episode_action_counts"], dtype=np.int64)
        episode_state_changes = int(saved["episode_state_changes"])
        episode_action_kinds = dict(saved["episode_action_kinds"])
        action_kind_totals = dict(saved["action_kind_totals"])
        episode_true_affected = saved.get("episode_true_affected")
        episode_predicted_affected = saved.get("episode_predicted_affected")
        episode = int(saved["episode"])
        returns = deque(saved["returns"], maxlen=100)
        successes = deque(saved["successes"], maxlen=100)
        change_windows = [tuple(row) for row in saved["change_windows"]]
        alarm_steps = [int(value) for value in saved["alarm_steps"]]
        repair_count = int(saved["repair_count"])
        repair_attempts = int(saved["repair_attempts"])
        rejected_repairs = int(saved["rejected_repairs"])
        unactivated_shift_episodes = int(saved.get("unactivated_shift_episodes", 0))
        partial_window_finalized = bool(saved.get("partial_window_finalized", False))
        # A final checkpoint may later be extended to a larger step budget.
        # Re-open its unfinished episode's scoring window before continuing.
        if partial_window_finalized and start_step <= config.agent.total_steps:
            expected_partial = (
                episode_start_step,
                episode_activation_step,
                int(checkpoint["step"]),
            )
            if (
                episode_activation_step is not None
                and change_windows
                and tuple(change_windows[-1]) == expected_partial
            ):
                change_windows.pop()
            elif episode_activation_step is None and episode_shift_step is not None:
                unactivated_shift_episodes = max(0, unactivated_shift_episodes - 1)
            partial_window_finalized = False
        diagnosis_records = list(saved["diagnosis_records"])
        graph_tracker.load_state_dict(saved["graph_tracker"])
        start_time = time.time() - float(saved.get("elapsed_seconds", 0.0))
        _truncate_log_after_checkpoint(log_path, int(checkpoint["step"]))
        _truncate_log_after_checkpoint(output / "repairs.jsonl", int(checkpoint["step"]))
        _restore_random_state(checkpoint["random_state"])
        print(f"Exact resume from step {int(checkpoint['step'])}")
    else:
        start_step = 1
        state, info = env.reset(seed=config.seed)
        agent.on_episode_reset()
        episode_return = 0.0
        episode_length = 0
        episode_start_step = start_step
        episode_shift_step: int | None = None
        episode_activation_step: int | None = None
        episode_activated_affected: list[int] = []
        episode_action_counts = np.zeros(env.action_dim, dtype=np.int64)
        episode_state_changes = 0
        episode_action_kinds: dict[str, int] = {}
        action_kind_totals: dict[str, int] = {}
        episode_true_affected: list[int] | None = None
        episode_predicted_affected: list[int] | None = None
        episode = 0
        returns: deque[float] = deque(maxlen=100)
        successes: deque[float] = deque(maxlen=100)
        change_windows: list[tuple[int, int, int]] = []
        alarm_steps: list[int] = []
        repair_count = 0
        repair_attempts = 0
        rejected_repairs = 0
        unactivated_shift_episodes = 0
        partial_window_finalized = False
        diagnosis_records: list[dict[str, float]] = []
        start_time = time.time()

    def capture_experiment_state() -> dict[str, Any]:
        return {
            "state": np.asarray(state, dtype=np.float32).copy(),
            "info": info,
            "episode_return": episode_return,
            "episode_length": episode_length,
            "episode_start_step": episode_start_step,
            "episode_shift_step": episode_shift_step,
            "episode_activation_step": episode_activation_step,
            "episode_activated_affected": list(episode_activated_affected),
            "episode_action_counts": episode_action_counts.copy(),
            "episode_state_changes": episode_state_changes,
            "episode_action_kinds": dict(episode_action_kinds),
            "action_kind_totals": dict(action_kind_totals),
            "episode_true_affected": episode_true_affected,
            "episode_predicted_affected": episode_predicted_affected,
            "episode": episode,
            "returns": list(returns),
            "successes": list(successes),
            "change_windows": list(change_windows),
            "alarm_steps": list(alarm_steps),
            "repair_count": repair_count,
            "repair_attempts": repair_attempts,
            "rejected_repairs": rejected_repairs,
            "unactivated_shift_episodes": unactivated_shift_episodes,
            "partial_window_finalized": partial_window_finalized,
            "diagnosis_records": list(diagnosis_records),
            "graph_tracker": graph_tracker.state_dict(),
            "elapsed_seconds": time.time() - start_time,
        }

    for global_step in range(start_step, config.agent.total_steps + 1):
        action = agent.act(
            state,
            info.get("valid_action_mask"),
            info.get("task_action_mask"),
            info.get("intervention_action_mask"),
        )
        action_kind = agent.last_action_kind
        episode_action_kinds[action_kind] = episode_action_kinds.get(action_kind, 0) + 1
        action_kind_totals[action_kind] = action_kind_totals.get(action_kind, 0) + 1
        next_state, reward, terminated, truncated, next_info = env.step(action)
        episode_action_counts[action] += 1
        episode_state_changes += int(np.max(np.abs(next_state - state)) > 1e-6)
        done = terminated or truncated
        if next_info.get("shift_event", False):
            episode_shift_step = global_step
            before_graph = info.get("true_adjacency")
            after_graph = next_info.get("true_adjacency")
            if before_graph is not None and after_graph is not None:
                episode_true_affected = np.flatnonzero(
                    np.any(before_graph != after_graph, axis=0)
                ).astype(int).tolist()
        if next_info.get("mechanism_event", False) and episode_activation_step is None:
            episode_activation_step = global_step
        if next_info.get("mechanism_event", False):
            episode_activated_affected = sorted(
                set(episode_activated_affected).union(next_info.get("mechanism_nodes", []))
            )
        report = agent.observe(
            state,
            action,
            reward,
            next_state,
            done,
            step=global_step,
            valid_action_mask=info.get("valid_action_mask"),
        )
        if config.agent.oracle_diagnosis and next_info.get("mechanism_event", False):
            affected = [int(value) for value in next_info.get("mechanism_nodes", [])]
            if affected:
                forced = agent.force_repair(affected, step=global_step)
                if forced.get("queued", False):
                    report.alarm = True
                    report.affected_nodes = list(forced["affected_nodes"])
                    report.repair = forced
        episode_return += reward
        episode_length += 1
        if report.alarm:
            alarm_steps.append(global_step)
            if (
                episode_activation_step is not None
                and global_step >= episode_activation_step
                and episode_predicted_affected is None
            ):
                episode_predicted_affected = list(report.affected_nodes or [])
        if report.repair and int(report.repair.get("steps", 0)) > 0:
            repair_attempts += 1
            if report.repair.get("applied"):
                repair_count += 1
            elif report.repair.get("rejected"):
                rejected_repairs += 1

        if report.repair is not None:
            append_jsonl(output / "repairs.jsonl", {
                "step": global_step, "episode": episode + 1,
                "trigger_action": action, **report.repair,
            })

        state, info = next_state, next_info
        if done:
            graph_metrics_episode: dict[str, float] = {}
            true_graph = next_info.get("true_adjacency")
            if true_graph is not None:
                learned_graph = agent.model.adjacency().detach().cpu().numpy()
                graph_tracker.update(
                    str(next_info.get("regime", "unknown")),
                    learned_graph,
                    true_graph,
                )
                graph_metrics_episode = structural_metrics(learned_graph, true_graph)
            diagnosis_episode: dict[str, float] = {}
            if (
                episode_true_affected is not None
                and episode_activation_step is not None
            ):
                diagnosis_episode = node_set_metrics(
                    episode_predicted_affected or [],
                    episode_activated_affected,
                )
                diagnosis_records.append(diagnosis_episode)
            if episode_activation_step is not None:
                change_windows.append(
                    (episode_start_step, episode_activation_step, global_step)
                )
            elif episode_shift_step is not None:
                unactivated_shift_episodes += 1
            episode += 1
            returns.append(episode_return)
            successes.append(float(next_info.get("success", terminated)))
            append_jsonl(
                log_path,
                {
                    "type": "episode",
                    "step": global_step,
                    "episode": episode,
                    "return": episode_return,
                    "length": episode_length,
                    "success": bool(next_info.get("success", terminated)),
                    "regime": next_info.get("regime"),
                    "alarm": report.alarm,
                    "affected_nodes": report.affected_nodes,
                    "shift_step": episode_shift_step,
                    "mechanism_activation_step": episode_activation_step,
                    "state_change_steps": episode_state_changes,
                    "action_counts": episode_action_counts.tolist(),
                    "action_kinds": dict(episode_action_kinds),
                    "true_affected_nodes": episode_true_affected,
                    "activated_affected_nodes": episode_activated_affected,
                    "predicted_affected_nodes": episode_predicted_affected,
                    **diagnosis_episode,
                    **graph_metrics_episode,
                },
            )
            state, info = env.reset()
            agent.on_episode_reset()
            episode_return = 0.0
            episode_length = 0
            episode_start_step = global_step + 1
            episode_shift_step = None
            episode_activation_step = None
            episode_activated_affected = []
            episode_action_counts.fill(0)
            episode_state_changes = 0
            episode_action_kinds = {}
            episode_true_affected = None
            episode_predicted_affected = None

        if global_step % config.logging.log_interval == 0:
            elapsed = max(time.time() - start_time, 1e-6)
            record = {
                "type": "progress",
                "step": global_step,
                "episodes": episode,
                "return_100": float(np.mean(returns)) if returns else 0.0,
                "success_100": float(np.mean(successes)) if successes else 0.0,
                "alarms": len(alarm_steps),
                "repairs": repair_count,
                "repair_attempts": repair_attempts,
                "rejected_repairs": rejected_repairs,
                "steps_per_second": global_step / elapsed,
                "training_loss": report.training_loss,
                "detector_score": report.detector_score,
                "action_kinds": dict(action_kind_totals),
            }
            if report.training_metrics is not None:
                record.update(report.training_metrics)
            append_jsonl(log_path, record)
            print(
                f"step={global_step:>7} return100={record['return_100']:.3f} "
                f"success100={record['success_100']:.2%} alarms={len(alarm_steps)}"
            )
        if global_step % config.logging.checkpoint_interval == 0:
            _save_checkpoint(
                output / f"checkpoint_{global_step}.pt",
                agent,
                config,
                global_step,
                env,
                capture_experiment_state(),
            )

    if not partial_window_finalized and episode_activation_step is not None:
        change_windows.append(
            (episode_start_step, episode_activation_step, config.agent.total_steps)
        )
        partial_window_finalized = True
    elif not partial_window_finalized and episode_shift_step is not None:
        unactivated_shift_episodes += 1
        partial_window_finalized = True
    final_path = output / "checkpoint_final.pt"
    _save_checkpoint(
        final_path,
        agent,
        config,
        config.agent.total_steps,
        env,
        capture_experiment_state(),
    )
    adjacency = agent.model.adjacency().detach().cpu().numpy()
    adjacency_by_action = agent.model.adjacency_by_action().detach().cpu().numpy()
    graph_summary = graph_tracker.summary()
    union_graph = graph_tracker.union_target()
    graph_metrics = structural_metrics(adjacency, union_graph) if union_graph is not None else {}
    diagnosis_summary = {
        key: float(np.mean([record[key] for record in diagnosis_records]))
        for key in (
            "diagnosis_precision",
            "diagnosis_recall",
            "diagnosis_f1",
            "diagnosis_exact",
        )
    } if diagnosis_records else {}
    summary = {
        "software_version": __version__,
        "source_hash": source_fingerprint(),
        "config_hash": config_hash(config),
        "checkpoint_sha256": file_sha256(output / "checkpoint_final.pt"),
        "training_used_oracle_diagnosis": config.agent.oracle_diagnosis,
        "graph_metric_metadata": GRAPH_METRIC_METADATA,
        "seed": config.seed,
        "total_steps": config.agent.total_steps,
        "episodes": episode,
        "return_100": float(np.mean(returns)) if returns else 0.0,
        "success_rate_100": float(np.mean(successes)) if successes else 0.0,
        "alarms": len(alarm_steps),
        "repairs": repair_count,
        "repair_attempts": repair_attempts,
        "rejected_repairs": rejected_repairs,
        "unactivated_shift_episodes": unactivated_shift_episodes,
        "detection_target": "first_observable_changed_mechanism_activation",
        "action_kinds": action_kind_totals,
        "elapsed_seconds": time.time() - start_time,
        **change_detection_metrics(change_windows, alarm_steps, config.agent.total_steps),
        **graph_metrics,
        **diagnosis_summary,
        "graph_target": "union_of_observed_regimes",
        "graph_aligned": graph_summary,
    }
    save_json(output / "summary.json", summary)
    np.save(output / "learned_adjacency.npy", adjacency)
    np.save(output / "learned_adjacency_by_action.npy", adjacency_by_action)
    if union_graph is not None:
        np.save(output / "true_adjacency.npy", union_graph)
        np.save(output / "true_adjacency_union.npy", union_graph)
    if graph_tracker.targets:
        np.savez(
            output / "true_adjacency_by_regime.npz",
            **graph_tracker.targets,
        )
        np.savez(
            output / "learned_adjacency_by_regime.npz",
            **graph_tracker.last_predicted,
        )
    save_json(
        output / "labels.json",
        {
            "node_names": list(getattr(env, "node_names", range(env.state_dim))),
            "action_names": list(getattr(env, "action_names", range(env.action_dim))),
            "graph_axis_order": "parent_to_child",
            "graph_target_definition": "observable_action_transition_dependency_proxy",
        },
    )
    print(f"Finished. Results: {output / 'summary.json'}")
    run_metadata["training_status"] = "completed"
    run_metadata["completed_steps"] = config.agent.total_steps
    run_metadata["checkpoint_sha256"] = summary["checkpoint_sha256"]
    save_json(output / "run_metadata.json", run_metadata)
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train ADR-CML")
    parser.add_argument("--config", default="configs/main.yaml")
    parser.add_argument("--override", default=None)
    parser.add_argument("--output", default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--total-steps", type=int, default=None)
    parser.add_argument("--resume", default=None, help="Resume model/optimizer/detector checkpoint")
    parser.add_argument(
        "--force-stale-lock",
        action="store_true",
        help="Remove a stale lock only after verifying its local owner is no longer running",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = load_config(args.config, args.override)
    if args.output is not None:
        config.output_dir = args.output
    if args.seed is not None:
        config.seed = args.seed
    if args.total_steps is not None:
        config.agent.total_steps = int(args.total_steps)
    run_experiment(
        config,
        resume_checkpoint=args.resume,
        force_stale_lock=args.force_stale_lock,
    )


if __name__ == "__main__":
    main()
