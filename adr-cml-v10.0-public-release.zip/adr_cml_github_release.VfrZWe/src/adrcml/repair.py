from __future__ import annotations

import copy
import hashlib
import random
from contextlib import contextmanager
from dataclasses import dataclass, field

import numpy as np
import torch
from torch import Tensor

from .buffer import ReplayBuffer
from .models import EnsembleWorldModel


@dataclass
class RepairReport:
    applied: bool
    affected_nodes: list[int]
    steps: int
    initial_loss: float
    final_loss: float
    anchor_size: int = 0
    recent_size: int = 0
    rejected: bool = False
    training_size: int = 0
    validation_size: int = 0
    relative_improvement: float = 0.0
    unaffected_relative_degradation: float = 0.0
    graph_delta_l1: float = 0.0
    graph_locality: float = 0.0
    skip_reason: str | None = None
    eligible_size: int = 0
    accepted_steps: int = 0
    target_actions: list[int] = field(default_factory=list)
    action_counts: dict[str, dict[str, int]] = field(default_factory=dict)
    training_indices: list[int] = field(default_factory=list)
    validation_indices: list[int] = field(default_factory=list)
    initial_unaffected_loss: float = 0.0
    final_unaffected_loss: float = 0.0
    target_action_initial_loss: dict[str, float] = field(default_factory=dict)
    target_action_final_loss: dict[str, float] = field(default_factory=dict)
    target_action_relative_improvement: dict[str, float] = field(default_factory=dict)
    primary_acceptance_metric: str = "ensemble_mean_next_state_mse"
    initial_target_mse: float = 0.0
    final_target_mse: float = 0.0
    initial_unaffected_mse: float = 0.0
    final_unaffected_mse: float = 0.0
    mse_relative_improvement: float = 0.0
    unaffected_mse_relative_degradation: float = 0.0
    target_action_initial_mse: dict[str, float] = field(default_factory=dict)
    target_action_final_mse: dict[str, float] = field(default_factory=dict)
    target_action_mse_relative_improvement: dict[str, float] = field(default_factory=dict)
    rng_isolated: bool = True
    graph_audit_scope: str = "active_context_only_not_causal_correctness"
    acceptance_target_nodes: list[int] = field(default_factory=list)
    trained_nodes: list[int] = field(default_factory=list)
    acceptance_scope: str = "same_diagnosed_children_and_complement_guard_for_local_and_global"


class LocalMechanismRepair:
    """Evidence-gated local update with chronological, action-constrained validation.

    One global time cutoff separates training from all validation observations.
    Action quotas constrain the cutoff; if none is feasible, repair waits.
    No repeated sampling or pre-alarm transition can satisfy the evidence minima.
    Passing the holdout demonstrates predictive improvement, not causal validity.
    """

    def __init__(
        self,
        model: EnsembleWorldModel,
        optimizer: torch.optim.Optimizer,
        device: str,
        repair_steps: int = 32,
        repair_batch_size: int = 256,
        anchor_batch_size: int = 128,
        distill_weight: float = 0.5,
        gradient_clip: float = 10.0,
        local: bool = True,
        loss_weights: dict[str, float] | None = None,
        validation_fraction: float = 0.25,
        min_relative_improvement: float = 0.005,
        max_unaffected_degradation: float = 0.01,
        min_train_samples: int = 8,
        min_validation_samples: int = 4,
        min_target_action_train: int = 2,
        min_target_action_validation: int = 1,
        max_nll_degradation: float = 0.01,
        rng_seed: int = 0,
    ) -> None:
        self.model = model
        self.optimizer = optimizer
        self.device = device
        self.repair_steps = max(0, int(repair_steps))
        self.repair_batch_size = max(1, int(repair_batch_size))
        self.anchor_batch_size = max(1, int(anchor_batch_size))
        self.distill_weight = float(distill_weight)
        self.gradient_clip = float(gradient_clip)
        self.local = bool(local)
        self.loss_weights = loss_weights or {}
        self.validation_fraction = float(np.clip(validation_fraction, 0.1, 0.5))
        self.min_relative_improvement = max(0.0, float(min_relative_improvement))
        self.max_unaffected_degradation = max(0.0, float(max_unaffected_degradation))
        self.min_train_samples = max(1, int(min_train_samples))
        self.min_validation_samples = max(1, int(min_validation_samples))
        self.min_target_action_train = max(1, int(min_target_action_train))
        self.min_target_action_validation = max(1, int(min_target_action_validation))
        self.max_nll_degradation = max(0.0, float(max_nll_degradation))
        self.rng_seed = int(rng_seed)

    def _validation_losses(self, batch: object, node_mask: Tensor) -> tuple[Tensor, Tensor, Tensor, Tensor]:
        """NLL and ensemble-mean MSE on the fixed, chronological holdout.

        NLL alone is insufficient: increasing predictive variance can reduce NLL
        without correcting the mean. The MSE gate cannot be satisfied that way.
        """
        errors = self.model.prediction_error(batch)
        if hasattr(self.model, "prediction_mse"):
            mse = self.model.prediction_mse(batch)
        elif hasattr(self.model, "predict_members"):
            means, _, _, _ = self.model.predict_members(
                batch.state, batch.action, context=getattr(batch, "context", None),
            )
            mse = (means.mean(0) - batch.next_state).square().mean(0)
        else:
            raise TypeError("repair validation requires prediction_mse or predict_members")
        unaffected_mask = 1.0 - node_mask
        def reduce(values: Tensor, mask: Tensor) -> Tensor:
            return (values * mask).sum() / mask.sum().clamp_min(1.0)
        return (reduce(errors, node_mask), reduce(errors, unaffected_mask),
                reduce(mse, node_mask), reduce(mse, unaffected_mask))

    @contextmanager
    def _isolated_randomness(self, identity: tuple):
        """Use a reproducible event-local stream without consuming caller RNG.

        Only devices that hold model parameters/buffers are seeded or restored.
        Python and legacy NumPy streams are also isolated for extension models.
        Replay's private generator is not used by the chronological repair.
        """
        digest = hashlib.blake2b(repr((self.rng_seed, identity)).encode(), digest_size=8).digest()
        seed = int.from_bytes(digest, "little") % (2 ** 63 - 1)
        devices = sorted({value.device.index for value in
                          [*self.model.parameters(), *self.model.buffers()]
                          if value.device.type == "cuda"})
        python_state, numpy_state = random.getstate(), np.random.get_state()
        try:
            with torch.random.fork_rng(devices=devices):
                torch.random.default_generator.manual_seed(seed)
                for device in devices:
                    torch.cuda.default_generators[device].manual_seed(seed)
                random.seed(seed)
                np.random.seed(seed % (2 ** 32))
                yield
        finally:
            random.setstate(python_state)
            np.random.set_state(numpy_state)

    @staticmethod
    def _zero_module_gradients(module: torch.nn.Module) -> None:
        for parameter in module.parameters():
            parameter.grad = None

    def _mask_local_gradients(self, affected: Tensor) -> None:
        if not self.local:
            return
        affected_set = set(torch.nonzero(affected, as_tuple=False).reshape(-1).tolist())
        for member in self.model.members:
            if member.edge_logits.grad is not None:
                member.edge_logits.grad.mul_(affected.reshape(1, -1))
            if member.action_edge_logits is not None and member.action_edge_logits.grad is not None:
                member.action_edge_logits.grad.mul_(affected.reshape(1, 1, -1))
            for child in range(member.state_dim):
                if child in affected_set:
                    continue
                self._zero_module_gradients(member.self_mechanisms[child])
                self._zero_module_gradients(member.node_heads[child])
                for name in ("context_encoders", "context_gate_heads"):
                    modules = getattr(member, name, None)
                    if modules is not None and child < len(modules):
                        self._zero_module_gradients(modules[child])
            for name in ("action_embedding", "reward_head", "done_head", "validity_head"):
                self._zero_module_gradients(getattr(member, name))

    def _split_evidence(
        self, replay: ReplayBuffer, indices: np.ndarray, target_actions: list[int],
    ) -> tuple[np.ndarray, np.ndarray, dict[str, dict[str, int]]]:
        """Find a single time cutoff satisfying total and target-action quotas.

        The global ordering is essential when replay includes history context:
        training after an earlier holdout would expose that holdout's outcomes
        through the stored history, even with disjoint physical indices.
        """
        chronological = indices[np.argsort(replay.steps[indices], kind="stable")]
        actions = sorted(set(replay.actions[indices].tolist()).union(target_actions))
        desired_validation = int(np.ceil(len(indices) * self.validation_fraction))
        best = None
        for split in range(len(chronological) + 1):
            # Multiple entries can share an environment step. Never split such
            # a group: all training steps must precede every validation step.
            if 0 < split < len(chronological) and replay.steps[chronological[split - 1]] >= replay.steps[chronological[split]]:
                continue
            training, validation = chronological[:split], chronological[split:]
            counts = {
                str(action): {
                    "eligible": int(np.sum(replay.actions[chronological] == action)),
                    "training": int(np.sum(replay.actions[training] == action)),
                    "validation": int(np.sum(replay.actions[validation] == action)),
                }
                for action in actions
            }
            deficit = max(0, self.min_train_samples - len(training)) + max(0, self.min_validation_samples - len(validation))
            for action in target_actions:
                deficit += max(0, self.min_target_action_train - counts[str(action)]["training"])
                deficit += max(0, self.min_target_action_validation - counts[str(action)]["validation"])
            # Every feasible split has zero deficit. Prefer the split nearest
            # the configured holdout fraction. If none is feasible, return the
            # least deficient partition so the waiting report remains useful.
            score = (deficit, abs(len(validation) - desired_validation), -split)
            if best is None or score < best[0]:
                best = (score, training, validation, counts)
        assert best is not None
        return best[1], best[2], best[3]

    def repair(
        self,
        replay: ReplayBuffer,
        affected_nodes: list[int],
        change_step: int,
        current_step: int,
        target_actions: list[int] | None = None,
        target_action: int | None = None,
        evidence_start_step: int | None = None,
    ) -> RepairReport:
        identity = (tuple(sorted(set(affected_nodes))), int(change_step), int(current_step),
                    tuple(sorted(set(target_actions or []))), target_action, evidence_start_step)
        with self._isolated_randomness(identity):
            return self._repair_impl(replay, affected_nodes, change_step, current_step,
                                     target_actions, target_action, evidence_start_step)

    def _repair_impl(
        self,
        replay: ReplayBuffer,
        affected_nodes: list[int],
        change_step: int,
        current_step: int,
        target_actions: list[int] | None = None,
        target_action: int | None = None,
        evidence_start_step: int | None = None,
    ) -> RepairReport:
        affected_nodes = sorted(set(int(node) for node in affected_nodes))
        targets = sorted(set(int(a) for a in (target_actions or [])))
        if target_action is not None:
            targets = sorted(set(targets).union([int(target_action)]))
        report = RepairReport(False, affected_nodes, 0, 0.0, 0.0, target_actions=targets)
        if not affected_nodes:
            report.skip_reason = "no_affected_nodes"
            return report
        if any(node < 0 or node >= self.model.state_dim for node in affected_nodes):
            raise ValueError("affected node outside model state dimension")
        report.acceptance_target_nodes = list(affected_nodes)
        report.trained_nodes = list(affected_nodes) if self.local else list(range(self.model.state_dim))
        start_step = int(change_step if evidence_start_step is None else evidence_start_step)
        physical = replay._physical_indices()
        pre_change = physical[replay.steps[physical] < start_step]
        post_change = physical[(replay.steps[physical] >= start_step) & (replay.steps[physical] <= int(current_step))]
        training, validation_indices, action_counts = self._split_evidence(replay, post_change, targets)
        report.anchor_size = min(len(pre_change), self.anchor_batch_size)
        report.recent_size = report.eligible_size = int(len(post_change))
        report.training_size, report.validation_size = int(len(training)), int(len(validation_indices))
        report.training_indices, report.validation_indices = training.tolist(), validation_indices.tolist()
        report.action_counts = action_counts
        if any(
            action_counts[str(action)]["training"] < self.min_target_action_train
            or action_counts[str(action)]["validation"] < self.min_target_action_validation
            for action in targets
        ):
            report.skip_reason = "insufficient_target_action_evidence"
            return report
        if len(training) < self.min_train_samples or len(validation_indices) < self.min_validation_samples:
            report.skip_reason = "insufficient_total_evidence"
            return report
        if self.repair_steps == 0:
            report.skip_reason = "repair_disabled"
            return report
        # Locality changes optimization freedom, never the acceptance target.
        # Otherwise a global repair can dilute a failed target repair in other
        # children and has no meaningful unaffected-mechanism guard.
        validation_node_mask = torch.zeros(self.model.state_dim, device=self.device)
        validation_node_mask[affected_nodes] = 1.0
        training_node_mask = validation_node_mask.clone() if self.local else torch.ones_like(validation_node_mask)
        teacher = copy.deepcopy(self.model).eval()
        was_training = self.model.training
        caller_gradients = [(parameter, None if parameter.grad is None else parameter.grad.detach().clone())
                            for parameter in self.model.parameters()]
        try:
            adjacency_before = None
            if hasattr(self.model, "adjacency"):
                with torch.no_grad():
                    adjacency_before = self.model.adjacency().detach().clone()
            for parameter in teacher.parameters():
                parameter.requires_grad_(False)
            # A fresh optimizer prevents stale moments or decoupled weight decay
            # from changing zero-gradient columns outside the local repair.
            repair_optimizer = torch.optim.Adam(self.model.parameters(), lr=float(self.optimizer.param_groups[0]["lr"]))
            anchor = (
                replay.batch_from_indices(pre_change[-self.anchor_batch_size :], self.device)
                if len(pre_change) else None
            )
            validation = replay.batch_from_indices(validation_indices, self.device)
            action_validation = {
                str(action): replay.batch_from_indices(validation_indices[replay.actions[validation_indices] == action], self.device)
                for action in targets
            }
            self.model.eval()
            with torch.no_grad():
                initial_validation, initial_unaffected, initial_mse, initial_unaffected_mse = self._validation_losses(validation, validation_node_mask)
                report.target_action_initial_loss = {
                    action: float(self._validation_losses(batch, validation_node_mask)[0].item())
                    for action, batch in action_validation.items()
                }
                report.target_action_initial_mse = {
                    action: float(self._validation_losses(batch, validation_node_mask)[2].item())
                    for action, batch in action_validation.items()
                }
            self.model.train()
            for iteration in range(self.repair_steps):
                # Each update uses unique training observations. Cycling the fixed
                # training set is optimization, never counted as new evidence.
                offset = (iteration * self.repair_batch_size) % len(training)
                selected = np.roll(training, -offset)[: self.repair_batch_size]
                recent = replay.batch_from_indices(selected, self.device)
                loss, _ = self.model.loss(recent, node_mask=training_node_mask, **self.loss_weights)
                if self.local and self.distill_weight > 0 and anchor is not None and len(self.model.members):
                    unaffected = 1.0 - validation_node_mask
                    distill_terms = []
                    for student, fixed in zip(self.model.members, teacher.members):
                        kwargs = {"sample_edges": False}
                        if getattr(anchor, "context", None) is not None:
                            kwargs["context"] = anchor.context
                        student_out = student(anchor.state, anchor.action, **kwargs)
                        with torch.no_grad():
                            teacher_out = fixed(anchor.state, anchor.action, **kwargs)
                        difference = (student_out.next_mean - teacher_out.next_mean).pow(2)
                        distill = (difference * unaffected.reshape(1, -1)).sum()
                        distill_terms.append(distill / (unaffected.sum() * difference.shape[0]).clamp_min(1.0))
                    loss = loss + self.distill_weight * torch.stack(distill_terms).mean()
                repair_optimizer.zero_grad(set_to_none=True)
                if not bool(torch.isfinite(loss)):
                    report.skip_reason = "nonfinite_training_loss"
                    break
                loss.backward()
                self._mask_local_gradients(training_node_mask)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.gradient_clip)
                repair_optimizer.step()
                report.steps += 1
            self.model.eval()
            with torch.no_grad():
                final_validation, final_unaffected, final_mse, final_unaffected_mse = self._validation_losses(validation, validation_node_mask)
                report.target_action_final_loss = {
                    action: float(self._validation_losses(batch, validation_node_mask)[0].item())
                    for action, batch in action_validation.items()
                }
                report.target_action_final_mse = {
                    action: float(self._validation_losses(batch, validation_node_mask)[2].item())
                    for action, batch in action_validation.items()
                }
            report.initial_target_mse, report.final_target_mse = float(initial_mse.item()), float(final_mse.item())
            report.initial_unaffected_mse, report.final_unaffected_mse = float(initial_unaffected_mse.item()), float(final_unaffected_mse.item())
            report.mse_relative_improvement = (report.initial_target_mse - report.final_target_mse) / max(report.initial_target_mse, 1e-8)
            report.unaffected_mse_relative_degradation = (report.final_unaffected_mse - report.initial_unaffected_mse) / max(report.initial_unaffected_mse, 1e-8)
            report.target_action_mse_relative_improvement = {
                action: (initial - report.target_action_final_mse[action]) / max(initial, 1e-8)
                for action, initial in report.target_action_initial_mse.items()
            }
            report.initial_loss, report.final_loss = float(initial_validation.item()), float(final_validation.item())
            report.initial_unaffected_loss, report.final_unaffected_loss = float(initial_unaffected.item()), float(final_unaffected.item())
            report.relative_improvement = (report.initial_loss - report.final_loss) / max(abs(report.initial_loss), 1e-8)
            report.unaffected_relative_degradation = (report.final_unaffected_loss - report.initial_unaffected_loss) / max(abs(report.initial_unaffected_loss), 1e-8)
            report.target_action_relative_improvement = {
                action: (initial - report.target_action_final_loss[action]) / max(abs(initial), 1e-8)
                for action, initial in report.target_action_initial_loss.items()
            }
            validation_values = [
                report.initial_loss, report.final_loss,
                report.initial_unaffected_loss, report.final_unaffected_loss,
                report.initial_target_mse, report.final_target_mse,
                report.initial_unaffected_mse, report.final_unaffected_mse,
                *report.target_action_initial_loss.values(), *report.target_action_final_loss.values(),
                *report.target_action_initial_mse.values(), *report.target_action_final_mse.values(),
            ]
            finite = all(np.isfinite(value) for value in validation_values)
            mse_improved = (report.mse_relative_improvement >= self.min_relative_improvement
                            and report.final_target_mse < report.initial_target_mse)
            action_mse_improved = all(
                improvement >= self.min_relative_improvement
                and report.target_action_final_mse[action] < report.target_action_initial_mse[action]
                for action, improvement in report.target_action_mse_relative_improvement.items()
            )
            nll_guard = (report.relative_improvement >= -self.max_nll_degradation
                         and all(value >= -self.max_nll_degradation
                                 for value in report.target_action_relative_improvement.values())
                         and report.unaffected_relative_degradation <= self.max_nll_degradation)
            collateral_ok = report.unaffected_mse_relative_degradation <= self.max_unaffected_degradation
            report.applied = bool(report.steps > 0 and report.skip_reason is None and finite
                                  and mse_improved and action_mse_improved and nll_guard and collateral_ok)
            report.rejected = not report.applied
            if report.rejected:
                self.model.load_state_dict(teacher.state_dict())
                if report.skip_reason is None:
                    if not finite:
                        report.skip_reason = "nonfinite_validation_loss"
                    elif not collateral_ok:
                        report.skip_reason = "collateral_degradation"
                    elif not mse_improved:
                        report.skip_reason = "insufficient_holdout_mse_improvement"
                    elif not action_mse_improved:
                        report.skip_reason = "insufficient_target_action_mse_improvement"
                    else:
                        report.skip_reason = "nll_calibration_guard"
            else:
                report.accepted_steps = report.steps
                parameters = list(self.model.parameters()) if not self.local else self.model.incoming_parameters(affected_nodes)
                if adjacency_before is not None:
                    with torch.no_grad():
                        graph_delta = (self.model.adjacency().detach() - adjacency_before).abs()
                        graph_delta.fill_diagonal_(0.0)
                        report.graph_delta_l1 = float(graph_delta.sum().item())
                        affected_delta = float(graph_delta[:, affected_nodes].sum().item())
                        report.graph_locality = affected_delta / max(report.graph_delta_l1, 1e-12)
                # Commit optimizer invalidation only after validation and audit
                # completed, so an earlier exception has no optimizer side effect.
                for parameter in parameters:
                    self.optimizer.state.pop(parameter, None)
        except BaseException:
            self.model.load_state_dict(teacher.state_dict())
            raise
        finally:
            self.model.train(was_training)
            for parameter, gradient in caller_gradients:
                parameter.grad = gradient
        return report
