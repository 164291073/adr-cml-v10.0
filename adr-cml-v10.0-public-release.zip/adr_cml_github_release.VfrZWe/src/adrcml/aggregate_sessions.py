"""Aggregate independent training seeds for the fixed support/query protocol.

Nested bootstrap first samples trained checkpoints, then paired sessions within
mechanism strata. Evaluation seeds must differ between checkpoints: shared test
banks require a crossed bootstrap, which this entry point deliberately refuses.
No number of repetitions or p-value certifies publication readiness.
"""
from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path
from typing import Any

import numpy as np

from . import __version__
from .evaluate_sessions import SESSION_PROTOCOL, SESSION_STATISTICAL_PLAN, _fingerprint, _sha256_file
from .utils import save_json
from .compare_evaluations import holm_adjust as _holm

FIELDS = {
    "query_success": ("query", "success_rate", "higher"),
    "query_return": ("query", "mean_return", "higher"),
    "probe_mse": ("probe_after", "mse", "lower"),
    "probe_changed_child_mse": ("probe_after", "changed_child_mse", "lower"),
    "probe_unchanged_child_mse": ("probe_after", "unchanged_child_mse", "lower"),
}
COSTS = ("environment_steps", "active_actions", "online_optimizer_steps",
         "repair_optimizer_steps", "repair_attempts", "accepted_repairs")



def seed_signflip(values: np.ndarray, *, seed: int = 0, samples: int = 100_000) -> dict[str, Any]:
    """Two-sided sign-flip inference on independent training-seed mean effects.

    Exchangeability/symmetry under the null is an assumption, not guaranteed by
    random training seeds. Five seeds cannot give exact two-sided p < 0.05.
    """
    values = np.asarray(values, dtype=np.float64)
    if len(values) < 2:
        return {"pvalue": None, "method": "undefined_one_training_seed", "n_seeds": len(values)}
    observed = abs(float(values.mean()))
    if len(values) <= 16:
        signs = np.asarray(list(itertools.product((-1.0, 1.0), repeat=len(values))))
        null = np.abs((signs * values).mean(axis=1))
        probability = float(np.mean(null >= observed - 1e-15))
        method = "exact_two_sided_training_seed_signflip"
    else:
        rng = np.random.default_rng(seed)
        signs = rng.choice((-1.0, 1.0), size=(samples, len(values)))
        null = np.abs((signs * values).mean(axis=1))
        probability = float((1 + np.sum(null >= observed - 1e-15)) / (samples + 1))
        method = "monte_carlo_two_sided_training_seed_signflip_plus_one"
    return {"pvalue": probability, "method": method, "n_seeds": len(values),
            "assumption": "independent_training_runs_and_sign_exchangeability_under_null"}


def _validate_result(result: dict[str, Any]) -> None:
    if result.get("protocol") != SESSION_PROTOCOL or not str(result.get("software_version", "")).startswith("10.0"):
        raise ValueError("Only native v10.0 independent-probe session results are aggregatable")
    if result.get("protocol_sha256") != _fingerprint(result.get("protocol_spec")):
        raise ValueError("Protocol fingerprint mismatch")
    if result["protocol_spec"].get("statistical_plan") != SESSION_STATISTICAL_PLAN:
        raise ValueError("The prespecified statistical plan is missing or incompatible")
    modes = result.get("mode_sessions", {})
    if not modes or "full" not in modes or set(modes) != set(result["protocol_spec"]["modes"]):
        raise ValueError("Full mode and every prespecified mode are required")
    count = int(result["sessions"])
    identity_keys = ("session", "regime", "support_seeds", "query_seeds", "environment_profile",
                     "mechanism_parameters", "probe_bank_hash", "probe_bank_sha256", "probe_rollout_seeds")
    reference = modes["full"]
    if len(reference) != count or len({row["session"] for row in reference}) != count:
        raise ValueError("Missing or duplicated evaluation session")
    all_task_seeds = [s for row in reference for name in ("support_seeds", "query_seeds") for s in row[name]]
    if len(all_task_seeds) != len(set(all_task_seeds)):
        raise ValueError("Support/query task seeds are not disjoint")
    for rows in modes.values():
        if len(rows) != count:
            raise ValueError("Missing mode sessions")
        for left, right in zip(reference, rows):
            if any(left.get(key) != right.get(key) for key in identity_keys):
                raise ValueError("Modes are not paired on the same session, parameters and probe bank")
            if not right.get("query_learning_audit_passed") or right.get("model_hash_after_support") != right.get("model_hash_after_query"):
                raise ValueError("Query model freeze audit failed or absent")
            if right.get("model_hash_before_support") != result.get("model_sha256"):
                raise ValueError("Session checkpoint lineage mismatch")
            if set(right["probe_rollout_seeds"]) & set(all_task_seeds):
                raise ValueError("Probe/task reset seed overlap")
            for side in ("probe_before", "probe_after"):
                if not right[side].get("readonly_audit_passed"):
                    raise ValueError("Read-only independent probe audit missing")
                if right[side]["samples"] != result["probe_samples_per_session"]:
                    raise ValueError("Probe sample budget mismatch")
            for section, field, _ in FIELDS.values():
                value = right[section][field]
                if value is not None and not np.isfinite(float(value)):
                    raise ValueError("Nonfinite measured result")


def _hierarchical_indices(results: list[dict[str, Any]], samples: int, rng) -> tuple[np.ndarray, np.ndarray]:
    n_seeds = len(results)
    n_sessions = results[0]["sessions"]
    outer = rng.integers(0, n_seeds, size=(samples, n_seeds))
    inner = np.empty((samples, n_seeds, n_sessions), dtype=np.int64)
    groups = []
    for result in results:
        rows = result["mode_sessions"]["full"]
        groups.append([np.asarray([i for i, row in enumerate(rows) if row["regime"] == regime])
                       for regime in sorted({row["regime"] for row in rows})])
    for slot in range(n_seeds):
        for selected in range(n_seeds):
            positions = np.flatnonzero(outer[:, slot] == selected)
            offset = 0
            for indices in groups[selected]:
                inner[positions, slot, offset:offset + len(indices)] = rng.choice(
                    indices, size=(len(positions), len(indices)), replace=True)
                offset += len(indices)
    return outer, inner


def aggregate_session_results(inputs: list[str | Path], *, output: str | Path,
                              bootstrap_samples: int = 10000, seed: int = 202701) -> dict[str, Any]:
    if not inputs or bootstrap_samples < 1:
        raise ValueError("Inputs and a positive bootstrap budget are required")
    destination = Path(output)
    if destination.exists():
        raise FileExistsError("Choose a new aggregate output file")
    paths = [Path(value) for value in inputs]
    results = [json.loads(path.read_text(encoding="utf-8")) for path in paths]
    for result in results:
        _validate_result(result)
    for key in ("training_seed", "model_sha256", "checkpoint_sha256", "evaluation_seed"):
        values = [result.get(key) for result in results]
        if any(value is None for value in values) or len(set(values)) != len(values):
            raise ValueError(f"Distinct nonempty {key} values required; duplicate or reused runs are not independent")
    seen_task_seeds: set[int] = set()
    seen_probe_seeds: set[int] = set()
    for result in results:
        rows = result["mode_sessions"]["full"]
        task_seeds = {value for row in rows for name in ("support_seeds", "query_seeds") for value in row[name]}
        probe_seeds = {value for row in rows for value in row["probe_rollout_seeds"]}
        if (task_seeds | probe_seeds) & (seen_task_seeds | seen_probe_seeds):
            raise ValueError("Repeated task/probe seeds across training runs require a crossed, not nested, bootstrap")
        seen_task_seeds.update(task_seeds)
        seen_probe_seeds.update(probe_seeds)
    if len({result["protocol_sha256"] for result in results}) != 1:
        raise ValueError("Mismatched protocols, model configurations, budgets or profiles cannot be pooled")
    rng = np.random.default_rng(seed)
    outer, inner = _hierarchical_indices(results, bootstrap_samples, rng)
    intervals_available = len(results) >= 2 and all(
        all(sum(row["regime"] == regime for row in result["mode_sessions"]["full"]) >= 2
            for regime in result["protocol_spec"]["regimes"]) for result in results)
    comparisons: dict[str, Any] = {}
    raw_pvalues: dict[str, float | None] = {name: None for name in SESSION_STATISTICAL_PLAN["exploratory_all_endpoints"]}
    modes = results[0]["protocol_spec"]["modes"]
    for mode in modes:
        if mode == "full":
            continue
        name = f"full_vs_{mode}"
        comparisons[name] = {}
        for field, (section, metric, direction) in FIELDS.items():
            raw = [[(a[section][metric], b[section][metric]) for a, b in zip(
                        result["mode_sessions"]["full"], result["mode_sessions"][mode])]
                   for result in results]
            if any(a is None or b is None for row in raw for a, b in row):
                comparisons[name][field] = {"available": False, "reason": "undefined_child_subset"}
                continue
            effects = np.asarray([[a - b for a, b in row] for row in raw], dtype=np.float64)
            seed_means = effects.mean(axis=1)
            bootstrap = effects[outer[:, :, None], inner].mean(axis=(1, 2))
            test = seed_signflip(seed_means, seed=seed)
            entry = {
                "available": True, "difference": "full_minus_comparator", "better_direction": direction,
                "mean_difference": float(seed_means.mean()),
                "training_seed_mean_differences": seed_means.tolist(),
                "ci95": np.quantile(bootstrap, [0.025, 0.975]).tolist() if intervals_available else None,
                "positive_seed_count": int(np.sum(seed_means > 0)),
                "negative_seed_count": int(np.sum(seed_means < 0)), "signflip": test,
            }
            comparisons[name][field] = entry
            raw_pvalues[f"{name}/{field}"] = test["pvalue"]
    adjusted = _holm(raw_pvalues)
    families = {}
    profile = results[0].get("environment_profile", results[0]["protocol_spec"].get("environment_profile"))
    for family in ("primary_task_return", "secondary_prediction", "exploratory_all_endpoints"):
        names = SESSION_STATISTICAL_PLAN[family]
        selected = {name: raw_pvalues.get(name) for name in names}
        family_adjusted = _holm(selected)
        families[family] = {
            "family_size": len(names),
            "is_confirmatory_profile": profile == SESSION_STATISTICAL_PLAN["confirmatory_profile"] and family != "exploratory_all_endpoints",
            "hypotheses": {name: {"pvalue": selected[name], "holm_pvalue": family_adjusted[name]} for name in names},
        }
    for name, comparison in comparisons.items():
        for field, entry in comparison.items():
            endpoint = f"{name}/{field}"
            entry["holm_pvalue"] = adjusted.get(endpoint)
            for family, prefix in (("primary_task_return", "primary"), ("secondary_prediction", "secondary")):
                entry[f"{prefix}_holm_pvalue"] = families[family]["hypotheses"].get(endpoint, {}).get("holm_pvalue")

    costs = {
        mode: {cost: {"per_training_seed": [sum(row["support"][cost] for row in result["mode_sessions"][mode])
                                           for result in results],
                       "mean": float(np.mean([sum(row["support"][cost] for row in result["mode_sessions"][mode])
                                              for result in results]))}
               for cost in COSTS} for mode in modes}
    report = {
        "schema": "session_multiseed_v1", "software_version": __version__,
        "environment_profile": results[0].get("environment_profile", results[0]["protocol_spec"].get("environment_profile")),
        "protocol": SESSION_PROTOCOL,
        "protocol_sha256": results[0]["protocol_sha256"], "protocol_spec": results[0]["protocol_spec"],
        "training_seeds": [result["training_seed"] for result in results],
        "n_training_seeds": len(results), "bootstrap_samples": bootstrap_samples, "statistics_seed": seed,
        "bootstrap_unit": "training_seed_then_paired_session_within_regime",
        "evaluation_seed_policy": "distinct_per_training_seed_nested_independent_sessions",
        "intervals_available": intervals_available,
        "interval_unavailable_reason": None if intervals_available else "need_two_training_seeds_and_two_sessions_per_regime_per_seed",
        "ci_multiplicity": "pointwise_95_percent_not_familywise_simultaneous",
        "statistical_plan": SESSION_STATISTICAL_PLAN, "inference_families": families,
        "holm_family": "all_25_prespecified_full_contrasts_times_query_and_probe_endpoints_including_undefined",
        "holm_hypotheses": len(raw_pvalues), "comparisons": comparisons, "support_costs": costs,
        "inference_limit": "descriptive_research_evidence_not_a_publication_readiness_certificate",
        "inputs": [{"path": str(path.resolve()), "sha256": _sha256_file(path),
                    "training_seed": result["training_seed"], "evaluation_seed": result["evaluation_seed"],
                    "checkpoint_sha256": result["checkpoint_sha256"], "model_sha256": result["model_sha256"]}
                   for path, result in zip(paths, results)],
    }
    destination.parent.mkdir(parents=True, exist_ok=True)
    save_json(destination, report)
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=202701)
    args = parser.parse_args()
    result = aggregate_session_results(args.inputs, output=args.output,
                                       bootstrap_samples=args.bootstrap_samples, seed=args.seed)
    print(json.dumps({"training_seeds": result["training_seeds"], "output": args.output}, indent=2))


if __name__ == "__main__":
    main()
