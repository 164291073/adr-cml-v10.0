from __future__ import annotations

from collections import defaultdict, deque

import numpy as np


GRAPH_METRIC_METADATA = {
    "version": "v10_tie_aware",
    "average_precision": "noninterpolated_precision_recall_steps_with_equal_scores_grouped",
    "average_precision_null_target": "zero_by_convention; inspect graph_target_edges",
    "topk_budget": "oracle_k_equals_number_of_ground_truth_edges; diagnostic_only",
    "topk_tie_break": "descending_score_then_row_major_edge_index; label_order_dependent",
    "topk_tie_expected": "expectation_under_uniform_selection_within_boundary_tie",
    "shd": "directed_adjacency_hamming_distance; reversed_edge_counts_as_two",
    "diagonal": "excluded_by_default",
}


def average_precision_ties(scores: np.ndarray, labels: np.ndarray) -> float:
    """Noninterpolated AP, grouping tied scores at one recall threshold.

    Arbitrarily sorting positive examples ahead of negatives within a tie
    overstates AP.  A constant score correctly yields positive prevalence.
    A target with no positives is assigned zero by convention.
    """
    scores = np.asarray(scores, dtype=np.float64)
    labels = np.asarray(labels)
    if scores.ndim != 1 or labels.shape != scores.shape:
        raise ValueError("scores and labels must be equally sized vectors")
    if not np.isfinite(scores).all() or not np.isin(labels, [0, 1]).all():
        raise ValueError("scores must be finite and labels binary")
    positives = int(labels.sum())
    if not positives:
        return 0.0
    order = np.argsort(-scores, kind="stable")
    ranked_scores, ranked_true = scores[order], labels[order].astype(bool)
    group_ends = np.r_[np.flatnonzero(ranked_scores[:-1] != ranked_scores[1:]), len(scores) - 1]
    cumulative_true = np.cumsum(ranked_true)[group_ends]
    precision = cumulative_true / (group_ends + 1)
    recall_increments = np.diff(np.r_[0, cumulative_true]) / positives
    return float(np.dot(recall_increments, precision))


def scalar_confidence_intervals(
    returns: list[float], successes: list[float], z: float = 1.959963984540054
) -> dict[str, float]:
    """Approximate 95% intervals for return and binary success summaries."""

    values = np.asarray(returns, dtype=np.float64)
    binary = np.asarray(successes, dtype=np.float64)
    if values.size == 0 or binary.size == 0:
        raise ValueError("returns and successes must be non-empty")
    mean = float(values.mean())
    if values.size > 1:
        half_width = float(z * values.std(ddof=1) / np.sqrt(values.size))
    else:
        half_width = 0.0
    n = float(binary.size)
    proportion = float(binary.mean())
    denominator = 1.0 + z**2 / n
    center = (proportion + z**2 / (2.0 * n)) / denominator
    wilson_half = (
        z
        * np.sqrt(proportion * (1.0 - proportion) / n + z**2 / (4.0 * n**2))
        / denominator
    )
    return {
        "mean_return_ci95_low": mean - half_width,
        "mean_return_ci95_high": mean + half_width,
        "success_rate_ci95_low": float(max(0.0, center - wilson_half)),
        "success_rate_ci95_high": float(min(1.0, center + wilson_half)),
    }


def structural_metrics(
    predicted: np.ndarray,
    target: np.ndarray,
    threshold: float = 0.5,
    include_diagonal: bool = False,
) -> dict[str, float]:
    values = np.asarray(predicted, dtype=float)
    raw_target = np.asarray(target)
    pred = values >= threshold
    true = raw_target.astype(bool)
    if pred.shape != true.shape or pred.ndim != 2 or pred.shape[0] != pred.shape[1]:
        raise ValueError("predicted and target must be equally-sized square matrices")
    if not np.isfinite(values).all() or not np.isfinite(threshold):
        raise ValueError("predicted scores and threshold must be finite")
    if not np.isin(raw_target, [0, 1]).all():
        raise ValueError("target adjacency must be binary")
    mask = np.ones_like(true, dtype=bool)
    if not include_diagonal:
        np.fill_diagonal(mask, False)
    p, t = pred[mask], true[mask]
    tp = int(np.logical_and(p, t).sum())
    fp = int(np.logical_and(p, ~t).sum())
    fn = int(np.logical_and(~p, t).sum())
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    f1 = 2 * precision * recall / max(precision + recall, 1e-12)
    shd = int(np.not_equal(p, t).sum())
    scores = values[mask]
    # Stable sort makes tied top-K reproducible, not label-invariant. Report
    # boundary tie expectation/range so accidental index ordering is visible.
    order = np.argsort(-scores, kind="stable")
    positives = int(t.sum())
    average_precision = average_precision_ties(scores, t)
    boundary_size = boundary_slots = 0
    topk_expected = topk_low = topk_high = 0.0
    if positives:
        topk = np.zeros_like(t, dtype=bool)
        topk[order[:positives]] = True
        topk_tp = int(np.logical_and(topk, t).sum())
        topk_f1 = topk_tp / positives
        topk_shd = int(np.not_equal(topk, t).sum())
        boundary_score = scores[order[positives - 1]]
        above = scores > boundary_score
        boundary = scores == boundary_score
        boundary_size = int(boundary.sum())
        boundary_slots = positives - int(above.sum())
        certain_tp = int(t[above].sum())
        boundary_tp = int(t[boundary].sum())
        topk_expected = (certain_tp + boundary_slots * boundary_tp / boundary_size) / positives
        topk_low = (certain_tp + max(0, boundary_slots - (boundary_size - boundary_tp))) / positives
        topk_high = (certain_tp + min(boundary_slots, boundary_tp)) / positives
    else:
        topk_f1 = 0.0
        topk_shd = 0
    return {
        "graph_precision": precision,
        "graph_recall": recall,
        "graph_f1": f1,
        "shd": float(shd),
        "graph_average_precision": average_precision,
        "graph_topk_f1": float(topk_f1),
        "graph_topk_shd": float(topk_shd),
        "graph_topk_oracle_k": float(positives),
        "graph_topk_boundary_tie_size": float(boundary_size),
        "graph_topk_boundary_selected": float(boundary_slots),
        "graph_topk_f1_tie_expected": float(topk_expected),
        "graph_topk_f1_tie_min": float(topk_low),
        "graph_topk_f1_tie_max": float(topk_high),
        "graph_topk_shd_tie_expected": float(2 * positives * (1 - topk_expected)),
        "graph_predicted_edges": float(p.sum()),
        "graph_target_edges": float(t.sum()),
        "graph_expected_edges": float(scores.sum()),
        "graph_density": float(p.mean()) if p.size else 0.0,
    }


def action_structural_metrics(
    predicted: np.ndarray,
    target: np.ndarray,
    threshold: float = 0.5,
) -> dict[str, object]:
    """Evaluate action-conditioned transition graphs without union leakage."""

    predicted = np.asarray(predicted)
    target = np.asarray(target)
    if predicted.shape != target.shape or predicted.ndim != 3:
        raise ValueError("action-conditioned graphs must have equal [A, N, N] shapes")
    by_action = {
        str(action): structural_metrics(
            predicted[action],
            target[action],
            threshold=threshold,
        )
        for action in range(predicted.shape[0])
    }
    informative = [
        metrics
        for metrics in by_action.values()
        if metrics["graph_target_edges"] > 0
    ]
    keys = informative[0].keys() if informative else []
    macro = {
        key: float(np.mean([metrics[key] for metrics in informative]))
        for key in keys
    }
    null_actions = [
        metrics
        for metrics in by_action.values()
        if metrics["graph_target_edges"] == 0
    ]
    macro["informative_actions"] = float(len(informative))
    macro["null_actions"] = float(len(null_actions))
    macro["null_action_predicted_edges"] = (
        float(np.mean([metrics["graph_predicted_edges"] for metrics in null_actions]))
        if null_actions
        else 0.0
    )
    return {"macro": macro, "by_action": by_action, "metric_metadata": dict(GRAPH_METRIC_METADATA)}


def node_set_metrics(predicted: list[int], target: list[int]) -> dict[str, float]:
    """Precision/recall/F1 for a localized set of changed child mechanisms."""
    pred = set(int(value) for value in predicted)
    true = set(int(value) for value in target)
    tp = len(pred & true)
    precision = tp / max(len(pred), 1)
    recall = tp / max(len(true), 1)
    f1 = 2 * precision * recall / max(precision + recall, 1e-12)
    return {
        "diagnosis_precision": precision,
        "diagnosis_recall": recall,
        "diagnosis_f1": f1,
        "diagnosis_exact": float(pred == true),
    }


class RegimeGraphTracker:
    """Keep graph metrics aligned with the regime that produced each target.

    Regime labels and ground-truth graphs stay in the experiment harness. They
    are never passed into the agent or replay buffer.
    """

    def __init__(self, window: int = 100) -> None:
        self.window = max(1, int(window))
        self.records: dict[str, deque[dict[str, float]]] = defaultdict(
            lambda: deque(maxlen=self.window)
        )
        self.last_predicted: dict[str, np.ndarray] = {}
        self.targets: dict[str, np.ndarray] = {}

    def update(self, regime: str, predicted: np.ndarray, target: np.ndarray) -> None:
        name = str(regime)
        predicted = np.asarray(predicted, dtype=np.float32)
        target = np.asarray(target, dtype=np.float32)
        self.records[name].append(structural_metrics(predicted, target))
        self.last_predicted[name] = predicted.copy()
        self.targets[name] = target.copy()

    def summary(self) -> dict[str, object]:
        by_regime: dict[str, dict[str, float]] = {}
        for regime, records in sorted(self.records.items()):
            keys = records[0].keys() if records else []
            by_regime[regime] = {
                key: float(np.mean([record[key] for record in records]))
                for key in keys
            }
            by_regime[regime]["episodes"] = float(len(records))
        metric_keys = [
            "graph_precision",
            "graph_recall",
            "graph_f1",
            "shd",
            "graph_average_precision",
            "graph_topk_f1",
            "graph_topk_shd",
            "graph_topk_oracle_k",
            "graph_topk_boundary_tie_size",
            "graph_topk_boundary_selected",
            "graph_topk_f1_tie_expected",
            "graph_topk_f1_tie_min",
            "graph_topk_f1_tie_max",
            "graph_topk_shd_tie_expected",
            "graph_predicted_edges",
            "graph_target_edges",
            "graph_expected_edges",
            "graph_density",
        ]
        macro = {
            key: (
                float(np.mean([metrics[key] for metrics in by_regime.values()]))
                if by_regime
                else 0.0
            )
            for key in metric_keys
        }
        return {"macro": macro, "by_regime": by_regime, "metric_metadata": dict(GRAPH_METRIC_METADATA)}

    def union_target(self) -> np.ndarray | None:
        if not self.targets:
            return None
        return np.maximum.reduce(list(self.targets.values()))

    def state_dict(self) -> dict[str, object]:
        return {
            "window": self.window,
            "records": {
                regime: list(records) for regime, records in self.records.items()
            },
            "last_predicted": {
                regime: value.copy()
                for regime, value in self.last_predicted.items()
            },
            "targets": {
                regime: value.copy() for regime, value in self.targets.items()
            },
        }

    def load_state_dict(self, state: dict[str, object]) -> None:
        self.window = max(1, int(state.get("window", self.window)))
        self.records.clear()
        raw_records = state.get("records", {})
        if isinstance(raw_records, dict):
            for regime, records in raw_records.items():
                self.records[str(regime)] = deque(
                    (dict(record) for record in records),
                    maxlen=self.window,
                )
        self.last_predicted = {
            str(regime): np.asarray(value, dtype=np.float32).copy()
            for regime, value in dict(state.get("last_predicted", {})).items()
        }
        self.targets = {
            str(regime): np.asarray(value, dtype=np.float32).copy()
            for regime, value in dict(state.get("targets", {})).items()
        }


def change_detection_metrics(
    change_windows: list[tuple[int, int, int]],
    alarm_steps: list[int],
    total_steps: int,
) -> dict[str, float]:
    """Score alarms inside explicit ``(start, change, end)`` windows.

    Each change can consume at most one post-change alarm.  Pre-change alarms
    and additional post-change alarms are false alarms.  Explicit episode
    windows prevent a late alarm in a later episode from being credited to an
    earlier missed change.
    """

    delays: list[int] = []
    misses = 0
    false_alarms = 0
    for start, shift, end in change_windows:
        if not start <= shift <= end:
            raise ValueError("Each change window must satisfy start <= shift <= end")
        local = sorted(a for a in alarm_steps if start <= a <= end)
        post = [a for a in local if a >= shift]
        if post:
            delays.append(post[0] - shift)
            false_alarms += len(local) - 1
        else:
            misses += 1
            false_alarms += len(local)

    in_any_window = {
        a
        for start, _, end in change_windows
        for a in alarm_steps
        if start <= a <= end
    }
    false_alarms += sum(a not in in_any_window for a in alarm_steps)
    fallback_delays = [end - shift + 1 for _, shift, end in change_windows]
    mean_delay = (
        float(np.mean(delays))
        if delays
        else float(np.mean(fallback_delays)) if fallback_delays else 0.0
    )
    detected = len(delays)
    n_changes = len(change_windows)
    return {
        "mean_detection_delay": mean_delay,
        "detected_changes": float(detected),
        "missed_changes": float(misses),
        "false_alarms": float(false_alarms),
        "detection_rate": detected / max(n_changes, 1),
        "false_alarms_per_1000_steps": 1000.0 * false_alarms / max(total_steps, 1),
    }


def detection_delay(shift_steps: list[int], alarm_steps: list[int], horizon: int) -> dict[str, float]:
    """Backward-compatible change scoring for a single continuous timeline."""

    shifts = sorted(int(step) for step in shift_steps)
    windows: list[tuple[int, int, int]] = []
    start = 0
    for index, shift in enumerate(shifts):
        end = shifts[index + 1] - 1 if index + 1 < len(shifts) else int(horizon)
        windows.append((start, shift, end))
        start = end + 1
    return change_detection_metrics(windows, alarm_steps, int(horizon))
