from __future__ import annotations

import torch
from torch import Tensor

from .models import EnsembleWorldModel


class CategoricalCEMPlanner:
    """Risk-aware categorical cross-entropy model-predictive controller."""

    def __init__(
        self,
        model: EnsembleWorldModel,
        horizon: int = 16,
        population: int = 512,
        elites: int = 64,
        iterations: int = 5,
        discount: float = 0.99,
        temperature: float = 0.8,
        risk_weight: float = 0.10,
        information_cap: float = 0.25,
        invalid_action_penalty: float = 1.0,
        active_weight: float = 0.25,
        device: str = "cpu",
    ) -> None:
        if not 0 < elites <= population:
            raise ValueError("elites must be in [1, population]")
        self.model = model
        self.horizon = int(horizon)
        self.population = int(population)
        self.elites = int(elites)
        self.iterations = int(iterations)
        self.discount = float(discount)
        self.temperature = float(temperature)
        self.risk_weight = float(risk_weight)
        self.information_cap = float(information_cap)
        self.invalid_action_penalty = float(invalid_action_penalty)
        self.active_weight = float(active_weight)
        self.device = device
        self.last_diagnostics: dict[str, float] = {}

    @torch.no_grad()
    def select_intervention(self, state, intervention_action_mask) -> int:
        mask = torch.as_tensor(
            intervention_action_mask,
            dtype=torch.bool,
            device=self.device,
        )
        candidates = torch.nonzero(mask, as_tuple=False).reshape(-1)
        if candidates.numel() == 0:
            raise ValueError("At least one intervention action must be available")
        state_t = torch.as_tensor(state, dtype=torch.float32, device=self.device)
        states = state_t.reshape(1, -1).expand(candidates.numel(), -1)
        next_states, rewards, _, _ = self.model.predict_members(states, candidates)
        scores = next_states.var(dim=0, unbiased=False).mean(dim=-1)
        scores = scores + rewards.var(dim=0, unbiased=False)
        probabilities = torch.softmax(scores / max(self.temperature, 1e-4), dim=0)
        selected = torch.multinomial(probabilities, 1)
        action = int(candidates[selected].item())
        self.last_diagnostics = {
            "plan_score": float(scores[selected].item()),
            "active_weight": float(self.active_weight),
            "action": float(action),
            "intervention": 1.0,
        }
        return action

    @torch.no_grad()
    def _score_sequences(self, initial_state: Tensor, sequences: Tensor, active_weight: float) -> Tensor:
        batch = sequences.shape[0]
        state = initial_state.reshape(1, -1).expand(batch, -1)
        member_returns = torch.zeros(self.model.ensemble_size, batch, device=self.device)
        survival = torch.ones_like(member_returns)
        info_return = torch.zeros(batch, device=self.device)
        discount = 1.0
        for t in range(self.horizon):
            actions = sequences[:, t]
            if self.invalid_action_penalty > 0 and hasattr(
                self.model, "predict_validity_members"
            ):
                validity = self.model.predict_validity_members(state).mean(dim=0)
                selected_validity = validity.gather(1, actions.reshape(-1, 1)).squeeze(1)
                member_returns -= (
                    discount
                    * survival
                    * self.invalid_action_penalty
                    * (1.0 - selected_validity).reshape(1, -1)
                )
            next_states, rewards, dones, _ = self.model.predict_members(state, actions)
            member_returns += discount * survival * rewards
            epistemic = next_states.var(dim=0, unbiased=False).mean(dim=-1)
            reward_disagreement = rewards.var(dim=0, unbiased=False)
            information = (epistemic + reward_disagreement).clamp(max=self.information_cap)
            info_return += discount * survival.mean(dim=0) * information
            state = next_states.mean(dim=0).clamp(0.0, 1.0)
            # Predicted termination must only suppress future rewards.  The old
            # implementation repeatedly shrank rewards that had already been
            # accumulated, biasing long sequences toward arbitrary actions.
            survival = survival * (1.0 - dones).clamp(0.0, 1.0)
            discount *= self.discount
        task_value = member_returns.mean(dim=0)
        risk_penalty = self.risk_weight * member_returns.std(dim=0, unbiased=False)
        return task_value - risk_penalty + active_weight * info_return

    @torch.no_grad()
    def plan(
        self,
        state,
        valid_action_mask=None,
        future_action_mask=None,
        active_multiplier: float = 1.0,
    ) -> int:
        state_t = torch.as_tensor(state, dtype=torch.float32, device=self.device)
        logits = torch.zeros(self.horizon, self.model.action_dim, device=self.device)
        if valid_action_mask is not None:
            mask = torch.as_tensor(valid_action_mask, dtype=torch.bool, device=self.device)
            if not bool(mask.any()):
                raise ValueError("At least one action must be valid")
        else:
            mask = torch.ones(self.model.action_dim, dtype=torch.bool, device=self.device)
        if future_action_mask is not None:
            future_mask = torch.as_tensor(
                future_action_mask,
                dtype=torch.bool,
                device=self.device,
            )
            if not bool(future_mask.any()):
                raise ValueError("At least one future action must be valid")
        else:
            future_mask = torch.ones(self.model.action_dim, dtype=torch.bool, device=self.device)
        effective_active = self.active_weight * float(active_multiplier)

        best_score = torch.tensor(float("-inf"), device=self.device)
        best_sequence = None
        for _ in range(self.iterations):
            sampling_logits = logits / max(self.temperature, 1e-4)
            sampling_logits[:, ~future_mask] = -1e9
            sampling_logits[0, ~mask] = -1e9
            dist = torch.distributions.Categorical(logits=sampling_logits)
            sequences = dist.sample((self.population,))
            scores = self._score_sequences(state_t, sequences, effective_active)
            elite_idx = torch.topk(scores, self.elites).indices
            elite = sequences[elite_idx]
            counts = torch.zeros_like(logits)
            for t in range(self.horizon):
                counts[t] = torch.bincount(elite[:, t], minlength=self.model.action_dim).float()
            updated = torch.log(counts + 1.0)
            logits = 0.25 * logits + 0.75 * updated
            if scores[elite_idx[0]] > best_score:
                best_score = scores[elite_idx[0]]
                best_sequence = sequences[elite_idx[0]].clone()

        assert best_sequence is not None
        action = int(best_sequence[0].item())
        self.last_diagnostics = {
            "plan_score": float(best_score.item()),
            "active_weight": float(effective_active),
            "action": float(action),
            "intervention": 0.0,
        }
        return action
