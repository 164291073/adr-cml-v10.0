from __future__ import annotations

import argparse
import copy
from pathlib import Path

import pandas as pd

from .config import load_config
from .train import run_experiment


def apply_ablation(config, name: str):
    cfg = copy.deepcopy(config)
    if name == "full":
        pass
    elif name == "no_active":
        cfg.agent.active_weight = 0.0
        cfg.agent.alarm_active_boost = 1.0
        cfg.agent.counterfactual_probe_probability = 0.0
    elif name == "no_counterfactual":
        cfg.agent.counterfactual_probe_probability = 0.0
    elif name == "static_gates":
        cfg.model.action_conditioned_gates = False
    elif name == "soft_gates":
        cfg.model.hard_concrete_gates = False
    elif name == "no_parent_budget":
        cfg.model.parent_budget_weight = 0.0
    elif name == "no_diagnosis":
        cfg.agent.diagnosis_enabled = False
        cfg.agent.repair_enabled = False
    elif name == "no_repair":
        cfg.agent.repair_enabled = False
    elif name == "global_repair":
        cfg.agent.local_repair = False
    elif name == "dense_graph":
        cfg.model.dense_graph = True
        cfg.model.sparsity_weight = 0.0
        cfg.model.parent_budget_weight = 0.0
        cfg.model.action_gate_regularization = 0.0
        cfg.model.edge_entropy_weight = 0.0
    elif name == "oracle_diagnosis":
        cfg.agent.oracle_diagnosis = True
        cfg.agent.diagnosis_enabled = False
    else:
        raise ValueError(f"Unknown ablation {name!r}")
    return cfg


def main() -> None:
    parser = argparse.ArgumentParser(description="Run ADR-CML ablations")
    parser.add_argument("--config", default="configs/main.yaml")
    parser.add_argument(
        "--variants",
        nargs="+",
        default=[
            "full",
            "no_active",
            "no_counterfactual",
            "static_gates",
            "soft_gates",
            "no_parent_budget",
            "no_diagnosis",
            "no_repair",
            "global_repair",
            "dense_graph",
            "oracle_diagnosis",
        ],
    )
    parser.add_argument("--seeds", nargs="+", type=int, default=[2025, 2026, 2027])
    parser.add_argument("--output", default="outputs/ablations")
    args = parser.parse_args()

    base = load_config(args.config)
    rows = []
    for variant in args.variants:
        for seed in args.seeds:
            config = apply_ablation(base, variant)
            config.seed = seed
            config.output_dir = str(Path(args.output) / variant / f"seed_{seed}")
            summary = run_experiment(config)
            rows.append({"variant": variant, **summary})
    frame = pd.DataFrame(rows)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output / "all_runs.csv", index=False)
    numeric = frame.select_dtypes(include="number").columns.tolist()
    aggregate = frame.groupby("variant")[numeric].agg(["mean", "std"])
    aggregate.to_csv(output / "aggregate.csv")
    print(aggregate)


if __name__ == "__main__":
    main()
