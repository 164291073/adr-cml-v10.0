from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path
from typing import Any

import numpy as np

from .utils import save_json


def exact_mcnemar_p(wins: int, losses: int) -> float:
    """Two-sided exact McNemar p-value for paired binary outcomes."""

    if int(wins) != wins or int(losses) != losses or wins < 0 or losses < 0:
        raise ValueError("wins and losses must be nonnegative integers")
    wins, losses = int(wins), int(losses)
    discordant = wins + losses
    if discordant == 0:
        return 1.0
    tail = sum(
        math.comb(discordant, index)
        for index in range(min(wins, losses) + 1)
    ) / (2**discordant)
    return float(min(1.0, 2.0 * tail))


def holm_adjust(p_values: dict[str, float | None]) -> dict[str, float | None]:
    """Holm correction, retaining undefined tests in the prespecified family.

    Undefined tests occupy the end of the family (as if p=1) and stay null.
    Silently dropping them would shrink the declared multiplicity penalty.
    """
    for value in p_values.values():
        if value is not None and (not np.isfinite(value) or not 0.0 <= value <= 1.0):
            raise ValueError("p-values must lie in [0, 1] or be None")
    ordered = sorted(p_values.items(), key=lambda item: 1.0 if item[1] is None else item[1])
    adjusted: dict[str, float | None] = {}
    running_max = 0.0
    for index, (name, value) in enumerate(ordered):
        if value is None:
            adjusted[name] = None
            continue
        running_max = max(running_max, (len(ordered) - index) * value)
        adjusted[name] = min(1.0, running_max)
    return adjusted


def paired_sign_flip_test(
    differences: list[float] | np.ndarray,
    samples: int = 20_000,
    seed: int = 0,
    exact_max_nonzero: int = 20,
) -> dict[str, Any]:
    """Two-sided paired sign-flip test of mean difference.

    This requires exchangeability of method labels within independent pairs
    (equivalently, a symmetric sign null conditional on magnitudes). It is
    not a distribution-free test of an arbitrary mean-zero distribution and
    does not measure uncertainty over training seeds. Monte Carlo estimates
    use the plus-one correction, so p=0 is never emitted.
    """
    values = np.asarray(differences, dtype=np.float64)
    if values.ndim != 1 or not np.isfinite(values).all():
        raise ValueError("differences must be a finite vector")
    if int(samples) != samples or samples < 1:
        raise ValueError("samples must be a positive integer")
    if not 0 <= exact_max_nonzero <= 24:
        raise ValueError("exact_max_nonzero must be between 0 and 24")
    nonzero = values[values != 0]
    result: dict[str, Any] = {
        "p_value": None,
        "method": "undefined_fewer_than_two_pairs",
        "pairs": int(values.size),
        "nonzero_pairs": int(nonzero.size),
        "alternative": "two_sided",
        "statistic": "absolute_sum_of_paired_differences",
        "assumption": "independent_pairs_and_within_pair_method_label_exchangeability_under_null",
        "randomization_samples": 0,
        "monte_carlo_standard_error": None,
    }
    if values.size < 2:
        return result
    if not nonzero.size:
        result.update(p_value=1.0, method="exact_all_differences_zero", randomization_samples=1)
        return result
    observed = abs(float(nonzero.sum()))
    tolerance = 8 * np.finfo(np.float64).eps * float(np.abs(nonzero).sum())
    exceedances = 0
    chunk_size = min(2_048, max(1, 1_000_000 // nonzero.size))
    if nonzero.size <= exact_max_nonzero:
        total = 2 ** int(nonzero.size)
        bit_positions = np.arange(nonzero.size, dtype=np.uint64)
        for start in range(0, total, chunk_size):
            ids = np.arange(start, min(start + chunk_size, total), dtype=np.uint64)
            signs = 2.0 * ((ids[:, None] >> bit_positions) & 1) - 1.0
            permuted = np.abs(signs @ nonzero)
            exceedances += int(np.count_nonzero(permuted >= observed - tolerance))
        result.update(p_value=exceedances / total, method="exact_sign_flip", randomization_samples=total)
    else:
        rng = np.random.default_rng(seed)
        total = int(samples)
        for start in range(0, total, chunk_size):
            count = min(chunk_size, total - start)
            signs = 2.0 * rng.integers(0, 2, size=(count, nonzero.size)) - 1.0
            permuted = np.abs(signs @ nonzero)
            exceedances += int(np.count_nonzero(permuted >= observed - tolerance))
        estimate = (exceedances + 1) / (total + 1)
        result.update(
            p_value=estimate,
            method="monte_carlo_sign_flip_plus_one",
            randomization_samples=total,
            randomization_seed=int(seed),
            monte_carlo_standard_error=float(np.sqrt(estimate * (1 - estimate) / total)),
        )
    return result


def paired_comparison(
    reference: list[dict[str, Any]],
    candidate: list[dict[str, Any]],
    bootstrap_samples: int = 20_000,
    seed: int = 0,
    randomization_samples: int = 20_000,
) -> dict[str, Any]:
    if len(reference) != len(candidate) or not reference:
        raise ValueError("paired evaluations must have the same non-zero length")
    if int(bootstrap_samples) != bootstrap_samples or bootstrap_samples <= 0:
        raise ValueError("bootstrap_samples must be a positive integer")
    seen: set[str] = set()
    for left, right in zip(reference, candidate):
        if any(field not in row for row in (left, right) for field in ("episode_seed", "assigned_regime")):
            raise ValueError("paired records require episode_seed and assigned_regime")
        pairing_fields = (
            "episode_seed", "assigned_regime", "protocol", "forced_shift_step",
            "active_budget_per_episode", "environment_profile", "task_action_access",
            "mechanism_parameters",
        )
        left_key = tuple(left.get(field) for field in pairing_fields)
        right_key = tuple(right.get(field) for field in pairing_fields)
        if left_key != right_key:
            raise ValueError("evaluation schedules are not paired")
        serialized_key = json.dumps(left_key, sort_keys=True, allow_nan=False)
        if serialized_key in seen:
            raise ValueError("duplicate evaluation pair; independent pairs must have unique schedule keys")
        seen.add(serialized_key)

    reference_return = np.asarray([row["return"] for row in reference], dtype=float)
    candidate_return = np.asarray([row["return"] for row in candidate], dtype=float)
    if not np.isfinite(reference_return).all() or not np.isfinite(candidate_return).all():
        raise ValueError("evaluation returns must be finite")
    raw_left_success = np.asarray([row["success"] for row in reference])
    raw_right_success = np.asarray([row["success"] for row in candidate])
    if not np.isin(raw_left_success, [0, 1]).all() or not np.isin(raw_right_success, [0, 1]).all():
        raise ValueError("success outcomes must be binary")
    reference_success = raw_left_success.astype(bool)
    candidate_success = raw_right_success.astype(bool)
    difference = reference_return - candidate_return
    rng = np.random.default_rng(seed)
    labels = np.asarray([str(row["assigned_regime"]) for row in reference])
    strata = [np.flatnonzero(labels == name) for name in sorted(set(labels))]
    # The evaluation schedule fixes regime proportions. Resample independent
    # episode pairs *within* assigned regimes and retain their original weight.
    # A single observation in a stratum cannot estimate its sampling variance.
    ci_low = ci_high = None
    enough_for_bootstrap = all(len(indices) >= 2 for indices in strata)
    if enough_for_bootstrap:
        sampled_means = np.zeros(int(bootstrap_samples), dtype=np.float64)
        chunk_size = min(2_048, max(1, 1_000_000 // len(difference)))
        for start in range(0, int(bootstrap_samples), chunk_size):
            stop = min(start + chunk_size, int(bootstrap_samples))
            for indices in strata:
                sampled = rng.integers(0, len(indices), size=(stop - start, len(indices)))
                sampled_means[start:stop] += difference[indices[sampled]].sum(axis=1) / len(difference)
        ci_low, ci_high = map(float, np.quantile(sampled_means, [0.025, 0.975]))
    sign_flip = paired_sign_flip_test(difference, samples=randomization_samples, seed=seed + 1_000_003)
    wins = int(np.logical_and(reference_success, ~candidate_success).sum())
    losses = int(np.logical_and(~reference_success, candidate_success).sum())
    return {
        "episodes": len(reference),
        "confidence_interval_unit": "paired_evaluation_episodes_conditional_on_one_training_seed",
        "confidence_interval_method": "percentile_bootstrap_stratified_by_assigned_regime",
        "confidence_interval_status": "estimated" if enough_for_bootstrap else "undefined_fewer_than_two_pairs_in_at_least_one_regime",
        "confidence_interval_multiplicity": "unadjusted_pointwise; separate_from_Holm_adjusted_tests",
        "reference_mean_return": float(reference_return.mean()),
        "candidate_mean_return": float(candidate_return.mean()),
        "paired_return_difference": float(difference.mean()),
        "paired_return_ci95_low": ci_low,
        "paired_return_ci95_high": ci_high,
        "paired_return_sign_flip_p": sign_flip["p_value"],
        "paired_return_sign_flip_test": sign_flip,
        "reference_success_rate": float(reference_success.mean()),
        "candidate_success_rate": float(candidate_success.mean()),
        "success_rate_difference": float(
            reference_success.mean() - candidate_success.mean()
        ),
        "discordant_reference_wins": wins,
        "discordant_reference_losses": losses,
        "exact_mcnemar_p": exact_mcnemar_p(wins, losses),
        "paired_outcomes": [
            {
                **{field: left.get(field) for field in pairing_fields},
                "reference_return": float(reference_return[index]),
                "candidate_return": float(candidate_return[index]),
                "return_difference": float(difference[index]),
                "reference_success": bool(reference_success[index]),
                "candidate_success": bool(candidate_success[index]),
            }
            for index, left in enumerate(reference)
        ],
    }


def compare_run(
    run: str | Path,
    reference_mode: str = "full",
    candidate_modes: tuple[str, ...] = (
        "global_repair",
        "matched_active",
        "oracle_repair",
        "no_active",
        "diagnose_no_repair",
        "online_only",
        "frozen",
    ),
    bootstrap_samples: int = 20_000,
    randomization_samples: int = 20_000,
) -> dict[str, Any]:
    run = Path(run)
    if not candidate_modes or reference_mode in candidate_modes or len(set(candidate_modes)) != len(candidate_modes):
        raise ValueError("candidate_modes must be unique, nonempty and exclude the reference mode")

    def load(mode: str) -> list[dict[str, Any]]:
        path = run / f"evaluation_{mode}_episodes.json"
        return json.loads(path.read_text(encoding="utf-8"))

    reference = load(reference_mode)
    available_order = [
        mode for mode in (
            "oracle_repair", "no_active", "full", "global_repair",
            "matched_active", "diagnose_no_repair", "online_only", "frozen",
        )
        if (run / f"evaluation_{mode}_episodes.json").exists()
    ]
    # Exploratory pairs must satisfy the same provenance audit as the primary
    # contrasts; stale extra outputs must not silently enter all_pairwise.
    selected_modes = tuple(dict.fromkeys((reference_mode, *candidate_modes, *available_order)))
    summaries = {}
    missing_summaries = []
    for mode in selected_modes:
        summary_path = run / f"evaluation_{mode}.json"
        if summary_path.exists():
            summaries[mode] = json.loads(summary_path.read_text(encoding="utf-8"))
        else:
            missing_summaries.append(mode)
    shared_fields = (
        "software_version", "checkpoint_software_version", "checkpoint_sha256",
        "checkpoint_config_hash", "source_fingerprint", "seed", "protocol",
        "environment_profile", "task_action_access", "training_environment_profile",
    )
    missing_metadata = {}
    for field in shared_fields:
        available = {mode: summary[field] for mode, summary in summaries.items() if field in summary}
        values = {json.dumps(value, sort_keys=True) for value in available.values()}
        if len(values) > 1:
            raise ValueError(f"Incompatible evaluation provenance: {field} differs across modes")
        absent = [mode for mode in selected_modes if mode not in available]
        if absent:
            missing_metadata[field] = absent
    output: dict[str, Any] = {
        "reference_mode": reference_mode,
        "bootstrap_samples": bootstrap_samples,
        "randomization_samples": randomization_samples,
        "confidence_interval_unit": "paired_evaluation_episodes_conditional_on_one_training_seed",
        "multiplicity_control": "Holm across prespecified overall contrasts within each endpoint; joint_success_return_Holm also reported",
        "inference_scope": "one_fixed_checkpoint; neither episode bootstrap nor sign flips estimate training-seed uncertainty",
        "provenance_audit": {
            "status": "complete" if not missing_metadata else "partial_legacy_or_missing_metadata; do_not_pool_with_new_runs",
            "missing_summary_files": missing_summaries,
            "missing_shared_fields_by_mode": missing_metadata,
            "note": "mode-specific evaluation_config_hash values may differ; shared checkpoint and environment fields must agree",
        },
        "exploratory_results": "by_regime and all_pairwise are unadjusted exploratory analyses",
        "comparisons": {},
        "all_pairwise": {},
    }
    regimes = sorted({str(row["assigned_regime"]) for row in reference})
    for offset, candidate_mode in enumerate(candidate_modes):
        candidate = load(candidate_mode)
        key = f"{reference_mode}_vs_{candidate_mode}"
        comparison: dict[str, Any] = {
            "overall": paired_comparison(
                reference,
                candidate,
                bootstrap_samples=bootstrap_samples,
                seed=1729 + offset,
                randomization_samples=randomization_samples,
            ),
            "by_regime": {},
        }
        for regime_index, regime in enumerate(regimes):
            reference_regime = [
                row for row in reference if str(row["assigned_regime"]) == regime
            ]
            candidate_regime = [
                row for row in candidate if str(row["assigned_regime"]) == regime
            ]
            comparison["by_regime"][regime] = paired_comparison(
                reference_regime,
                candidate_regime,
                bootstrap_samples=bootstrap_samples,
                seed=10_000 + 100 * offset + regime_index,
                randomization_samples=randomization_samples,
            )
        output["comparisons"][key] = comparison

    adjusted = holm_adjust({
        key: comparison["overall"]["exact_mcnemar_p"]
        for key, comparison in output["comparisons"].items()
    })
    for key, value in adjusted.items():
        output["comparisons"][key]["overall"]["exact_mcnemar_p_holm"] = value
        output["comparisons"][key]["overall"]["holm_family_size"] = len(adjusted)

    return_adjusted = holm_adjust({
        key: comparison["overall"]["paired_return_sign_flip_p"]
        for key, comparison in output["comparisons"].items()
    })
    joint_p_values = {}
    for key, comparison in output["comparisons"].items():
        joint_p_values[f"{key}:success"] = comparison["overall"]["exact_mcnemar_p"]
        joint_p_values[f"{key}:return"] = comparison["overall"]["paired_return_sign_flip_p"]
    joint_adjusted = holm_adjust(joint_p_values)
    for key, value in return_adjusted.items():
        overall = output["comparisons"][key]["overall"]
        overall["paired_return_sign_flip_p_holm"] = value
        overall["return_holm_family_size"] = len(return_adjusted)
        overall["exact_mcnemar_p_holm_joint_endpoints"] = joint_adjusted[f"{key}:success"]
        overall["paired_return_sign_flip_p_holm_joint_endpoints"] = joint_adjusted[f"{key}:return"]
        overall["joint_endpoint_holm_family_size"] = len(joint_adjusted)

    for pair_index, (left_mode, right_mode) in enumerate(
        itertools.combinations(available_order, 2)
    ):
        left = load(left_mode)
        right = load(right_mode)
        key = f"{left_mode}_vs_{right_mode}"
        pair: dict[str, Any] = {
            "overall": paired_comparison(
                left,
                right,
                bootstrap_samples=bootstrap_samples,
                seed=30_000 + pair_index,
                randomization_samples=randomization_samples,
            ),
            "by_regime": {},
        }
        for regime_index, regime in enumerate(regimes):
            pair["by_regime"][regime] = paired_comparison(
                [row for row in left if str(row["assigned_regime"]) == regime],
                [row for row in right if str(row["assigned_regime"]) == regime],
                bootstrap_samples=bootstrap_samples,
                seed=40_000 + 100 * pair_index + regime_index,
                randomization_samples=randomization_samples,
            )
        output["all_pairwise"][key] = pair
    save_json(run / "evaluation_comparison.json", output)
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description="Paired comparison of ADR-CML modes")
    parser.add_argument("--run", required=True)
    parser.add_argument("--reference", default="full")
    parser.add_argument(
        "--candidates",
        nargs="+",
        default=[
            "global_repair",
            "matched_active",
            "oracle_repair",
            "no_active",
            "diagnose_no_repair",
            "online_only",
            "frozen",
        ],
    )
    parser.add_argument("--bootstrap-samples", type=int, default=20_000)
    parser.add_argument("--randomization-samples", type=int, default=20_000)
    args = parser.parse_args()
    result = compare_run(
        args.run,
        reference_mode=args.reference,
        candidate_modes=tuple(args.candidates),
        bootstrap_samples=args.bootstrap_samples,
        randomization_samples=args.randomization_samples,
    )
    for name, comparison in result["comparisons"].items():
        overall = comparison["overall"]
        print(
            f"{name}: success_diff={overall['success_rate_difference']:.3f} "
            f"return_diff={overall['paired_return_difference']:.3f} "
            f"McNemar_p={overall['exact_mcnemar_p']:.4f} "
            f"success_Holm_p={overall['exact_mcnemar_p_holm']:.4f} "
            f"return_Holm_p={overall['paired_return_sign_flip_p_holm']}"
        )


if __name__ == "__main__":
    main()
