"""Inventory reproducible evidence without treating successful execution as publication proof.

Run ``python -m adrcml.evidence_report --root outputs --output evidence``.
The report never decides that a paper is publishable. Supported claims are scoped
only to the exact protocol and explicitly corrected, paired evidence inspected.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
from typing import Any

import numpy as np

REPORT_SCHEMA = "adr_cml_evidence_inventory_v1"
CLAIMS = (
    "implementation", "local_predictive_benefit", "local_vs_global", "active_value",
    "ood_parameter_adaptation", "causal_graph_recovery", "full_agent_long_horizon",
)
RECOGNIZED = {
    "summary.json": "training", "session_evaluation.json": "session",
    "session_aggregate.json": "session_aggregate", "implementation_validation.json": "validation",
    "scm_evaluation.json": "scm", "scm_results.json": "scm",
    "scm_benchmark.json": "scm", "scm_aggregate.json": "scm_aggregate",
}


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _fingerprint(value: Any) -> str:
    """Match the evaluator's primitive/NumPy fingerprint without importing torch."""
    digest = hashlib.sha256()

    def visit(item: Any) -> None:
        if isinstance(item, np.ndarray):
            digest.update(str(item.dtype).encode())
            digest.update(str(item.shape).encode())
            if item.dtype.hasobject:
                visit(item.tolist())
            else:
                digest.update(np.ascontiguousarray(item).tobytes())
        elif isinstance(item, dict):
            for key in sorted(item, key=str):
                visit(key)
                visit(item[key])
        elif isinstance(item, (tuple, list)):
            digest.update(str(len(item)).encode())
            for child in item:
                visit(child)
        else:
            digest.update((type(item).__name__ + ":" + repr(item) + ";").encode())
    visit(value)
    return digest.hexdigest()


def _finite(value: Any) -> bool:
    if isinstance(value, float):
        return math.isfinite(value)
    if isinstance(value, dict):
        return all(_finite(v) for v in value.values())
    if isinstance(value, list):
        return all(_finite(v) for v in value)
    return True


def _number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _hash_string(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def _version10(value: Any) -> bool:
    return isinstance(value, str) and value.startswith("10.0")


def _issue(record: dict, code: str, detail: str, *, severity: str = "incomplete") -> None:
    record["issues"].append({"code": code, "severity": severity, "detail": detail})


def _read(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Expected a JSON object")
    if not _finite(value):
        raise ValueError("Nonfinite numeric value; result cannot be used as evidence")
    return value


def _safe_local_file(base: Path, filename: Any) -> Path | None:
    if not isinstance(filename, str):
        return None
    candidate = (base / filename).resolve()
    # Evidence files are local to their run; never inspect arbitrary paths from JSON.
    return candidate if candidate.is_relative_to(base.resolve()) and candidate.is_file() else None


def _session_audit(path: Path, data: dict, record: dict) -> None:
    if data.get("protocol") != "fixed_regime_support_query_independent_probes_v2":
        _issue(record, "session_protocol_not_v10", "Only the independent-probe v10 session protocol establishes these claims")
    if (not _hash_string(data.get("training_source_hash")) or not _hash_string(data.get("evaluation_source_hash")) or
            data.get("training_source_hash") != data.get("evaluation_source_hash")):
        _issue(record, "source_lineage_unverified", "Recorded training/evaluation source hashes are absent or differ")
    if (data.get("training_used_oracle_diagnosis") is True or
            data.get("training_config", {}).get("agent", {}).get("oracle_diagnosis") is True):
        _issue(record, "privileged_training", "Oracle-assisted training must be reported separately; it cannot establish an ordinary nonoracle-agent claim")
    for field in ("checkpoint_sha256", "model_sha256", "protocol_sha256"):
        if not _hash_string(data.get(field)):
            _issue(record, "missing_" + field, "A real hash is required: " + field)
    spec = data.get("protocol_spec")
    if not isinstance(spec, dict) or _fingerprint(spec) != data.get("protocol_sha256"):
        _issue(record, "protocol_hash_mismatch", "Missing or mismatched protocol specification hash", severity="invalid")
    if data.get("environment_profile") not in ("train", "heldout_v1"):
        _issue(record, "unknown_profile", "Environment profile must be explicit")
    if not isinstance(data.get("training_seed"), int):
        _issue(record, "training_seed_missing", "Evaluation episodes cannot substitute for a training seed")
    modes = data.get("mode_sessions")
    if not isinstance(modes, dict) or not modes:
        _issue(record, "sessions_missing", "No raw session summaries supplied")
        return
    if isinstance(spec, dict) and (set(spec.get("modes", [])) != set(modes) or
                                  spec.get("environment_profile") != data.get("environment_profile")):
        _issue(record, "protocol_mode_or_profile_mismatch", "Declared protocol modes/profile differ from executed results", severity="invalid")
    if not {"full", "global_repair", "diagnose_no_repair", "frozen"}.issubset(modes):
        _issue(record, "missing_core_controls", "Core adaptation controls are absent")
    session_count = data.get("sessions")
    support_count = data.get("support_episodes_per_session")
    query_count = data.get("query_episodes_per_session")
    if not all(isinstance(v, int) and v > 0 for v in (session_count, support_count, query_count)):
        _issue(record, "invalid_task_counts", "Positive declared support/query/session counts are required", severity="invalid")
        return
    if data.get("active_budget_interpretation") != "equal_maximum_allowance_not_equal_realized_action_counts":
        _issue(record, "action_budget_scope_missing", "Maximum allowance must not be represented as exact action matching")
    budget = data.get("active_budget_per_task")
    if not isinstance(budget, int) or budget < 0:
        _issue(record, "invalid_active_budget", "Explicit nonnegative action allowance is required", severity="invalid")
    references: dict[Any, tuple] = {}
    seen_banks: dict[Any, str] = {}
    for mode, rows in modes.items():
        if not isinstance(rows, list) or len(rows) != session_count:
            _issue(record, "incomplete_mode_sessions", f"{mode}: missing or extra sessions", severity="invalid")
            continue
        ids: set[Any] = set()
        for row in rows:
            if not isinstance(row, dict):
                _issue(record, "malformed_session", f"{mode}: non-object row", severity="invalid")
                continue
            sid = row.get("session")
            if sid is None or sid in ids:
                _issue(record, "duplicate_session", f"{mode}: missing/duplicate session ID", severity="invalid")
            ids.add(sid)
            support = row.get("support_seeds", [])
            query = row.get("query_seeds", [])
            probe = row.get("probe_rollout_seeds", [])
            if not all(isinstance(v, list) and all(isinstance(x, int) for x in v) for v in (support, query, probe)):
                _issue(record, "invalid_seed_bank", f"{mode}/{sid}: invalid seed lists", severity="invalid")
                continue
            if (len(support) != support_count or len(query) != query_count or not probe or
                    len(set(support)) != len(support) or len(set(query)) != len(query) or
                    set(support) & set(query) or set(probe) & (set(support) | set(query))):
                _issue(record, "probe_independence_not_verified", f"{mode}/{sid}: missing or overlapping seed banks", severity="invalid")
            signature = (row.get("regime"), tuple(support), tuple(query), tuple(probe), row.get("probe_bank_hash"),
                         json.dumps(row.get("mechanism_parameters"), sort_keys=True))
            if sid in references and references[sid] != signature:
                _issue(record, "unpaired_mode_schedule", f"Session {sid} uses different tasks/banks/parameters across modes", severity="invalid")
            references.setdefault(sid, signature)
            if not _hash_string(row.get("probe_bank_hash")):
                _issue(record, "probe_bank_hash_missing", f"{mode}/{sid}: no content hash")
            else:
                seen_banks[sid] = row["probe_bank_hash"]
            bank_file = _safe_local_file(path.parent, row.get("probe_bank_file"))
            if bank_file is None:
                _issue(record, "probe_bank_file_missing", f"{mode}/{sid}: bank not available for independent verification")
            else:
                try:
                    with np.load(bank_file, allow_pickle=False) as bank:
                        values = {key: bank[key] for key in bank.files}
                    if not all(np.isfinite(v).all() for v in values.values() if np.issubdtype(v.dtype, np.number)):
                        raise ValueError("Nonfinite probe bank")
                    if row.get("probe_bank_sha256"):
                        matches = _hash_file(bank_file) == row["probe_bank_sha256"] and _fingerprint(values) == row.get("probe_bank_hash")
                    else:
                        matches = _fingerprint(values) == row.get("probe_bank_hash")
                    if not matches:
                        _issue(record, "probe_bank_hash_mismatch", f"{mode}/{sid}: bank hash mismatch", severity="invalid")
                except (ValueError, OSError) as exc:
                    _issue(record, "probe_bank_unreadable", str(exc), severity="invalid")
            after = row.get("model_hash_after_support")
            if (row.get("query_learning_audit_passed") is not True or not _hash_string(after) or
                    row.get("model_hash_after_query") != after):
                _issue(record, "query_freeze_not_verified", f"{mode}/{sid}: query model hashes/audit missing or unequal", severity="invalid")
            if row.get("model_hash_before_support") != data.get("model_sha256"):
                _issue(record, "initial_model_mismatch", f"{mode}/{sid}: controls do not share recorded checkpoint", severity="invalid")
            for phase in ("support", "query"):
                metrics = row.get(phase, {})
                expected_tasks = support_count if phase == "support" else query_count
                required_costs = ("tasks", "environment_steps", "active_actions", "online_optimizer_steps", "repair_optimizer_steps")
                if not isinstance(metrics, dict) or any(not _number(metrics.get(k)) or metrics[k] < 0 for k in required_costs):
                    _issue(record, "cost_or_task_accounting_missing", f"{mode}/{sid}/{phase}: incomplete counts")
                    continue
                if metrics["tasks"] != expected_tasks:
                    _issue(record, "incomplete_task_count", f"{mode}/{sid}/{phase}: tasks missing", severity="invalid")
                if isinstance(budget, int) and metrics["active_actions"] > budget * expected_tasks:
                    _issue(record, "active_budget_exceeded", f"{mode}/{sid}/{phase}: allowance exceeded", severity="invalid")
                if phase == "query" and (metrics["online_optimizer_steps"] or metrics["repair_optimizer_steps"]):
                    _issue(record, "query_learning_detected", f"{mode}/{sid}: optimizer ran during query", severity="invalid")
            for key in ("probe_before", "probe_after"):
                probe_metrics = row.get(key, {})
                if (probe_metrics.get("readonly_audit_passed") is not True or
                        not _number(probe_metrics.get("mse")) or probe_metrics.get("mse", -1) < 0 or
                        not _number(probe_metrics.get("samples")) or probe_metrics.get("samples", 0) <= 0):
                    _issue(record, "probe_prediction_audit_missing", f"{mode}/{sid}/{key}: no finite independent readonly score")
    if len(set(seen_banks.values())) != len(seen_banks):
        _issue(record, "duplicate_probe_bank", "Different session IDs reuse a probe bank", severity="invalid")
    all_task_seeds = [seed for value in references.values() for seeds in value[1:3] for seed in seeds]
    if len(all_task_seeds) != len(set(all_task_seeds)) or any(set(value[3]) & set(all_task_seeds) for value in references.values()):
        _issue(record, "cross_session_seed_overlap", "Independent probe/query/support seed namespaces overlap across sessions", severity="invalid")
    raw = path.parent / "session_episodes.json"
    if not raw.is_file():
        _issue(record, "raw_task_records_missing", "Cannot verify query audits, failures or exact task counts")
    else:
        try:
            episodes = json.loads(raw.read_text(encoding="utf-8"))
            if not isinstance(episodes, list) or not _finite(episodes):
                raise ValueError("Invalid/nonfinite task records")
            queries = [r for r in episodes if r.get("phase") == "query"]
            if len(queries) != len(modes) * session_count * query_count:
                _issue(record, "raw_query_count_mismatch", "Failed/missing queries cannot silently disappear", severity="invalid")
            expected_queries = {(mode, row["session"], seed) for mode, rows in modes.items() for row in rows for seed in row["query_seeds"]}
            actual_queries = {(r.get("mode"), r.get("session"), r.get("episode_seed")) for r in queries}
            if actual_queries != expected_queries or len(actual_queries) != len(queries):
                _issue(record, "raw_query_identity_mismatch", "Query records are duplicated, omitted or not the declared paired seeds", severity="invalid")
            support_rows = [r for r in episodes if r.get("phase") == "support"]
            expected_support = {(mode, row["session"], seed) for mode, rows in modes.items() for row in rows for seed in row["support_seeds"]}
            actual_support = {(r.get("mode"), r.get("session"), r.get("episode_seed")) for r in support_rows}
            if actual_support != expected_support or len(actual_support) != len(support_rows):
                _issue(record, "raw_support_identity_mismatch", "Support tasks are duplicated or omitted; failed tasks must remain recorded", severity="invalid")
            if any(not _number(r.get("return")) or not isinstance(r.get("success"), (bool, int)) or
                   r.get("success") not in (False, True) or not _number(r.get("length")) or r["length"] <= 0
                   for r in [*support_rows, *queries]):
                _issue(record, "raw_task_outcome_missing", "Finite returns, success/failure and positive task length are required", severity="invalid")
            for row in queries:
                before = row.get("learning_hashes_before", row.get("query_learning_hashes_before"))
                after = row.get("learning_hashes_after", row.get("query_learning_hashes_after"))
                if (row.get("query_learning_audit_passed") is not True or not isinstance(before, dict) or
                        not {"model", "optimizer", "detector", "replay_contents"}.issubset(before) or
                        any(not _hash_string(v) for v in before.values()) or before != after or
                        row.get("learning_observations_before") is None or
                        row.get("learning_observations_before") != row.get("learning_observations_after")):
                    _issue(record, "raw_query_hash_audit_missing", "Query learning-state hashes missing or changed", severity="invalid")
                    break
        except (ValueError, OSError, AttributeError) as exc:
            _issue(record, "raw_task_records_invalid", str(exc), severity="invalid")
    record["scope"] = "known_mechanism_family_support_query; independent_training_seed_count_not_episode_count"
    record["modes"] = sorted(modes)


def _claim(status: str = "incomplete", reason: str = "No auditable evidence supplied") -> dict:
    return {"status": status, "reasons": [reason], "supporting_files": [], "scope": None, "protocol_findings": []}


def _finding(claims: dict, name: str, status: str, reason: str, scope: str, path: str) -> None:
    claim = claims[name]
    claim["protocol_findings"].append({"status": status, "reason": reason, "scope": scope, "path": path})
    if status == "supported_in_this_protocol":
        claim["status"] = status
        claim["scope"] = "Only the explicitly supported protocol_findings; no pooling or generalization across protocols"
        claim["supporting_files"].append(path)
        claim["reasons"] = ["At least one narrowly scoped contrast passes the stated checks; inspect all positive and negative protocol findings"]
    elif claim["status"] != "supported_in_this_protocol":
        claim["status"] = status
        claim["reasons"] = [reason]


def _holm(values: dict[str, float]) -> dict[str, float]:
    result, previous = {}, 0.0
    for index, (key, value) in enumerate(sorted(values.items(), key=lambda pair: pair[1])):
        previous = max(previous, min(1.0, (len(values) - index) * value))
        result[key] = previous
    return result


def _scm_audit(path: Path, data: dict, record: dict, claims: dict) -> None:
    """Validate the distinct known-dictionary component experiment, never the agent."""
    protocol_path = path.parent / "protocol.json"
    try:
        document = _read(protocol_path)
        checksum = document.pop("sha256", None)
        computed = hashlib.sha256(json.dumps(document, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        if checksum != computed or data.get("protocol_sha256") != checksum:
            raise ValueError("SCM protocol fingerprint mismatch")
        protocol = document["protocol"]
        if protocol.get("name") != "v10_independent_scm_component_v2":
            raise ValueError("Pre-audit SCM protocol: shared local/global acceptance and replay control not established")
        fairness = data.get("fairness", document.get("fairness", {}))
        if (fairness.get("nonoracle_acceptance_targets") != "shared_residual_diagnosis" or
                fairness.get("same_nonoracle_collateral_guard") is not True):
            raise ValueError("SCM shared acceptance/guard fairness audit is missing")
        seeds, families = protocol["seeds"], protocol["families"]
        horizon = str(protocol["primary_horizon"])
        if len(seeds) != len(set(seeds)) or not seeds or not families:
            raise ValueError("Missing or duplicate prescribed SCM seeds")
        if data.get("complete") is not True or data.get("failures"):
            raise ValueError("SCM run failed or incomplete; failures cannot be excluded")
        rows = []
        for seed in seeds:
            filename = path.parent / f"seed_{seed}.json"
            values = json.loads(filename.read_text(encoding="utf-8"))
            if not isinstance(values, list) or not _finite(values):
                raise ValueError("Nonfinite or invalid raw SCM seed results")
            expected = {(seed, family, scenario) for family in families for scenario in ("no_change", "coefficient_shift", "edge_addition")}
            actual = {(r.get("seed"), r.get("family"), r.get("scenario")) for r in values}
            if actual != expected or len(values) != len(expected):
                raise ValueError("Missing, extra or duplicate SCM family/scenario rows")
            rows.extend(values)
        if data.get("completed_rows") != len(rows) or data.get("expected_seed_scenario_rows") != len(rows):
            raise ValueError("SCM completed row count mismatch")
        required_modes = {"no_repair", "diagnosed_local", "global_same_steps", "global_matched_parameter_work", "global_replay", "dense_global", "random_local", "oracle_local"}
        required_streams = {"base_train", "base_calibration", "diagnosis", "support", "acceptance", "query", "query_rollout"}
        for row in rows:
            streams, modes = row.get("stream_sha256", {}), row.get("modes", {})
            if (set(streams) != required_streams or any(not _hash_string(v) for v in streams.values()) or
                    len(set(streams.values())) != len(streams) or not required_modes.issubset(modes)):
                raise ValueError("SCM data isolation streams or required controls missing")
            for mode in required_modes:
                mse = modes[mode].get("recursive_noiseless_mse_by_horizon", {}).get(horizon)
                if not _number(mse) or mse < 0:
                    raise ValueError("Missing finite held-out horizon error")
                if modes[mode].get("repair", {}).get("uses_query") is True:
                    raise ValueError("SCM repair used query data")
        contrasts = data.get("primary_contrasts", {})
        expected_keys = {f"{family}/{scenario}/vs_{mode}" for family in families
                         for scenario in ("coefficient_shift", "edge_addition")
                         for mode in ("no_repair", "global_matched_parameter_work", "global_replay", "dense_global")}
        if set(contrasts) != expected_keys:
            raise ValueError("Missing or extra prespecified SCM contrasts")
        raw_ps = {}
        for key, entry in contrasts.items():
            family, scenario, baseline = key.split("/")
            baseline = baseline.removeprefix("vs_")
            selected = [r for r in rows if r["family"] == family and r["scenario"] == scenario]
            differences = [r["modes"][baseline]["recursive_noiseless_mse_by_horizon"][horizon] -
                           r["modes"]["diagnosed_local"]["recursive_noiseless_mse_by_horizon"][horizon] for r in selected]
            if entry.get("n_independent_seeds") != len(seeds) or not math.isclose(
                    entry.get("mean_baseline_minus_local", float("nan")), float(np.mean(differences)), rel_tol=1e-8, abs_tol=1e-12):
                raise ValueError("SCM aggregate mean/seed count disagrees with raw records")
            p = entry.get("two_sided_sign_flip_p")
            if len(seeds) >= 2:
                if not _number(p) or not 0 <= p <= 1:
                    raise ValueError("Missing valid paired SCM inference")
                raw_ps[key] = p
                if len(seeds) <= 16:
                    signs = np.asarray(list(itertools.product((-1.0, 1.0), repeat=len(seeds))))
                    null = np.abs((signs * np.asarray(differences)).mean(axis=1))
                    expected_p = float(np.mean(null >= abs(float(np.mean(differences))) - 1e-15))
                    if not math.isclose(p, expected_p, abs_tol=1e-8):
                        raise ValueError("SCM sign-flip inference disagrees with raw paired seeds")
        for key, adjusted in _holm(raw_ps).items():
            if not math.isclose(contrasts[key].get("holm_adjusted_p", float("nan")), adjusted, abs_tol=1e-8):
                raise ValueError("SCM correction does not cover every prescribed contrast")
        if record["issues"]:
            return
        record["scope"] = "Synthetic fully observed known-feature modular estimator; not the shipped neural agent"
        record["scm_independent_seeds"] = seeds
        for baseline, claim_name in (("no_repair", "local_predictive_benefit"),
                                     ("global_matched_parameter_work", "local_vs_global"),
                                     ("global_replay", "local_vs_global"), ("dense_global", "local_vs_global")):
            for key, entry in contrasts.items():
                if not key.endswith("/vs_" + baseline):
                    continue
                interval = entry.get("paired_seed_bootstrap_ci95")
                supported = (len(seeds) >= 2 and isinstance(interval, list) and len(interval) == 2 and
                             all(_number(v) for v in interval) and interval[0] > 0 and
                             _number(entry.get("holm_adjusted_p")) and entry["holm_adjusted_p"] < .05 and
                             entry["mean_baseline_minus_local"] > 0)
                _finding(claims, claim_name, "supported_in_this_protocol" if supported else "insufficient",
                         "Paired independent-seed component contrast with Holm correction" if supported else
                         "Component contrast lacks corrected directional evidence; retained without exclusion",
                         record["scope"] + "; " + key + "; coefficient-update budget is not measured FLOPs", record["path"])
    except (ValueError, OSError, KeyError, TypeError) as exc:
        _issue(record, "scm_evidence_incomplete_or_invalid", str(exc), severity="invalid")


def _inference_supports(stats: Any, *, smaller_is_better: bool = False) -> bool:
    """Require both directional uncertainty and corrected paired inference."""
    if not isinstance(stats, dict):
        return False
    p = stats.get("holm_pvalue", stats.get("p_holm", stats.get("holm_p", stats.get("pvalue_holm"))))
    interval = stats.get("ci95")
    lo, hi = interval if isinstance(interval, list) and len(interval) == 2 else (stats.get("ci95_low"), stats.get("ci95_high"))
    mean = stats.get("mean_difference", stats.get("mean"))
    return (all(_number(v) for v in (p, lo, hi, mean)) and 0 <= p < .05 and lo <= mean <= hi and
            ((hi < 0 and mean < 0) if smaller_is_better else (lo > 0 and mean > 0)))


def _aggregate_audit(data: dict, record: dict, sessions: list[tuple[dict, dict]], claims: dict) -> None:
    # Concrete aggregators may expose paired contrasts under either documented key.
    protocol = data.get("protocol_sha256")
    if not _hash_string(protocol):
        _issue(record, "aggregate_protocol_missing", "No exact protocol fingerprint")
        return
    included = [pair for pair in sessions if pair[0].get("protocol_sha256") == protocol]
    training_seeds = data.get("training_seeds", data.get("seeds"))
    if not isinstance(training_seeds, list) or len(training_seeds) < 2 or len(set(training_seeds)) != len(training_seeds):
        _issue(record, "no_between_training_inference", "At least two distinct training runs are needed to estimate between-training variability; this is not a publication threshold")
        return
    good = {d.get("training_seed"): (d, r) for d, r in included if not r["issues"]}
    if set(good) != set(training_seeds):
        _issue(record, "aggregate_inputs_unverified", "All declared seeds must have complete auditable same-protocol session files; no failures may be excluded")
        return
    if len({d.get("model_sha256") for d, _ in good.values()}) != len(good):
        _issue(record, "duplicate_trained_model", "Different seeds reference the same trained model", severity="invalid")
        return
    if data.get("bootstrap_unit") != "training_seed_then_paired_session_within_regime":
        _issue(record, "incorrect_inference_unit", "Session/episode inference is not independent-training inference")
        return
    inputs = data.get("inputs", [])
    if not isinstance(inputs, list) or len(inputs) != len(training_seeds):
        _issue(record, "aggregate_lineage_missing", "Every aggregate input needs file, model, checkpoint and seed lineage")
        return
    for item in inputs:
        match = good.get(item.get("training_seed"))
        if match is None or item.get("sha256") != match[1]["sha256"] or any(
                item.get(key) != match[0].get(key) for key in ("checkpoint_sha256", "model_sha256", "evaluation_seed")):
            _issue(record, "aggregate_lineage_mismatch", "Aggregate input hashes/seeds do not match supplied raw runs", severity="invalid")
            return
    if len({d.get("evaluation_seed") for d, r in good.values()}) != len(good):
        _issue(record, "reused_evaluation_seed", "Nested inference requires independent evaluation seeds across trained checkpoints", severity="invalid")
        return
    if data.get("holm_family") != "all_25_prespecified_full_contrasts_times_query_and_probe_endpoints_including_undefined":
        _issue(record, "correction_family_missing", "Prespecified multiplicity correction family is absent")
        return
    paired = data.get("paired_comparisons", data.get("comparisons", data.get("paired", {})))
    if not isinstance(paired, dict):
        _issue(record, "paired_inference_missing", "Missing paired contrasts")
        return
    metric_fields = {
        "query_success": ("query", "success_rate"), "query_return": ("query", "mean_return"),
        "probe_mse": ("probe_after", "mse"), "probe_changed_child_mse": ("probe_after", "changed_child_mse"),
        "probe_unchanged_child_mse": ("probe_after", "unchanged_child_mse"),
    }
    for contrast, metrics in paired.items():
        if not contrast.startswith("full_vs_") or not isinstance(metrics, dict):
            _issue(record, "unknown_paired_contrast", "Contrast names or schema are invalid", severity="invalid")
            return
        comparator = contrast.removeprefix("full_vs_")
        for metric, (section, field) in metric_fields.items():
            entry = metrics.get(metric, {})
            if entry.get("available") is False:
                continue
            effects = []
            for seed in training_seeds:
                runs = good[seed][0]["mode_sessions"]
                if comparator not in runs:
                    _issue(record, "missing_contrast_control", "Cannot infer effects without the exact baseline", severity="invalid")
                    return
                differences = [a.get(section, {}).get(field) - b.get(section, {}).get(field)
                               for a, b in zip(runs["full"], runs[comparator])]
                effects.append(float(np.mean(differences)))
            if (not _number(entry.get("mean_difference")) or
                    not math.isclose(entry["mean_difference"], float(np.mean(effects)), abs_tol=1e-10, rel_tol=1e-8) or
                    not np.allclose(entry.get("training_seed_mean_differences", []), effects, rtol=1e-8, atol=1e-10)):
                _issue(record, "paired_effect_mismatch", "Reported effects disagree with paired raw trained-seed records", severity="invalid")
                return
            if len(effects) <= 16:
                signs = np.asarray(list(itertools.product((-1.0, 1.0), repeat=len(effects))))
                expected_p = float(np.mean(np.abs((signs * np.asarray(effects)).mean(axis=1)) >= abs(float(np.mean(effects))) - 1e-15))
                if not _number(entry.get("signflip", {}).get("pvalue")) or not math.isclose(
                        entry["signflip"]["pvalue"], expected_p, abs_tol=1e-8):
                    _issue(record, "paired_inference_mismatch", "Sign-flip inference does not match supplied raw effects", severity="invalid")
                    return
    plan = data.get("statistical_plan", {})
    spec_plan = data.get("protocol_spec", {}).get("statistical_plan")
    if (not isinstance(plan, dict) or plan != spec_plan or
            plan.get("confirmatory_profile") != "heldout_v1" or
            plan.get("primary_task_return") != ["full_vs_diagnose_no_repair/query_return", "full_vs_global_repair/query_return"] or
            plan.get("secondary_prediction") != ["full_vs_diagnose_no_repair/probe_mse", "full_vs_global_repair/probe_mse"]):
        _issue(record, "statistical_plan_not_verified", "Primary/secondary families must be fixed in the hashed protocol")
        return
    families = data.get("inference_families", {})
    for family in ("primary_task_return", "secondary_prediction", "exploratory_all_endpoints"):
        declared = plan.get(family, [])
        supplied = families.get(family, {})
        hypotheses = supplied.get("hypotheses", {})
        if supplied.get("family_size") != len(declared) or set(hypotheses) != set(declared):
            _issue(record, "inference_family_incomplete", "Missing hypotheses must retain their correction slots", severity="invalid")
            return
        pvalues = {name: (entry.get("pvalue") if _number(entry.get("pvalue")) else 1.0) for name, entry in hypotheses.items()}
        adjusted = _holm(pvalues)
        for name, entry in hypotheses.items():
            if entry.get("pvalue") is not None and (not _number(entry.get("holm_pvalue")) or
                    not math.isclose(entry["holm_pvalue"], adjusted[name], abs_tol=1e-8)):
                _issue(record, "inference_correction_mismatch", "Reported Holm values disagree with fixed family", severity="invalid")
                return
    mappings = {
        "local_predictive_benefit": ("full_vs_diagnose_no_repair", "probe_mse", True),
        "local_vs_global": ("full_vs_global_repair", "probe_mse", True),
        "active_value": ("full_vs_no_active", "query_return", False),
    }
    for name, (contrast, metric, lower) in mappings.items():
        block = paired.get(contrast, {})
        stats = block.get(metric, block.get("metrics", {}).get(metric, {}))
        scoped_stats = dict(stats)
        if name in ("local_predictive_benefit", "local_vs_global"):
            scoped_stats["holm_pvalue"] = stats.get("secondary_holm_pvalue")
        confirmatory = data.get("environment_profile") == "heldout_v1"
        supported = confirmatory and _inference_supports(scoped_stats, smaller_is_better=lower)
        _finding(claims, name, "supported_in_this_protocol" if supported else "insufficient",
                 "Positive paired training-seed contrast with corrected inference and directional interval" if supported else
                 "Complete runs do not show a prespecified corrected positive paired contrast for this claim",
                 "Neural session protocol " + protocol + "; prediction contrasts do not replace failed primary task-return evidence", record["path"])
    if data.get("environment_profile", data.get("protocol_spec", {}).get("environment_profile")) == "heldout_v1":
        for contrast in ("full_vs_diagnose_no_repair", "full_vs_global_repair"):
            stats = dict(paired.get(contrast, {}).get("query_return", {}))
            stats["holm_pvalue"] = stats.get("primary_holm_pvalue")
            supported = _inference_supports(stats)
            _finding(claims, "ood_parameter_adaptation", "supported_in_this_protocol" if supported else "insufficient",
                     "Primary task-return contrast; prediction improvements cannot replace it",
                     "Held-out parameters within known families only; " + contrast + "; " + protocol, record["path"])


def build_evidence_report(root: str | Path) -> dict:
    root = Path(root).resolve()
    if not root.is_dir():
        raise NotADirectoryError(root)
    records: list[dict] = []
    loaded: list[tuple[dict, dict]] = []
    seen_hashes: dict[str, str] = {}
    for path in sorted(root.rglob("*.json")):
        # Pipeline stage markers describe orchestration status, not measured
        # research evidence, even when their basename matches a result file.
        if "stage_status" in path.relative_to(root).parts:
            continue
        kind = RECOGNIZED.get(path.name)
        if kind is None and path.name.endswith("_sessions.json") and path.name != "session_episodes.json":
            kind = "session_aggregate"
        if kind is None and (path.name.endswith("_architecture_comparison.json") or path.name.startswith("architecture_comparison_")):
            kind = "architecture_comparison"
        if kind is None:
            continue
        record = {"path": str(path), "kind": kind, "sha256": _hash_file(path), "issues": []}
        records.append(record)
        quarantined = "incomplete_attempts" in path.relative_to(root).parts
        if quarantined:
            _issue(record, "quarantined_incomplete_attempt", "Retained failed/incomplete attempt; excluded from formal comparisons", severity="invalid")
        if record["sha256"] in seen_hashes:
            _issue(record, "duplicate_artifact", "Byte-identical to " + seen_hashes[record["sha256"]], severity="invalid")
        if not quarantined:
            seen_hashes.setdefault(record["sha256"], str(path))
        try:
            data = _read(path)
        except (ValueError, OSError) as exc:
            _issue(record, "unreadable_or_nonfinite", str(exc), severity="invalid")
            continue
        record.update({key: data.get(key) for key in ("software_version", "training_seed", "protocol", "protocol_sha256", "environment_profile")})
        if data.get("scope") == "synthetic_modular_regression_component_not_full_agent":
            kind = record["kind"] = "scm"
        if kind == "session_aggregate" and data.get("schema") != "session_multiseed_v1":
            _issue(record, "unknown_aggregate_schema", "Only the documented training-seed aggregate schema is comparable")
        if not _version10(data.get("software_version")):
            _issue(record, "not_v10_evidence", "Historical or unspecified software cannot establish v10 claims")
        if data.get("completed") is False or data.get("status") in ("failed", "incomplete", "running"):
            _issue(record, "run_not_completed", "Failed/incomplete runs are retained in the inventory", severity="invalid")
        if kind == "training":
            record["training_seed"] = data.get("seed")
            record["total_steps"] = data.get("total_steps")
            record["episodes"] = data.get("episodes")
            record["completion_evidence"] = "training_summary_present_not_reexecuted"
            if not isinstance(data.get("seed"), int) or not _number(data.get("total_steps")) or data.get("total_steps", 0) <= 0:
                _issue(record, "training_summary_incomplete", "Missing seed or positive completed-step count")
        elif kind == "session":
            try:
                _session_audit(path, data, record)
            except (ValueError, TypeError, KeyError, AttributeError) as exc:
                _issue(record, "malformed_session_schema", str(exc), severity="invalid")
        loaded.append((data, record))
    claims = {name: _claim() for name in CLAIMS}
    sessions = [(d, r) for d, r in loaded if r["kind"] == "session"]
    # A seed reused with a different output path is not an independent replicate.
    seen_seed_protocol: dict[tuple, str] = {}
    seen_model_seed: dict[str, Any] = {}
    for data, record in sessions:
        key = (data.get("protocol_sha256"), data.get("training_seed"))
        if key in seen_seed_protocol:
            _issue(record, "duplicate_training_seed_protocol", "Same training seed/protocol already at " + seen_seed_protocol[key], severity="invalid")
        seen_seed_protocol.setdefault(key, record["path"])
        model = data.get("model_sha256")
        if _hash_string(model) and model in seen_model_seed and seen_model_seed[model] != data.get("training_seed"):
            _issue(record, "same_model_different_seed", "Different declared seeds share an identical trained model", severity="invalid")
        if _hash_string(model):
            seen_model_seed.setdefault(model, data.get("training_seed"))
    for data, record in loaded:
        if record["kind"] == "validation" and not record["issues"]:
            if data.get("completed") is True and data.get("tests_failed") == 0 and _number(data.get("tests_passed")) and data["tests_passed"] > 0:
                claims["implementation"] = _claim("supported_in_this_protocol", "Recorded test execution passed; limited to supplied tests and recorded device")
                claims["implementation"]["supporting_files"] = [record["path"]]
                claims["implementation"]["scope"] = data.get("scope", "Implementation checks only; scientific claims require experiments")
            else:
                _issue(record, "validation_incomplete", "Need completed test execution, positive passed count and zero failures")
        elif record["kind"] == "session_aggregate" and not record["issues"]:
            try:
                _aggregate_audit(data, record, sessions, claims)
            except (ValueError, TypeError, KeyError, AttributeError) as exc:
                _issue(record, "malformed_aggregate_schema", str(exc), severity="invalid")
        elif record["kind"] == "scm":
            _scm_audit(Path(record["path"]), data, record, claims)
        elif record["kind"] == "architecture_comparison":
            record["scope"] = "Separately trained dense architecture control, not an external published baseline"
            _issue(record, "architecture_review_required", "Architecture comparison retained for review; no automatic external-baseline or publication claim")
    gaps = [
        "No automatic publication-readiness decision: novelty, external validity and research design require scientific review.",
        "Support/query tasks in known mechanism families do not establish unseen-family or full-agent long-horizon generalization.",
        "Causal graph scores alone do not establish causal identification; independent interventions and defensible target semantics are required.",
        "Equal active-action allowances are not exact realized action or total compute matching.",
        "This inventory cannot detect unuploaded or undeclared experiments; preserve the prespecified run manifest and all failed attempts.",
    ]
    valid_sessions = [(d, r) for d, r in sessions if not r["issues"]]
    seeds = sorted({r["training_seed"] for r in records if isinstance(r.get("training_seed"), int)})
    if len(seeds) <= 1:
        gaps.append("Zero or one trained seed: many sessions/episodes do not estimate between-training uncertainty.")
    modes = {mode for d, r in sessions if isinstance(d.get("mode_sessions"), dict) for mode in d["mode_sessions"]}
    dense_present = any(d.get("training_config", {}).get("model", {}).get("dense_graph") is True for d, r in sessions)
    if not dense_present and not any("dense" in mode for mode in modes):
        gaps.append("No dense model baseline in supplied session evidence.")
    if not any(d.get("environment_profile") == "heldout_v1" for d, r in valid_sessions):
        gaps.append("No complete independently audited held-out-parameter session evidence.")
    if not any("no_active" in mode for mode in modes):
        gaps.append("No no-active matched-budget control: active exploration contribution is unestablished.")
    if not any(r["kind"] in ("scm", "scm_aggregate") for r in records):
        gaps.append("No structural-mechanism benchmark evidence supplied.")
    return {
        "schema": REPORT_SCHEMA, "root": str(root), "decision": "requires_research_review",
        "paper_claims_supported": False,
        "interpretation": "An evidence inventory, not certification of publication readiness or causal identification",
        "independent_training_seeds_found": seeds, "independent_training_seed_count": len(seeds),
        "auditable_session_run_count": len(valid_sessions), "artifact_count": len(records),
        "invalid_or_incomplete_artifact_count": sum(bool(r["issues"]) for r in records),
        "claims": claims, "remaining_gaps": gaps, "artifacts": records,
    }


def render_text(report: dict) -> str:
    lines = ["ADR-CML evidence report", "Decision: requires_research_review", "Paper claims supported: false",
             "This report never certifies publication readiness.",
             f"Independent training seeds found: {report['independent_training_seed_count']}",
             f"Auditable session runs: {report['auditable_session_run_count']}", "", "CLAIMS"]
    for name, claim in report["claims"].items():
        lines.append(f"{name}: {claim['status']}")
        lines.extend("  " + reason for reason in claim["reasons"])
        if claim.get("scope"):
            lines.append("  Scope: " + claim["scope"])
        for finding in claim.get("protocol_findings", []):
            lines.append(f"  Protocol finding: {finding['status']}")
            lines.append("    Scope: " + finding["scope"])
            lines.append("    " + finding["reason"])
    lines.extend(["", "REMAINING GAPS", *report["remaining_gaps"], "", "ARTIFACTS (including failures and incomplete results)"])
    for record in report["artifacts"]:
        lines.append(record["path"])
        lines.extend(f"  {issue['severity']}: {issue['code']}: {issue['detail']}" for issue in record["issues"])
        if not record["issues"]:
            lines.append("  Inventory checks passed; this is not a scientific success verdict.")
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, help="Output directory; defaults to ROOT")
    args = parser.parse_args()
    report = build_evidence_report(args.root)
    output = (args.output or args.root).resolve()
    output.mkdir(parents=True, exist_ok=True)
    (output / "evidence_report.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    (output / "evidence_report.txt").write_text(render_text(report), encoding="utf-8")
    print(output / "evidence_report.json")
    print(output / "evidence_report.txt")


if __name__ == "__main__":
    main()
