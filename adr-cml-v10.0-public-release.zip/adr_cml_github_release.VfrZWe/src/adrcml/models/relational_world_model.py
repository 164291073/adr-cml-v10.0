from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import torch
from torch import Tensor, nn
import torch.nn.functional as F

from adrcml.buffer import TransitionBatch


@dataclass
class WorldModelOutput:
    next_mean: Tensor
    next_logvar: Tensor
    reward_mean: Tensor
    done_logit: Tensor
    adjacency: Tensor
    validity_logits: Tensor


def _mlp(input_dim: int, hidden_dim: int, output_dim: int) -> nn.Sequential:
    return nn.Sequential(
        nn.Linear(input_dim, hidden_dim),
        nn.SiLU(),
        nn.LayerNorm(hidden_dim),
        nn.Linear(hidden_dim, output_dim),
    )


class RelationalCausalWorldModel(nn.Module):
    """Node-factorized transition model with differentiable parent gates.

    ``edge_logits[parent, child]`` parameterizes a predictive dependency gate.
    In v0.9 a child's gate controls both a parent's present value and all of its
    historical state/delta inputs. Gates depend on actions and learned weights,
    never on unmasked history. Reward history is not a transition input.

    This provides a one-step information-path constraint conditional on action
    history. It does not establish causal identifiability from observational
    trajectories, and an edge can represent a historical or present dependency.
    """

    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        hidden_dim: int = 96,
        edge_temperature: float = 0.5,
        edge_init_logit: float = -0.5,
        hard_concrete_gates: bool = True,
        hard_concrete_gamma: float = -0.1,
        hard_concrete_zeta: float = 1.1,
        dense_graph: bool = False,
        action_conditioned_gates: bool = True,
        context_dim: int = 0,
        context_hidden_dim: int = 32,
        context_gate_scale: float = 2.0,
    ) -> None:
        super().__init__()
        self.state_dim = int(state_dim)
        self.action_dim = int(action_dim)
        self.hidden_dim = int(hidden_dim)
        self.edge_temperature = float(edge_temperature)
        self.hard_concrete_gates = bool(hard_concrete_gates)
        self.hard_concrete_gamma = float(hard_concrete_gamma)
        self.hard_concrete_zeta = float(hard_concrete_zeta)
        if not self.hard_concrete_gamma < 0.0 < 1.0 < self.hard_concrete_zeta:
            raise ValueError("Hard-concrete bounds must satisfy gamma < 0 < 1 < zeta")
        self.dense_graph = bool(dense_graph)
        self.action_conditioned_gates = bool(action_conditioned_gates)
        self.context_dim = int(context_dim)
        self.context_hidden_dim = int(context_hidden_dim) if self.context_dim else 0
        # Retained in the constructor for config/API compatibility. History
        # offsets are intentionally absent in v0.9: even a context-dependent
        # gate could transmit a blocked parent's information through its value.
        self.context_gate_scale = float(context_gate_scale)
        expected_context_dim = 2 * (2 * self.state_dim + self.action_dim + 1)
        if self.context_dim not in (0, expected_context_dim):
            raise ValueError(
                f"context_dim must be 0 or HistoryContext layout size {expected_context_dim}"
            )
        if self.context_dim and self.context_hidden_dim < 1:
            raise ValueError("Invalid history context dimensions")
        # This buffer describes the live observed past, not a learned parameter.
        # Replay training always supplies the context stored with each sample.
        self.register_buffer("current_context", torch.zeros(self.context_dim), persistent=False)
        self.context_encoders = nn.ModuleList(
            [_mlp(self.context_dim, self.context_hidden_dim, self.context_hidden_dim)
             for _ in range(state_dim)] if self.context_dim else []
        )
        self.action_embedding = nn.Embedding(action_dim, hidden_dim)
        # The same parent gates mask present values AND historical state/delta
        # features before each child's private history encoder. Own-node history
        # remains available through the always-on diagonal. Action history stays
        # an explicit conditioning input; observed rewards are always masked.
        self.self_mechanisms = nn.ModuleList(
            [_mlp(state_dim + hidden_dim + self.context_hidden_dim, hidden_dim, hidden_dim) for _ in range(state_dim)]
        )
        self.node_heads = nn.ModuleList(
            [_mlp(hidden_dim, hidden_dim, 2) for _ in range(state_dim)]
        )
        self.reward_head = _mlp(state_dim + hidden_dim, hidden_dim, 1)
        self.done_head = _mlp(state_dim + hidden_dim, hidden_dim, 1)
        self.validity_head = _mlp(state_dim, hidden_dim, action_dim)

        # Starting every candidate edge near zero makes a persistence-only
        # solution too attractive on sparse-event environments.  A moderately
        # uncertain prior lets transition evidence move useful gates in either
        # direction; sparsity is introduced only after a configurable warmup.
        initial = torch.full((state_dim, state_dim), float(edge_init_logit))
        initial.fill_diagonal_(4.0)
        self.edge_logits = nn.Parameter(initial)
        if self.action_conditioned_gates:
            self.action_edge_logits = nn.Parameter(
                torch.zeros(action_dim, state_dim, state_dim)
            )
        else:
            self.register_parameter("action_edge_logits", None)

    def _force_diagonal(self, gates: Tensor) -> Tensor:
        eye = torch.eye(self.state_dim, device=gates.device, dtype=gates.dtype)
        return gates * (1.0 - eye) + eye

    def _gates_from_logits(self, logits: Tensor, sample: bool) -> Tensor:
        if sample and self.training:
            uniform = torch.rand_like(logits).clamp_(1e-6, 1 - 1e-6)
            logistic = torch.log(uniform) - torch.log1p(-uniform)
            probabilities = torch.sigmoid(
                (logits + logistic) / self.edge_temperature
            )
        else:
            probabilities = torch.sigmoid(logits / self.edge_temperature)
        if not self.hard_concrete_gates:
            return probabilities
        stretched = (
            probabilities
            * (self.hard_concrete_zeta - self.hard_concrete_gamma)
            + self.hard_concrete_gamma
        )
        clipped = stretched.clamp(0.0, 1.0)
        if self.training:
            # Straight-through clipping preserves gradients for a gate currently
            # at zero/one; sparsity below uses smooth probabilities as well.
            return stretched + (clipped - stretched).detach()
        return clipped

    def set_context(self, context: Tensor | None) -> None:
        value = torch.zeros_like(self.current_context) if context is None else torch.as_tensor(
            context, device=self.edge_logits.device, dtype=self.edge_logits.dtype
        )
        if value.shape != (self.context_dim,):
            raise ValueError("Live model context must be a single context vector")
        self.current_context.copy_(value.detach())

    def _context_values(self, context: Tensor | None, batch_size: int) -> Tensor:
        values = self.current_context if context is None else torch.as_tensor(
            context, device=self.edge_logits.device, dtype=self.edge_logits.dtype
        )
        if values.ndim == 1:
            values = values.unsqueeze(0)
        if values.ndim != 2 or values.shape[-1] != self.context_dim:
            raise ValueError("Context shape must be (context_dim,) or (batch, context_dim)")
        if values.shape[0] not in (1, batch_size):
            raise ValueError("Context batch does not match transition batch")
        return values

    def _context_mask(self, parent_gates: Tensor) -> Tensor:
        """Map (batch, parents) gates to [mean(row), last(row)] history masks."""
        batch_size = parent_gates.shape[0]
        # History row layout: [state, action one-hot, delta, reward]. Keeping
        # reward as a zero-masked reserved slot preserves the replay wire shape.
        row_mask = torch.cat([
            parent_gates,
            parent_gates.new_ones((batch_size, self.action_dim)),
            parent_gates,
            parent_gates.new_zeros((batch_size, 1)),
        ], dim=-1)
        return torch.cat([row_mask, row_mask], dim=-1)

    def _context_features(
        self, context: Tensor | None, adjacency: Tensor, action: Tensor,
        deterministic_gates: bool,
    ) -> list[Tensor]:
        if not self.context_dim:
            return []
        values = self._context_values(context, len(action))
        if values.shape[0] == 1 and deterministic_gates:
            # CEM candidates share one observed past, but different actions have
            # different masks. Encode once per ACTION and child, not per CEM
            # candidate. No cache crosses calls or parameter updates. Indexing
            # accumulates the same gradients as repeated per-candidate encoding.
            all_action_gates = self.adjacency_by_action(sample=False)
            return [encoder(values * self._context_mask(all_action_gates[:, :, child]))[action]
                    for child, encoder in enumerate(self.context_encoders)]
        return [encoder(values * self._context_mask(adjacency[:, :, child]))
                for child, encoder in enumerate(self.context_encoders)]

    def _base_action_logits(self) -> Tensor:
        logits = self.edge_logits.unsqueeze(0)
        if self.action_edge_logits is not None:
            return logits + self.action_edge_logits
        return logits.expand(self.action_dim, -1, -1)

    def _selected_logits(self, action: Tensor) -> Tensor:
        logits = self.edge_logits.unsqueeze(0).expand(len(action), -1, -1)
        if self.action_edge_logits is not None:
            logits = logits + self.action_edge_logits[action]
        return logits

    def adjacency_by_action(self, sample: bool = False, context: Tensor | None = None) -> Tensor:
        """All action graphs, shape (A, N, N); independent of observed context.

        ``context`` remains an accepted compatibility keyword and is ignored.
        Graphs can change through weight updates, not unmasked history offsets.
        """
        logits = self._base_action_logits()
        if self.dense_graph:
            return torch.ones_like(logits)
        return self._force_diagonal(self._gates_from_logits(logits, sample))

    def adjacency(
        self, action: Tensor | None = None, sample: bool = False,
        context: Tensor | None = None,
    ) -> Tensor:
        if action is None:
            return self.adjacency_by_action(sample=sample).max(dim=0).values
        action = action.long().reshape(-1)
        logits = self._selected_logits(action)
        gates = torch.ones_like(logits) if self.dense_graph else self._gates_from_logits(logits, sample)
        return self._force_diagonal(gates)

    def forward(
        self, state: Tensor, action: Tensor, sample_edges: bool = True,
        context: Tensor | None = None,
    ) -> WorldModelOutput:
        if state.ndim == 1:
            state = state.unsqueeze(0)
        action = action.long().reshape(-1)
        action_embedding = self.action_embedding(action)
        logits = self._selected_logits(action)
        gates = torch.ones_like(logits) if self.dense_graph else self._gates_from_logits(logits, sample_edges)
        adjacency = self._force_diagonal(gates)
        context_features = self._context_features(
            context, adjacency, action,
            deterministic_gates=self.dense_graph or not (sample_edges and self.training),
        )

        means, logvars = [], []
        for child in range(self.state_dim):
            gated_parents = state * adjacency[:, :, child]
            inputs = [gated_parents, action_embedding]
            if context_features:
                inputs.append(context_features[child])
            mechanism_input = torch.cat(inputs, dim=-1)
            aggregate = self.self_mechanisms[child](mechanism_input)
            stats = self.node_heads[child](F.silu(aggregate))
            means.append(state[:, child] + stats[:, 0])
            logvars.append(stats[:, 1].clamp(-6.0, 2.0))

        next_mean = torch.stack(means, dim=-1)
        next_logvar = torch.stack(logvars, dim=-1)
        global_input = torch.cat([next_mean, action_embedding], dim=-1)
        reward_mean = self.reward_head(global_input).squeeze(-1)
        done_logit = self.done_head(global_input).squeeze(-1)
        validity_logits = self.validity_head(state)
        return WorldModelOutput(
            next_mean, next_logvar, reward_mean, done_logit, adjacency, validity_logits,
        )

    def node_nll(self, output: WorldModelOutput, target: Tensor) -> Tensor:
        inv_var = torch.exp(-output.next_logvar)
        return 0.5 * ((target - output.next_mean).pow(2) * inv_var + output.next_logvar)

    def loss(
        self,
        batch: TransitionBatch,
        state_loss_weight: float = 1.0,
        reward_loss_weight: float = 1.0,
        done_loss_weight: float = 0.1,
        feasibility_loss_weight: float = 0.2,
        sparsity_weight: float = 1e-3,
        parent_budget: float = 3.0,
        parent_budget_weight: float = 0.02,
        action_gate_regularization: float = 1e-4,
        edge_entropy_weight: float = 2e-4,
        transition_change_weight: float = 0.0,
        node_mask: Tensor | None = None,
        state_mse_loss_weight: float = 0.0,
    ) -> tuple[Tensor, dict[str, Tensor]]:
        output = self(batch.state, batch.action, sample_edges=True, context=batch.context)
        node_loss = self.node_nll(output, batch.next_state)
        node_mse = (output.next_mean - batch.next_state).pow(2)
        if transition_change_weight > 0:
            # Rare state-changing transitions carry most of the relational
            # signal in MechanismMaze.  Upweight them without using graph or
            # regime labels.
            change = (batch.next_state - batch.state).abs().clamp(0.0, 1.0)
            change_weights = 1.0 + float(transition_change_weight) * change
            node_loss = node_loss * change_weights
            node_mse = node_mse * change_weights
        if node_mask is not None:
            weights = node_mask.float().reshape(1, -1)
            denominator = (weights.sum() * node_loss.shape[0]).clamp_min(1.0)
            state_loss = (node_loss * weights).sum() / denominator
            state_mse_loss = (node_mse * weights).sum() / denominator
        else:
            state_loss = node_loss.mean()
            state_mse_loss = node_mse.mean()
        reward_loss = F.mse_loss(output.reward_mean, batch.reward)
        done_loss = F.binary_cross_entropy_with_logits(output.done_logit, batch.done)
        if batch.valid_action_mask is not None and batch.valid_mask_known is not None:
            validity_per_row = F.binary_cross_entropy_with_logits(
                output.validity_logits,
                batch.valid_action_mask.float(),
                reduction="none",
            ).mean(dim=-1)
            known = batch.valid_mask_known.float().reshape(-1)
            feasibility_loss = (validity_per_row * known).sum() / known.sum().clamp_min(1.0)
        else:
            feasibility_loss = output.validity_logits.sum() * 0.0
        # Smooth (unclipped) probabilities retain regularization gradients when
        # deterministic hard-concrete gates have clipped to exactly zero or one.
        # The global prior covers all actions; selected terms cover observed
        # actions, avoiding a B*A*N*N intermediate allocation.
        prior_probs = torch.sigmoid(self._base_action_logits() / self.edge_temperature)
        selected_logits = self._selected_logits(batch.action.long().reshape(-1))
        selected_probs = torch.sigmoid(selected_logits / self.edge_temperature)
        if self.dense_graph:
            prior_probs = torch.ones_like(prior_probs)
            selected_probs = torch.ones_like(selected_probs)
        offdiag = 1.0 - torch.eye(self.state_dim, device=prior_probs.device)
        group_strength = prior_probs.amax(dim=0)
        group_sparsity = (group_strength * offdiag).sum() / offdiag.sum().clamp_min(1.0)
        observed_sparsity = (selected_probs * offdiag).sum() / (
            offdiag.sum() * len(batch.action)
        ).clamp_min(1.0)
        sparsity = 0.5 * (group_sparsity + observed_sparsity)
        parent_counts = (group_strength * offdiag).sum(dim=0)
        observed_counts = (selected_probs * offdiag).sum(dim=1)
        parent_budget_loss = 0.5 * (
            torch.relu(parent_counts - float(parent_budget)).pow(2).mean()
            + torch.relu(observed_counts - float(parent_budget)).pow(2).mean()
        )
        action_gate_loss = (
            self.action_edge_logits.pow(2).mean()
            if self.action_edge_logits is not None else prior_probs.sum() * 0.0
        )
        probs = selected_probs.clamp(1e-6, 1 - 1e-6)
        entropy = (-(probs * probs.log() + (1 - probs) * (1 - probs).log()) * offdiag).sum()
        entropy = entropy / (offdiag.sum() * len(batch.action)).clamp_min(1.0)
        total = (
            state_loss_weight * state_loss
            + state_mse_loss_weight * state_mse_loss
            + reward_loss_weight * reward_loss
            + done_loss_weight * done_loss
            + feasibility_loss_weight * feasibility_loss
            + sparsity_weight * sparsity
            + parent_budget_weight * parent_budget_loss
            + action_gate_regularization * action_gate_loss
            + edge_entropy_weight * entropy
        )
        parts = {
            "loss": total.detach(),
            "state_loss": state_loss.detach(),
            "state_mse_loss": state_mse_loss.detach(),
            "reward_loss": reward_loss.detach(),
            "done_loss": done_loss.detach(),
            "feasibility_loss": feasibility_loss.detach(),
            "sparsity": sparsity.detach(),
            "parent_budget_loss": parent_budget_loss.detach(),
            "mean_parent_count": parent_counts.mean().detach(),
            "action_gate_regularization": action_gate_loss.detach(),
            "edge_entropy": entropy.detach(),
        }
        return total, parts


class EnsembleWorldModel(nn.Module):
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        hidden_dim: int = 96,
        ensemble_size: int = 5,
        edge_temperature: float = 0.5,
        edge_init_logit: float = -0.5,
        hard_concrete_gates: bool = True,
        hard_concrete_gamma: float = -0.1,
        hard_concrete_zeta: float = 1.1,
        dense_graph: bool = False,
        action_conditioned_gates: bool = True,
        context_dim: int = 0,
        context_hidden_dim: int = 32,
        context_gate_scale: float = 2.0,
    ) -> None:
        super().__init__()
        self.state_dim = int(state_dim)
        self.action_dim = int(action_dim)
        self.context_dim = int(context_dim)
        self.members = nn.ModuleList(
            [
                RelationalCausalWorldModel(
                    state_dim,
                    action_dim,
                    hidden_dim,
                    edge_temperature,
                    edge_init_logit,
                    hard_concrete_gates,
                    hard_concrete_gamma,
                    hard_concrete_zeta,
                    dense_graph,
                    action_conditioned_gates,
                    context_dim,
                    context_hidden_dim,
                    context_gate_scale,
                )
                for _ in range(ensemble_size)
            ]
        )

    def set_context(self, context: Tensor | None) -> None:
        for member in self.members:
            member.set_context(context)

    @property
    def ensemble_size(self) -> int:
        return len(self.members)

    def adjacency(self) -> Tensor:
        return torch.stack([member.adjacency(sample=False) for member in self.members]).mean(0)

    def adjacency_by_action(self) -> Tensor:
        return torch.stack(
            [member.adjacency_by_action(sample=False) for member in self.members]
        ).mean(0)

    def predict_members(self, state: Tensor, action: Tensor, context: Tensor | None = None) -> tuple[Tensor, Tensor, Tensor, Tensor]:
        outputs = [member(state, action, sample_edges=False, context=context) for member in self.members]
        next_states = torch.stack([output.next_mean for output in outputs])
        rewards = torch.stack([output.reward_mean for output in outputs])
        dones = torch.stack([torch.sigmoid(output.done_logit) for output in outputs])
        aleatoric = torch.stack([torch.exp(output.next_logvar) for output in outputs])
        return next_states, rewards, dones, aleatoric

    def predict_validity_members(self, state: Tensor) -> Tensor:
        if state.ndim == 1:
            state = state.unsqueeze(0)
        return torch.stack(
            [torch.sigmoid(member.validity_head(state)) for member in self.members]
        )

    @torch.no_grad()
    def prediction_error(self, batch: TransitionBatch) -> Tensor:
        node_errors = []
        for member in self.members:
            output = member(batch.state, batch.action, sample_edges=False, context=batch.context)
            node_errors.append(member.node_nll(output, batch.next_state))
        return torch.stack(node_errors).mean((0, 1))

    def loss(self, batch: TransitionBatch, node_mask: Tensor | None = None, **weights: float):
        losses = []
        parts: dict[str, list[Tensor]] = {}
        for member in self.members:
            loss, member_parts = member.loss(batch, node_mask=node_mask, **weights)
            losses.append(loss)
            for key, value in member_parts.items():
                parts.setdefault(key, []).append(value)
        total = torch.stack(losses).mean()
        averaged = {key: torch.stack(values).mean() for key, values in parts.items()}
        averaged["loss"] = total.detach()
        return total, averaged

    def incoming_parameters(self, affected_nodes: Iterable[int]) -> list[nn.Parameter]:
        affected = set(int(i) for i in affected_nodes)
        params: list[nn.Parameter] = []
        for member in self.members:
            params.append(member.edge_logits)
            if member.action_edge_logits is not None:
                params.append(member.action_edge_logits)
            for child in affected:
                params.extend(member.self_mechanisms[child].parameters())
                params.extend(member.node_heads[child].parameters())
                if member.context_dim:
                    params.extend(member.context_encoders[child].parameters())
            # Shared action embeddings are frozen during local repair.
            # Updating them would change every child, including unaffected ones.
        return params
