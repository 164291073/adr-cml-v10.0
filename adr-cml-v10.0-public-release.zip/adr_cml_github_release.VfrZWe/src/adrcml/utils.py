from __future__ import annotations

import json
import os
import random
import socket
import time
import uuid
from pathlib import Path
from typing import Any

import numpy as np


class OutputRunLock:
    """Exclusive lock protecting one experiment output directory.

    The lock is deliberately independent of advisory OS locks so it also
    protects runs launched by separate shells.  A random token prevents an old
    process from removing a newer process's lock during interpreter cleanup.
    """

    def __init__(self, output_dir: str | Path, force_stale: bool = False) -> None:
        self.output_dir = Path(output_dir)
        self.path = self.output_dir / ".train.lock"
        self.force_stale = bool(force_stale)
        self.token = uuid.uuid4().hex
        self.acquired = False

    @staticmethod
    def _pid_is_alive(pid: int) -> bool:
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        return True

    @staticmethod
    def _process_start_ticks(pid: int) -> int | None:
        """Linux process start time, used to distinguish PID reuse."""

        try:
            stat = Path(f"/proc/{int(pid)}/stat").read_text(encoding="utf-8")
            # The command name in parentheses may contain spaces. Fields after
            # the final ')' begin at procfs field 3; starttime is field 22.
            fields_after_name = stat[stat.rfind(")") + 2 :].split()
            return int(fields_after_name[19])
        except (OSError, ValueError, IndexError):
            return None

    def _existing_metadata(self) -> dict[str, Any]:
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            return {}

    def acquire(self) -> "OutputRunLock":
        self.output_dir.mkdir(parents=True, exist_ok=True)
        if self.path.exists() and self.force_stale:
            metadata = self._existing_metadata()
            same_host = metadata.get("hostname") == socket.gethostname()
            pid = int(metadata.get("pid", -1))
            recorded_start = metadata.get("process_start_ticks")
            current_start = self._process_start_ticks(pid)
            same_process = (
                recorded_start is None
                or current_start is None
                or int(recorded_start) == current_start
            )
            if same_host and self._pid_is_alive(pid) and same_process:
                raise RuntimeError(
                    f"Refusing to remove active training lock {self.path} "
                    f"owned by PID {pid}."
                )
            self.path.unlink(missing_ok=True)
        payload = {
            "token": self.token,
            "pid": os.getpid(),
            "hostname": socket.gethostname(),
            "process_start_ticks": self._process_start_ticks(os.getpid()),
            "created_unix": time.time(),
        }
        try:
            descriptor = os.open(
                self.path,
                os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                0o600,
            )
        except FileExistsError as error:
            metadata = self._existing_metadata()
            owner = (
                f"PID {metadata.get('pid')} on {metadata.get('hostname')}"
                if metadata
                else "an unknown process"
            )
            raise RuntimeError(
                f"Output directory {self.output_dir} is already locked by {owner}. "
                "Do not start a second run in the same directory. If the old "
                "process has definitely stopped, rerun with --force-stale-lock."
            ) from error
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False)
            handle.flush()
            os.fsync(handle.fileno())
        self.acquired = True
        return self

    def release(self) -> None:
        if not self.acquired:
            return
        metadata = self._existing_metadata()
        if metadata.get("token") == self.token:
            self.path.unlink(missing_ok=True)
        self.acquired = False

    def __enter__(self) -> "OutputRunLock":
        return self.acquire()

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.release()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass


def resolve_device(requested: str) -> str:
    import torch

    requested = requested.strip().lower()
    if requested.startswith("cuda"):
        if not torch.cuda.is_available():
            raise RuntimeError(
                "CUDA was requested but PyTorch cannot access it. Run "
                "`python -m adrcml.device_info --require-cuda` and install a "
                "CUDA-enabled PyTorch wheel before training."
            )
        return requested
    if requested != "auto":
        return requested
    if torch.cuda.is_available():
        return "cuda"
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def configure_torch_runtime(device: str) -> None:
    """Enable safe accelerator defaults without changing model precision."""
    if device.startswith("cuda"):
        import torch

        # On Ampere/Ada GPUs this lets float32 matrix multiplications use TF32
        # where PyTorch considers it appropriate. Parameters and checkpoints
        # remain float32, so no GradScaler or mixed-precision recovery path is
        # required.
        torch.set_float32_matmul_precision("high")


def device_description(device: str) -> str:
    import torch

    if not device.startswith("cuda"):
        return device
    index = torch.cuda.current_device() if device == "cuda" else torch.device(device).index
    index = 0 if index is None else index
    properties = torch.cuda.get_device_properties(index)
    memory_gib = properties.total_memory / (1024**3)
    return f"{device} ({properties.name}, {memory_gib:.1f} GiB)"


def append_jsonl(path: str | Path, record: dict[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def save_json(path: str | Path, data: Any) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.tmp-{os.getpid()}")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, target)
