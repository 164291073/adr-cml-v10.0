from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Mapping

import yaml


@dataclass
class EnvironmentConfig:
    name: str = "mechanism_maze"
    max_steps: int = 64
    shift_step: int = 28
    shift_step_min: int | None = None
    shift_step_max: int | None = None
    shift_mode: str = "random"
    warmup_episodes: int = 0
    observation_noise: float = 0.01
    stochasticity: float = 0.03
    coupled_energy_threshold: float = 0.55
    fragile_energy_threshold: float = 0.35
    draining_artifact_requires_key: bool = True
    # v10 gives every policy the productive shielding action. Legacy access
    # remains available only for explicitly labelled checkpoint comparisons.
    task_action_access: str = "shared_shield"
    environment_profile: str = "train"


@dataclass
class ModelConfig:
    hidden_dim: int = 96
    ensemble_size: int = 5
    edge_temperature: float = 0.5
    edge_init_logit: float = -1.0
    hard_concrete_gates: bool = True
    hard_concrete_gamma: float = -0.1
    hard_concrete_zeta: float = 1.1
    dense_graph: bool = False
    action_conditioned_gates: bool = True
    context_enabled: bool = True
    context_window: int = 8
    context_hidden_dim: int = 32
    context_gate_scale: float = 0.0  # Retired compatibility field: history cannot control gates.
    state_loss_weight: float = 0.1  # Gaussian NLL calibration term.
    state_mse_loss_weight: float = 1.0  # Prediction-mean accuracy is explicit.
    reward_loss_weight: float = 1.0
    done_loss_weight: float = 0.1
    feasibility_loss_weight: float = 0.2
    sparsity_weight: float = 1e-3
    parent_budget: float = 4.0
    parent_budget_weight: float = 0.02
    action_gate_regularization: float = 0.0
    edge_entropy_weight: float = 2e-4
    transition_change_weight: float = 4.0
    sparsity_warmup_steps: int = 2_000
    sparsity_anneal_steps: int = 8_000


@dataclass
class AgentConfig:
    total_steps: int = 100_000
    learning_starts: int = 1_000
    random_steps: int = 2_000
    batch_size: int = 256
    replay_capacity: int = 200_000
    updates_per_step: int = 2
    learning_rate: float = 3e-4
    gradient_clip: float = 10.0
    active_weight: float = 0.25
    active_warmup_steps: int = 2_000
    intervention_probability: float = 0.05
    counterfactual_probe_probability: float = 0.03
    alarm_active_boost: float = 3.0
    exploration_epsilon_start: float = 0.20
    exploration_epsilon_end: float = 0.02
    exploration_decay_steps: int = 20_000
    informative_fraction: float = 0.50
    repair_enabled: bool = True
    diagnosis_enabled: bool = True
    oracle_diagnosis: bool = False
    local_repair: bool = True
    repair_steps: int = 32
    repair_delay_steps: int = 8
    repair_consensus_min_samples: int = 4
    repair_min_train_samples: int = 8
    repair_min_validation_samples: int = 4
    repair_min_target_action_train: int = 2
    repair_min_target_action_validation: int = 1
    repair_retry_interval: int = 4
    repair_max_wait_steps: int = 32
    repair_batch_size: int = 256
    anchor_batch_size: int = 128
    distill_weight: float = 0.5
    repair_validation_fraction: float = 0.25
    repair_min_relative_improvement: float = 0.005
    repair_max_unaffected_degradation: float = 0.01
    detector_skip_active_probes: bool = True


@dataclass
class DetectorConfig:
    warmup: int = 300
    ema_rate: float = 0.02
    drift: float = 0.4
    threshold: float = 8.0
    decay: float = 0.98
    cooldown: int = 8
    localization_ratio: float = 0.8
    max_affected_nodes: int = 0
    localization_window: int = 8
    confirmation_steps: int = 2
    baseline_guard_z: float = 3.0
    score_clip: float = 10.0
    robust_window: int = 256
    robust_min_samples: int = 64
    robust_scale_floor: float = 0.05
    action_conditioned_baseline: bool = True
    action_min_samples: int = 16
    rearm_steps: int = 3
    rearm_z_threshold: float | None = None


@dataclass
class PlannerConfig:
    horizon: int = 16
    population: int = 512
    elites: int = 64
    iterations: int = 5
    discount: float = 0.99
    temperature: float = 0.8
    risk_weight: float = 0.10
    information_cap: float = 0.25
    invalid_action_penalty: float = 1.0


@dataclass
class LoggingConfig:
    log_interval: int = 500
    checkpoint_interval: int = 10_000


@dataclass
class ExperimentConfig:
    seed: int = 2027
    device: str = "auto"
    output_dir: str = "outputs/main"
    environment: EnvironmentConfig = field(default_factory=EnvironmentConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    agent: AgentConfig = field(default_factory=AgentConfig)
    detector: DetectorConfig = field(default_factory=DetectorConfig)
    planner: PlannerConfig = field(default_factory=PlannerConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _merge(base: Dict[str, Any], update: Mapping[str, Any]) -> Dict[str, Any]:
    for key, value in update.items():
        if isinstance(value, Mapping) and isinstance(base.get(key), dict):
            _merge(base[key], value)
        else:
            base[key] = value
    return base


def _construct(
    raw: Mapping[str, Any],
    legacy_missing_hard_concrete: bool = False,
) -> ExperimentConfig:
    model_raw = dict(raw.get("model", {}))
    # v0.5 and earlier checkpoints used ordinary sigmoid gates. Preserve that
    # interpretation during evaluation instead of silently changing their
    # learned model when the new field is absent.
    if legacy_missing_hard_concrete and "hard_concrete_gates" not in model_raw:
        model_raw["hard_concrete_gates"] = False
    return ExperimentConfig(
        seed=int(raw.get("seed", 2027)),
        device=str(raw.get("device", "auto")),
        output_dir=str(raw.get("output_dir", "outputs/main")),
        environment=EnvironmentConfig(**raw.get("environment", {})),
        model=ModelConfig(**model_raw),
        agent=AgentConfig(**raw.get("agent", {})),
        detector=DetectorConfig(**raw.get("detector", {})),
        planner=PlannerConfig(**raw.get("planner", {})),
        logging=LoggingConfig(**raw.get("logging", {})),
    )


def load_config(path: str | Path, override_path: str | Path | None = None) -> ExperimentConfig:
    with Path(path).open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle) or {}
    if override_path is not None:
        with Path(override_path).open("r", encoding="utf-8") as handle:
            override = yaml.safe_load(handle) or {}
        raw = _merge(raw, override)
    return _construct(raw)
