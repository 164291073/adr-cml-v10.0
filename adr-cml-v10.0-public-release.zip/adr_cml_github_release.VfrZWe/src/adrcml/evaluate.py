from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import copy
from dataclasses import asdict
import json
from pathlib import Path
from typing import Any

import numpy as np
import torch

from . import __version__
from .config import _construct
from .envs import make_env
from .envs.mechanism_maze import MechanismMazeEnv
from .metrics import (
    GRAPH_METRIC_METADATA,
    RegimeGraphTracker,
    action_structural_metrics,
    change_detection_metrics,
    node_set_metrics,
    scalar_confidence_intervals,
    structural_metrics,
)
from .provenance import config_hash, file_sha256, source_fingerprint
from .train import build_agent
from .utils import resolve_device, save_json, set_seed


DEFAULT_EVALUATION_MODES = (
    "full",
    "global_repair",
    "matched_active",
    "oracle_repair",
    "diagnose_no_repair",
    "online_only",
    "frozen",
)
EVALUATION_MODES = (*DEFAULT_EVALUATION_MODES, "no_active")
EVALUATION_PROTOCOLS = ("balanced_shift", "random_shift", "no_shift", "natural")


def evaluation_config(
    checkpoint: dict[str, Any], *, environment_profile: str | None = None,
    task_action_access: str | None = None, allow_legacy_checkpoint: bool = False,
):
    """Resolve compatibility explicitly; never silently relabel old action access."""
    version = str(checkpoint.get("software_version", ""))
    legacy = version.startswith("0.9")
    if not version.startswith("10.0") and not (legacy and allow_legacy_checkpoint):
        raise ValueError(
            "v10.0 evaluation requires a v10.0 checkpoint. To audit a v0.9 "
            "checkpoint, explicitly pass --allow-legacy-checkpoint; this defaults "
            "to legacy_probe_only action access and is not a v10 training result."
        )
    raw = copy.deepcopy(checkpoint["config"])
    raw.setdefault("environment", {})
    if legacy:
        raw["environment"].setdefault("task_action_access", "legacy_probe_only")
    if task_action_access is not None:
        raw["environment"]["task_action_access"] = task_action_access
    if environment_profile is not None:
        raw["environment"]["environment_profile"] = environment_profile
    config = _construct(raw)
    if config.environment.task_action_access not in MechanismMazeEnv.task_action_access_modes:
        raise ValueError("Unknown task_action_access")
    if config.environment.environment_profile not in MechanismMazeEnv.environment_profiles:
        raise ValueError("Unknown environment_profile")
    return config


def configure_evaluation_mode(agent, mode: str) -> None:
    """Test-time ablations keep the same environment task-action capabilities."""
    if mode not in EVALUATION_MODES:
        raise ValueError(f"Unknown evaluation mode: {mode}")
    # Truth access is an explicit evaluator mode, never inherited invisibly
    # from a checkpoint's training configuration.
    agent.agent_config.oracle_diagnosis = False
    if mode == "global_repair":
        agent.agent_config.diagnosis_enabled = True
        agent.agent_config.repair_enabled = True
        agent.agent_config.local_repair = False
        agent.repairer.local = False
    elif mode == "diagnose_no_repair":
        agent.agent_config.diagnosis_enabled = True
        agent.agent_config.repair_enabled = False
    elif mode == "oracle_repair":
        agent.agent_config.diagnosis_enabled = False
        agent.agent_config.oracle_diagnosis = False
        agent.agent_config.repair_enabled = True
    elif mode in {"online_only", "matched_active", "frozen"}:
        agent.agent_config.diagnosis_enabled = False
        agent.agent_config.repair_enabled = False
    elif mode == "no_active":
        # Full adaptation minus designed/counterfactual exploration AND the
        # information bonus in actual planner instance. Shielding is unchanged.
        agent.agent_config.intervention_probability = 0.0
        agent.agent_config.counterfactual_probe_probability = 0.0
        agent.agent_config.active_weight = 0.0
        agent.planner.active_weight = 0.0


def balanced_regime_schedule(
    episodes: int,
    regimes: tuple[str, ...] | list[str],
    seed: int,
) -> list[str]:
    """Build a deterministic, nearly equal regime schedule."""

    names = tuple(str(value) for value in regimes)
    if episodes <= 0 or not names:
        raise ValueError("episodes and regimes must be non-empty")
    schedule = [names[index % len(names)] for index in range(int(episodes))]
    np.random.default_rng(seed).shuffle(schedule)
    return schedule



def evaluation_schedule(
    episodes: int,
    regimes: tuple[str, ...] | list[str],
    base_seed: int,
    schedule_seed: int,
    protocol: str,
    eval_shift_step: int = 2,
    eval_shift_min: int = 5,
    eval_shift_max: int = 20,
) -> list[dict[str, Any]]:
    """Prespecify paired task regimes and change times without agent access."""
    if episodes <= 0:
        raise ValueError("episodes must be positive")
    if protocol not in EVALUATION_PROTOCOLS:
        raise ValueError(f"Unknown protocol: {protocol}")
    if protocol in {"balanced_shift", "random_shift"}:
        names: list[str | None] = balanced_regime_schedule(episodes, regimes, schedule_seed)
    elif protocol == "no_shift":
        names = ["none"] * episodes
    else:
        names = [None] * episodes
    if protocol == "random_shift":
        if not 0 < eval_shift_min <= eval_shift_max:
            raise ValueError("random shift bounds must satisfy 0 < min <= max")
        rng = np.random.default_rng(schedule_seed + 1)
        shifts = [int(step) for step in rng.integers(eval_shift_min, eval_shift_max + 1, episodes)]
    elif protocol == "balanced_shift":
        if eval_shift_step <= 0:
            raise ValueError("eval_shift_step must be positive")
        shifts = [int(eval_shift_step)] * episodes
    else:
        shifts = [None] * episodes
    return [
        {
            "episode": index + 1,
            "episode_seed": base_seed + index,
            "protocol": protocol,
            "assigned_regime": names[index],
            "forced_shift_step": shifts[index],
        }
        for index in range(episodes)
    ]


def validate_active_budget(action_kinds: dict[str, int], active_budget: int) -> int:
    """Audit the actual combined probe/intervention count, not just its schedule."""
    count = int(action_kinds.get("counterfactual_probe", 0) + action_kinds.get("designed_intervention", 0))
    if active_budget < 0:
        raise ValueError("active_budget must be non-negative")
    if count > active_budget:
        raise RuntimeError(f"Active action count {count} exceeds cap {active_budget}")
    return count


def _paired_schedule_key(row: dict[str, Any]) -> tuple[Any, ...]:
    return (
        row.get("episode_seed"), row.get("assigned_regime"),
        row.get("protocol"), row.get("forced_shift_step"),
        row.get("environment_profile", "train"),
        row.get("task_action_access", "legacy_probe_only"),
    )


def _graph_delta(before: np.ndarray, after: np.ndarray) -> dict[str, float]:
    mask = ~np.eye(before.shape[-1], dtype=bool)
    differences = (np.asarray(after) - np.asarray(before))[..., mask]
    changes = ((np.asarray(after) >= 0.5) != (np.asarray(before) >= 0.5))[..., mask]
    return {
        "mean_absolute_probability_change": float(np.abs(differences).mean()),
        "max_absolute_probability_change": float(np.abs(differences).max(initial=0.0)),
        "threshold_edge_changes": int(changes.sum()),
    }


def _task_metrics_by_regime(records: list[dict[str, Any]]) -> dict[str, Any]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        grouped[str(record["assigned_regime"])].append(record)
    result: dict[str, Any] = {}
    for regime, rows in sorted(grouped.items()):
        returns = [float(row["return"]) for row in rows]
        successes = [float(row["success"]) for row in rows]
        metrics = {
            "episodes": len(rows),
            "mean_return": float(np.mean(returns)),
            "success_rate": float(np.mean(successes)),
            "mean_length": float(np.mean([row["length"] for row in rows])),
            "experienced_shift_rate": float(
                np.mean([row["experienced_shift"] for row in rows])
            ),
            "mechanism_activation_rate": float(
                np.mean([row.get("mechanism_activated", False) for row in rows])
            ),
            "mean_alarm_count": float(
                np.mean([row.get("alarm_count", 0) for row in rows])
            ),
            "mean_active_actions": float(
                np.mean(
                    [
                        row.get("action_kinds", {}).get("counterfactual_probe", 0)
                        + row.get("action_kinds", {}).get("designed_intervention", 0)
                        for row in rows
                    ]
                )
            ),
            "repair_attempts": int(
                sum(row.get("repair_attempts", 0) for row in rows)
            ),
            "accepted_repairs": int(
                sum(row.get("accepted_repairs", 0) for row in rows)
            ),
        }
        metrics.update(scalar_confidence_intervals(returns, successes))
        result[regime] = metrics
    return result



def _diagnosis_metrics_by_regime(records: list[dict[str, Any]]) -> dict[str, Any]:
    """Report localization by assigned task with explicit eligible denominators.

    Unactivated episodes never contribute synthetic zero diagnosis scores.
    Accepted-repair localization is a post-hoc episode-union proxy only; it
    does not assert that a particular event was correctly repaired.
    """
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in records:
        grouped[str(row["assigned_regime"])].append(row)
    result: dict[str, Any] = {}
    base_metrics = ("diagnosis_precision", "diagnosis_recall", "diagnosis_f1", "diagnosis_exact")
    for regime, rows in sorted(grouped.items()):
        activated = [row for row in rows if row.get("mechanism_activated", False)]
        summary: dict[str, Any] = {
            "episodes": len(rows),
            "mechanism_activated_episodes": len(activated),
            "diagnosis_evaluated_episodes": sum("diagnosis_f1" in row for row in activated),
            "first_diagnosis_evaluated_episodes": sum("first_diagnosis_f1" in row for row in activated),
            "consensus_diagnosis_evaluated_episodes": sum("consensus_diagnosis_f1" in row for row in activated),
        }
        for prefix in ("", "first_", "consensus_"):
            for name in base_metrics:
                key = prefix + name
                values = [float(row[key]) for row in activated if key in row and row[key] is not None]
                if values:
                    summary[key] = float(np.mean(values))
        accepted_proxy = [
            node_set_metrics(record.get("affected_nodes", []), row.get("activated_affected_nodes", []))
            for row in activated
            for record in row.get("repair_records", [])
            if record.get("applied", False)
        ]
        repair: dict[str, Any] = {
            "attempts": sum(int(row.get("repair_attempts", 0)) for row in rows),
            "accepted": sum(int(row.get("accepted_repairs", 0)) for row in rows),
            "rejected": sum(int(row.get("rejected_repairs", 0)) for row in rows),
            "skip_reasons": dict(Counter(
                str(record["skip_reason"])
                for row in rows for record in row.get("repair_records", [])
                if record.get("skip_reason")
            )),
            "accepted_repair_episode_union_proxy_records": len(accepted_proxy),
            "proxy_interpretation": "posthoc_node_overlap_with_episode_activated_union_not_event_correctness",
        }
        if accepted_proxy:
            repair["accepted_repair_episode_union_proxy"] = {
                name: float(np.mean([record[name] for record in accepted_proxy]))
                for name in base_metrics
            }
        summary["repair"] = repair
        result[regime] = summary
    return result


def evaluate(
    checkpoint_path: str,
    episodes: int = 100,
    online_adapt: bool | None = None,
    mode: str | None = None,
    protocol: str = "balanced_shift",
    eval_shift_step: int = 2,
    schedule_seed: int | None = None,
    device: str | None = None,
    reset_agent_each_episode: bool = True,
    matched_alarm_schedule: str | None = None,
    active_budget: int = 3,
    eval_shift_min: int = 5,
    eval_shift_max: int = 20,
    output_dir: str | None = None,
    environment_profile: str | None = None,
    task_action_access: str | None = None,
    allow_legacy_checkpoint: bool = False,
) -> dict[str, Any]:
    if mode is None:
        mode = "full" if online_adapt is not False else "frozen"
    if mode not in EVALUATION_MODES:
        raise ValueError(f"mode must be one of {EVALUATION_MODES}")
    if protocol not in EVALUATION_PROTOCOLS:
        raise ValueError(f"protocol must be one of {EVALUATION_PROTOCOLS}")

    if episodes <= 0 or active_budget < 0:
        raise ValueError("episodes must be positive and active_budget non-negative")

    parent = Path(output_dir) if output_dir is not None else Path(checkpoint_path).parent
    parent.mkdir(parents=True, exist_ok=True)
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    config = evaluation_config(
        checkpoint, environment_profile=environment_profile,
        task_action_access=task_action_access,
        allow_legacy_checkpoint=allow_legacy_checkpoint,
    )
    config.device = resolve_device(config.device if device is None else device)
    config.environment.warmup_episodes = 0
    base_seed = config.seed + 10_000
    schedule_seed = config.seed + 20_000 if schedule_seed is None else int(schedule_seed)
    set_seed(base_seed)
    env = make_env(**asdict(config.environment), seed=base_seed)
    agent = build_agent(config, env.state_dim, env.action_dim)
    agent.load_checkpoint(copy.deepcopy(checkpoint), load_optimizer=mode != "frozen")
    configure_evaluation_mode(agent, mode)
    if mode == "no_active" and config.environment.task_action_access != "shared_shield":
        raise ValueError("no_active requires shared_shield task action access for a fair ablation")

    schedule_records = evaluation_schedule(
        episodes, tuple(getattr(env, "shift_modes", ())), base_seed, schedule_seed,
        protocol, eval_shift_step, eval_shift_min, eval_shift_max,
    )
    for row in schedule_records:
        row["environment_profile"] = config.environment.environment_profile
        row["task_action_access"] = config.environment.task_action_access
        shift = row["forced_shift_step"]
        if shift is not None and shift >= config.environment.max_steps:
            raise ValueError("Evaluation change times must lie inside the episode")

    replayed_alarm_schedule: list[set[int]] = [set() for _ in range(episodes)]
    if mode == "matched_active":
        schedule_path = Path(matched_alarm_schedule) if matched_alarm_schedule else (
            parent / "evaluation_full_episodes.json"
        )
        if not schedule_path.exists():
            raise FileNotFoundError(
                "matched_active requires a completed full evaluation; missing "
                f"{schedule_path}"
            )
        full_records = json.loads(schedule_path.read_text(encoding="utf-8"))
        if len(full_records) != episodes:
            raise ValueError("matched alarm schedule episode count does not match")
        for index, (expected, source) in enumerate(zip(schedule_records, full_records)):
            # Natural schedules are resolved by the environment at reset.
            expected_key = _paired_schedule_key(expected)
            source_key = _paired_schedule_key(source)
            if protocol == "natural":
                expected_key = (
                    expected["episode_seed"], source.get("assigned_regime"), protocol, None,
                    expected["environment_profile"], expected["task_action_access"],
                )
            if source_key != expected_key:
                raise ValueError("matched alarm schedule is not paired with this evaluation")
            if source.get("active_budget_per_episode") != active_budget:
                raise ValueError("matched alarm schedule uses a different active budget")
            replayed_alarm_schedule[index] = {
                int(step) for step in source.get("alarm_local_steps", [])
            }

    returns: list[float] = []
    successes: list[float] = []
    post_shift_returns: list[float] = []
    shifted_successes: list[float] = []
    alarm_steps: list[int] = []
    change_windows: list[tuple[int, int, int]] = []
    evaluation_step = int(agent.total_observations)
    graph_tracker = RegimeGraphTracker(window=episodes)
    action_graph_records: dict[str, list[dict[str, float]]] = defaultdict(list)
    action_graph_by_action_records: dict[str, list[dict[str, Any]]] = defaultdict(list)
    action_graph_targets: dict[str, np.ndarray] = {}
    action_graph_predictions: dict[str, np.ndarray] = {}
    diagnosis_records: list[dict[str, float]] = []
    first_diagnosis_records: list[dict[str, float]] = []
    consensus_diagnosis_records: list[dict[str, float]] = []
    episode_records: list[dict[str, Any]] = []
    action_kind_totals: dict[str, int] = {}
    repair_attempts = 0
    accepted_repairs = 0
    rejected_repairs = 0
    graph_locality: list[float] = []
    mechanism_activated_episodes = 0

    for episode in range(episodes):
        episode_seed = base_seed + episode
        if reset_agent_each_episode:
            agent.load_checkpoint(copy.deepcopy(checkpoint), load_optimizer=mode != "frozen")
        agent.reseed(episode_seed + 50_000)
        torch.manual_seed(episode_seed + 60_000)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(episode_seed + 60_000)
        options = None
        schedule = schedule_records[episode]
        if protocol in {"balanced_shift", "random_shift"}:
            options = {
                "shift_mode": schedule["assigned_regime"],
                "shift_step": schedule["forced_shift_step"],
            }
        elif protocol == "no_shift":
            options = {"shift_mode": "none"}
        if options is None:
            state, info = env.reset(seed=episode_seed)
        else:
            state, info = env.reset(seed=episode_seed, options=options)
        assigned_regime = str(
            info.get("assigned_regime", info.get("shift_mode", "unknown"))
        )
        agent.on_episode_reset()
        agent.set_active_budget(active_budget)
        schedule_records[episode]["assigned_regime"] = assigned_regime
        initial_action_graph = agent.model.adjacency_by_action().detach().cpu().numpy().copy()
        activation_action_graph: np.ndarray | None = None
        total_reward = 0.0
        pre_shift_return = 0.0
        post_shift_return = 0.0
        episode_start = evaluation_step + 1
        shift_global: int | None = None
        activation_global: int | None = None
        true_affected: list[int] | None = None
        activated_affected: list[int] = []
        first_predicted: list[int] | None = None
        repair_predicted: list[int] | None = None
        localization_evidence = np.zeros(env.state_dim, dtype=np.float64)
        action_kinds: dict[str, int] = {}
        executed_action_counts = np.zeros(env.action_dim, dtype=np.int64)
        episode_alarm_count = 0
        episode_alarm_local_steps: list[int] = []
        episode_repair_attempts = 0
        episode_accepted_repairs = 0
        episode_rejected_repairs = 0
        repair_graph_locality: float | None = None
        episode_repair_records: list[dict[str, Any]] = []

        for local_step in range(config.environment.max_steps):
            evaluation_step += 1
            local_step_number = local_step + 1
            if (
                mode == "matched_active"
                # A full-mode alarm is observed after executing step t, so its
                # exploration boost starts at t+1. Replay that causal timing.
                and (local_step_number - 1) in replayed_alarm_schedule[episode]
            ):
                agent.trigger_active_boost()
                alarm_steps.append(evaluation_step)
                episode_alarm_count += 1
                episode_alarm_local_steps.append(local_step_number)
            action = agent.act(
                state,
                info.get("valid_action_mask"),
                info.get("task_action_mask"),
                info.get("intervention_action_mask"),
            )
            action_kind = agent.last_action_kind
            executed_action_counts[int(action)] += 1
            action_kinds[action_kind] = action_kinds.get(action_kind, 0) + 1
            action_kind_totals[action_kind] = action_kind_totals.get(action_kind, 0) + 1
            next_state, reward, terminated, truncated, next_info = env.step(action)
            done = terminated or truncated
            if next_info.get("shift_event"):
                shift_global = evaluation_step
                before_graph = info.get("true_adjacency")
                after_graph = next_info.get("true_adjacency")
                if before_graph is not None and after_graph is not None:
                    true_affected = np.flatnonzero(
                        np.any(before_graph != after_graph, axis=0)
                    ).astype(int).tolist()
            if next_info.get("mechanism_event") and activation_global is None:
                activation_global = evaluation_step
                # Snapshot before learning from the first observable changed transition.
                activation_action_graph = agent.model.adjacency_by_action().detach().cpu().numpy().copy()
            if next_info.get("mechanism_event"):
                activated_affected = sorted(
                    set(activated_affected).union(
                        next_info.get("mechanism_nodes", [])
                    )
                )

            report = None
            if mode == "frozen":
                # Frozen weights still consume observed history: context is an
                # input, not an online parameter update.
                agent.observe_context_only(state, action, reward, next_state)
            else:
                report = agent.observe(
                    state,
                    action,
                    reward,
                    next_state,
                    done,
                    step=evaluation_step,
                    valid_action_mask=info.get("valid_action_mask"),
                )
                step_repair_reports = [copy.deepcopy(report.repair)] if report.repair else []
                if mode == "oracle_repair" and next_info.get("mechanism_event", False):
                    affected = [int(value) for value in next_info.get("mechanism_nodes", [])]
                    if affected:
                        forced = agent.force_repair(affected, step=evaluation_step)
                        if forced:
                            step_repair_reports.append(copy.deepcopy(forced))
                        if forced.get("queued", False):
                            report.alarm = True
                            report.affected_nodes = list(forced["affected_nodes"])
                            report.repair = forced

                if activation_global is not None and report.localization_scores is not None:
                    scores = np.asarray(report.localization_scores, dtype=np.float64)
                    maximum = float(scores.max(initial=0.0))
                    if maximum > 0:
                        localization_evidence += scores / maximum
                if report.alarm:
                    alarm_steps.append(evaluation_step)
                    episode_alarm_count += 1
                    episode_alarm_local_steps.append(local_step_number)
                    if activation_global is not None and first_predicted is None:
                        first_predicted = list(report.affected_nodes or [])
                for repair_record in step_repair_reports:
                    episode_repair_records.append({
                        "local_step": local_step_number,
                        "evaluation_step": evaluation_step,
                        "observed_action": int(action),
                        **repair_record,
                    })
                    if int(repair_record.get("steps", 0)) <= 0 and not repair_record.get("attempted", False):
                        continue
                    repair_attempts += 1
                    episode_repair_attempts += 1
                    if repair_record.get("applied"):
                        accepted_repairs += 1
                        episode_accepted_repairs += 1
                        if shift_global is not None and repair_predicted is None:
                            repair_predicted = list(repair_record.get("affected_nodes", []))
                        if repair_graph_locality is None:
                            repair_graph_locality = float(repair_record.get("graph_locality", 0.0))
                            graph_locality.append(repair_graph_locality)
                    elif repair_record.get("rejected"):
                        rejected_repairs += 1
                        episode_rejected_repairs += 1

            if shift_global is None:
                pre_shift_return += reward
            else:
                post_shift_return += reward
            total_reward += reward
            state, info = next_state, next_info
            if done:
                break

        success = float(info.get("success", False))
        experienced_shift = shift_global is not None
        returns.append(total_reward)
        successes.append(success)
        if experienced_shift:
            post_shift_returns.append(post_shift_return)
            shifted_successes.append(success)
        if activation_global is not None:
            mechanism_activated_episodes += 1
            change_windows.append(
                (episode_start, int(activation_global), evaluation_step)
            )

        learned_episode = agent.model.adjacency().detach().cpu().numpy()
        true_episode = info.get("true_adjacency")
        graph_regime = str(info.get("regime", assigned_regime))
        graph_episode: dict[str, float] = {}
        if true_episode is not None:
            graph_tracker.update(graph_regime, learned_episode, true_episode)
            graph_episode = structural_metrics(learned_episode, true_episode)
        true_action_episode = info.get("true_adjacency_by_action")
        action_graph_episode: dict[str, float] = {}
        action_metrics: dict[str, Any] = {}
        learned_action_episode = agent.model.adjacency_by_action().detach().cpu().numpy()
        if true_action_episode is not None:
            action_metrics = action_structural_metrics(
                learned_action_episode,
                true_action_episode,
            )
            action_graph_episode = {
                f"action_{key}": float(value)
                for key, value in action_metrics["macro"].items()
            }
            action_graph_records[graph_regime].append(
                dict(action_metrics["macro"])
            )
            action_graph_by_action_records[graph_regime].append(action_metrics["by_action"])
            action_graph_targets[graph_regime] = np.asarray(
                true_action_episode,
                dtype=np.float32,
            ).copy()
            action_graph_predictions[graph_regime] = learned_action_episode.copy()

        consensus_predicted = agent.detector.select_affected(localization_evidence)
        primary_predicted = repair_predicted or consensus_predicted
        diagnosis_episode: dict[str, float] = {}
        first_diagnosis_episode: dict[str, float] = {}
        consensus_diagnosis_episode: dict[str, float] = {}
        if (
            true_affected is not None
            and activation_global is not None
            and mode != "frozen"
            and agent.agent_config.diagnosis_enabled
        ):
            diagnosis_episode = node_set_metrics(
                primary_predicted, activated_affected
            )
            first_diagnosis_episode = node_set_metrics(
                first_predicted or [], activated_affected
            )
            consensus_diagnosis_episode = node_set_metrics(
                consensus_predicted, activated_affected
            )
            diagnosis_records.append(diagnosis_episode)
            first_diagnosis_records.append(first_diagnosis_episode)
            consensus_diagnosis_records.append(consensus_diagnosis_episode)

        actual_active_actions = validate_active_budget(action_kinds, active_budget)
        episode_records.append(
            {
                "episode": episode + 1,
                "episode_seed": episode_seed,
                "environment_profile": info.get("environment_profile", "train"),
                "mechanism_parameters": info.get("mechanism_parameters", {}),
                "task_action_access": config.environment.task_action_access,
                "protocol": protocol,
                "forced_shift_step": schedule["forced_shift_step"],
                "assigned_regime": assigned_regime,
                "final_regime": info.get("regime", "unknown"),
                "experienced_shift": experienced_shift,
                "return": total_reward,
                "pre_shift_return": pre_shift_return,
                "post_shift_return": post_shift_return,
                "success": bool(success),
                "length": local_step + 1,
                "shift_step": shift_global,
                "mechanism_activation_step": activation_global,
                "mechanism_activated": activation_global is not None,
                "alarm_count": episode_alarm_count,
                "alarm_local_steps": episode_alarm_local_steps,
                "repair_attempts": episode_repair_attempts,
                "accepted_repairs": episode_accepted_repairs,
                "rejected_repairs": episode_rejected_repairs,
                "action_kinds": action_kinds,
                "action_counts": executed_action_counts.tolist(),
                "productive_shield_actions": int(executed_action_counts[9]),
                "information_probe_actions": int(executed_action_counts[8]),
                "true_affected_nodes": true_affected,
                "activated_affected_nodes": activated_affected,
                "first_predicted_affected_nodes": first_predicted,
                "consensus_predicted_affected_nodes": consensus_predicted,
                "repair_predicted_affected_nodes": repair_predicted,
                "predicted_affected_nodes": primary_predicted,
                "repair_graph_locality": repair_graph_locality,
                "repair_records": episode_repair_records,
                "pending_repairs_at_end": len(agent.pending_repairs),
                "graph_evaluation_regime": graph_regime,
                "active_budget_per_episode": active_budget,
                "active_action_count": actual_active_actions,
                "active_budget_utilization": actual_active_actions / active_budget if active_budget else 0.0,
                "action_graph_by_action": action_metrics.get("by_action", {}),
                "action_graph_delta_start_to_end": _graph_delta(initial_action_graph, learned_action_episode),
                "action_graph_delta_activation_to_end": (
                    _graph_delta(activation_action_graph, learned_action_episode)
                    if activation_action_graph is not None else None
                ),
                **diagnosis_episode,
                **{f"first_{key}": value for key, value in first_diagnosis_episode.items()},
                **{
                    f"consensus_{key}": value
                    for key, value in consensus_diagnosis_episode.items()
                },
                **graph_episode,
                **action_graph_episode,
            }
        )

    learned = agent.model.adjacency().detach().cpu().numpy()
    graph_summary = graph_tracker.summary()
    action_graph_by_regime: dict[str, dict[str, float]] = {}
    for regime, records in sorted(action_graph_records.items()):
        keys = records[0].keys() if records else []
        action_graph_by_regime[regime] = {
            key: float(np.mean([record[key] for record in records]))
            for key in keys
        }
        action_graph_by_regime[regime]["episodes"] = float(len(records))
    action_metric_keys = [
        key
        for metrics in action_graph_by_regime.values()
        for key in metrics
        if key != "episodes"
    ]
    action_graph_macro = {
        key: float(
            np.mean(
                [metrics[key] for metrics in action_graph_by_regime.values() if key in metrics]
            )
        )
        for key in sorted(set(action_metric_keys))
    }
    per_action_by_regime: dict[str, Any] = {}
    for regime, records in action_graph_by_action_records.items():
        per_action_by_regime[regime] = {
            action: {
                key: float(np.mean([record[action][key] for record in records]))
                for key in records[0][action]
            }
            for action in records[0]
        }
    union_graph = graph_tracker.union_target()
    result: dict[str, Any] = {
        "software_version": __version__,
        "checkpoint_software_version": checkpoint.get("software_version", "legacy"),
        "checkpoint_sha256": file_sha256(checkpoint_path),
        "checkpoint_config_hash": config_hash(checkpoint["config"]),
        "evaluation_config_hash": config_hash(config),
        "source_fingerprint": source_fingerprint(),
        "checkpoint_source_fingerprint": checkpoint.get("source_hash", checkpoint.get("source_fingerprint")),
        "model_dense_graph": bool(config.model.dense_graph),
        "training_used_oracle_diagnosis": bool(checkpoint["config"].get("agent", {}).get("oracle_diagnosis", False)),
        "seed": config.seed,
        "episodes": episodes,
        "mode": mode,
        "protocol": protocol,
        "environment_profile": config.environment.environment_profile,
        "environment_profile_interpretation": "known_mechanism_family_parameter_shift" if config.environment.environment_profile == "heldout_v1" else "configured_training_parameters",
        "environment_profile_ranges": MechanismMazeEnv.heldout_parameter_ranges if config.environment.environment_profile == "heldout_v1" else None,
        "task_action_access": config.environment.task_action_access,
        "checkpoint_compatibility": "legacy_v09_explicit_evaluation" if str(checkpoint.get("software_version", "")).startswith("0.9") else "native_v10",
        "training_environment_profile": checkpoint["config"].get("environment", {}).get("environment_profile", "train"),
        "productive_shield_action": 9,
        "information_probe_actions": [8],
        "productive_shield_action_count": sum(row["productive_shield_actions"] for row in episode_records),
        "information_probe_action_count": sum(row["information_probe_actions"] for row in episode_records),
        "task_action_mask": env.task_action_mask.tolist(),
        "intervention_action_mask": env.intervention_action_mask.tolist(),
        "public_action_mask_source": "noise_free_simulator_base_prerequisites_without_hidden_regime_thresholds",
        "active_exploration_enabled": mode != "no_active",
        "planner_information_weight": agent.planner.active_weight,
        "eval_shift_step": eval_shift_step if protocol == "balanced_shift" else None,
        "schedule_seed": schedule_seed,
        "eval_shift_min": eval_shift_min if protocol == "random_shift" else None,
        "eval_shift_max": eval_shift_max if protocol == "random_shift" else None,
        "active_budget_per_episode": active_budget,
        "active_budget_protocol": "equal_maximum_allowance",
        "matched_active_protocol": "replayed_alarm_boost_timing" if mode == "matched_active" else None,
        "active_budget_utilization": float(np.mean([row["active_budget_utilization"] for row in episode_records])),
        "confidence_interval_unit": "evaluation_episodes_conditional_on_one_training_seed",
        "repair_skip_reasons": dict(Counter(
            str(record["skip_reason"])
            for row in episode_records for record in row["repair_records"]
            if record.get("skip_reason")
        )),
        "online_adapt": mode != "frozen",
        "reset_agent_each_episode": bool(reset_agent_each_episode),
        "diagnosis_enabled": bool(mode != "frozen" and agent.agent_config.diagnosis_enabled),
        "repair_enabled": bool(mode != "frozen" and agent.agent_config.repair_enabled),
        "local_repair": agent.repairer.local,
        "oracle_repair": bool(mode == "oracle_repair"),
        "oracle_control_interpretation": "observable_activation_node_localization_not_guaranteed_task_upper_bound",
        "graph_snapshot_aggregation": "last_episode_per_actual_final_regime",
        "mean_return": float(np.mean(returns)),
        "std_return": float(np.std(returns)),
        "success_rate": float(np.mean(successes)),
        "experienced_shift_episodes": int(
            sum(row["experienced_shift"] for row in episode_records)
        ),
        "experienced_shift_rate": float(
            np.mean([row["experienced_shift"] for row in episode_records])
        ),
        "mechanism_activated_episodes": mechanism_activated_episodes,
        "mechanism_activation_rate": mechanism_activated_episodes / max(episodes, 1),
        "detection_target": "first_observable_changed_mechanism_activation",
        "mean_post_shift_return": (
            float(np.mean(post_shift_returns)) if post_shift_returns else 0.0
        ),
        "post_shift_success_rate": (
            float(np.mean(shifted_successes)) if shifted_successes else 0.0
        ),
        "assigned_regime_counts": dict(
            Counter(row["assigned_regime"] for row in episode_records)
        ),
        "task_by_regime": _task_metrics_by_regime(episode_records),
        "diagnosis_by_regime": _diagnosis_metrics_by_regime(episode_records),
        "alarms": len(alarm_steps),
        "action_kinds": action_kind_totals,
        "active_action_count": int(
            action_kind_totals.get("counterfactual_probe", 0)
            + action_kind_totals.get("designed_intervention", 0)
        ),
        "active_actions_per_episode": float(
            (
                action_kind_totals.get("counterfactual_probe", 0)
                + action_kind_totals.get("designed_intervention", 0)
            )
            / max(episodes, 1)
        ),
        "active_action_rate": float(
            (
                action_kind_totals.get("counterfactual_probe", 0)
                + action_kind_totals.get("designed_intervention", 0)
            )
            / max(sum(action_kind_totals.values()), 1)
        ),
        "pending_repairs_at_episode_end": sum(row["pending_repairs_at_end"] for row in episode_records),
        "repair_attempts": repair_attempts,
        "accepted_repairs": accepted_repairs,
        "rejected_repairs": rejected_repairs,
        "mean_repair_graph_locality": (
            float(np.mean(graph_locality)) if graph_locality else 0.0
        ),
    }
    result.update(scalar_confidence_intervals(returns, successes))
    if mode in {"full", "global_repair", "diagnose_no_repair", "no_active"}:
        result.update(
            change_detection_metrics(
                change_windows,
                alarm_steps,
                max(1, evaluation_step - int(checkpoint.get("total_observations", 0))),
            )
        )

    def add_diagnosis(prefix: str, records: list[dict[str, float]]) -> None:
        if not records:
            return
        for key in (
            "diagnosis_precision",
            "diagnosis_recall",
            "diagnosis_f1",
            "diagnosis_exact",
        ):
            output_key = key if not prefix else f"{prefix}_{key}"
            result[output_key] = float(np.mean([record[key] for record in records]))

    add_diagnosis("", diagnosis_records)
    add_diagnosis("first", first_diagnosis_records)
    add_diagnosis("consensus", consensus_diagnosis_records)
    if diagnosis_records:
        result["diagnosis_target"] = (
            "activated_changed_children_using_repair_nodes_or_window_consensus"
        )
    if union_graph is not None:
        result.update(structural_metrics(learned, union_graph))
        result["graph_target"] = "union_of_observed_evaluation_regimes"
        result["graph_prediction"] = "final_episode_parameter_snapshot_not_union_of_models_across_episodes"
        result["graph_comparison_interpretation"] = "single_final_snapshot_versus_target_union; use graph_aligned and action_graph_aligned for regime-matched recovery"
    result["graph_target_definition"] = "observable_action_transition_dependency_proxy"
    result["graph_metric_metadata"] = dict(GRAPH_METRIC_METADATA)
    result["graph_interpretation"] = "action_conditioned_parent_gates_cover_current_and_history_inputs; hidden-latch edges are proxy annotations"
    result["graph_aligned"] = graph_summary
    result["action_graph_aligned"] = {
        "macro": action_graph_macro,
        "by_regime": action_graph_by_regime,
        "by_regime_and_action": per_action_by_regime,
    }

    save_json(parent / "evaluation_schedule.json", schedule_records)
    save_json(parent / f"evaluation_{mode}.json", result)
    save_json(parent / f"evaluation_{mode}_episodes.json", episode_records)
    np.save(parent / f"learned_adjacency_evaluation_{mode}.npy", learned)
    if mode == "full" and action_graph_targets:
        np.savez(
            parent / "true_adjacency_by_action_by_regime.npz",
            **action_graph_targets,
        )
        np.savez(
            parent / "learned_adjacency_by_action_by_regime.npz",
            **action_graph_predictions,
        )
    if mode == "full":
        save_json(parent / "evaluation.json", result)
        save_json(parent / "evaluation_online.json", result)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate an ADR-CML checkpoint")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output-dir", default=None, help="Optional isolated evaluation output directory")
    parser.add_argument("--episodes", type=int, default=100)
    parser.add_argument("--environment-profile", choices=MechanismMazeEnv.environment_profiles, default=None)
    parser.add_argument("--task-action-access", choices=MechanismMazeEnv.task_action_access_modes, default=None)
    parser.add_argument("--allow-legacy-checkpoint", action="store_true",
                        help="Explicit v0.9 audit; preserves old action access unless separately overridden")
    parser.add_argument(
        "--mode",
        choices=EVALUATION_MODES,
        default="full",
        help="Adaptation mode used during evaluation",
    )
    parser.add_argument(
        "--protocol",
        choices=EVALUATION_PROTOCOLS,
        default="balanced_shift",
        help="balanced_shift forces the same assigned mechanisms in every mode",
    )
    parser.add_argument("--eval-shift-step", type=int, default=2)
    parser.add_argument("--eval-shift-min", type=int, default=5)
    parser.add_argument("--eval-shift-max", type=int, default=20)
    parser.add_argument("--active-budget", type=int, default=3,
                        help="Maximum total designed and counterfactual actions per episode")
    parser.add_argument("--schedule-seed", type=int, default=None)
    parser.add_argument(
        "--continual-eval",
        action="store_true",
        help="Keep adaptations across evaluation episodes instead of resetting the checkpoint",
    )
    parser.add_argument(
        "--matched-alarm-schedule",
        default=None,
        help="Optional full-mode episode JSON used by matched_active",
    )
    parser.add_argument(
        "--device",
        choices=["auto", "cpu", "cuda", "mps"],
        default=None,
        help="Optional evaluation-only device override",
    )
    parser.add_argument(
        "--frozen", action="store_true", help="Backward-compatible frozen mode"
    )
    args = parser.parse_args()
    mode = "frozen" if args.frozen else args.mode
    result = evaluate(
        args.checkpoint,
        args.episodes,
        mode=mode,
        protocol=args.protocol,
        eval_shift_step=args.eval_shift_step,
        schedule_seed=args.schedule_seed,
        device=args.device,
        reset_agent_each_episode=not args.continual_eval,
        matched_alarm_schedule=args.matched_alarm_schedule,
        active_budget=args.active_budget,
        eval_shift_min=args.eval_shift_min,
        eval_shift_max=args.eval_shift_max,
        output_dir=args.output_dir,
        environment_profile=args.environment_profile,
        task_action_access=args.task_action_access,
        allow_legacy_checkpoint=args.allow_legacy_checkpoint,
    )
    print(result)


if __name__ == "__main__":
    main()
