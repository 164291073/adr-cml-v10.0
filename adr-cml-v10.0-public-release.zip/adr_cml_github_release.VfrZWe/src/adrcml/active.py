from __future__ import annotations

import torch
from torch import Tensor

from .models import EnsembleWorldModel


class ActiveInterventionScorer:
    """Approximate expected information gain using ensemble disagreement.

    The score combines epistemic next-state variance with uncertainty on edges
    entering nodes that an action changes. This is a tractable online proxy for
    mutual information I(theta; s' | s, do(a)).
    """

    def __init__(self, model: EnsembleWorldModel, edge_weight: float = 0.15) -> None:
        self.model = model
        self.edge_weight = float(edge_weight)

    @torch.no_grad()
    def score(self, state: Tensor, actions: Tensor) -> Tensor:
        next_states, rewards, _, aleatoric = self.model.predict_members(state, actions)
        epistemic = next_states.var(dim=0, unbiased=False).mean(dim=-1)
        reward_disagreement = rewards.var(dim=0, unbiased=False)
        total_var = next_states.var(dim=0, unbiased=False) + aleatoric.mean(dim=0)
        signal_to_noise = epistemic / (total_var.mean(dim=-1) + 1e-6)
        adjacency = self.model.adjacency().clamp(1e-6, 1 - 1e-6)
        edge_entropy = -(adjacency * adjacency.log() + (1 - adjacency) * (1 - adjacency).log())
        structural_uncertainty = edge_entropy.mean()
        return signal_to_noise + reward_disagreement + self.edge_weight * structural_uncertainty

