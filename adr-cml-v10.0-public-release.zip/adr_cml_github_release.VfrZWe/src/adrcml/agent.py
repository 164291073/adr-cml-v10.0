from __future__ import annotations

import copy
from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
import torch

from .buffer import ReplayBuffer, TransitionBatch
from .config import AgentConfig, DetectorConfig, ModelConfig, PlannerConfig
from .context import HistoryContext
from .detection import DetectionResult, NodewiseCUSUMDetector
from .models import EnsembleWorldModel
from .planning import CategoricalCEMPlanner
from .repair import LocalMechanismRepair, RepairReport


@dataclass
class ObserveReport:
    alarm: bool = False
    affected_nodes: list[int] | None = None
    detector_score: float = 0.0
    training_loss: float | None = None
    training_metrics: dict[str, float] | None = None
    repair: dict[str, Any] | None = None
    localization_scores: list[float] | None = None


class ADRCMLAgent:
    """The complete Act -> Diagnose -> Repair online learning loop."""

    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        model_config: ModelConfig,
        agent_config: AgentConfig,
        detector_config: DetectorConfig,
        planner_config: PlannerConfig,
        device: str = "cpu",
        seed: int = 0,
    ) -> None:
        self.state_dim = int(state_dim)
        self.action_dim = int(action_dim)
        self.agent_config = agent_config
        self.device = device
        self.rng = np.random.default_rng(seed)
        self.total_observations = 0
        self.alarm_active_countdown = 0
        self.pending_repairs: dict[int, dict[str, Any]] = {}
        self.oracle_triggered_pairs: set[tuple[int, int]] = set()
        self.last_observed_action: int | None = None
        self.active_budget: int | None = None
        self.active_actions_used = 0
        self.history_context = HistoryContext(state_dim, action_dim, window=model_config.context_window)
        self.context_enabled = bool(model_config.context_enabled)
        self.context_dim = len(self.history_context.vector()) if self.context_enabled else 0
        self.last_action_kind = "unknown"
        self.sparsity_warmup_steps = int(model_config.sparsity_warmup_steps)
        self.sparsity_anneal_steps = int(model_config.sparsity_anneal_steps)

        self.model = EnsembleWorldModel(
            state_dim=state_dim,
            action_dim=action_dim,
            hidden_dim=model_config.hidden_dim,
            ensemble_size=model_config.ensemble_size,
            edge_temperature=model_config.edge_temperature,
            edge_init_logit=model_config.edge_init_logit,
            hard_concrete_gates=model_config.hard_concrete_gates,
            hard_concrete_gamma=model_config.hard_concrete_gamma,
            hard_concrete_zeta=model_config.hard_concrete_zeta,
            dense_graph=model_config.dense_graph,
            action_conditioned_gates=model_config.action_conditioned_gates,
            context_dim=self.context_dim,
            context_hidden_dim=model_config.context_hidden_dim,
            context_gate_scale=model_config.context_gate_scale,
        ).to(device)
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(), lr=agent_config.learning_rate, weight_decay=1e-5
        )
        self.replay = ReplayBuffer(
            agent_config.replay_capacity,
            state_dim,
            seed,
            action_dim=action_dim,
            context_dim=self.context_dim,
        )
        self.detector = NodewiseCUSUMDetector(
            state_dim,
            n_actions=action_dim,
            **asdict(detector_config),
        )
        self.base_loss_weights = {
            "state_loss_weight": model_config.state_loss_weight,
            "state_mse_loss_weight": model_config.state_mse_loss_weight,
            "reward_loss_weight": model_config.reward_loss_weight,
            "done_loss_weight": model_config.done_loss_weight,
            "feasibility_loss_weight": model_config.feasibility_loss_weight,
            "sparsity_weight": model_config.sparsity_weight,
            "parent_budget": model_config.parent_budget,
            "parent_budget_weight": model_config.parent_budget_weight,
            "action_gate_regularization": model_config.action_gate_regularization,
            "edge_entropy_weight": model_config.edge_entropy_weight,
            "transition_change_weight": model_config.transition_change_weight,
        }
        self.planner = CategoricalCEMPlanner(
            model=self.model,
            active_weight=agent_config.active_weight,
            device=device,
            **asdict(planner_config),
        )
        self.repairer = LocalMechanismRepair(
            model=self.model,
            optimizer=self.optimizer,
            device=device,
            repair_steps=agent_config.repair_steps,
            repair_batch_size=agent_config.repair_batch_size,
            anchor_batch_size=agent_config.anchor_batch_size,
            distill_weight=agent_config.distill_weight,
            gradient_clip=agent_config.gradient_clip,
            local=agent_config.local_repair,
            loss_weights=self.base_loss_weights,
            validation_fraction=agent_config.repair_validation_fraction,
            min_relative_improvement=agent_config.repair_min_relative_improvement,
            max_unaffected_degradation=agent_config.repair_max_unaffected_degradation,
            min_train_samples=agent_config.repair_min_train_samples,
            min_validation_samples=agent_config.repair_min_validation_samples,
            min_target_action_train=agent_config.repair_min_target_action_train,
            min_target_action_validation=agent_config.repair_min_target_action_validation,
            rng_seed=int(seed) + 901,
        )

    def set_active_budget(self, budget: int | None) -> None:
        """Equal allowance, not a promise of equal realized counts after termination."""
        if budget is not None and (isinstance(budget, bool) or int(budget) != budget or budget < 0):
            raise ValueError("active budget must be a nonnegative integer or None")
        self.active_budget = None if budget is None else int(budget)
        self.active_actions_used = 0

    def _context_vector(self) -> np.ndarray | None:
        return self.history_context.vector() if self.context_enabled else None

    def observe_context_only(self, state, action, reward, next_state) -> None:
        """Advance observable memory even when frozen evaluation disables learning."""
        self.last_observed_action = int(action)
        self.history_context.update(state, action, reward, next_state)
        self.model.set_context(self._context_vector())

    def _valid_actions(self, valid_action_mask: np.ndarray | None) -> np.ndarray:
        mask = (
            np.ones(self.action_dim, dtype=bool)
            if valid_action_mask is None
            else np.asarray(valid_action_mask, dtype=bool)
        )
        valid = np.flatnonzero(mask)
        if valid.size == 0:
            raise ValueError("At least one action must be valid")
        return valid

    def _exploration_epsilon(self) -> float:
        cfg = self.agent_config
        progress = min(1.0, self.total_observations / max(1, cfg.exploration_decay_steps))
        return float(
            cfg.exploration_epsilon_start
            + progress * (cfg.exploration_epsilon_end - cfg.exploration_epsilon_start)
        )

    def _loss_weights(self) -> dict[str, float]:
        weights = dict(self.base_loss_weights)
        elapsed = self.total_observations - self.sparsity_warmup_steps
        if elapsed <= 0:
            scale = 0.0
        else:
            scale = min(1.0, elapsed / max(1, self.sparsity_anneal_steps))
        weights["sparsity_weight"] *= scale
        weights["parent_budget_weight"] *= scale
        weights["edge_entropy_weight"] *= scale
        return weights

    def act(
        self,
        state: np.ndarray,
        valid_action_mask: np.ndarray | None = None,
        task_action_mask: np.ndarray | None = None,
        intervention_action_mask: np.ndarray | None = None,
    ) -> int:
        multiplier = (
            self.agent_config.alarm_active_boost if self.alarm_active_countdown > 0 else 1.0
        )
        active_enabled = (
            self.total_observations >= self.agent_config.active_warmup_steps
            and self.agent_config.active_weight * multiplier > 0
        )
        active_action_allowed = active_enabled and (
            self.active_budget is None or self.active_actions_used < self.active_budget
        )
        current_mask = (
            np.ones(self.action_dim, dtype=bool)
            if valid_action_mask is None
            else np.asarray(valid_action_mask, dtype=bool).copy()
        )
        future_mask = (
            np.ones(self.action_dim, dtype=bool)
            if task_action_mask is None
            else np.asarray(task_action_mask, dtype=bool).copy()
        )
        allow_intervention = (
            active_action_allowed
            and intervention_action_mask is not None
            and self.rng.random()
            < min(0.5, self.agent_config.intervention_probability * multiplier)
        )
        # Occasionally execute a deliberately invalid task action. The public
        # validity mask tells the agent that the action is currently infeasible,
        # but observing its no-op transition supplies the counterfactual evidence
        # needed to distinguish state prerequisites from the action embedding.
        counterfactual_candidates = np.zeros(self.action_dim, dtype=bool)
        if task_action_mask is not None:
            counterfactual_candidates = (
                np.asarray(task_action_mask, dtype=bool) & ~current_mask
            )
        allow_counterfactual = (
            active_action_allowed
            and counterfactual_candidates.any()
            and self.rng.random()
            < min(
                0.25,
                self.agent_config.counterfactual_probe_probability * multiplier,
            )
        )
        if allow_counterfactual:
            self.model.eval()
            action = self.planner.select_intervention(
                state,
                counterfactual_candidates,
            )
            self.last_action_kind = "counterfactual_probe"
            self.active_actions_used += 1
            if self.alarm_active_countdown > 0:
                self.alarm_active_countdown -= 1
            return action
        if allow_intervention:
            interventions = np.asarray(intervention_action_mask, dtype=bool)
            self.model.eval()
            action = self.planner.select_intervention(state, interventions)
            self.last_action_kind = "designed_intervention"
            self.active_actions_used += 1
            if self.alarm_active_countdown > 0:
                self.alarm_active_countdown -= 1
            return action
        valid = self._valid_actions(current_mask)
        if (
            self.total_observations < self.agent_config.random_steps
            or self.rng.random() < self._exploration_epsilon()
        ):
            self.last_action_kind = "random"
            if self.alarm_active_countdown > 0:
                self.alarm_active_countdown -= 1
            return int(self.rng.choice(valid))
        if not active_enabled:
            multiplier = 0.0
        self.model.eval()
        action = self.planner.plan(
            state,
            current_mask,
            future_action_mask=future_mask,
            active_multiplier=multiplier,
        )
        self.last_action_kind = "planned"
        if self.alarm_active_countdown > 0:
            self.alarm_active_countdown -= 1
        return action

    def _single_batch(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        valid_action_mask: np.ndarray | None = None,
    ) -> TransitionBatch:
        return TransitionBatch(
            state=torch.as_tensor(state, dtype=torch.float32, device=self.device).reshape(1, -1),
            action=torch.as_tensor([action], dtype=torch.long, device=self.device),
            reward=torch.as_tensor([reward], dtype=torch.float32, device=self.device),
            next_state=torch.as_tensor(next_state, dtype=torch.float32, device=self.device).reshape(1, -1),
            done=torch.as_tensor([float(done)], dtype=torch.float32, device=self.device),
            context=(None if not self.context_enabled else torch.as_tensor(
                self._context_vector(), dtype=torch.float32, device=self.device
            ).reshape(1, -1)),
            valid_action_mask=(
                None
                if valid_action_mask is None
                else torch.as_tensor(
                    np.asarray(valid_action_mask, dtype=np.float32).reshape(1, -1),
                    device=self.device,
                )
            ),
            valid_mask_known=(
                None
                if valid_action_mask is None
                else torch.ones(1, dtype=torch.bool, device=self.device)
            ),
        )

    def _update_model(self) -> dict[str, float] | None:
        if len(self.replay) < max(self.agent_config.learning_starts, self.agent_config.batch_size):
            return None
        last: dict[str, float] | None = None
        self.model.train()
        for _ in range(self.agent_config.updates_per_step):
            batch = self.replay.sample(
                self.agent_config.batch_size,
                self.device,
                informative_fraction=self.agent_config.informative_fraction,
            )
            loss, parts = self.model.loss(batch, **self._loss_weights())
            self.optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.agent_config.gradient_clip)
            self.optimizer.step()
            last = {key: float(value.item()) for key, value in parts.items()}
        return last

    def observe(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        step: int = 0,
        valid_action_mask: np.ndarray | None = None,
    ) -> ObserveReport:
        self.total_observations += 1
        detector_eligible = False
        detector_result = DetectionResult(False, [], np.zeros(self.state_dim), np.zeros(self.state_dim), 0.0)
        if (
            self.agent_config.diagnosis_enabled
            and len(self.replay) >= self.agent_config.learning_starts
        ):
            single = self._single_batch(
                state,
                action,
                reward,
                next_state,
                done,
                valid_action_mask,
            )
            self.model.eval()
            errors = self.model.prediction_error(single).detach().cpu().numpy()
            detector_eligible = not (
                self.agent_config.detector_skip_active_probes
                and self.last_action_kind
                in {"counterfactual_probe", "designed_intervention"}
            )
            detector_result = self.detector.update(
                errors,
                action=action,
                eligible=detector_eligible,
            )

        # Regime labels are intentionally not exposed to the agent. They are
        # reserved for the outer experiment harness and offline evaluation.
        self.replay.add(
            state,
            action,
            reward,
            next_state,
            done,
            regime="unknown",
            step=step,
            valid_action_mask=valid_action_mask,
            context=self._context_vector(),
        )
        # This transition may inform t+1, never its own prediction at t.
        self.observe_context_only(state, action, reward, next_state)
        update = self._update_model()
        repair_report: RepairReport | None = None
        if detector_result.alarm:
            self.alarm_active_countdown = max(1, self.planner.horizon)
            if self.agent_config.repair_enabled:
                if int(action) not in self.pending_repairs:
                    self.pending_repairs[int(action)] = {
                        "affected_nodes": list(detector_result.affected_nodes),
                        "alarm_step": int(step),
                        "target_actions": [int(action)],
                        "localization_history": [],
                        "last_check_step": int(step),
                        "oracle": False,
                    }
        # Keep hypotheses for different actions separate: a spurious key alarm
        # must not take over a subsequent bridge-specific evidence window.
        pending = self.pending_repairs.get(int(action))
        if pending is not None and not pending.get("oracle", False):
            history = list(pending.get("localization_history", []))
            if detector_result.localization_scores is not None and detector_eligible:
                scores = np.maximum(np.asarray(detector_result.z_scores) - self.detector.drift, 0.0)
                maximum = float(scores.max(initial=0.0))
                history.append((scores / max(maximum, 1e-12)).astype(np.float64))
            history = history[-max(1, self.detector.localization_window):]
            if len(history) >= self.agent_config.repair_consensus_min_samples:
                consensus = np.median(np.stack(history, axis=0), axis=0)
                refined = self.detector.select_affected(consensus)
                pending["affected_nodes"] = refined
            pending["localization_history"] = history
        repair_detail = None
        ready = sorted(self.pending_repairs.items(), key=lambda item: item[1]["last_check_step"])
        for candidate_action, candidate in ready:
            alarm_step = int(candidate["alarm_step"])
            if not candidate["affected_nodes"]:
                repair_detail = {
                    "steps": 0, "applied": False, "skip_reason": "diagnostic_evidence_resolved",
                    "affected_nodes": [], "target_actions": candidate["target_actions"],
                    "alarm_step": alarm_step,
                }
                del self.pending_repairs[candidate_action]
                break
            if int(step) - alarm_step > self.agent_config.repair_max_wait_steps:
                repair_detail = {
                    "steps": 0, "applied": False, "skip_reason": "expired_evidence_window",
                    "affected_nodes": candidate["affected_nodes"], "target_actions": candidate["target_actions"],
                    "alarm_step": alarm_step,
                }
                del self.pending_repairs[candidate_action]
                break
            if int(step) - alarm_step < self.agent_config.repair_delay_steps:
                continue
            if int(step) - int(candidate["last_check_step"]) < self.agent_config.repair_retry_interval:
                continue
            candidate["last_check_step"] = int(step)
            if (
                not candidate.get("oracle", False)
                and len(candidate["localization_history"]) < self.agent_config.repair_consensus_min_samples
            ):
                repair_detail = {
                    "steps": 0, "applied": False, "skip_reason": "insufficient_diagnostic_consensus",
                    "affected_nodes": candidate["affected_nodes"], "target_actions": candidate["target_actions"],
                    "consensus_samples": len(candidate["localization_history"]),
                    "alarm_step": alarm_step,
                }
                break
            self.repairer.loss_weights = self._loss_weights()
            repair_report = self.repairer.repair(
                self.replay, candidate["affected_nodes"], change_step=alarm_step,
                current_step=int(step), target_actions=candidate["target_actions"],
            )
            repair_detail = asdict(repair_report)
            repair_detail["alarm_step"] = alarm_step
            repair_detail["oracle"] = bool(candidate.get("oracle", False))
            if repair_report.steps > 0 or not str(repair_report.skip_reason or "").startswith("insufficient"):
                del self.pending_repairs[candidate_action]
            # At most one expensive candidate per transition. Others remain queued.
            break
        return ObserveReport(
            alarm=detector_result.alarm,
            affected_nodes=detector_result.affected_nodes,
            detector_score=detector_result.score,
            training_loss=None if update is None else update["loss"],
            training_metrics=update,
            repair=repair_detail,
            localization_scores=(
                None
                if detector_result.localization_scores is None
                else detector_result.localization_scores.astype(float).tolist()
            ),
        )

    def checkpoint(self) -> dict[str, Any]:
        return {
            "model": self.model.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "detector": self.detector.state_dict(),
            "total_observations": self.total_observations,
            "replay": self.replay.state_dict(),
            "rng_state": self.rng.bit_generator.state,
            "alarm_active_countdown": self.alarm_active_countdown,
            "pending_repairs": copy.deepcopy(self.pending_repairs),
            "history_context": self.history_context.state_dict(),
            "last_observed_action": self.last_observed_action,
            "active_budget": self.active_budget,
            "active_actions_used": self.active_actions_used,
            "oracle_triggered_pairs": sorted(self.oracle_triggered_pairs),
        }

    def force_repair(self, affected_nodes: list[int], step: int = 0, action: int | None = None) -> dict[str, Any]:
        """Oracle-node diagnostic baseline, not a guaranteed performance bound."""
        target_action = self.last_observed_action if action is None else int(action)
        if target_action is None or not 0 <= target_action < self.action_dim:
            raise ValueError("Oracle repair requires a valid observed triggering action")
        if any(not 0 <= int(node) < self.state_dim for node in affected_nodes):
            raise ValueError("Oracle affected node is outside state dimension")
        oracle_nodes = sorted(
            int(i) for i in set(affected_nodes)
            if (target_action, int(i)) not in self.oracle_triggered_pairs
        )
        if not oracle_nodes:
            return {
                "applied": False,
                "queued": False,
                "affected_nodes": [],
                "steps": 0,
            }
        self.oracle_triggered_pairs.update((target_action, node) for node in oracle_nodes)
        self.alarm_active_countdown = max(1, self.planner.horizon)
        old_candidate = self.pending_repairs.get(target_action)
        if old_candidate is not None and old_candidate.get("oracle", False):
            oracle_nodes = sorted(
                set(old_candidate.get("affected_nodes", [])).union(oracle_nodes)
            )
            alarm_step = min(int(step), int(old_candidate["alarm_step"]))
        else:
            alarm_step = int(step)
        self.pending_repairs[target_action] = {
            "affected_nodes": oracle_nodes,
            "alarm_step": alarm_step,
            "localization_history": [],
            "target_actions": [target_action],
            "last_check_step": int(step),
            "oracle": True,
        }
        return {
            "applied": False,
            "queued": True,
            "affected_nodes": oracle_nodes,
            "target_actions": [target_action],
            "steps": 0,
        }

    def trigger_active_boost(self) -> None:
        """Start the same exploration boost without exposing detector state."""
        self.alarm_active_countdown = max(1, self.planner.horizon)

    def reseed(self, seed: int) -> None:
        """Give every paired evaluation episode an independent agent RNG."""
        self.rng = np.random.default_rng(int(seed))
        self.replay.rng = np.random.default_rng(int(seed) + 1)

    def on_episode_reset(self, keep_adaptation_state: bool = False) -> None:
        """Reset task history; optionally retain evidence in a fixed-mechanism session.

        Ordinary independent episodes use the default. Only the explicit
        support/query harness retains evidence between support tasks; it never
        retains observation history across environment resets.
        """
        if not keep_adaptation_state:
            self.detector.start_episode()
            self.pending_repairs.clear()
            self.oracle_triggered_pairs.clear()
        self.alarm_active_countdown = 0
        self.history_context.reset()
        self.model.set_context(self._context_vector())
        self.last_observed_action = None
        self.active_actions_used = 0

    def load_checkpoint(self, checkpoint: dict[str, Any], load_optimizer: bool = True) -> None:
        self.model.load_state_dict(checkpoint["model"])
        if load_optimizer and "optimizer" in checkpoint:
            self.optimizer.load_state_dict(copy.deepcopy(checkpoint["optimizer"]))
            for state in self.optimizer.state.values():
                for key, value in state.items():
                    if torch.is_tensor(value):
                        state[key] = value.to(self.device).clone()
        if "detector" in checkpoint:
            self.detector.load_state_dict(checkpoint["detector"])
        self.total_observations = int(checkpoint.get("total_observations", 0))
        if "replay" in checkpoint:
            self.replay.load_state_dict(checkpoint["replay"])
        if "rng_state" in checkpoint:
            self.rng.bit_generator.state = checkpoint["rng_state"]
        self.alarm_active_countdown = int(checkpoint.get("alarm_active_countdown", 0))
        self.pending_repairs = copy.deepcopy(checkpoint.get("pending_repairs", {}))
        self.history_context.reset()
        if "history_context" in checkpoint:
            self.history_context.load_state_dict(checkpoint["history_context"])
        self.model.set_context(self._context_vector())
        self.last_observed_action = checkpoint.get("last_observed_action")
        self.active_budget = checkpoint.get("active_budget")
        self.active_actions_used = int(checkpoint.get("active_actions_used", 0))
        self.oracle_triggered_pairs = set(
            tuple(int(v) for v in value) for value in checkpoint.get("oracle_triggered_pairs", [])
        )
