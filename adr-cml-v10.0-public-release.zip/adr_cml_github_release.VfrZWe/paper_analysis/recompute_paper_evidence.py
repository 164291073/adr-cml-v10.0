#!/usr/bin/env python3
"""Recompute paper-facing statistics from existing ADR-CML v10.0 artifacts.

This script is deliberately read-only with respect to the project.  It reads
JSON/CSV records already present under outputs/v10/paper (and, when present,
the validation directories), never loads checkpoints or replay buffers, and
writes only to the requested analysis directory.

The short-evaluation cross-seed summaries are explicitly exploratory: the
native evaluation_comparison files make inference conditional on one trained
checkpoint, so this script recomputes a descriptive seed-level summary without
turning it into the prespecified session claim.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import html
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import numpy as np


MODES = (
    "full",
    "global_repair",
    "diagnose_no_repair",
    "online_only",
    "frozen",
    "no_active",
)
ARCHITECTURES = ("sparse", "dense")
PROFILES = ("train", "heldout_v1")
EVAL_PROTOCOLS = ("balanced_shift", "no_shift", "random_shift")


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def exact_signflip(values: list[float]) -> float | None:
    values = np.asarray(values, dtype=float)
    if len(values) < 2:
        return None
    observed = abs(float(values.mean()))
    signs = np.asarray(list(itertools.product((-1.0, 1.0), repeat=len(values))))
    null = np.abs((signs * values).mean(axis=1))
    return float(np.mean(null >= observed - 1e-15))


def bootstrap_ci(values: list[float], seed: int, samples: int = 20_000) -> list[float] | None:
    values = np.asarray(values, dtype=float)
    if len(values) < 2:
        return None
    rng = np.random.default_rng(seed)
    draws = rng.choice(values, size=(samples, len(values)), replace=True).mean(axis=1)
    return [float(value) for value in np.quantile(draws, [0.025, 0.975])]


def finite_mean(rows: list[dict[str, Any]], field: str) -> float | None:
    values = [row.get(field) for row in rows if isinstance(row.get(field), (int, float))]
    return None if not values else float(np.mean(values))


def collect_inventory(project: Path) -> dict[str, Any]:
    paper = project / "outputs" / "v10" / "paper"
    statuses = sorted((paper / "stage_status").glob("*.json"))
    status_rows = [read_json(path) for path in statuses]
    scm_summary_path = paper / "scm" / "summary.json"
    scm_summary = read_json(scm_summary_path) if scm_summary_path.is_file() else {}
    source_hashes: set[str] = set()
    for path in paper.glob("seed_*/*/run_metadata.json"):
        value = read_json(path).get("source_hash")
        if isinstance(value, str):
            source_hashes.add(value)
    for path in paper.glob("seed_*/*/sessions/*/session_evaluation.json"):
        data = read_json(path)
        for key in ("training_source_hash", "evaluation_source_hash"):
            value = data.get(key)
            if isinstance(value, str):
                source_hashes.add(value)
    return {
        "project_root": str(project.resolve()),
        "paper_root": str(paper.resolve()),
        "software_version": read_json(paper / "protocol_manifest.json").get("software_version"),
        "training_seeds": read_json(paper / "protocol_manifest.json").get("training_seeds"),
        "scm_seeds": read_json(paper / "protocol_manifest.json").get("scm_seeds"),
        "training_steps_per_architecture": read_json(paper / "protocol_manifest.json").get(
            "training_steps_per_architecture"
        ),
        "stage_status_files": len(statuses),
        "stage_status_completed": sum(row.get("completed") is True for row in status_rows),
        "stage_status_incomplete": sum(row.get("completed") is not True for row in status_rows),
        "checkpoints": {
            architecture: len(list(paper.glob(f"seed_*/{architecture}/checkpoint_final.pt")))
            for architecture in ARCHITECTURES
        },
        "session_evaluations": len(list(paper.glob("seed_*/[sd]*/sessions/*/session_evaluation.json"))),
        "short_evaluation_full_summaries": len(
            list(paper.glob("seed_*/[sd]*/evaluation/*/*/evaluation_full.json"))
        ),
        "scm_expected_rows": scm_summary.get("expected_seed_scenario_rows"),
        "scm_completed_rows": scm_summary.get("completed_rows"),
        "scm_failures": scm_summary.get("failures", []),
        "source_fingerprint_count": len(source_hashes),
    }


def collect_session_absolute(project: Path) -> list[dict[str, Any]]:
    paper = project / "outputs" / "v10" / "paper"
    rows: list[dict[str, Any]] = []
    for path in sorted(paper.glob("seed_*/[sd]*/sessions/*/session_evaluation.json")):
        parts = path.relative_to(paper).parts
        seed = int(parts[0].removeprefix("seed_"))
        architecture = parts[1]
        data = read_json(path)
        for mode, values in data.get("aggregate", {}).items():
            rows.append(
                {
                    "source": str(path),
                    "architecture": architecture,
                    "profile": data.get("environment_profile"),
                    "training_seed": seed,
                    "mode": mode,
                    "query_return": values.get("query_mean_return"),
                    "query_success": values.get("query_success_rate"),
                    "probe_before": values.get("probe_mse_before"),
                    "probe_after": values.get("probe_mse_after"),
                    "support_active_actions": values.get("support_active_actions"),
                    "support_repair_steps": values.get("support_repair_optimizer_steps"),
                    "support_repair_attempts": values.get("support_repair_attempts"),
                    "support_accepted_repairs": values.get("support_accepted_repairs"),
                }
            )
    return rows


def collect_session_contrasts(project: Path) -> list[dict[str, Any]]:
    paper = project / "outputs" / "v10" / "paper"
    rows: list[dict[str, Any]] = []
    for path in sorted((paper / "aggregate").glob("*_sessions.json")):
        data = read_json(path)
        parts = path.stem.removesuffix("_sessions").split("_")
        architecture = parts[0]
        profile = "heldout_v1" if "heldout_v1" in path.stem else "train"
        for contrast, metrics in data.get("comparisons", {}).items():
            comparator = contrast.removeprefix("full_vs_")
            for metric, entry in metrics.items():
                if not isinstance(entry, dict):
                    continue
                rows.append(
                    {
                        "evidence_family": "formal_session_multiseed",
                        "architecture": architecture,
                        "profile": profile,
                        "contrast": f"full_vs_{comparator}",
                        "endpoint": metric,
                        "available": entry.get("available"),
                        "mean_difference": entry.get("mean_difference"),
                        "ci95_low": (entry.get("ci95") or [None, None])[0],
                        "ci95_high": (entry.get("ci95") or [None, None])[1],
                        "raw_p": (entry.get("signflip") or {}).get("pvalue"),
                        "holm_p": entry.get("holm_pvalue"),
                        "primary_holm_p": entry.get("primary_holm_pvalue"),
                        "secondary_holm_p": entry.get("secondary_holm_pvalue"),
                        "positive_seed_count": entry.get("positive_seed_count"),
                        "negative_seed_count": entry.get("negative_seed_count"),
                        "n_training_seeds": data.get("n_training_seeds"),
                        "statistical_unit": data.get("bootstrap_unit"),
                        "interpretation": data.get("inference_limit"),
                    }
                )
    return rows


def collect_scm(project: Path) -> list[dict[str, Any]]:
    summary_path = project / "outputs" / "v10" / "paper" / "scm" / "summary.json"
    data = read_json(summary_path)
    rows: list[dict[str, Any]] = []
    for contrast, entry in sorted(data.get("primary_contrasts", {}).items()):
        family, scenario, baseline = contrast.split("/")
        rows.append(
            {
                "evidence_family": "formal_scm_component",
                "family": family,
                "scenario": scenario,
                "contrast": baseline.removeprefix("vs_"),
                "endpoint": "recursive_noiseless_mse_H8",
                "mean_difference": entry.get("mean_baseline_minus_local"),
                "ci95_low": (entry.get("paired_seed_bootstrap_ci95") or [None, None])[0],
                "ci95_high": (entry.get("paired_seed_bootstrap_ci95") or [None, None])[1],
                "raw_p": entry.get("two_sided_sign_flip_p"),
                "holm_p": entry.get("holm_adjusted_p"),
                "positive_seed_count": entry.get("positive_seed_count"),
                "n_independent_seeds": entry.get("n_independent_seeds"),
                "effect_definition": data.get("positive_effect_definition"),
                "scope": data.get("scope"),
            }
        )
    return rows


def collect_architecture(project: Path) -> list[dict[str, Any]]:
    paper = project / "outputs" / "v10" / "paper"
    rows: list[dict[str, Any]] = []
    for path in sorted((paper).glob("architecture_comparison_*.json")):
        data = read_json(path)
        profile = data.get("environment_profile")
        for contrast, metrics in data.get("comparisons", {}).items():
            for endpoint, entry in metrics.items():
                rows.append(
                    {
                        "evidence_family": "architecture_comparison",
                        "profile": profile,
                        "contrast": contrast,
                        "endpoint": endpoint,
                        "mean_difference": entry.get("mean_difference"),
                        "ci95_low": (entry.get("ci95") or [None, None])[0],
                        "ci95_high": (entry.get("ci95") or [None, None])[1],
                        "raw_p": (entry.get("signflip") or {}).get("p_value"),
                        "holm_p": entry.get("holm_pvalue"),
                        "positive_seed_count": entry.get("positive_seed_count"),
                        "negative_seed_count": entry.get("negative_seed_count"),
                        "n_training_seeds": data.get("n_training_seeds"),
                        "baseline_interpretation": data.get("baseline_interpretation"),
                    }
                )
    return rows


def collect_short_eval(project: Path) -> list[dict[str, Any]]:
    """Cross-seed descriptive recomputation for the 100-episode summaries."""
    paper = project / "outputs" / "v10" / "paper"
    rows: list[dict[str, Any]] = []
    for architecture in ARCHITECTURES:
        for profile in PROFILES:
            for protocol in EVAL_PROTOCOLS:
                summary: dict[str, dict[int, dict[str, Any]]] = defaultdict(dict)
                for mode in MODES:
                    for path in sorted(
                        paper.glob(
                            f"seed_*/{architecture}/evaluation/{profile}/{protocol}/evaluation_{mode}.json"
                        )
                    ):
                        data = read_json(path)
                        summary[mode][int(data["seed"])] = data
                if len(summary.get("full", {})) != 8:
                    continue
                for comparator in MODES[1:]:
                    seeds = sorted(summary["full"])
                    differences = [
                        float(summary["full"][seed]["mean_return"] - summary[comparator][seed]["mean_return"])
                        for seed in seeds
                    ]
                    rows.append(
                        {
                            "evidence_family": "exploratory_short_eval_cross_seed",
                            "architecture": architecture,
                            "profile": profile,
                            "protocol": protocol,
                            "contrast": f"full_vs_{comparator}",
                            "endpoint": "mean_return",
                            "mean_full": float(np.mean([summary["full"][s]["mean_return"] for s in seeds])),
                            "mean_comparator": float(
                                np.mean([summary[comparator][s]["mean_return"] for s in seeds])
                            ),
                            "mean_difference": float(np.mean(differences)),
                            "ci95_low": bootstrap_ci(differences, 2_026_111_010)[0],
                            "ci95_high": bootstrap_ci(differences, 2_026_111_010)[1],
                            "raw_p": exact_signflip(differences),
                            "holm_p": None,
                            "positive_seed_count": int(np.sum(np.asarray(differences) > 0)),
                            "negative_seed_count": int(np.sum(np.asarray(differences) < 0)),
                            "n_training_seeds": len(seeds),
                            "episodes_per_checkpoint": 100,
                            "mechanism_activation_rate_full": float(
                                np.mean([summary["full"][s].get("mechanism_activation_rate", 0.0) for s in seeds])
                            ),
                            "scope": "Exploratory: original files infer within one checkpoint; this is a descriptive seed-level reanalysis.",
                        }
                    )
    return rows


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    for row in rows:
        for field in row:
            if field not in fields:
                fields.append(field)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _svg_text(x: float, y: float, value: str, *, size: int = 12, anchor: str = "start") -> str:
    return f'<text x="{x:.1f}" y="{y:.1f}" font-family="Arial,sans-serif" font-size="{size}px" text-anchor="{anchor}">{html.escape(value)}</text>'


def _save_bar_svg(
    path: Path,
    title: str,
    y_label: str,
    labels: list[str],
    means: list[float],
    lows: list[float],
    highs: list[float],
    colors: list[str],
    width: int = 1100,
    height: int = 560,
) -> None:
    margin_left, margin_right, margin_top, margin_bottom = 90, 35, 70, 110
    plot_w = width - margin_left - margin_right
    plot_h = height - margin_top - margin_bottom
    finite = [float(v) for v in [*means, *lows, *highs] if v is not None and np.isfinite(v)]
    if not finite:
        finite = [0.0, 1.0]
    ymin, ymax = min(0.0, min(finite)), max(1.0, max(finite))
    pad = 0.08 * max(1e-12, ymax - ymin)
    ymin, ymax = ymin - pad, ymax + pad
    scale = plot_h / (ymax - ymin)

    def y(value: float) -> float:
        return margin_top + (ymax - value) * scale

    pieces = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="white"/>',
        _svg_text(width / 2, 30, title, size=18, anchor="middle"),
        _svg_text(20, margin_top + plot_h / 2, y_label, size=12),
        f'<line x1="{margin_left}" y1="{y(ymin):.1f}" x2="{margin_left}" y2="{y(ymax):.1f}" stroke="black"/>',
        f'<line x1="{margin_left}" y1="{y(0):.1f}" x2="{width-margin_right}" y2="{y(0):.1f}" stroke="#666" stroke-width="1"/>',
    ]
    for tick in np.linspace(ymin, ymax, 5):
        yy = y(float(tick))
        pieces.append(f'<line x1="{margin_left}" y1="{yy:.1f}" x2="{width-margin_right}" y2="{yy:.1f}" stroke="#dddddd"/>')
        pieces.append(_svg_text(margin_left - 8, yy + 4, f"{tick:.3g}", size=10, anchor="end"))
    slot = plot_w / max(1, len(labels))
    bar_w = slot * 0.58
    for index, (label, mean, low, high, color) in enumerate(zip(labels, means, lows, highs, colors)):
        cx = margin_left + (index + 0.5) * slot
        top, bottom = y(max(0.0, mean)), y(min(0.0, mean))
        pieces.append(f'<rect x="{cx-bar_w/2:.1f}" y="{min(top,bottom):.1f}" width="{bar_w:.1f}" height="{abs(bottom-top):.1f}" fill="{color}" opacity="0.82"/>')
        lo, hi = mean - low, mean + high
        pieces.append(f'<line x1="{cx:.1f}" y1="{y(lo):.1f}" x2="{cx:.1f}" y2="{y(hi):.1f}" stroke="black"/>')
        pieces.append(f'<line x1="{cx-5:.1f}" y1="{y(lo):.1f}" x2="{cx+5:.1f}" y2="{y(lo):.1f}" stroke="black"/>')
        pieces.append(f'<line x1="{cx-5:.1f}" y1="{y(hi):.1f}" x2="{cx+5:.1f}" y2="{y(hi):.1f}" stroke="black"/>')
        pieces.append(_svg_text(cx, height - margin_bottom + 22, label, size=10, anchor="middle"))
    pieces.append('</svg>')
    path.write_text("\n".join(pieces), encoding="utf-8")


def save_figures(output: Path, session_rows: list[dict[str, Any]], scm_rows: list[dict[str, Any]], architecture_rows: list[dict[str, Any]]) -> list[str]:
    """Write simple SVG plots without importing Matplotlib/fontconfig."""
    figures = output / "figures"
    figures.mkdir(parents=True, exist_ok=True)
    made: list[str] = []

    # Formal session absolute query return means, one file per architecture/profile.
    for architecture, profile in (("sparse", "heldout_v1"), ("dense", "heldout_v1"), ("sparse", "train"), ("dense", "train")):
        selected = [row for row in session_rows if row["architecture"] == architecture and row["profile"] == profile]
        means, lows, highs = [], [], []
        for mode in MODES:
            values = [row["query_return"] for row in selected if row["mode"] == mode]
            mean = float(np.mean(values))
            ci = bootstrap_ci(values, 2_026_111_011)
            means.append(mean)
            lows.append(mean - ci[0])
            highs.append(ci[1] - mean)
        path = figures / f"session_query_return_{architecture}_{profile}.svg"
        _save_bar_svg(path, f"Formal session query return: {architecture} / {profile}", "query return", list(MODES), means, lows, highs, ["#4C78A8"] * len(MODES))
        made.append(str(path))

    # SCM: local benefit is baseline H=8 MSE minus local H=8 MSE.
    selected = [row for row in scm_rows if row["contrast"] == "global_replay"]
    labels = [f"{row['family']}/{row['scenario']}" for row in selected]
    effects = [row["mean_difference"] for row in selected]
    low = [row["mean_difference"] - row["ci95_low"] for row in selected]
    high = [row["ci95_high"] - row["mean_difference"] for row in selected]
    path = figures / "scm_global_replay_effects.svg"
    _save_bar_svg(path, "SCM component: local benefit versus global_replay", "baseline MSE - local MSE", labels, effects, low, high, ["#59A14F" if value > 0 else "#E15759" for value in effects])
    made.append(str(path))

    # Architecture heldout/train effect plot for query return only.
    selected = [row for row in architecture_rows if row["endpoint"] == "query_return"]
    labels = [f"{row['profile']}/{row['contrast'].replace('_', ' ')}" for row in selected]
    effects = [row["mean_difference"] for row in selected]
    low = [row["mean_difference"] - row["ci95_low"] for row in selected]
    high = [row["ci95_high"] - row["mean_difference"] for row in selected]
    path = figures / "architecture_query_return.svg"
    _save_bar_svg(path, "Paired architecture comparison", "sparse - dense query return", labels, effects, low, high, ["#F28E2B"] * len(labels))
    made.append(str(path))
    return made


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    project = args.project_root.resolve()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)

    inventory = collect_inventory(project)
    session_absolute = collect_session_absolute(project)
    session_contrasts = collect_session_contrasts(project)
    scm_rows = collect_scm(project)
    architecture_rows = collect_architecture(project)
    short_rows = collect_short_eval(project)

    bundle = {
        "inventory": inventory,
        "formal_session_absolute": session_absolute,
        "formal_session_contrasts": session_contrasts,
        "formal_scm_contrasts": scm_rows,
        "architecture_comparisons": architecture_rows,
        "exploratory_short_eval": short_rows,
        "notes": [
            "No checkpoint, replay buffer, NPZ probe bank, training log, or episode-level binary was loaded by this script.",
            "The formal session contrasts are copied/recomputed from the existing native aggregate reports.",
            "The short-evaluation cross-seed rows are exploratory descriptive reanalysis, not the prespecified session claim.",
        ],
    }
    (output / "recomputed_statistics.json").write_text(
        json.dumps(bundle, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (output / "inventory.json").write_text(
        json.dumps(inventory, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_csv(output / "formal_session_contrasts.csv", session_contrasts)
    write_csv(output / "formal_scm_contrasts.csv", scm_rows)
    write_csv(output / "architecture_comparisons.csv", architecture_rows)
    write_csv(output / "exploratory_short_eval.csv", short_rows)
    write_csv(output / "formal_session_absolute.csv", session_absolute)
    figures = save_figures(output, session_absolute, scm_rows, architecture_rows)
    (output / "figure_manifest.json").write_text(
        json.dumps({"figures": figures}, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({"output": str(output), "figures": figures, "inventory": inventory}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
