# ADR-CML v10.0 论文分析产物

本目录只包含对 `/Users/liuhongjiu/Desktop/adr-cml-v10.0` 现有源码、配置和结果的只读分析。没有重新训练、启动评估流水线、搜索超参数，也没有加载 checkpoint、replay buffer 或 probe-bank 二进制内容。

主要文件：

- `inventory.md`：材料清点、正式/快检/历史证据边界与完整性核对。
- `evidence_matrix.md`：逐条结论、支持文件、统计结果、适用条件、反例和局限。
- `paper_positioning.md`：基于证据的论文定位、题目、贡献和章节安排。
- `paper_draft_zh.md`：中文论文初稿；所有结果都标记了正式、描述性或探索性范围。
- `related_work_verified.md`：已查证的一手相关工作来源与引用边界。
- `recompute_paper_evidence.py`：从已有 JSON 重新汇总统计并生成 SVG 图；默认要求显式传入项目根目录和输出目录。
- `recomputed_statistics.json`、各 `*.csv`：重算后的机器可读统计表。
- `figures/`：不依赖 Matplotlib/fontconfig 的 SVG 图，仅用于结果展示。

运行重算示例：

```bash
python3 paper_analysis/recompute_paper_evidence.py \
  --project-root /Users/liuhongjiu/Desktop/adr-cml-v10.0 \
  --output-dir /Users/liuhongjiu/Desktop/adr-cml-v10.0/paper_analysis
```

短回合 100-episode 结果的跨训练 seed 表是本目录脚本做的探索性描述性重算；原始 `evaluation_comparison.json` 的推断单位仍是“单个 checkpoint 内的配对评估回合”，不能把这次重算改写成预注册的确认性结论。
