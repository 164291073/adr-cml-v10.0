# 交付前证据、比较对象与参考文献审计

审计对象：`paper_draft_nmi_en.md` 与 `paper_draft_nmi_zh.md`。审计只读取已有源码、配置、JSON/CSV 结果和论文出处；没有启动训练、评估、统计搜索，也没有加载 checkpoint 或 replay binary。

## 一、交付结论

当前证据可以支持的主线是：**局部修复在完全观察、已知特征字典的独立 SCM 组件中对部分机制变化降低开环预测误差，但该收益没有在正式神经智能体的 heldout query-return 端点上得到确认；非线性新增边条件还出现了 dense global 优于 local 的反例。**

不能据此声称：完整智能体整体优于所有对照、完成因果图识别、泛化到未知机制类型、在外部 benchmark 上领先，或局部修复具有普遍优势。

本轮发现并修正了两处交付前文本问题：

1. 将“163 stages = 16 + 32 + 96 + 60”改为“163 条已完成的 stage-status 记录；另有 60 条 SCM 条件结果行”。60 条 SCM 行不是 163 条 stage-status 记录的组成部分。
2. 将英文方法中的转义残留改为 `tanh(2x)`。

## 二、关键数字出处核对

| 正文中的数字或统计 | 原始出处 | 核对结果与适用条件 |
|---|---|---|
| 8 个神经智能体训练 seed；sparse/dense 各 100,000 steps | `outputs/v10/paper/protocol_manifest.json`；`paper_analysis/inventory.json`；16 份 `run_metadata.json` | 一致。统计单位是独立 training seed，不是 episode 数。 |
| 10 个 SCM seed；60 条 SCM 条件行 | `protocol_manifest.json` 的 `scm_seeds`；`paper_analysis/inventory.json`；`paper_analysis/formal_scm_contrasts.csv` | 一致。SCM 是独立组件实验，不是完整智能体实验。 |
| MechanismMaze 有 8 个状态节点、10 个动作、3 个机制变化模式 | `src/adrcml/envs/mechanism_maze.py:19-54` | 一致。模式为 `coupled_lock`、`fragile_bridge`、`draining_key`。 |
| `heldout_v1` 改变已知机制族内阈值范围，而非引入新机制类型 | `src/adrcml/envs/mechanism_maze.py:56-61`；`protocol_manifest.json` | 一致。该表述不应扩展为“未知机制泛化”。 |
| sparse 配置：hidden dim 96、ensemble 5、parent budget 4、sparsity weight .004、parent-budget weight .02；dense 关闭这些结构惩罚并使用全 1 adjacency | `configs/main.yaml:20-47`；`src/adrcml/ablations.py:32-41`；`src/adrcml/models/relational_world_model.py:212-232` | 一致。dense 是项目内 ablation，不是外部发表 baseline。 |
| 每个 session 为 12 support episodes + 4 query episodes；probe 为 512；active budget 上限为 3 | `protocol_manifest.json`；`src/adrcml/evaluate_sessions.py:345-361` | 一致。active budget 是最大 allowance，不等于各条件实际动作数或 FLOPs。 |
| 163 条已完成 stage-status 记录；另有 60 条 SCM 条件行 | `paper_analysis/inventory.json`；`outputs/v10/paper/stage_status/*.json`；`paper_analysis/formal_scm_contrasts.csv` | 163/163 stage-status 完成；SCM 60/60 条件完成。两类记录不能相加或互相替代。 |
| SCM 相对 `no_repair` 的 4 个 H=8 效应 | `paper_analysis/formal_scm_contrasts.csv`，字段 `contrast=no_repair`、`endpoint=recursive_noiseless_mse_H8` | linear/coefficient_shift: `4.5549e-5`, CI `[3.0606e-5, 6.0211e-5]`, Holm p `.03125`; linear/edge_addition: `1.1658e-5`, CI `[7.8021e-6, 1.6205e-5]`, Holm p `.03125`; nonlinear/coefficient_shift: `1.7631e-4`, CI `[1.1519e-4, 2.3500e-4]`, Holm p `.03125`; nonlinear/edge_addition: `1.2624e-5`, CI `[-1.55e-7, 2.9313e-5]`, Holm p `.49219`。效应定义是 `baseline error - diagnosed local error`，正值才表示 local 误差较低。 |
| SCM 相对 `global_replay` 的比较 | 同一 CSV，`contrast=global_replay` | linear/coefficient_shift: `9.1103e-6`, Holm p `.03125`; linear/edge_addition: `2.3553e-6`, Holm p `.05859`; nonlinear/coefficient_shift: `-6.0581e-7`, Holm p `.84180`; nonlinear/edge_addition: `6.6156e-6`, Holm p `.046875`。因此只能写“两个条件通过校正”，不能写 local 普遍优于 global。 |
| 非线性新增边的 dense-global 反例 | 同一 CSV，`contrast=dense_global`、`family=nonlinear`、`scenario=edge_addition` | `dense_global - local = -1.0507e-4`，95% CI `[-1.3331e-4, -8.3433e-5]`，Holm p `.03125`。负号表示 dense global 的递归误差更低。 |
| 完整智能体 heldout primary query-return 四个比较 | `paper_analysis/formal_session_contrasts.csv`；对应 `profile=heldout_v1`、`endpoint=query_return` | sparse `full - diagnose_no_repair = -0.01650`, CI `[-0.04944, 0.01444]`, Holm p `.35938`; sparse `full - global_repair = -0.01684`, CI `[-0.05399, 0.01616]`, Holm p `.35938`; dense 对应为 `+0.01712`, CI `[-0.01672, 0.05353]`, Holm p `.25000`，以及 `+0.01349`, CI `[-0.03521, 0.07317]`, Holm p `.83594`。四个区间均跨零。 |
| sparse/dense 架构比较 | `paper_analysis/architecture_comparisons.csv` | heldout query-return `sparse - dense = -0.00265625`, Holm p `1.0`；heldout probe MSE Holm p `.28125`；train probe MSE `sparse - dense = +0.0002574054`, CI `[.0001361925, .0003812444]`, Holm p `.03125`。后一个结果是 train profile 的描述性发展证据，不能替代 heldout task-return 证据。 |
| planner 数字：horizon 16、population 512、elites 64、iterations 5、risk weight .1、information cap .25 | `configs/main.yaml:109-116`；`src/adrcml/planning.py:15-37` | 一致。它们是配置事实，不是效果数字。 |

## 三、比较对象审计

| 比较 | 真实比较对象 | 可以怎样写 | 不可以怎样写 |
|---|---|---|---|
| SCM `local` vs `no_repair` | 独立的模块化回归器，在完全观察、已知可分离特征字典、指定机制族和 H=8 递归预测下比较 | “组件级预测误差在部分条件下降低” | “完整智能体提升”“完成因果识别” |
| SCM `local` vs `global_replay` | 带 replay/anchor 保护的全局更新代理 | “在两个特定机制条件下通过校正” | “local 普遍优于 global repair” |
| SCM `dense_global` vs `local` | 非线性新增边条件下的 dense global 与局部更新 | 保留 dense-global 胜出的反例 | 删除反例或概括成局部性总是更好 |
| 完整智能体 `full` vs `diagnose_no_repair` | 允许诊断、主动动作和修复的完整流程 vs 诊断但不更新 | heldout query-return 的 primary contrast | 把 SCM 的正结果移植成 full-agent 优势 |
| 完整智能体 `full` vs `global_repair` | 局部流程 vs 全节点更新流程 | 报告 sparse/dense 各自的 seed-level paired result | 省略 sparse/dense 条件或把 dense 点估计当作确认性优势 |
| sparse vs dense | 两组独立训练的项目内架构 ablation | “内部架构敏感性比较” | “超过外部 baseline/SOTA” |

统计代码与结果文件共同显示：完整智能体的 session 聚合以 training seed 为主要独立单位，SCM 以 10 个独立 seed 为单位；随机化检验为双侧 sign-flip，预设比较家族内使用 Holm 校正。依据为 `src/adrcml/aggregate_sessions.py`、`src/adrcml/compare_evaluations.py`、`src/adrcml/scm_benchmark.py`、`src/adrcml/compare_architectures.py` 及其生成的 CSV。正文因此保留 CI、原始方向和校正后 p 值，不把 episode 数当作独立重复。

## 四、实现与数据来源边界

- `src/adrcml/models/relational_world_model.py:32-43` 明确将 gate 描述为 action-conditioned predictive dependency 的信息路径约束，并明确不保证 observational causal identifiability。论文使用 “predictive dependency” 比 “causal graph discovery” 更准确。
- 正式 v10 结果来自项目自定义的程序化 `MechanismMaze` 和独立 SCM 生成器，不是从公开静态数据集下载的训练集。仓库中的 CausalWorld adapter 是可选代码，但正式 v10 manifest 没有使用 CausalWorld。
- support/query 的冻结逻辑和 hash audit 位于 `src/adrcml/evaluate_sessions.py:102-160`；query 不更新模型、优化器、detector、replay 和学习计数器。该审计证明协议执行，不证明方法有效。
- `changed_child_mask` 和 graph score 是可观测预测依赖代理，不是真实 causal child 标签；因此文稿不应把 graph F1 写成因果识别准确率。

## 五、参考文献出处审计

修订稿现列出 38 条参考文献。原有 8 条的详细核验如下；新增 30 条的逐条出处、年份、类型和与本文关系见 [`reference_audit_2026.md`](reference_audit_2026.md)。已核验的 38 条中没有发现幻觉文献。

| 编号 | 文献 | 核验出处 | 状态 |
|---|---|---|---|
| 1 | Schölkopf et al., *Toward Causal Representation Learning* | [IEEE Xplore](https://ieeexplore.ieee.org/abstract/document/9363924/authors), DOI [10.1109/JPROC.2021.3058954](https://doi.org/10.1109/JPROC.2021.3058954) | 题名、作者、*Proceedings of the IEEE* 109(5), 612–634, 2021 一致 |
| 2 | Mooij, Magliacane & Claassen, *Joint Causal Inference from Multiple Contexts* | [JMLR 正式页面](https://jmlr.org/papers/v21/17-123.html) | 21(99):1–108, 2020 一致 |
| 3 | Xia et al., *The Causal-Neural Connection: Expressiveness, Learnability, and Inference* | [NeurIPS 2021 正式页面](https://proceedings.neurips.cc/paper/2021/hash/5989add1703e4b0480f75e2390739f34-Abstract.html) | NeurIPS 34, 2021 一致 |
| 4 | Moerland et al., *Model-based Reinforcement Learning: A Survey* | [Publisher DOI](https://doi.org/10.1561/2200000086) | *Foundations and Trends in Machine Learning* 16(1), 1–118, 2023；采用正式出版版本 |
| 5 | Ahmed et al., *CausalWorld: A Robotic Manipulation Benchmark for Causal Structure and Transfer Learning* | [MPI-IS publication record](https://is.mpg.de/en/publications/ahmedetal21)；[OpenReview 论文条目](https://openreview.net/forum?id=SK7A5pdrgov) | 题名、作者和 ICLR 2021 会议出处一致；正文应明确 CausalWorld 未用于本项目正式结果 |
| 6 | Herdeanu et al., *CausalDynamics: A large-scale benchmark for structural discovery of dynamical causal models* | [NeurIPS 2025 正式页面](https://proceedings.neurips.cc/paper_files/paper/2025/hash/39a3f7dc00e4723a5ca7808b04fc4d4f-Abstract-Datasets_and_Benchmarks_Track.html) | NeurIPS 38 Main Conference, Datasets and Benchmarks Track, 2025 一致 |
| 7 | Page, *Continuous Inspection Schemes* | [Oxford Academic 正式条目](https://academic.oup.com/biomet/article-abstract/41/1-2/100/456627?login=false), DOI [10.1093/biomet/41.1-2.100](https://doi.org/10.1093/biomet/41.1-2.100) | *Biometrika* 41(1–2), 100–115, 1954 一致 |
| 8 | Altamirano, Briol & Knoblauch, *Robust and Scalable Bayesian Online Changepoint Detection* | [PMLR](https://proceedings.mlr.press/v202/altamirano23a.html) | ICML 40, PMLR 202:642–663, 2023；正式会议版本 |

需要特别区分：这 38 条参考文献用于界定因果表示、跨 context、MBRL、变化检测、稀疏门控和 benchmark 的背景，不构成本文方法已经超过这些工作的证据。当前项目没有外部发表 baseline，也没有证据支持 “first”“unique” 或 “state of the art”。

## 六、确实需要作者确认的事项

以下事项不是从源码或现有结果中可以替作者决定的外部事实，应单独确认：

1. 作者顺序、通讯作者、作者贡献和伦理/数据声明；当前已按作者提供的信息写入：刘清扬，华东理工大学信息科学与工程学院；无致谢、无基金、无 competing interest。
2. 代码仓库的公开 URL、commit/tag、许可证、是否公开 checkpoint，以及 source data tables、生成协议和运行环境的发布方式。当前稿中的 availability 仍是投稿前计划，不是已完成的公开承诺。
3. 第 4 条参考文献已统一采用 Moerland et al. 的 2023 年正式出版版本；投稿前只需按期刊格式统一 BibTeX 和正文排版。
4. 是否保留 CausalWorld 作为相关工作。保留时必须继续写明它是可选 adapter 且未用于 v10 正式结果；若正文不讨论 adapter，可以删除该条以减少误解。
5. 是否接受题目和全文统一使用 “predictive mechanism/dependency” 而不是暗示 “causal identification”；这是术语和定位选择，不是实验结果可以替作者决定的事实。
6. 图、Extended Data 和 source data table 的最终编号、图注、统计表展示位置。当前仓库有分析表和 SVG，但没有期刊投稿版的最终图表映射。
7. 正文目前已加入相关工作段落和 38 条文内编号引用；最终排版仍需确认 Nature/NMI 的引用格式、图表引用方式和是否保留全部 38 条。
8. 若项目目录之外存在未纳入本次审计的外部数据、运行或作者自有结果，需要作者确认其是否属于本文证据。就当前 v10 formal manifest 和 outputs 而言，没有外部静态数据集输入。

除上述事项外，当前数字、比较方向、实验层级边界和 38 条参考文献均有可追溯出处；没有把缺失信息补写成结果。
