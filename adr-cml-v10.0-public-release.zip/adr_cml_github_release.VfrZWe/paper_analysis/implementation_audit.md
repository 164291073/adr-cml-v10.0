# 第二步：实现与证据核对

## 1. 完整神经智能体实际实现

### 世界模型

- 入口：`src/adrcml/agent.py:30` 的 `ADRCMLAgent`。
- 模型：`src/adrcml/models/relational_world_model.py:32` 的 `RelationalCausalWorldModel`，外层是 ensemble。
- 正式配置：`hidden_dim=96`、`ensemble_size=5`、`dense_graph=False/True` 两个独立架构、`action_conditioned_gates=True`、`context_window=8`、hard-concrete gates。
- 训练：replay buffer 采样，`updates_per_step=2`，learning starts 1000，batch 256；损失中同时包含 next-state NLL/MSE、reward、done、validity、sparsity、parent budget、entropy 和 transition-change weighting。
- 结构语义：gate mask 作用于当前 parent value 以及历史 state/delta 输入；对角线 self dependency 强制开启；action history 是显式条件输入。源码注释明确写出该设计是 one-step information-path constraint，不构成 causal identifiability。

### 诊断

- 入口：`src/adrcml/detection.py:19` 的 `NodewiseCUSUMDetector`。
- 实际输入是节点 prediction error/NLL，不是真实 regime、change node 或 simulator graph。
- 具有 warm-up、EMA/robust history、action-conditioned baseline、CUSUM drift/threshold、localization window 和 median consensus。
- `agent.py:327` 之后只有在 replay 达到 learning start 且 diagnosis enabled 时调用 detector；active probe 可配置为不进入 detector baseline。

### 修复

- 入口：`src/adrcml/repair.py:62` 的 `LocalMechanismRepair`。
- 变化后的 replay 证据按一个 chronological cutoff 划分 train/validation；必须满足总样本和 target-action quotas。
- local 模式只对 affected child 的 incoming parameters 训练；global 模式训练全部节点；两者共享同一诊断 targets、validation、NLL guard 和 unaffected-node collateral guard。
- local 额外使用 change 前 anchor distillation 保护未改变节点；验证不通过时加载 teacher 状态回滚。
- 代码中的 acceptance 是内部预测验证规则，不等价于独立 query 改善、任务成功或因果正确定位。

### 规划与动作预算

- 入口：`src/adrcml/planning.py`，agent 使用 `CategoricalCEMPlanner`。
- 正式配置为 horizon 16、population 512、elites 64、iterations 5、risk weight .1、information cap .25。
- `active_budget=3` 是每个 task 的最大 allowance。`MechanismMazeEnv` 中 `shield_bridge` 是共享的生产性 task action，不是只给某个模式的特权动作；`probe_lock` 是信息动作。

## 2. 实验实现的审计点

### session support/query

`src/adrcml/evaluate_sessions.py:345`：

- 每个 session 先固定 mechanism parameters，再运行 12 support tasks 和 4 query tasks。
- query 通过 `adapt=False`，只调用 `observe_context_only`；任务前后检查 model、optimizer、detector、replay 内容和 learning counter fingerprints。
- `no_active` 只关闭 support collection 的主动探索，query 恢复相同 checkpoint exploration settings，因此它不是“整个 query 阶段永远没有主动动作”的比较。
- probe bank 独立生成，在 support/query 之外；`changed_child_mask` 被明确定义为 potential observable dependency proxy，不是真实 causal truth。

### 聚合统计

`src/adrcml/aggregate_sessions.py:123`：

- 先按独立 training seed，再在 regime 内 paired sessions 做 bootstrap。
- 主任务 family 是 heldout_v1 的 `full_vs_diagnose_no_repair/query_return` 和 `full_vs_global_repair/query_return`。
- probe MSE 是 secondary family；其它 endpoints 进入 25-hypothesis exploratory family，并保留 undefined slots。
- Holm correction 作用于预设 family；`p<.05` 只在对应 protocol 和 family 下解释。

### 短回合评估

`outputs/v10/paper/seed_*/{sparse,dense}/evaluation/{profile}/{protocol}/` 的 `evaluation_comparison.json` 声明 inference scope 是 one fixed checkpoint，episode bootstrap/sign flip 不估计 training-seed uncertainty。因此本目录脚本把 100-episode 结果跨 8 seed 的合并单独标为 exploratory reanalysis，没有把它混进正式 session 主结论。

## 3. SCM 组件与完整智能体的边界

`src/adrcml/scm_benchmark.py:34` 是独立的 `ModularRegressor` 组件实验：

- 8 个完全观察状态节点，3 个动作；已知可分离 feature dictionary；训练、校准、诊断、支持、验收、query 和 rollout 使用分离 deterministic streams。
- `features_np` 使用 state/`tanh(2*state)` 加 intercept；`fit` 使用 group-penalized FISTA；`diagnose` 使用 calibration/evidence 残差差异；`accept_candidate` 使用目标收益与 collateral guard。
- SCM 的 success 只支持该估计器、特征字典和机制族下的 H=8 open-loop prediction，不支持神经世界模型、CEM 规划、MechanismMaze 任务回报、隐藏状态环境或完整智能体 causal identification。

因此，本文所有 SCM 正结果都在文稿中写作“组件级、受限条件下的预测收益”；不会写成完整 ADR-CML agent 的整体优势。

## 4. 配置和版本核对结论

- `protocol_manifest.json`：软件版本 10.0.0；8 个 neural training seeds；两架构各 100,000 steps；`device=cuda`；正式 session 12/12/4/512；SCM 10 seeds。
- 16 份 neural `run_metadata.json` 均为版本 10.0.0；32 份 session 结果 training steps 均为 100,000；正式结果的 source fingerprints 一致。
- 本地 `validation_results/tests/` 的 237 passed、4 skipped 是 CPU 软件测试记录，不是 4090 训练或性能证据。
- `V10_VALIDATION_REPORT.txt` 明确指出正式 paper 结果应区分 software correctness、component validity 和 full-agent research claim；本分析沿用该边界。
