# Springer Nature template package

This package uses the December 2024 Springer Nature journal article template
with the `sn-nature` option for a Nature Portfolio submission.

## Compile in Overleaf

1. Upload the ZIP file and open `paper_draft_nmi_en_sn.tex` as the main file.
2. Use `pdfLaTeX` as the compiler.
3. The package includes `sn-jnl.cls`, the Nature bibliography style file, and
   all six external PDF figures used by the manuscript.

The manuscript keeps references inside the main `.tex` file, so no BibTeX run
or external bibliography database is required. The figures and tables are
generated from existing project outputs; no training or evaluation run is
needed to compile this package. Session figures show the recorded
training-seed observations together with bootstrap mean
intervals; this is a display change only and does not add experiments.
