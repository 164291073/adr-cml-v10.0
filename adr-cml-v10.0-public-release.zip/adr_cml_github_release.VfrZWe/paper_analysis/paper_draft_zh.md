# 机制变化下的诊断与局部修复：从模块化动力学到神经智能体的证据校准研究

> 中文初稿（基于已有源码与结果）。本文有意不把组件级正结果扩写为完整智能体优势；结果中同时保留无显著优势、负结果和反例。

## 摘要

环境机制变化会使智能体既有的动力学预测和规划失配。一个自然的应对思路是先从预测残差中定位受影响的局部机制，再只更新相关参数，以减少对未改变机制的破坏。本文研究这一思路在两个层次上的证据是否一致：完全观察、已知特征字典的模块化机制估计器，以及带隐藏状态的神经关系世界模型智能体。系统由动作条件的稀疏关系世界模型、节点级 CUSUM 诊断器、带独立验收和未改变机制保护的局部/全局修复器，以及基于 CEM 的规划器组成。为避免把支持期拟合、修复接受率或单个 checkpoint 的预测变化误当成任务收益，我们采用独立 query、独立预测 probe、查询阶段冻结审计、训练 seed 层级聚合和预设多重比较。

在 10 个独立 seed 的 SCM 组件实验中，局部修复相对 no-repair 在 4 个变化条件中的 3 个条件通过 Holm 校正；相对带 replay 保护的全局修复，仅在线性系数变化和非线性新增边两个条件中通过校正，另两个条件没有显著优势。非线性新增边场景还出现明确反例：dense_global 的 H=8 递归误差显著低于局部修复。另一方面，在 8 个独立神经训练 seed、sparse/dense 两种架构和 heldout_v1 参数条件下，full 相对 diagnose_no_repair 与 global_repair 的预设 query-return 主比较均未通过校正；sparse 的点估计甚至低于两个对照，dense 的点估计为正但区间跨零。由此，现有证据支持“局部修复在受限组件条件下具有条件性预测收益”，不支持“完整神经智能体已经普遍优于强基线”或“系统完成了因果识别”。

**关键词：** 机制变化；在线诊断；局部修复；关系世界模型；模型基础强化学习；证据校准

## 1 引言

模型基础强化学习通过学习环境动力学并在模型中规划动作，将交互数据转化为可复用的预测模型[4]。当环境机制发生变化时，固定世界模型会出现预测残差，直接继续更新又可能破坏尚未改变的机制。因此，机制变化下的智能体需要同时回答三个问题：变化是否已经发生、哪些局部依赖受到了影响、以及局部更新能否转化为未来任务收益。

这些问题与因果表示学习和跨 context 因果发现的动机相近[1,2]，但不能被简单等同。因果表示学习关注从低层观测中恢复有意义的变量，跨 context 因果发现利用多环境或干预信息推断关系；而本项目中的主环境使用 8 维隐藏状态、动作条件关系和任务奖励，关系图评分是可观测转移依赖的代理指标。源码文档明确说明，该图门控并不保证从观察轨迹中获得因果可识别性。因此，本文把“机制变化适应”拆成可验证的预测与任务端点，而不把结构分数直接当作因果证明。

本文的第二个动机是证据链。局部修复在一个简单、完全观察、已知特征字典的模块化回归器中有效，并不意味着它会在神经世界模型和规划器中有效。后者还受到检测延迟、动作覆盖、修复接受、规划误差、任务前提和计算成本的共同影响。为此，正式协议预设了两个层次的实验：独立 SCM 组件审计和完整智能体 support/query 评估。

本文的贡献是：

1. 给出一个可审计的动作条件关系世界模型—变化诊断—证据门控修复闭环，并逐项对应实现细节；
2. 通过独立 seed、独立 query/probe、查询冻结 hash 和 Holm 校正，报告局部修复的正结果、无显著优势和明确反例；
3. 展示组件级预测收益没有自动迁移为完整神经智能体任务收益，并把这一证据断层作为主要结论，而不是选择性报告有利结果。

## 2 相关工作

### 2.1 因果表示学习与多 context 机制变化

Schölkopf 等人将因果变量、干预、分布变化和跨任务泛化联系起来，并把从低层观测发现因果变量视为重要问题[1]。Mooij 等人的 JCI 框架进一步讨论如何利用多个 context 和干预统一因果发现[2]。这两条路线为本文提供问题动机，但本文的 heldout_v1 只是在已知 MechanismMaze 机制族内改变阈值参数，不能被称为未知机制类型泛化或完整因果发现。

神经网络的表达能力也不能自动消除因果可识别性限制[3]。因此，本文将关系门解释为 action-conditioned predictive dependency，并把 SCM 组件与神经智能体分开报告。

### 2.2 模型基础强化学习与可干预环境

模型基础强化学习通常包含动力学建模和规划两个环节，并需要处理随机性、部分可观测性、模型误差和探索预算[4]。CausalWorld 等环境通过可干预因素和任务分布支持因果结构与迁移研究[5]；CausalDynamics 则面向动态系统结构发现提供包含噪声、混杂和滞后的更大规模基准[6]。相比这些外部基准，本文的环境规模和机制族更小，优势在于可以逐步审计诊断、修复、query 冻结和成本，而不是覆盖更广的真实任务。

### 2.3 在线变化检测

CUSUM 源自 Page 的连续检查方案[7]，在线 change-point filtering 也有 BOCPD 等概率方法[8]。本文实现的是作用于节点预测 NLL 的、带 action-conditioned baseline 和 robust window 的工程变体；它没有给出新的检测理论，也没有与 BOCPD 进行外部算法比较。本文关注的是检测后的局部修复是否改善独立未来行为。

## 3 问题定义

环境在时间 (t) 产生隐藏机制状态 (z_t)，智能体可观察带噪状态 (o_t)、执行动作 (a_t)，并接收 (r_t,o_{t+1})。机制变化可能改变某一动作条件下的参数或依赖关系。智能体不知道 (z_t)，也不能使用真实 changed-node 标签进行诊断或修复。

主环境 `MechanismMaze` 有 8 个状态节点：energy、material、key、bridge、door、crossed、artifact 和 shield；共有 10 个动作，其中 `probe_lock` 是信息动作，`shield_bridge` 在 v10 协议中是所有模式都可使用的生产性任务动作。heldout_v1 只改变 coupled_lock 和 fragile_bridge 的阈值范围；draining_key 保持为不变机制控制，因而它不是未见机制类型测试。

正式神经实验区分：

- `support`：允许在线更新、诊断和修复；
- `query`：从同一个 support 后状态出发，但禁止模型、优化器、诊断器、replay 和学习计数器改变；
- `probe`：独立生成的 512 个预测样本，不进入训练、修复接受或 query。

主要端点是 query return，次要端点是独立 probe MSE。主要 profile 是 heldout_v1；train profile 只作描述性比较。

## 4 方法

### 4.1 动作条件稀疏关系世界模型

源码 `src/adrcml/models/relational_world_model.py:32` 定义了 node-factorized transition model。每个 child 节点使用 parent gate 对当前状态以及历史状态/delta 特征进行遮罩；动作历史作为显式条件输入，reward history 不作为 transition 输入。对每个动作，模型维护 action-conditioned edge logits；对角线被强制为 always-on self dependency。sparse 模式使用 hard-concrete gates 和稀疏/parent-budget 正则，dense 模式将非对角关系设为全连接。

在正式配置中，hidden dimension 为 96，ensemble size 为 5，context window 为 8，context hidden dimension 为 32。模型同时预测下一状态均值/对数方差、reward、done 和 action-validity。训练损失由节点 NLL、状态 MSE、reward、done、可行性、稀疏、parent-budget 及 action-gate 项组成；变化 transition 通过 `transition_change_weight` 增权，但不使用真实机制标签。

### 4.2 节点级变化诊断

`src/adrcml/detection.py:19` 的 `NodewiseCUSUMDetector` 作用于节点预测误差。模型至少积累到 learning-start 之后才更新 detector；误差基线包含 EMA 与 robust history，动作样本足够时使用 action-conditioned baseline。CUSUM 超过阈值后，依据最近窗口的相对正证据选择 affected nodes。多次证据用于 median consensus，检测到的 action 还会触发短时间的 active boost。

这一步是预测残差诊断，而不是对真实变化机制的直接识别。特别是，只有在动作真正触发隐藏条件机制时，变化才会出现在观测残差中；未被激活的机制不能被当作“检测失败”或“图恢复成功”简单解释。

### 4.3 证据门控的局部与全局修复

`src/adrcml/repair.py:62` 的 `LocalMechanismRepair` 首先在一个全局时间 cutoff 上把变化后的 replay 证据划分为训练和验证，确保训练时间早于全部验证观察，并检查总样本量和目标 action 配额。局部模式只优化 affected child 的 incoming parameters，并用变化前 anchor 对未改变节点进行蒸馏；全局模式可优化全部节点参数，但两者共享同一个诊断目标、验证集和 collateral guard。

候选修复必须同时满足：目标节点验证 MSE 至少相对改善 0.5%、每个目标 action 都改善、NLL calibration guard 不恶化、未改变节点 MSE degradation 不超过 1%。否则恢复 teacher 状态，不提交 optimizer side effect。该机制使“有 repair attempt”与“未来任务变好”保持分离。

### 4.4 规划和主动动作

智能体在 `src/adrcml/agent.py:30` 中将世界模型、detector、repairer 和 `CategoricalCEMPlanner` 组成闭环。正式配置的 CEM horizon 为 16，population 为 512，elite 数为 64，迭代数为 5。active budget 为每个 task 最多 3 次；这只是相同的最大 allowance，不保证每种模式实际执行相同数量的 active actions、optimizer steps 或 repair steps，因此本文不声称 exact FLOP matching。

## 5 证据协议与统计单位

### 5.1 完整智能体

正式 paper 运行使用 8 个独立训练 seed（11、23、37、51、71、89、101、113），sparse/dense 各训练 100,000 steps。每个 checkpoint 在 train 和 heldout_v1 上各运行 12 sessions，每 session 12 个 support tasks 和 4 个 query tasks。相同训练 seed 的 sparse/dense 使用配对 task seeds；不同训练 seed 的 task/probe seeds 相互独立。

聚合器的统计单位是 `training_seed_then_paired_session_within_regime`，不是 episode。确认性 family 只包含 heldout_v1 的两个 query-return 对照：

1. `full - diagnose_no_repair`；
2. `full - global_repair`。

probe MSE 是独立的次要 family；其它 mode 和 train profile 是补充或描述性分析。所有 25 个预设 full contrasts 的探索性结果保留 correction slots，并用 Holm 校正。

### 5.2 独立 SCM 组件

`src/adrcml/scm_benchmark.py:34` 的 SCM 实验不是神经智能体。它使用 8 个完全观察节点、3 个动作和已知的可分离特征字典；linear 使用 state 特征，nonlinear 使用 state 与 (	anh(2x)) 特征。每个 child 由随机机制产生两个 parent，变化场景为 no_change、coefficient_shift 和 edge_addition。模块化回归器用 FISTA、group penalty 和 ridge penalty 更新 action-child mechanism。

SCM 使用 10 个独立 seed，H=8 是预设主要递归预测时域。`global_replay` 额外复用固定数量的 pretraining anchor 来保护诊断认为未改变的机制；`dense_global` 是强结构基线。SCM 的 H=8/H=32 是 open-loop prediction，不是长程任务成功率。

## 6 实验结果

### 6.1 SCM：局部收益是条件性的

表 1 的效应定义为 baseline MSE 减去 local MSE，正值有利于 local。CI 和 Holm p 来自 10 个 independent seed 的预设比较。

| 机制族 | 变化 | 对照 | H=8 效应 | 描述性 95% CI | Holm p | 结论 |
|---|---|---|---:|---:|---:|---|
| linear | coefficient_shift | no_repair | (+4.5549\times10^{-5}) | [(3.0606\times10^{-5}), (6.0211\times10^{-5})] | .03125 | 支持 local |
| linear | edge_addition | no_repair | (+1.1658\times10^{-5}) | [(7.8021\times10^{-6}), (1.6205\times10^{-5})] | .03125 | 支持 local |
| nonlinear | coefficient_shift | no_repair | (+1.7631\times10^{-4}) | [(1.1519\times10^{-4}), (2.3500\times10^{-4})] | .03125 | 支持 local |
| nonlinear | edge_addition | no_repair | (+1.2624\times10^{-5}) | [(-1.55\times10^{-7}), (2.9313\times10^{-5})] | .49219 | 无校正后的优势证据 |

相对更强的 `global_replay`，local 在 linear/coefficient_shift 中的效应为 (+9.1103\times10^{-6})，Holm p=.03125；在 nonlinear/edge_addition 中为 (+6.6156\times10^{-6})，Holm p=.046875。linear/edge_addition 的 Holm p=.05859，nonlinear/coefficient_shift 的 Holm p=.84180，不能写成普遍优势。

最重要的反例来自 nonlinear/edge_addition：`dense_global - local` 的 H=8 效应为 (-1.0507\times10^{-4})，CI 为 ([-1.3331\times10^{-4},-8.3433\times10^{-5}])，Holm p=.03125；负号表示 dense_global 的误差更低。同一场景 local 相对 no_repair 的 Holm p=.49219。这个结果说明，局部性本身不是所有机制形式下的优越归纳偏置。

### 6.2 完整神经智能体：主端点没有确认性优势

表 2 使用正式 heldout_v1 session 聚合。query return 越高越好，primary Holm p 在两个预设任务回报比较的 family 内计算。

| 架构 | 对照 | full - 对照 query return | 95% CI | raw p | primary Holm p |
|---|---|---:|---:|---:|---:|
| sparse | diagnose_no_repair | -.01650 | [-.04944, .01444] | .17969 | .35938 |
| sparse | global_repair | -.01684 | [-.05399, .01616] | .28125 | .35938 |
| dense | diagnose_no_repair | +.01712 | [-.01672, .05353] | .12500 | .25000 |
| dense | global_repair | +.01349 | [-.03521, .07317] | .83594 | .83594 |

因此 sparse 的点估计不但没有显示收益，方向还略差于两个对照；dense 的点估计虽为正，但不确定性足以覆盖零，且 full 相对 global_repair 的 raw p 很大。这个结果直接否定“完整神经智能体已被证明优于强基线”的表述。

独立 probe 也不能替代任务回报。sparse heldout 中 full 相对 diagnose_no_repair 的 probe MSE 差为 (+1.27\times10^{-6})，secondary Holm p=.97656；相对 global_repair 为 (-2.32\times10^{-5})，Holm p=.90625。dense heldout 的对应 Holm p 为 .89063 和 .46094。没有校正后的预测优势证据。

### 6.3 架构比较和短回合补充

架构比较是独立训练的 dense ablation，不是外部发表基线。heldout full query-return 的 sparse−dense 差为 -.00266，CI [-.05147,.04633]，Holm p=1.0；train profile 的差为 +.02225，Holm p=.75。heldout probe MSE 的 sparse−dense 差为 (+1.7319\times10^{-4})，CI 跨零；train profile 中差为 (+2.5741\times10^{-4})，Holm p=.03125，方向反而显示 dense 的 probe MSE 更低。因而不能把 sparse 结构偏置写成一致的任务/预测优势。

每个 checkpoint 的 100-episode 短回合评估在原始文件中以“单 checkpoint 内的配对 episode”为推断单位。本研究将其跨 8 个训练 seed 重新汇总，仅作为探索性描述：balanced_shift 下 sparse full−diagnose_no_repair 的平均 return 差约 -.00032，dense 约 +.00024；这些数值没有替代正式 session 主检验。no_shift 中机制没有被激活，full 与不修复模式相同或近似相同，不能用于支持机制适应。

### 6.4 检测、图指标和代价

balanced_shift 短评估中，full 的平均 diagnosis F1 约为 sparse .400、dense .442；对应 graph F1 约为 sparse .452、dense .564。它们只能说明当前配置下残差诊断和 predictive dependency proxy 的表现，不能说明真实因果图已被识别。尤其是 graph target 是 observable action-transition dependency proxy，且部分 top-k 诊断使用 oracle-K。

同一最大 active allowance 不等于同一计算预算。正式 sparse/heldout_v1 session 中，按训练 seed 平均的 support active actions 约为 full 260.5、global_repair 259.9、diagnose_no_repair 262.0、online_only 160.8；repair optimizer steps 约为 full 2548、global_repair 2668，其他不修复模式为 0。代价和回报必须一起报告，不能称为 exact FLOP-matched。

## 7 讨论

### 7.1 为什么组件收益没有自动迁移到任务收益

SCM 组件使用完全观察状态、已知特征字典、随机动作干预和稳定的线性/非线性回归结构；诊断目标与真实机制的关系更直接。完整智能体则需要在隐藏状态、动作前提、奖励和规划误差中发现变化，并且只有被特定动作激活的机制才会产生可观察残差。修复还受到 target-action evidence、chronological holdout、未改变节点保护和 query 行为的共同约束。因此，组件中“局部参数更新降低未来预测误差”只是必要条件之一，不足以推出“智能体完成任务更好”。

一个与源码和记录一致、但应标为事后解释的候选瓶颈是诊断到修复的链条：balanced_shift 短评估中 full 的平均 diagnosis F1 只有约 .40–.44，且每个 checkpoint 被接受的 repair 数量很少。这个解释不是独立的因果实验结论，只能作为后续研究假设；当前硬约束下不启动补充实验。

### 7.2 局部性不是无条件优越的归纳偏置

局部更新通过梯度遮罩和 anchor distillation 保护未改变节点，这一设计在 SCM 的线性系数变化和非线性新增边中有帮助。但 nonlinear/edge_addition 中 dense_global 明显更优，可能反映新增边需要跨多个参数或共享表示重构。因为当前项目没有做机制类型扩展、参数规模扩展或外部算法比较，本文只能将其写成边界证据，不能提出普适的局部修复定理。

### 7.3 统计解释

8 个训练 seed 的 exact two-sided sign-flip p 值分辨率有限，CI 是嵌套 seed/session bootstrap 的描述性区间；无显著不等于等效。100-episode 短评估的 episode bootstrap 只衡量单 checkpoint 的条件不确定性，跨 seed 重算是探索性统计。论文中应同时给出所有 seed、效应量、区间、校正 family 和失败/反例，避免把显著的单个补充端点替代主任务端点。

## 8 局限

1. 主环境是自定义 MechanismMaze，8 个状态节点、10 个动作，不能代表真实机器人或更大规模环境。
2. heldout_v1 只留出已知机制族内的阈值范围，不是未知机制类型留出。
3. 图指标是 predictive dependency proxy，不是 causal identification；隐藏状态和 action/history 门控限制因果解释。
4. 没有外部强算法、外部发表基线、真实环境、多任务或更长任务长度的证据。
5. active allowance 只匹配最大次数，不匹配实际 action、优化更新、repair steps 或 FLOPs。
6. SCM 的 H=8/H=32 是开环递归预测，不是完整智能体长程任务成功率。
7. 当前正式神经结果不支持主任务回报优势，因此不能在不增加证据的情况下承诺 CCF A 或中科院一区投稿成功。

## 9 结论

本文对机制变化下的智能体诊断与局部修复进行了分层证据审计。结果显示：局部修复不是没有价值；在完全观察、已知字典的 SCM 组件中，它在若干预设机制变化下改善了 H=8 未来预测，并在部分条件下超过 replay-global。然而，组件收益没有在当前完整神经智能体的确认性 query-return 端点上稳定出现，且存在 dense_global 在非线性新增边上胜出的反例。

因此，本文的可靠结论不是“局部修复已经解决了机制变化”，而是：**局部修复的效果具有机制和系统层级条件性；独立 query/probe 和训练 seed 层级审计揭示了从局部预测改进到完整任务恢复之间的证据断层。** 这一定位与当前源码和已有输出一致，也为后续需要补齐的检测、覆盖、机制泛化和外部基准研究留下明确边界。

## 参考文献

[1] Schölkopf, B. et al. Toward Causal Representation Learning. *Proceedings of the IEEE*, 109(5):612–634, 2021. DOI: 10.1109/JPROC.2021.3058954.

[2] Mooij, J. M., Magliacane, S., and Claassen, T. Joint Causal Inference from Multiple Contexts. *JMLR*, 21(99):1–108, 2020.

[3] Xia, K., Lee, K.-Z., Bengio, Y., and Bareinboim, E. The Causal-Neural Connection: Expressiveness, Learnability, and Inference. *NeurIPS 34*, 2021.

[4] Moerland, T. M. et al. Model-based Reinforcement Learning: A Survey. *Foundations and Trends in Machine Learning*, 16(1):1–118, 2023. DOI: 10.1561/2200000086.

[5] Ahmed, O. et al. CausalWorld: A Robotic Manipulation Benchmark for Causal Structure and Transfer Learning. *ICLR 2021*.

[6] Herdeanu, B. et al. CausalDynamics: A Large-Scale Benchmark for Structural Discovery of Dynamical Causal Models. *NeurIPS 38*, Datasets and Benchmarks Track, 2025.

[7] Page, E. S. Continuous Inspection Schemes. *Biometrika*, 41(1–2):100–115, 1954.

[8] Altamirano, M., Briol, F.-X. and Knoblauch, J. Robust and Scalable Bayesian Online Changepoint Detection. *ICML 40*, PMLR 202:642–663, 2023.
