# 第三步：论文证据表

约定：任务回报越高越好；probe MSE 越低越好；SCM 表中的效应定义为 `baseline H=8 MSE - diagnosed_local H=8 MSE`，因此正值表示局部修复误差更低。所有 CI 是已有报告中的描述性 bootstrap CI；seed-level sign-flip p 值依赖独立 seed 和零假设下符号可交换等假设。

## A. 可直接支持的结论

| 拟提出的结论 | 支持文件 | 具体统计结果 | 适用条件 | 反例/无显著优势 | 局限与写法 |
|---|---|---|---|---|---|
| 局部修复在部分完全观察的 SCM 变化场景中改善独立未来预测 | `outputs/v10/paper/scm/summary.json`；`scm/seed_*.json` | 相对 `no_repair`：linear/coefficient_shift `+4.5549e-5`，95% CI `[3.0606e-5,6.0211e-5]`，Holm p=`.03125`；linear/edge_addition `+1.1658e-5`，CI `[7.8021e-6,1.6205e-5]`，Holm p=`.03125`；nonlinear/coefficient_shift `+1.7631e-4`，CI `[1.1519e-4,2.3500e-4]`，Holm p=`.03125` | 10 个独立 seed；8 节点、3 动作；完全观察；已知可分离特征字典；模块化回归器；递归无噪声 H=8 | nonlinear/edge_addition：`+1.2624e-5`，CI `[-1.55e-7,2.9313e-5]`，Holm p=`.49219` | 可写成“部分 SCM 条件下有效”，不能写成神经智能体或通用因果发现有效。将“哪些条件有效”的归纳标为看过结果后的探索性总结；四个场景本身都在预设比较家族内。 |
| 局部修复在部分场景优于带 replay 保护的全局修复 | 同上 | linear/coefficient_shift：`+9.1103e-6`，CI `[2.1000e-6,2.1922e-5]`，Holm p=`.03125`；nonlinear/edge_addition：`+6.6156e-6`，CI `[2.6003e-6,1.1525e-5]`，Holm p=`.046875` | 同上；global_replay 使用固定数量训练期 anchor 保护未改变机制，成本单独记录 | linear/edge_addition Holm p=`.05859`；nonlinear/coefficient_shift Holm p=`.84180`，均无校正后的优势证据 | “局部优于全局”必须带机制形式和基线条件，不能泛化成普遍优势。 |
| v10 实现了可审计的 support/query 冻结协议 | `src/adrcml/evaluate_sessions.py:102-160,345-600`；32 份 `session_evaluation.json` 和 `session_episodes.json` | 32 个 session 结果；每个 session 12 support + 4 query；查询前后 model/optimizer/detector/replay hash 审计；独立 probe 512 样本、readonly audit | 已有训练 checkpoint、已知 MechanismMaze mechanism family；查询只冻结参数，观察历史仍会演化 | 审计完整不是效果优势；probe 的 changed-child 是可观测依赖代理，不是真实因果 child 标签 | 可作为协议/工程贡献，不能单独作为算法新颖性或因果识别证明。 |

## B. 重要的零结果、负结果和反例

| 拟提出的结论 | 支持文件 | 具体统计结果 | 适用条件 | 反例/无显著优势 | 论文处理 |
|---|---|---|---|---|---|
| 完整神经智能体的 full 在 heldout_v1 上优于不修复/全局修复 | `outputs/v10/paper/aggregate/sparse_heldout_v1_sessions.json`、`dense_heldout_v1_sessions.json` | sparse：full−diagnose_no_repair `−.01650`，CI `[-.04944,.01444]`，primary Holm p=`.35938`；full−global_repair `−.01684`，CI `[-.05399,.01616]`，Holm p=`.35938`。dense：full−diagnose_no_repair `+.01712`，CI `[-.01672,.05353]`，Holm p=`.25`；full−global_repair `+.01349`，CI `[-.03521,.07317]`，Holm p=`.83594` | 确认性 profile=heldout_v1；8 独立训练 seed；12 session/seed；主端点是 query return | sparse full 的点估计反而低于两个对照；dense 虽点估计为正，但 CI 跨零且校正后不显著 | 不能声称神经智能体整体优越；这是当前最重要的负证据。 |
| full 的预测 probe 改善可替代任务回报改善 | 同上聚合 JSON | sparse heldout：full−diagnose probe MSE `+1.27e-6`，secondary Holm p=`.97656`；full−global `−2.32e-5`，secondary Holm p=`.90625`。dense heldout：分别 `+2.44e-6`（Holm `.89063`）和 `−2.82e-5`（Holm `.46094`） | probe 是独立库；MSE 端点是预设次要家族 | probe 方向在不同对照间不一致，且没有校正后的证据 | 不把预测端点替代 primary task-return；如展示，必须同时给回报和 probe。 |
| 主动探索是完整智能体的已证实优势 | `outputs/v10/paper/aggregate/*_sessions.json`；`exploratory_short_eval.csv` | sparse heldout full−no_active query return `+.00445`，exploratory Holm=`1.0`；dense heldout `+.01517`，exploratory Holm=`1.0`；train profile sparse `+.00510`、dense `−.01171`，均无校正优势 | no_active 只关闭 support 期主动探索，query 恢复相同探索设置 | train/dense 方向与 sparse 不一致；主动 action allowance 是上限而非实际相同动作或 FLOPs | 只写为补充/探索性现象，不能作为主贡献。 |
| 局部修复普遍优于更强全局基线 | `outputs/v10/paper/scm/summary.json` | nonlinear/edge_addition 中 dense_global−local `−1.0507e-4`，CI `[-1.3331e-4,-8.3433e-5]`，Holm p=`.03125`；负号表示 dense_global MSE 更低 | SCM 组件；同一非线性新增边场景；H=8 | 这是局部方法明确的反例；同场景 local−no_repair Holm p=`.49219`，也无主要指标优势 | 必须保留，不能用“局部性”叙事掩盖。 |
| sparse 架构在预测和任务上都优于 dense | `outputs/v10/paper/architecture_comparison_heldout_v1.json`、`architecture_comparison_train.json` | heldout query：sparse−dense `−.00266`，CI `[-.05147,.04633]`，Holm p=`1.0`；heldout probe MSE `+.000173`，CI 跨零，Holm p=`.28125`。train query `+.02225`，Holm `.75`；train probe MSE `+.000257`，CI `[.000136,.000381]`，Holm p=`.03125` | 两架构独立训练，各 8 seed；dense 是内部 ablation，不是外部发表基线；heldout 才是确认性 profile | train probe MSE 显著方向反而支持 dense；heldout query 没有差异证据 | 只能写成架构敏感性/内部对照，不能写成外部 SOTA 比较。 |
| causal graph 分数证明了因果识别 | `src/adrcml/models/relational_world_model.py:32-43`；短评估 `evaluation_full.json` | 例如 balanced_shift full 的平均 graph F1 约 sparse `.4523`、dense `.5641`；graph target 定义为 observable action-transition dependency proxy | 图指标是 action-conditioned predictive dependency proxy；top-k 使用 oracle-K，仅作诊断 | 源码 docstring 明确不保证 causal identifiability；隐藏状态、代理标签、最终 snapshot vs regime union 都限制解释 | 只能说“预测依赖结构代理恢复”，不能写“发现真实因果图”或“完成因果识别”。 |

## C. 完整性和代价证据

| 事实 | 支持文件 | 解释 |
|---|---|---|
| formal paper 阶段全部有记录 | `outputs/v10/paper/protocol_manifest.json`、`stage_status/*.json` | 163/163 stage completed；这是数据链路完整性，不是效果成功。 |
| 神经证据来自 8 个独立训练 seed | 16 个 checkpoint、32 个 session 聚合 | 不能把 12×4 query episodes 当成 384 个独立训练重复；聚合器使用 `training_seed_then_paired_session_within_regime`。 |
| active budget 不是 exact compute matching | manifest、`session_evaluation.json`、`docs/V10_EXPERIMENT_PROTOCOL.md` | 各模式最多 3 个主动动作，但实际 action 数、optimizer steps、repair steps 不相同；只能说相同最大 allowance。 |
| probe coverage 不均匀 | `session_evaluation.json` 的 `probe_after.mechanism_activated_transitions` | formal session 中 fragile_bridge 的 activated transition 数明显少于其他 regime；changed-child MSE 不能单独证明对变化机制的适应。 |

## D. 当前可用的总判断

最稳妥的总论断是：**v10 建立了一个具有独立 query/probe 审计的机制变化诊断与局部修复实现；局部修复在完全观察、已知特征字典的 SCM 组件中对部分机制变化有效，但这种收益没有在当前正式神经智能体的确认性 query-return 端点上得到支持，且存在 dense_global 胜出的非线性新增边反例。**

这是一条“组件有效性与系统级迁移之间存在证据断层”的论文主线，而不是“完整智能体已经优于所有对照”的论文主线。
