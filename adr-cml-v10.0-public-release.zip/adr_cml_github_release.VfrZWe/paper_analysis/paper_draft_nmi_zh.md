# 机制变化下模型基础智能体的预测机制诊断与局部修复

> Nature Machine Intelligence Article 风格中文工作稿。作者信息已补充；该稿以现有实验记录为边界，不把组件级结果外推为完整智能体优势。最终投稿仍需英文母语化和图表重排。

**作者：刘清扬**  
**单位：华东理工大学信息科学与工程学院**  
**通讯邮箱：qingyang.liu@ecust.edu.cn**

## 摘要

环境机制变化会使智能体既有的动力学模型失配。局部修复从预测残差中定位预测误差发生变化的状态变量，只更新相应机制。本文检验局部修复的预测收益能否从受控模块化系统迁移到隐藏状态神经智能体。系统由动作条件稀疏关系世界模型、节点级变化检测器、带验证门控的局部与全局修复器，以及基于模型的规划组成。在完全观察的合成机制基准中，局部修复相对于 no-repair 在四个预设变化条件中的三个条件降低了开环递归预测误差；但非线性新增边条件是反例，其中 dense global 的误差低于局部修复。在隐藏状态智能体中，8 个独立训练 seed 进行配对 support/query 评估。经过多重比较校正后，无论是 sparse 还是 dense 架构，full 诊断—修复相对于 no-repair 或 global repair 都没有显示 query return 优势。因此，组件级预测收益不能作为当前智能体任务收益改善的证据。

模型基础强化学习将学习到的转移模型与规划或想象 rollout 结合起来。已有方法包括 Dyna、概率模型基础控制、潜在空间规划、Dreamer 和 MuZero <sup>4,9–16</sup>。这些工作说明了如何利用学习到的模型进行决策，但没有回答环境发生局部机制变化后应更新模型的哪一部分。

CausalWorld 和 CausalDynamics 等 benchmark 将结构迁移和动态因果发现显式化，但它们评价的设置与本文的程序化环境不同 <sup>5,6</sup>。

快速适应工作通过元学习动力学先验、潜在任务变量、策略驱动的模型更新以及上下文或事件表征来处理这一问题 <sup>17–24</sup>。近期工作还研究了模块化潜在世界模型和因果过程模型 <sup>22,25</sup>。本文的问题更窄：不是证明世界模型能够在任意测试时协议下适应，而是检验检测器提出的局部更新是否改善模型冻结后的 query return。

因果表示和不变预测研究构成本文的识别边界 <sup>1–3,29–31</sup>。动态因果发现方法通常依赖干预、时间约束或明确的结构假设 <sup>32–35</sup>；关系推断模型则可以从观察数据学习预测性交互，但不保证因果识别 <sup>38</sup>。近期因果智能体工作将主动干预发现与变化图结构结合起来 <sup>25,27</sup>，但这并不能把本文的预测门控自动变成可识别的因果图。本文的检测器与变化点和概念漂移监测有关 <sup>7,8,24,28</sup>，稀疏门控与连续松弛和随机稀疏化有关 <sup>36,37</sup>。因此，本文将学习到的 adjacency 解释为预测依赖代理，并将结构机制组件结果与隐藏状态完整智能体分开报告。

本文将两个容易混淆的端点分开：完全观察模块化组件中的开环预测误差，以及完整智能体冻结 query 阶段的任务回报。这样的设计用于检验局部预测更新能否迁移到任务行为，而不把组件级结果直接当作完整智能体收益的证据。

## 结果

### 机制变化将模型适应分解为三个问题

机制变化下的智能体需要回答三个相互关联但不能混为一谈的问题：变化是否发生，哪些预测依赖受到影响，以及局部更新是否改善未来行为。本文分别使用节点预测误差、独立 probe 的前向预测 MSE 和冻结 query 阶段的任务回报来描述这三个量。support 阶段允许学习、诊断和修复；query 阶段从 support 结束状态开始，并冻结模型、优化器、诊断器、replay 和学习计数器。每个 session 的 query return 定义为 4 个 query episodes 的平均 episode return。

本文研究的主环境是项目自定义的 `MechanismMaze`，是一个包含 8 个状态节点和 10 个动作的隐藏状态环境，机制变化具有动作条件。训练使用 `train` profile，主要泛化评估使用 `heldout_v1`；后者改变的是已知机制族内的阈值分布，而不是全新的机制类型。项目代码还保留了可选的 CausalWorld 适配器，但本文报告的正式实验结果没有使用 CausalWorld 或其他外部静态数据集；实验轨迹由环境交互程序化生成。

### 一个以预测依赖为中心的诊断—修复闭环

智能体使用节点分解的关系世界模型。对每个 child j，动作条件的 parent gates 对其他状态变量的对应特征及其历史 state/delta 特征进行遮罩，child 自身的对角依赖始终保留。稀疏模型使用 Hard-Concrete 风格的可微门控、非对角边稀疏惩罚和父节点预算；dense 对照将图设为全连接并关闭这些结构正则。reward history 不作为 parent-gated state input。该图约束的是 action-conditioned predictive information path，而不是由观察轨迹保证的因果可识别结构。

节点级 CUSUM 检测器对预测 NLL 进行鲁棒、动作条件的基线校正，并在局部窗口内定位受影响节点。局部修复只更新受影响 child 的 incoming mechanism，同时对未改变节点进行 anchor distillation；全局修复更新全部节点。两者都必须通过同一套验证条件：目标节点预测改善、目标 action 覆盖、NLL guard 以及未改变节点的 collateral degradation guard。验证失败则回滚到 teacher 状态。

这个设计把“提出修复”与“修复有效”分开。修复接受率、图分数和训练期 loss 不能替代独立 query 行为。

### 局部修复在模块化系统中有条件地改善预测

首先，我们在独立的结构机制组件中检验局部修复的预测效果。该组件使用 8 个完全观察节点、3 个动作、已知特征字典、线性或非线性机制，以及 coefficient shift 或 edge addition。每个条件使用 10 个独立 seed，主要指标是预测时域 (H=8) 的开环递归 MSE。该组件评估的是已知特征结构下的预测机制修复，不是因果识别实验。

我们报告 `baseline MSE − local-repair MSE`，正值有利于局部修复。`global_replay` 和 `dense_global` 是结构机制组件中的对照，`global_repair` 则是完整神经智能体中的修复模式；这些条件不合并分析。相对于 no-repair，局部修复在四个变化条件中的三个通过预设 Holm 校正：linear/coefficient_shift 的效应为 4.55 × 10⁻⁵（95% CI [3.06, 6.02] × 10⁻⁵），linear/edge_addition 为 1.17 × 10⁻⁵（95% CI [0.78, 1.62] × 10⁻⁵），nonlinear/coefficient_shift 为 1.76 × 10⁻⁴（95% CI [1.15, 2.35] × 10⁻⁴）。nonlinear/edge_addition 的效应为 1.26 × 10⁻⁵（95% CI [−0.02, 2.93] × 10⁻⁵），校正后 p=0.492；因此不能写成四种条件下都有效。

相对于 `global_replay`，证据并不一致。local 在 linear/coefficient_shift 中的效应为 9.11 × 10⁻⁶（95% CI [2.10, 21.92] × 10⁻⁶，Holm p=0.03125），在 nonlinear/edge_addition 中的效应为 6.62 × 10⁻⁶（95% CI [2.60, 11.52] × 10⁻⁶，Holm p=0.046875）。linear/edge_addition 的效应为 2.36 × 10⁻⁶（95% CI [1.09, 3.41] × 10⁻⁶，Holm p=0.05859），nonlinear/coefficient_shift 的效应为 −0.61 × 10⁻⁶（95% CI [−5.81, 5.29] × 10⁻⁶，Holm p=0.84180），校正后均不能作为优势证据。这里的置信区间未作多重性校正，而 p 值经过 Holm 校正；因此置信区间可以不包含零，而校正后 p 值仍高于 0.05。最明确的反例来自 nonlinear/edge_addition：`dense_global − local` 的 H=8 效应为 −1.05 × 10⁻⁴，95% CI 为 [−1.33, −0.83] × 10⁻⁴，Holm p=0.03125；负号表示 dense_global 的递归误差更低。由此，局部性不是独立于机制族的优越归纳偏置。

![图 1. 结构机制组件相对于 global_replay 的对比](figures/scm_global_replay_effects.svg)

**图 1｜结构机制组件相对于 `global_replay` 的对比。** 点表示四个机制/变化条件下 (H=8) 的递归 MSE 差异（`global_replay - local`），水平误差线表示十个组件 seed 计算得到的 95% 置信区间；竖直线表示零差异。正值有利于局部修复。校正后的比较和 nonlinear/edge_addition 反例已在正文与表 1 中报告。

### 完整智能体中没有确认性任务优势

完整智能体实验使用 8 个独立训练 seed，sparse 和 dense 各训练 100,000 steps。每个模型在 `heldout_v1` 上进行 support/query session，query 阶段冻结模型、优化器、诊断器、replay 和学习计数器。统计独立单位是 training seed 内按 regime 配对的 session，而不是单个 episode。

在 heldout_v1 上，sparse 的 full 相对于 diagnose-no-repair 的 query-return 差异为 −0.01650，95% CI 为 [−0.04944, 0.01444]，Holm p=0.35938；相对于 global-repair 的差异为 −0.01684，95% CI 为 [−0.05399, 0.01616]，Holm p=0.35938。dense 的对应差异分别为 0.01712（95% CI [−0.01672, 0.05353]，Holm p=0.25000）和 0.01349（95% CI [−0.03521, 0.07317]，Holm p=0.83594），每项比较均为 (n=8)。sparse 的两个差异均为负；dense 的两个差异虽为正，但置信区间均覆盖零。因此，现有结果不支持完整诊断—修复流程在该环境中的任务回报优势。

独立 probe MSE 同样没有为完整智能体的主要结论提供多重比较校正后的优势证据。sparse 的 full−diagnose_no_repair probe MSE 差异为 1.27 × 10⁻⁶（95% CI [−7.06, 6.58] × 10⁻⁵，校正后 p=0.97656），dense 的 full−global_repair 差异为 −2.82 × 10⁻⁵（95% CI [−1.03, 0.52] × 10⁻⁴，校正后 p=0.46094）。架构比较中，train profile 的 sparse−dense probe MSE 差异为 2.57 × 10⁻⁴（95% CI [1.36, 3.81] × 10⁻⁴，校正后 p=0.03125），方向表示 dense 的 probe MSE 更低；但 heldout query-return 没有区分两种架构。训练 profile 上较低的模型误差不能作为 held-out 参数上适应更好的证据。

![图 2. sparse 与 dense 架构的 query return 对比](figures/architecture_query_return.svg)

**图 2｜sparse 与 dense 架构的 query-return 对比。** 点表示各 profile 和 session 条件下的 query-return 差异（`sparse - dense`），水平误差线表示八个独立训练 seed 的 95% 置信区间；竖直线表示零差异。正值有利于 sparse 架构。heldout `full` 比较的区间覆盖零，与表 2 的任务级主要比较一致。

稀疏和 dense 架构在 `heldout_v1` profile 下的绝对 query-return 图见 Fig. 2 和 Fig. 3；对应的 `train` profile 图见 Extended Data Fig. 1 和 Extended Data Fig. 2。这些图用于描述性展示；确认性比较仍以表 2 的 seed 层级配对差异为准。

### 组件级预测收益不能推出系统级收益

结构机制组件中的局部修复使用完全观察状态、已知特征字典和明确的模块化目标；完整智能体还要面对隐藏状态、变化是否被动作激活、检测延迟、有限主动预算、修复验收和 CEM 规划误差。当前结果不能判断其中哪个环节是唯一瓶颈，但可以排除一种过强推论：组件级局部预测收益并不自动证明完整智能体的任务级适应有效。

这也是本文对“因果机制学习”表述的限制。主环境中的图分数反映可观测预测依赖代理，不是完整结构因果模型的因果识别；结构机制组件的正结果也不等于神经世界模型已经恢复了因果结构。

## 讨论

本文的主要结论不是局部修复在所有环境中优于全局修复，而是其收益取决于机制可观察性、变化覆盖和修复后的行为链条。在当前证据中，局部修复在受控结构机制任务中具有条件性预测收益，但完整智能体的 heldout query-return 没有确认性提升。在该协议下，修复接受率、图分数和预测误差不能单独证明任务行为改善；冻结 query 阶段的行为才是主要任务端点。

本文不能支持以下主张：完整因果图识别、未知机制类型泛化、真实环境有效性、外部 benchmark 上的领先性能，或完整智能体的长程任务优势。`heldout_v1` 只改变已知机制族内的参数分布；结构机制实验的 H=8 是开环预测时域，不是任务成功率；相同的 active-action allowance 也不代表实际 FLOPs 相同。

## 方法

### 实验对象与数据生成

完整智能体数据由项目内置 `MechanismMaze` 通过交互程序化生成，不依赖外部静态数据集。环境含 8 个状态节点、10 个动作、隐藏 regime 和三类机制变化模式。正式实验使用 8 个训练 seed（11、23、37、51、71、89、101、113），每种架构训练 100,000 steps。结构机制组件使用 10 个 seed（11、23、37、51、71、89、101、127、149、173），覆盖 linear/nonlinear 与 no_change/coefficient_shift/edge_addition。

### 统计协议

正式 session 使用 support/query 分离：support 允许在线学习、诊断和修复；query 从同一 support 后状态出发并冻结全部学习状态。probe 由独立样本生成，不参与训练或验收。主 profile 是 `heldout_v1`；train profile 仅作描述性比较。主要比较是 `full - diagnose_no_repair` 和 `full - global_repair` 的 query return，次要比较是独立 probe MSE。效应量、置信区间、双侧 sign-flip p 值及预设比较家族的 Holm 校正均按 training-seed 层级配对结果计算。

### 可复现性与审计

正式 paper inventory 记录 163 个已完成的阶段状态；其中包括 16 个训练运行、32 个 session 评估和 96 个完整 evaluation summary 等协议阶段。另有 60 个已完成的结构机制条件结果行。源码指纹、配置哈希、训练 seed、session pairing 和 query freeze checks 均记录在原始实验输出目录中。本文的分析脚本只读取已有 JSON/CSV 记录，不加载 checkpoint 或 replay binary，也不启动新的训练或评估。

## 数据与代码可用性

本文报告的所有数据均由 `MechanismMaze` 环境和结构机制生成器程序化生成，未使用外部静态数据集。源码、生成协议、分析表和聚合结果将在投稿时上传至公开仓库，并向编辑和审稿人提供仓库 URL 或匿名审稿链接。CausalWorld 适配器未用于本文报告的实验。

## 作者信息

## 作者贡献

Q.L. 负责研究构思、实验实现、数据分析和论文撰写。

刘清扬，华东理工大学信息科学与工程学院。通讯作者：qingyang.liu@ecust.edu.cn。

## 致谢

无。

## 基金

本研究没有基金资助。

## 利益冲突

作者声明不存在利益冲突。

## 参考文献

1. Schölkopf, B. et al. Toward causal representation learning. *Proc. IEEE* **109**, 612–634 (2021). https://doi.org/10.1109/JPROC.2021.3058954
2. Mooij, J. M., Magliacane, S. & Claassen, T. Joint causal inference from multiple contexts. *J. Mach. Learn. Res.* **21**, 1–108 (2020). https://jmlr.org/papers/v21/17-123.html
3. Xia, K., Lee, K.-Z., Bengio, Y. & Bareinboim, E. The causal-neural connection: expressiveness, learnability, and inference. *NeurIPS* **34** (2021). https://proceedings.neurips.cc/paper/2021/hash/5989add1703e4b0480f75e2390739f34-Abstract.html
4. Moerland, T. M., Broekens, J., Plaat, A. & Jonker, C. M. Model-based reinforcement learning: a survey. *Foundations and Trends in Machine Learning* **16**, 1–118 (2023). https://doi.org/10.1561/2200000086
5. Ahmed, O. et al. CausalWorld: a robotic manipulation benchmark for causal structure and transfer learning. *ICLR* (2021). https://openreview.net/forum?id=SK7A5pdrgov
6. Herdeanu, B. et al. CausalDynamics: a large-scale benchmark for structural discovery of dynamical causal models. *NeurIPS* **38**, Datasets and Benchmarks Track (2025). https://proceedings.neurips.cc/paper_files/paper/2025/hash/39a3f7dc00e4723a5ca7808b04fc4d4f-Abstract-Datasets_and_Benchmarks_Track.html
7. Page, E. S. Continuous inspection schemes. *Biometrika* **41**, 100–115 (1954). https://doi.org/10.1093/biomet/41.1-2.100
8. Altamirano, M., Briol, F.-X. & Knoblauch, J. Robust and scalable Bayesian online changepoint detection. *ICML* **40**, 642–663 (2023). https://proceedings.mlr.press/v202/altamirano23a.html
9. Sutton, R. S. Dyna, an integrated architecture for learning, planning, and reacting. *SIGART Bull.* **2**, 160–163 (1991). https://doi.org/10.1145/122344.122377
10. Ha, D. & Schmidhuber, J. Recurrent world models facilitate policy evolution. *NeurIPS* **31** (2018). https://papers.nips.cc/paper/7512-recurrent-world-models-facilitate-policy-evolution
11. Chua, K., Calandra, R., McAllister, R. & Levine, S. Deep reinforcement learning in a handful of trials using probabilistic dynamics models. *NeurIPS* **31** (2018). https://proceedings.neurips.cc/paper_files/paper/2018/hash/3de568f8597b94bda53149c7d7f5958c-Abstract.html
12. Janner, M., Fu, J., Zhang, M. & Levine, S. When to trust your model: model-based policy optimization. *NeurIPS* **32** (2019). https://proceedings.neurips.cc/paper/2019/hash/5faf461eff3099671ad63c6f3f094f7f-Abstract.html
13. Hafner, D. et al. Learning latent dynamics for planning from pixels. *ICML* **36**, 2555–2565 (2019). https://proceedings.mlr.press/v97/hafner19a.html
14. Hafner, D., Lillicrap, T., Ba, J. & Norouzi, M. Dream to control: learning behaviors by latent imagination. *ICLR* (2020). https://research.google/pubs/dream-to-control-learning-behaviors-by-latent-imagination/
15. Schrittwieser, J. et al. Mastering Atari, Go, chess and shogi by planning with a learned model. *Nature* **588**, 604–609 (2020). https://doi.org/10.1038/s41586-020-03051-4
16. Hafner, D., Pasukonis, J., Ba, J. & Lillicrap, T. Mastering diverse control tasks through world models. *Nature* **640**, 647–653 (2025). https://doi.org/10.1038/s41586-025-08744-2
17. Nagabandi, A. et al. Learning to adapt in dynamic, real-world environments through meta-reinforcement learning. *ICLR* (2019). https://openreview.net/pdf/4ac2c9a8d05224872f7c9b5ff9b81384148492f8.pdf
18. Gospodinov, E. et al. Adaptive world models: learning behaviors by latent imagination under non-stationarity. *Workshop on Adaptive Foundation Models at NeurIPS 2024* (2024). https://adaptive-foundation-models.org/papers.html
19. Chen, J., Xu, L., Venugopal, A. & Schneider, J. Policy-driven world model adaptation for robust offline model-based reinforcement learning. *ICML* **43**, 17734–17765 (2026). https://proceedings.mlr.press/v306/chen26fl.html
20. Nishimoto, Y. & Matsubara, T. Object-centric world models for causality-aware reinforcement learning. *Proceedings of the AAAI Conference on Artificial Intelligence* **40**(29), 24585–24593 (2026). https://doi.org/10.1609/aaai.v40i29.39642
21. Peng, Z.-H. et al. From observations to events: event-aware world models for reinforcement learning. *ICLR* (2026). https://proceedings.iclr.cc/paper_files/paper/2026/hash/fc09b26b85ab3abb2832bd555a2e4215-Abstract-Conference.html
22. Zhang, B. et al. Mixture-of-world models: scaling multi-task reinforcement learning with modular latent dynamics. *ICLR* (2026). https://proceedings.iclr.cc/paper_files/paper/2026/hash/33b47b3d2441a17b95344cd635f3dd01-Abstract-Conference.html
23. Qin, Z., Jiang, J. & Zhu, Z. Learning to adapt: in-context learning beyond stationarity. *ICLR* (2026). https://proceedings.iclr.cc/paper_files/paper/2026/hash/8c1df8153bc1b1366fe27f0785e5fdd4-Abstract-Conference.html
24. Steland, A. Online detection of changes in moment-based projections: when to retrain deep learners or update portfolios? *J. Mach. Learn. Res.* **27**, 1–50 (2026). https://www.jmlr.org/papers/volume27/23-0274/23-0274.pdf
25. Orujlu, T., Gumbsch, C., Butz, M. V. & Wu, C. M. Causal process models: reframing dynamic causal graph discovery as a reinforcement learning problem. *Proceedings of the Fifth Conference on Causal Learning and Reasoning*, PMLR **323**, 1450–1480 (2026). https://proceedings.mlr.press/v323/orujlu26a.html
26. Kekić, A. et al. Learning nonlinear causal reductions to explain reinforcement learning policies. *ICLR* (2026). https://proceedings.iclr.cc/paper_files/paper/2026/hash/c01dfe01b97aadc10fc16a201faa80d8-Abstract-Conference.html
27. Zhao, Z. et al. Curious causality-seeking agents in open-ended worlds. *NeurIPS* **38** (2025). https://papers.nips.cc/paper_files/paper/2025/hash/e21c92a1661709c3caf21fdd958bac99-Abstract-Conference.html
28. Gama, J. et al. A survey on concept drift adaptation. *ACM Comput. Surv.* **46**, Article 44 (2014). https://doi.org/10.1145/2523813
29. Peters, J., Bühlmann, P. & Meinshausen, N. Causal inference by using invariant prediction: identification and confidence intervals. *J. R. Stat. Soc. B* **78**, 947–1012 (2016). https://doi.org/10.1111/rssb.12167
30. Ahuja, K., Shanmugam, K., Varshney, K. R. & Dhurandhar, A. Invariant risk minimization games. *ICML* **37**, 145–155 (2020). https://proceedings.mlr.press/v119/ahuja20a.html
31. Khemakhem, I., Kingma, D., Monti, R. & Hyvärinen, A. Variational autoencoders and nonlinear ICA: a unifying framework. *AISTATS* **23**, 2207–2217 (2020). https://proceedings.mlr.press/v108/khemakhem20a.html
32. Zheng, X. et al. DAGs with NO TEARS: continuous optimization for structure learning. *NeurIPS* **31** (2018). https://proceedings.neurips.cc/paper/2018/hash/e347c51419ffb23ca3fd5050202f9c3d-Abstract.html
33. Pamfil, R. et al. DYNOTEARS: structure learning from time-series data. *AISTATS* **23** (2020). https://proceedings.mlr.press/v108/pamfil20a.html
34. Runge, J. et al. Detecting and quantifying causal associations in large nonlinear time series datasets. *Sci. Adv.* **5**, eaau4996 (2019). https://doi.org/10.1126/sciadv.aau4996
35. Brouillard, P. et al. Differentiable causal discovery from interventional data. *NeurIPS* **33** (2020). https://proceedings.neurips.cc/paper/2020/hash/f8b7aa3a0d349d9562b424160ad18612-Abstract.html
36. Louizos, C., Welling, M. & Kingma, D. P. Learning sparse neural networks through L0 regularization. *ICLR* (2018). https://openreview.net/forum?id=H1Y8hhg0b
37. Maddison, C. J., Mnih, A. & Teh, Y. W. The concrete distribution: a continuous relaxation of discrete random variables. *ICLR* (2017). https://openreview.net/forum?id=S1jE5L5gl
38. Kipf, T. et al. Neural relational inference for interacting systems. *ICML* **35**, 2688–2697 (2018). https://proceedings.mlr.press/v80/kipf18a.html

