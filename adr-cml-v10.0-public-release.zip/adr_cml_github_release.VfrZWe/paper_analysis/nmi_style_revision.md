# Nature Machine Intelligence 风格修订说明

## 先区分“风格”与“证据水平”

本文可以按 *Nature Machine Intelligence* 的 Article 风格重写，但现有证据本身仍不足以声称已经达到该刊的发表门槛。NMI 的编辑判断强调：结论是否被适当数据和分析支持，以及结论是否对广泛读者有意义。因此，修订重点是让主张更集中、更易读、更可证伪，而不是把有限的合成实验包装成通用智能体结论。

官方准备建议要求 Article 使用约 150 词的无引用摘要、约 3,000 词的主文和有限数量的主图表；详细复现实验放入 Methods 或 Extended Data。标题应简洁，正文应面向非专业读者，并避免用工程模块清单替代科学问题。

官方页面：

- [Nature Machine Intelligence brief submission guide](https://www.nature.com/documents/natmachintell-brief-submission-guide.pdf)
- [Nature Machine Intelligence editorial process](https://www.nature.com/natmachintell/submission-guidelines/editorial-process)
- [AIP and formatting](https://www.nature.com/natmachintell/submission-guidelines/aip-and-formatting)

## 修订后的单一核心信息

> Local repair can improve forward prediction after a mechanism shift in a controlled, fully observed modular system, but the benefit is conditional and does not translate into a confirmed task-level advantage for the hidden-state neural agent studied here.

中文工作表述：

> 局部修复可以在受控、完全观察的模块化系统中改善机制变化后的前向预测，但这种收益具有条件性，且没有转化为本文隐藏状态神经智能体的确认性任务优势。

这句话同时容纳正结果、无显著优势和反例，不把 SCM 组件结果冒充为完整智能体结果。

## 标题与文章类型

建议标题：

**Predictive mechanism diagnosis and local repair in model-based agents under mechanism shifts**

中文工作标题：

**机制变化下模型基础智能体的预测机制诊断与局部修复**

这个标题比单独的 “Local repair under changing mechanisms” 更明确地交代研究对象和方法，同时避免 ADR-CML、SCM、CEM 等缩写，也不预设局部修复一定有效。稿件按 Article 组织，而不是按工程报告组织：

1. 无引用摘要；
2. 面向非专业读者的短导语；
3. `Results` 作为正文主入口，不设置冗长的 `Introduction` 标题；
4. 只保留一条主论证链：问题—方法—组件证据—完整智能体证据—边界；
5. 具体超参数、文件路径、完整统计协议放入 Methods 或 Extended Data；
6. 主文图表只强调两件事：SCM 中的条件性收益，以及完整智能体中未确认的任务收益。

## 主文与扩展材料的分工

主文建议保留：

- 一张方法与证据链概览图；
- 一张 SCM 局部修复效应与 nonlinear edge-addition 反例图；
- 一张 heldout query return 的 sparse/dense 主结果图；
- 一张紧凑主表，列出效应量、置信区间和校正后 p 值。

放入 Extended Data 或 Supplementary Information：

- 全部 16 个 SCM 主要比较；
- train profile 和短 episode 结果；
- active action、repair step 和 accepted repair 的成本记录；
- 完整 session protocol、seed pairing、冻结审计和文件指纹；
- 诊断器、修复器和稀疏世界模型的逐项实现细节。

## 必须避免的表述

- `causal graph recovery`：主环境图只是可观测预测依赖代理；
- `general agents` 或 `robust long-horizon adaptation`：没有未知机制类型、外部环境或完整智能体长程优势证据；
- `local repair outperforms global repair`：SCM 存在机制族依赖和 dense_global 反例；
- `state of the art`：没有外部已发表强基线；
- `equal computation`：协议只固定最大 active allowance，实际 active actions、repair steps 和优化量并不相同；
- `CausalWorld benchmark results`：代码有可选 CausalWorld adapter，但 v10 正式结果使用的是自定义 MechanismMaze。

