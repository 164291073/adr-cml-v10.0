# 第一步：材料清点与实验完整性

## 1. 范围

用户提供的项目目录是 `/Users/liuhongjiu/Desktop/adr-cml-v10.0/`。当前可写工作区本身没有项目源码，因此本分析直接读取该目录；新产物另存于本目录的 `paper_analysis/`，不触碰原始 `src/`、`configs/`、`outputs/`。

已检查：

- `src/adrcml/`：智能体、关系世界模型、检测、修复、规划、环境、session 评估、聚合、SCM 基准和证据报告实现。
- `configs/`、`scripts/`：正式配置和运行脚本；没有执行这些脚本。
- `docs/V10_EXPERIMENT_PROTOCOL.md`、`V10_VALIDATION_REPORT.txt`、`README.md`。
- `outputs/v10/paper/`：正式 paper 运行。
- `outputs/v10/pilot/`、`outputs/v10/quick/`：快检/试运行，不能替代正式论文证据。
- `validation_results/`、`historical_validation/`：软件验证、SCM 组件审计和修复前历史记录，作为审计材料，不与正式 paper 结果混池。

## 2. 正式 paper 运行清单

`outputs/v10/paper/protocol_manifest.json` 声明：

| 项目 | 记录 |
|---|---:|
| 软件版本 | 10.0.0 |
| 神经训练 seed | 11, 23, 37, 51, 71, 89, 101, 113（8 个） |
| 架构 | sparse、dense（各独立训练） |
| 每种架构训练步数 | 100,000 |
| 短回合评估 | 3 protocol × 2 profile × 8 seed × 2 架构；每 checkpoint 100 episodes |
| session 评估 | 2 profile × 8 seed × 2 架构 = 32 个 `session_evaluation.json` |
| session 结构 | 12 sessions/session；每 session 12 support + 4 query；512 probe samples |
| SCM seed | 11, 23, 37, 51, 71, 89, 101, 127, 149, 173（10 个） |
| SCM seed/scenario 记录 | 60，`expected=60`、`completed=60`、`failures=[]` |
| stage 状态 | 163 个；163 个 `completed=true`，0 个未完成 |

按阶段计数，163 = 1 个 SCM 阶段 + 2 个架构比较阶段 + 16 个训练阶段 + 32 个 session 阶段 + 96 个短评估阶段 + 16 个 session 聚合阶段。形式上没有发现 paper 目录内的中断/失败阶段文件；这证明执行链路完整，不证明方法有效。

## 3. 正式、快检和历史记录的区分

### 正式 paper

正式证据是 `outputs/v10/paper/` 下的 8 seed、两架构、两个 profile 的 session 与短评估结果，以及 `outputs/v10/paper/scm/` 的 10 seed SCM 组件结果。它们有 protocol manifest、源代码 fingerprint、配置 hash、checkpoint lineage 和 stage artifact hash。

### pilot / quick

`outputs/v10/quick/` 和 `outputs/v10/pilot/` 是软件链路/数据链路检查，seed 数量更少、训练预算更小，不能作为论文模型或主要效应的替代证据。`V10_VALIDATION_REPORT.txt` 明确说明 quick 的每种机制通常只有一个 session，不能过度解释。

### 历史记录

`historical_validation/` 里的 SCM v1 和修复前 evidence report 只保留审计轨迹；当前有效的 SCM 组件结论使用 `outputs/v10/paper/scm/` 的 v2 protocol，不能把修复前结果当作当前主证据。

## 4. 代码版本和配置核对

读取的 16 份神经 `run_metadata.json`、32 份 session 结果和 96 份短评估 `evaluation_full.json` 都记录软件版本 `10.0.0`，神经训练步数为 100,000，session 配置设备为 `cuda`，并且这些记录中的 source fingerprint 各自一致。正式 manifest 记录的运行时为 Python 3.11.7、PyTorch 2.11.0+cu128、CUDA 12.8；这与 `V10_VALIDATION_REPORT.txt` 中本地 CPU 软件测试环境不同，不能用本地 CPU 测试替代 4090 实验环境验证。

## 5. 本清点的结论

实验材料在文件和阶段层面是完整的，统计单位也被显式记录：正式 session 的独立层级是训练 checkpoint/seed，session 是其条件内的配对重复，episode 不能当成独立训练重复。完整性结论只回答“记录是否齐全、审计是否可复核”，不回答“full 是否优于对照”或“是否达到发表标准”。
