# 第四步：论文定位、题目和结构方案

## 1. 建议定位

当前证据不支持把稿件定位成“通用因果智能体”或“完整神经智能体在机制变化下显著优于强基线”的方法论文。更可靠的定位是：

> **面向机制变化的诊断—局部修复框架与证据校准研究：从完全观察 SCM 组件到稀疏关系世界模型智能体。**

核心科学问题不是“局部修复是否永远最好”，而是：

1. 在什么受限条件下，检测到的局部机制变化能转化为独立未来预测收益？
2. 组件级局部收益为什么没有自动转化为完整神经智能体的任务回报收益？
3. 独立 query、独立 probe、冻结审计和强全局对照如何避免把修复接受率、图分数或单 checkpoint 结果误写成系统优势？

这个定位诚实地吸收了正结果、无显著优势、反例和实验设计限制。若目标必须是 CCF A/中科院一区，当前版本仍有明显风险：没有外部强算法、多环境/多任务泛化、机制类型留出、长时域任务优势或理论保证；在不增加实验的硬约束下，不能承诺这些缺口已被补齐。

## 2. 建议题目

主标题：

**Diagnosis and Local Repair under Mechanism Shifts: An Evidence-Calibrated Study from Modular Dynamics to Neural Agents**

中文工作题目：

**机制变化下的诊断与局部修复：从模块化动力学到神经智能体的证据校准研究**

备选标题：

- **When Local Repair Helps—and When It Does Not: Evidence from Mechanism-Shifting Agents**
- **From Predictive Dependency Change to Task Recovery: Auditing Local Mechanism Repair in Adaptive Agents**

不建议使用的标题：

- “Causal Mechanism Learning for General Agents”——现有图分数是预测依赖代理，不能支持通用因果识别。
- “Local Repair Outperforms Global Adaptation”——SCM 中已有反例，神经智能体主端点也没有确认性优势。
- “Robust Long-Horizon Adaptation”——当前结果没有 full-agent long-horizon 证据，H=8/H=32 只在 SCM 中是开环递归预测。 

## 3. 可承担的贡献点

1. **可审计的算法实现。** 给出动作条件的稀疏关系世界模型、节点级预测误差诊断、证据门控修复和 CEM 规划的完整闭环，并明确每个组件的作用边界。
2. **局部修复的条件性证据。** 在 10 个独立 seed 的完全观察 SCM 组件中，局部修复相对 no-repair 在 3/4 变化场景通过预设 Holm 校正；相对 replay-global 在 2/4 场景通过校正，另外 2/4 无显著优势。
3. **组件到系统的证据断层。** 在 8 seed、sparse/dense、train/heldout_v1 的正式 support/query 实验中，full 相对 diagnose_no_repair 和 global_repair 的 primary query-return 端点均未通过确认性校正；这说明组件级预测收益不能直接推出完整任务收益。
4. **负结果与审计协议。** 将独立 query、probe、查询冻结 hash、训练 seed 层级聚合、Holm 校正、成本记录和 dense_global 反例纳入主结果，形成可复核的证据校准范式。

第 4 点应谨慎写成实验设计/证据贡献，不宜包装成未经文献审查的全新统计理论。

## 4. 论文整体架构

1. 引言：机制变化、在线诊断与修复的动机；指出“组件预测收益 ≠ 智能体任务收益”。
2. 相关工作：因果表示学习、跨 context 因果发现、模型基础强化学习、在线变化检测、因果/结构基准。
3. 问题定义：隐藏机制变化、可观测状态、动作条件依赖、support/query、局部修复与任务回报。
4. 方法：稀疏关系世界模型、节点级 CUSUM、局部/全局 repair、共享验收守卫、CEM 规划。
5. 证据协议：正式 paper manifest、seed/session 统计单位、独立 probe、冻结审计、Holm 家族、成本语义。
6. 组件实验：SCM 设计、4 个变化条件、H=8 结果、正结果与 dense_global 反例。
7. 完整智能体实验：MechanismMaze、sparse/dense、train/heldout_v1、主/次/补充端点。
8. 结果：主结果先给 null/negative，再给组件正结果和架构/主动探索补充结果。
9. 讨论：为何局部组件收益没有转化为 task return；检测延迟、低覆盖、规划和 repair acceptance 的可能瓶颈。
10. 局限与结论：不声称 causal identification、未知机制类型泛化、外部 benchmark、强基线或长程任务成功。

## 5. 结果呈现建议

- 主表只放 `heldout_v1` session 的 query return 和独立 probe MSE，并同时列 sparse/dense、full、diagnose_no_repair、global_repair。
- SCM 表列全部 16 个预设主要比较或至少列四个变化场景的 `no_repair`、`global_replay`、`dense_global`，不要只列局部胜出的两行。
- 100-episode 短评估作为补充表，明确“原始推断为单 checkpoint；跨 seed 仅为本次探索性重算”。
- 图指标放补充材料，标题用“predictive dependency proxy”，不使用“causal graph recovery success”。
- 所有主动动作、repair steps、accepted repairs 用成本表披露，避免“equal budget”被理解成 equal FLOPs。
