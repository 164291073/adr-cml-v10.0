# 已查证的基础相关工作

本文件保留最初核验的 8 条基础文献。修订稿现使用 38 条参考文献；新增文献的逐条出处与类型见 `paper_analysis/reference_audit_2026.md`。

以下引用在 2026-11-10 通过论文官网、JMLR、NeurIPS、AAAI、OpenReview 或 DOI 页面核对过题名、作者、年份和主要论断。它们用于界定关系，不用于暗示 ADR-CML 已经超过这些工作。

## 1. 因果表示学习与跨 context 机制变化

- Schölkopf, B., Locatello, F., Bauer, S., Ke, N. R., Kalchbrenner, N., Goyal, A., & Bengio, Y. (2021). *Toward Causal Representation Learning*. Proceedings of the IEEE, 109(5), 612–634. DOI: [10.1109/JPROC.2021.3058954](https://doi.org/10.1109/JPROC.2021.3058954)。该文将因果变量发现、干预、分布变化和跨任务泛化联系起来；本文借用其问题动机，但不声称从神经状态中识别因果变量。
- Mooij, J. M., Magliacane, S., & Claassen, T. (2020). *Joint Causal Inference from Multiple Contexts*. Journal of Machine Learning Research, 21(99), 1–108. [JMLR 页面](https://jmlr.org/papers/v21/17-123.html)。该工作强调多 context/干预信息可以用于因果发现，并明确区分实验和观察数据；本文的 heldout_v1 是已知机制族内参数变化，不是 JCI 意义下的完整因果发现。
- Xia, K., Lee, K.-Z., Bengio, Y., & Bareinboim, E. (2021). *The Causal-Neural Connection: Expressiveness, Learnability, and Inference*. NeurIPS 34. [NeurIPS 页面](https://proceedings.neurips.cc/paper/2021/hash/5989add1703e4b0480f75e2390739f34-Abstract.html)。该文提醒神经网络表达能力不能自动消除可识别性限制；这支持本文对 graph score 和 SCM 组件外推保持克制。

## 2. 模型基础强化学习和结构/因果环境

- Moerland, T. M., Broekens, J., Plaat, A., & Jonker, C. M. (2023). *Model-based Reinforcement Learning: A Survey*. *Foundations and Trends in Machine Learning*, 16(1), 1–118. [Publisher DOI](https://doi.org/10.1561/2200000086)。该综述将动力学建模、规划、探索预算、不确定性和部分可观测性放在统一 MBRL 框架内；本文的关系世界模型+CEM 属于这一广义路线。
- Ahmed, O., Träuble, F., Goyal, A., Neitz, A., Bengio, Y., Schölkopf, B., Wüthrich, M., & Bauer, S. (2021). *CausalWorld: A Robotic Manipulation Benchmark for Causal Structure and Transfer Learning*. ICLR 2021. [OpenReview 页面](https://openreview.net/forum?id=SK7A5pdrgov)。CausalWorld 提供可干预因子、共享机制和任务分布；本文使用自定义 MechanismMaze，不能把自定义环境结果写成外部 causal benchmark 结果。
- Herdeanu, B. et al. (2025). *CausalDynamics: A large-scale benchmark for structural discovery of dynamical causal models*. NeurIPS 38, Datasets and Benchmarks Track. [NeurIPS 页面](https://proceedings.neurips.cc/paper_files/paper/2025/hash/39a3f7dc00e4723a5ca7808b04fc4d4f-Abstract-Datasets_and_Benchmarks_Track.html)。该基准强调动态系统结构发现、噪声、混杂和滞后；它也说明本文 8 节点、隐藏状态、代理 graph target 的覆盖面有限。

## 3. 在线变化检测

- Page, E. S. (1954). *Continuous Inspection Schemes*. Biometrika, 41(1–2), 100–115. DOI: [10.1093/biomet/41.1-2.100](https://doi.org/10.1093/biomet/41.1-2.100)。本文的节点级 detector 是工程化的 action-conditioned、robust-window CUSUM 变体，不应写成对 Page 方法的理论改进。
- Altamirano, M., Briol, F.-X. & Knoblauch, J. (2023). *Robust and Scalable Bayesian Online Changepoint Detection*. ICML 40, PMLR 202:642–663. [PMLR 页面](https://proceedings.mlr.press/v202/altamirano23a.html)。该工作提供在线变化点检测的正式会议路线；本文没有实现该算法，因此只作为变化检测相关工作，不作算法对比。

## 4. 相关工作边界

当前项目没有外部发表 baseline、真实环境、机制类型留出或 causal identification theorem。初稿中的“相关工作差异”只能写为问题设置和审计协议的组合差异；在没有更完整文献检索和外部实验的情况下，不应写“首次”“唯一”或“state of the art”。
