# 数据与参考文献 DOI 二次核对

核对日期：2026-11-18  
核对对象：现有 `outputs/v10/paper/`、当前 NMI 风格中英文稿件以及 `paper_analysis/` 中的重算表。  
核对原则：只读取已有 JSON/CSV/文本结果并重新计算统计量；不加载 checkpoint 或 replay buffer，不重新训练，不运行原实验或评估流水线。

## 结论

1. 论文正文中的主要数字与现有统计表一致。对已有结果执行只读重算后，`inventory.json`、`recomputed_statistics.json`、`formal_session_contrasts.csv`、`formal_scm_contrasts.csv` 和 `architecture_comparisons.csv` 均与 `paper_analysis/` 中相应文件逐字一致；六张 SVG 图也逐字一致。唯一差异是临时重算生成的 `figure_manifest.json` 使用了临时目录的绝对路径，图和数据本身没有差异。
2. 现有正式运行记录是完整可审计的，但不等于论文主张已经被完全支持。项目自带的 `evidence_report` 明确给出 `Decision: requires_research_review`、`Paper claims supported: false`，并将神经智能体的主要任务回报证据列为 insufficient；SCM 组件结果只能支持相应的组件级、条件化结论。
3. 当前 38 条参考文献中，10 条带 DOI。逐一检查后，这 10 个 DOI 均可解析到与作者、题名、期刊/会议和年份相符的正式记录。其余 28 条主要是 ICLR、NeurIPS、ICML、AISTATS、PMLR 或 OpenReview 记录，当前稿件使用官方论文页或正式 proceedings 页，没有人为填入 DOI。
4. 因而可以准确写成“10 条 DOI 已核验，28 条使用正式出版/会议记录链接”，不能写成“38 条参考文献均有 DOI”。如果目标期刊强制每条参考文献提供 DOI，需要作者决定是否替换无 DOI 字段的会议记录；不能通过猜测或拼接 DOI 补齐。

## 一、数据、运行记录与正文数字

| 核对项 | 已有结果 | 正文/分析中的对应表述 | 核对结论 |
|---|---:|---|---|
| 软件版本 | `10.0.0` | 方法与 protocol manifest | 一致 |
| 独立训练种子 | 8 个：11, 23, 37, 51, 71, 89, 101, 113 | 稀疏/稠密两种架构各 8 个训练种子 | 一致 |
| SCM 组件种子 | 10 个：11, 23, 37, 51, 71, 89, 101, 127, 149, 173 | 独立 SCM 组件实验使用 10 个种子 | 一致 |
| 每种架构训练步数 | 100,000 | sparse 与 dense 各训练 100,000 steps | 一致 |
| 已完成 stage-status 记录 | 163/163 | 16 个训练运行、32 个 session-evaluation 运行、96 个 full-evaluation summary | 一致；这些数字描述记录清单，不是性能结论 |
| SCM 结果行 | 60/60，失败 0 行 | 8 个 shift/比较条件 × 3 个 horizon/汇总维度的完整组件记录 | 一致 |
| session 协议 | 每个 session 12 个 support episodes + 4 个 query episodes | query 阶段冻结模型、优化器、检测器、replay 与学习计数器 | 一致 |
| probe bank | 512 个样本 | 独立 probe bank；probe MSE 为次要指标 | 一致 |
| planner | horizon 16，population 512，elites 64，5 iterations | 正文中的 CEM planner 配置 | 一致 |
| active-action allowance | 3 | 正文中的最大 active-action allowance | 一致；不应写成精确 FLOP 或总计算量匹配 |
| held-out 条件 | `heldout_v1` 只改变已知机制族内的参数范围 | 正文写作中未称为 unseen mechanism family | 一致；不能宣称未见机制类型泛化 |

### 主要性能数字

下列数字来自现有 `paper_analysis/formal_scm_contrasts.csv`、`formal_session_contrasts.csv` 和 `architecture_comparisons.csv`，并已由 `recompute_paper_evidence.py` 重新计算核对。

| 分析层级 | 比较 | 估计差异 | 95% CI | Holm 校正后 p | 解释边界 |
|---|---|---:|---|---:|---|
| SCM 组件，linear/coefficient shift | local − no repair | `4.55e-5` | `[3.06e-5, 6.02e-5]` | `0.03125` | 支持 fully observed、known-feature、组件级局部更新在该条件下优于 no repair |
| SCM 组件，linear/edge addition | local − no repair | `1.17e-5` | `[0.78e-5, 1.62e-5]` | `0.03125` | 同上；不能外推到完整神经智能体 |
| SCM 组件，nonlinear/coefficient shift | local − no repair | `1.76e-4` | `[1.15e-4, 2.35e-4]` | `0.03125` | 同上 |
| SCM 组件，nonlinear/edge addition | local − no repair | `1.26e-5` | `[-0.02e-5, 2.93e-5]` | `0.49219` | 无显著优势，已保留为负/不确定结果 |
| SCM 组件，nonlinear/edge addition | dense global − local | `-1.05e-4` | `[-1.33e-4, -0.83e-4]` | `0.03125` | 局部方法在该组件条件下优于 dense global；仍不是完整智能体结论 |
| 完整智能体，heldout_v1 | sparse full − diagnose-no-repair | `-0.01650` | `[-0.04944, 0.01444]` | `0.35938` | 任务回报没有显著优势 |
| 完整智能体，heldout_v1 | sparse full − global repair | `-0.01684` | `[-0.05399, 0.01616]` | `0.35938` | 任务回报没有显著优势 |
| 完整智能体，heldout_v1 | dense full − diagnose-no-repair | `0.01712` | `[-0.01672, 0.05353]` | `0.25000` | 任务回报没有显著优势 |
| 完整智能体，heldout_v1 | dense full − global repair | `0.01349` | `[-0.03521, 0.07317]` | `0.83594` | 任务回报没有显著优势 |
| 架构比较，train | sparse full − dense full，probe MSE | `0.000257405` | `[0.00013619, 0.00038124]` | `0.03125` | dense 的 probe MSE 更低；这是训练 profile 的预测指标，不是 held-out task-return 优势 |
| 架构比较，heldout_v1 | sparse full − dense full，query return | `-0.00265625` | `[-0.051472, 0.046331]` | `1.00000` | held-out query return 不区分两种架构 |

因此，正文可以保留“SCM 组件在若干预设条件下支持局部更新”的窄结论，但必须同时保留两点：

- nonlinear/edge-addition 相对于 no-repair 的组件差异不显著；
- 完整智能体的 held-out query return 没有显示局部修复相对于主要对照的显著优势。

项目自带 `outputs/v10/paper/evidence_report.txt` 还明确指出：prediction contrast 不能替代失败的 primary task-return evidence；当前结果不能建立 unseen-family 或 full-agent long-horizon generalization，也不能把 causal graph score 单独解释为 causal identification。

## 二、正文与结果文件的可追溯关系

| 正文内容 | 直接依据 |
|---|---|
| 环境包含 8 个 state nodes、10 个 actions、3 类 shift modes | `src/adrcml/envs/mechanism_maze.py` |
| `heldout_v1` 是已知机制族内的参数范围变化 | `src/adrcml/envs/mechanism_maze.py` 与 `protocol_manifest.json` |
| 稀疏模型使用 predictive dependency gates，并加入 off-diagonal sparsity 与 parent-count budget | `src/adrcml/models/relational_world_model.py`、`configs/main.yaml` |
| sparsity weight `0.004`、parent budget `4.0`、budget weight `0.02` | `configs/main.yaml` |
| planner 为 Categorical CEM，horizon 16、population 512、elites 64、5 iterations | `src/adrcml/planning.py`、`configs/main.yaml` |
| session query 阶段冻结更新，并使用 12 support + 4 query episodes | `src/adrcml/evaluate_sessions.py`、`protocol_manifest.json` |
| SCM 组件实验与完整神经智能体实验分开报告 | `outputs/v10/paper/scm/summary.json`、各 architecture session summaries |

## 三、DOI 核验

核验标准是：DOI resolver/正式出版方记录可定位，且记录中的题名、作者、载体和年份与当前稿件一致。当前稿件中的 10 条 DOI 如下。

| 文献编号 | 当前稿件中的 DOI | 匹配的正式记录 | 结果 |
|---:|---|---|---|
| 1 | `10.1109/JPROC.2021.3058954` | Schölkopf et al., *Toward Causal Representation Learning*, Proceedings of the IEEE 109, 612–634 (2021)，见 [IEEE Xplore](https://ieeexplore.ieee.org/abstract/document/9363924/authors) | 存在且匹配 |
| 4 | `10.1561/2200000086` | Moerland et al., *Model-based Reinforcement Learning: A Survey*, Foundations and Trends in Machine Learning 16, 1–118 (2023)，见 [DOI/出版社记录](https://doi.org/10.1561/2200000086) | 存在且匹配 |
| 7 | `10.1093/biomet/41.1-2.100` | Page, *Continuous Inspection Schemes*, Biometrika 41, 100–115 (1954)，见 [Oxford Academic](https://academic.oup.com/biomet/article-abstract/41/1-2/100/456627?login=false) | 存在且匹配 |
| 9 | `10.1145/122344.122377` | Sutton, *Dyna, an Integrated Architecture for Learning, Planning, and Reacting*, SIGART Bulletin 2, 160–163 (1991) | 存在且匹配 |
| 15 | `10.1038/s41586-020-03051-4` | Schrittwieser et al., *Mastering Atari, Go, chess and shogi by planning with a learned model*, Nature 588, 604–609 (2020)，见 [Nature DOI record](https://doi.org/10.1038/s41586-020-03051-4) | 存在且匹配 |
| 16 | `10.1038/s41586-025-08744-2` | Hafner et al., *Mastering diverse control tasks through world models*, Nature 640, 647–653 (2025)，见 [Nature DOI record](https://doi.org/10.1038/s41586-025-08744-2) | 存在且匹配 |
| 20 | `10.1609/aaai.v40i29.39642` | Nishimoto & Matsubara, *Object-Centric World Models for Causality-Aware Reinforcement Learning*, AAAI 40(29), 24585–24593 (2026)，见 [AAAI record](https://ojs.aaai.org/index.php/AAAI/article/view/39642) | 存在且匹配 |
| 28 | `10.1145/2523813` | Gama et al., *A Survey on Concept Drift Adaptation*, ACM Computing Surveys 46(4), Article 44 (2014)，见 [ACM DOI record](https://doi.org/10.1145/2523813) | 存在且匹配 |
| 29 | `10.1111/rssb.12167` | Peters et al., *Causal Inference by Using Invariant Prediction: Identification and Confidence Intervals*, JRSSB 78, 947–1012 (2016)，见 [Wiley DOI record](https://doi.org/10.1111/rssb.12167) | 存在且匹配 |
| 34 | `10.1126/sciadv.aau4996` | Runge et al., *Detecting and Quantifying Causal Associations in Large Nonlinear Time Series Datasets*, Science Advances 5, eaau4996 (2019)，见 [Science Advances DOI record](https://doi.org/10.1126/sciadv.aau4996) | 存在且匹配 |

### 当前稿件未填写 DOI 的 28 条记录

编号 2、3、5、6、8、10–14、17–19、21–27、30–33、35–38 当前没有在稿件中填写 DOI。它们使用的是 JMLR、NeurIPS、ICLR/OpenReview、ICML/AISTATS/PMLR、Google Research 或正式会议页面。此处不把 OpenReview 或 proceedings URL 误写成 DOI，也不依据标题自行推断 DOI。

当前稿件中已排除仅有预印本版本的条目；检查 `paper_draft_nmi_en.md`、`paper_draft_nmi_zh.md` 和 `paper_draft_zh.md` 未发现 `arXiv` 或 `preprint` 引用。

## 四、需要作者确认的事项

1. 是否接受“10 条 DOI + 28 条正式出版/会议链接”的参考文献格式。如果期刊排版系统要求每条记录都有 DOI，需要先确定替换策略；不建议为无 DOI 的正式会议记录补写未经核实的 DOI。
2. 是否把项目自带 evidence report 的状态原样保留在内部材料中。它目前不是出版就绪认证，而是 `requires_research_review`，并明确 `Paper claims supported: false`。
3. 论文主张是否限定为：SCM 组件在若干已知、fully observed 的合成条件下显示局部更新优势；完整智能体在现有 held-out 参数条件下没有得到显著 task-return 优势。若改成“整体提升适应性”“发现因果结构”或“对未见机制泛化”，现有证据不足以支持。

## 复核文件

- [NMI 英文稿](./paper_draft_nmi_en.md)
- [NMI 中文稿](./paper_draft_nmi_zh.md)
- [参考文献审计表](./reference_audit_2026.md)
- [交付前证据审计](./delivery_evidence_audit.md)
- [重算脚本](./recompute_paper_evidence.py)
