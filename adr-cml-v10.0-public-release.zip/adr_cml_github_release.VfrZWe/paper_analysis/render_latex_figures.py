#!/usr/bin/env python3
"""Render publication-style figures from existing paper-analysis CSV files.

This script only reads CSV files already present in paper_analysis/. It does
not access checkpoints, replay buffers, source outputs, or start experiments.
The plotted quantities and bootstrap procedure match the existing analysis
figures generated from the formal evidence tables.
"""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
FIGURES = ROOT / "figures"
MODES = ("full", "global_repair", "diagnose_no_repair", "online_only", "frozen", "no_active")
MODE_LABELS = {
    "full": "Full",
    "global_repair": "Global repair",
    "diagnose_no_repair": "Diagnose\n(no repair)",
    "online_only": "Online only",
    "frozen": "Frozen",
    "no_active": "No active\nactions",
}

# Nature-style figure conventions: restrained colours, sans-serif labels and
# small text intended for the final printed figure size.
INK = "#1F2933"
BLUE = "#2F6F9F"
BLUE_LIGHT = "#B7CBD9"
GRID = "#D9E1E8"
ZERO = "#68737D"

matplotlib.rcParams.update(
    {
        "font.family": "Arial",
        "font.size": 7,
        "axes.labelsize": 7,
        "axes.titlesize": 8,
        "xtick.labelsize": 6.5,
        "ytick.labelsize": 7,
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "xtick.major.size": 3,
        "ytick.major.size": 3,
        "axes.edgecolor": INK,
        "axes.labelcolor": INK,
        "xtick.color": INK,
        "ytick.color": INK,
        "text.color": INK,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    }
)


def read_csv(name: str) -> list[dict[str, str]]:
    with (ROOT / name).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def bootstrap_ci(values: list[float], seed: int, samples: int = 20_000) -> tuple[float, float]:
    """Reproduce the existing seed-level bootstrap mean interval."""

    data = np.asarray(values, dtype=float)
    rng = np.random.default_rng(seed)
    draws = rng.choice(data, size=(samples, len(data)), replace=True).mean(axis=1)
    return tuple(np.quantile(draws, [0.025, 0.975]))


def save_figure(fig: matplotlib.figure.Figure, path: Path) -> None:
    """Save editable vector outputs used by the manuscript and archive."""

    fig.savefig(path, format="pdf", bbox_inches="tight", pad_inches=0.03)
    fig.savefig(path.with_suffix(".svg"), format="svg", bbox_inches="tight", pad_inches=0.03)
    plt.close(fig)


def finish_axes(ax: matplotlib.axes.Axes, grid_axis: str = "y") -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(axis=grid_axis, color=GRID, linewidth=0.55)
    ax.set_axisbelow(True)


def save_forest(
    path: Path,
    labels: list[str],
    means: list[float],
    lows: list[float],
    highs: list[float],
    xlabel: str,
    scale: float = 1.0,
) -> None:
    """Save a horizontal effect-size plot with a zero reference line."""

    values = np.asarray(means, dtype=float) * scale
    low = np.asarray(lows, dtype=float) * scale
    high = np.asarray(highs, dtype=float) * scale
    y = np.arange(len(labels))[::-1]

    fig, ax = plt.subplots(figsize=(6.6, 3.05))
    xerr = np.vstack([values - low, high - values])
    ax.errorbar(
        values,
        y,
        xerr=xerr,
        fmt="o",
        markersize=4.6,
        markerfacecolor=BLUE,
        markeredgecolor=BLUE,
        ecolor=BLUE,
        elinewidth=1.15,
        capsize=2.8,
        capthick=1.0,
        zorder=3,
    )
    ax.axvline(0.0, color=ZERO, linewidth=0.8, zorder=1)
    ax.set_yticks(y, labels)
    ax.set_xlabel(xlabel)
    ax.tick_params(axis="y", length=0)
    finish_axes(ax, grid_axis="x")
    ax.set_ylim(-0.65, len(labels) - 0.35)
    ax.margins(x=0.08)
    fig.subplots_adjust(left=0.28, right=0.98, bottom=0.20, top=0.96)
    save_figure(fig, path)


def save_session_plot(path: Path, rows: list[dict[str, str]]) -> None:
    """Show seed-level observations with the existing bootstrap mean intervals."""

    means: list[float] = []
    lows: list[float] = []
    highs: list[float] = []
    observations: list[list[float]] = []
    for mode in MODES:
        mode_rows = sorted((row for row in rows if row["mode"] == mode), key=lambda row: int(row["training_seed"]))
        values = [float(row["query_return"]) for row in mode_rows]
        mean = float(np.mean(values))
        low, high = bootstrap_ci(values, 2_026_111_011)
        observations.append(values)
        means.append(mean)
        lows.append(low)
        highs.append(high)

    x = np.arange(len(MODES), dtype=float)
    fig, ax = plt.subplots(figsize=(6.6, 3.35))
    for index, values in enumerate(observations):
        offsets = np.linspace(-0.11, 0.11, len(values)) if len(values) > 1 else np.zeros(1)
        ax.scatter(
            np.full(len(values), x[index]) + offsets,
            values,
            s=16,
            facecolor="white",
            edgecolor=BLUE_LIGHT,
            linewidth=0.8,
            zorder=2,
        )

    mean_values = np.asarray(means)
    yerr = np.vstack([mean_values - np.asarray(lows), np.asarray(highs) - mean_values])
    ax.errorbar(
        x,
        mean_values,
        yerr=yerr,
        fmt="o",
        markersize=4.8,
        markerfacecolor=BLUE,
        markeredgecolor=BLUE,
        ecolor=BLUE,
        elinewidth=1.15,
        capsize=2.8,
        capthick=1.0,
        zorder=3,
    )
    ax.set_xticks(x, [MODE_LABELS[mode] for mode in MODES])
    ax.set_ylabel("Query return")
    ax.tick_params(axis="x", length=0, pad=4)
    finish_axes(ax, grid_axis="y")
    observed_low = min(min(values) for values in observations)
    observed_high = max(max(values) for values in observations)
    interval_low = min(lows)
    interval_high = max(highs)
    span = max(interval_high, observed_high) - min(interval_low, observed_low)
    ax.set_ylim(min(interval_low, observed_low) - 0.08 * span, max(interval_high, observed_high) + 0.08 * span)
    fig.subplots_adjust(left=0.12, right=0.98, bottom=0.23, top=0.96)
    save_figure(fig, path)


def render_sessions() -> None:
    rows = read_csv("formal_session_absolute.csv")
    for architecture, profile in (
        ("sparse", "heldout_v1"),
        ("dense", "heldout_v1"),
        ("sparse", "train"),
        ("dense", "train"),
    ):
        selected = [row for row in rows if row["architecture"] == architecture and row["profile"] == profile]
        save_session_plot(
            FIGURES / f"session_query_return_{architecture}_{profile}.pdf",
            selected,
        )


def render_scm() -> None:
    rows = [row for row in read_csv("formal_scm_contrasts.csv") if row["contrast"] == "global_replay"]
    order = {
        ("linear", "coefficient_shift"): 0,
        ("linear", "edge_addition"): 1,
        ("nonlinear", "coefficient_shift"): 2,
        ("nonlinear", "edge_addition"): 3,
    }
    rows.sort(key=lambda row: order[(row["family"], row["scenario"])])
    labels = [
        f"{row['family'].capitalize()}: {row['scenario'].replace('_', ' ')}"
        for row in rows
    ]
    save_forest(
        FIGURES / "scm_global_replay_effects.pdf",
        labels,
        [float(row["mean_difference"]) for row in rows],
        [float(row["ci95_low"]) for row in rows],
        [float(row["ci95_high"]) for row in rows],
        r"Effect on recursive MSE (global replay - local repair; $\times 10^{-5}$)",
        scale=1e5,
    )


def render_architecture() -> None:
    rows = [row for row in read_csv("architecture_comparisons.csv") if row["endpoint"] == "query_return"]
    profile_order = {"train": 0, "heldout_v1": 1}
    contrast_order = {"sparse_full_vs_dense_full": 0, "sparse_full_vs_dense_online_only": 1}
    rows.sort(key=lambda row: (profile_order[row["profile"]], contrast_order[row["contrast"]]))
    labels = []
    for row in rows:
        profile = "Held-out" if row["profile"] == "heldout_v1" else "Train"
        condition = "full" if row["contrast"].endswith("dense_full") else "online only"
        labels.append(f"{profile}: {condition}")
    save_forest(
        FIGURES / "architecture_query_return.pdf",
        labels,
        [float(row["mean_difference"]) for row in rows],
        [float(row["ci95_low"]) for row in rows],
        [float(row["ci95_high"]) for row in rows],
        "Mean query-return difference (sparse - dense)",
    )


def main() -> None:
    FIGURES.mkdir(exist_ok=True)
    render_scm()
    render_sessions()
    render_architecture()


if __name__ == "__main__":
    main()
