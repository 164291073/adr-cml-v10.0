# 参考文献扩展与出处审计

目标数量：38 篇。范围包括正式发表的基础工作、与机制变化/世界模型/因果结构直接相关的近年工作，以及 2026 年已能在官方会议或期刊页面核验的论文。本清单不包含仅有预印本版本的论文。

## 核验结果

| 编号 | 文献 | 年份与类型 | 可核验出处 | 与本文的关系 |
|---:|---|---|---|---|
| 1 | Schölkopf et al., “Toward Causal Representation Learning” | 2021, *Proceedings of the IEEE* | [IEEE Xplore](https://ieeexplore.ieee.org/abstract/document/9363924/authors); [DOI](https://doi.org/10.1109/JPROC.2021.3058954) | 因果表示学习与跨分布泛化的背景 |
| 2 | Mooij, Magliacane & Claassen, “Joint Causal Inference from Multiple Contexts” | 2020, *JMLR* | [JMLR](https://jmlr.org/papers/v21/17-123.html) | 多 context 与干预信息；本文不声称完成 JCI |
| 3 | Xia et al., “The Causal-Neural Connection: Expressiveness, Learnability, and Inference” | 2021, NeurIPS 34 | [NeurIPS](https://proceedings.neurips.cc/paper/2021/hash/5989add1703e4b0480f75e2390739f34-Abstract.html) | 神经模型表达能力与因果可识别性的边界 |
| 4 | Moerland et al., “Model-based Reinforcement Learning: A Survey” | 2023, *Foundations and Trends in Machine Learning* 16(1) | [Publisher DOI](https://doi.org/10.1561/2200000086) | MBRL、动力学学习与规划综述 |
| 5 | Ahmed et al., “CausalWorld: A Robotic Manipulation Benchmark for Causal Structure and Transfer Learning” | 2021, ICLR | [OpenReview](https://openreview.net/forum?id=SK7A5pdrgov); [MPI-IS record](https://is.mpg.de/en/publications/ahmedetal21) | 外部 causal benchmark；未用于本项目正式结果 |
| 6 | Herdeanu et al., “CausalDynamics: A large-scale benchmark for structural discovery of dynamical causal models” | 2025, NeurIPS 38, Datasets and Benchmarks Track | [NeurIPS](https://proceedings.neurips.cc/paper_files/paper/2025/hash/39a3f7dc00e4723a5ca7808b04fc4d4f-Abstract-Datasets_and_Benchmarks_Track.html) | 动态因果结构发现 benchmark 与本文覆盖边界 |
| 7 | Page, “Continuous Inspection Schemes” | 1954, *Biometrika* | [Oxford Academic](https://academic.oup.com/biomet/article-abstract/41/1-2/100/456627?login=false); [DOI](https://doi.org/10.1093/biomet/41.1-2.100) | CUSUM 的经典出处；本文 detector 是工程化变体 |
| 8 | Altamirano, Briol & Knoblauch, “Robust and Scalable Bayesian Online Changepoint Detection” | 2023, ICML 40 | [PMLR](https://proceedings.mlr.press/v202/altamirano23a.html) | 在线变化点检测的正式会议工作；本文未实现该算法 |
| 9 | Sutton, “Dyna, an Integrated Architecture for Learning, Planning, and Reacting” | 1991, *SIGART Bulletin* | [DOI](https://doi.org/10.1145/122344.122377); [DBLP](https://dblp.uni-trier.de/rec/journals/sigart/Sutton91.html) | 学习、模型和规划闭环的早期框架 |
| 10 | Ha & Schmidhuber, “Recurrent World Models Facilitate Policy Evolution” | 2018, NeurIPS 31 | [NeurIPS](https://papers.nips.cc/paper/7512-recurrent-world-models-facilitate-policy-evolution) | 世界模型与潜在想象 |
| 11 | Chua et al., “Deep Reinforcement Learning in a Handful of Trials using Probabilistic Dynamics Models” | 2018, NeurIPS 31 | [NeurIPS](https://proceedings.neurips.cc/paper_files/paper/2018/hash/3de568f8597b94bda53149c7d7f5958c-Abstract.html) | 概率动力学 ensemble 与模型规划 |
| 12 | Janner, Fu, Zhang & Levine, “When to Trust Your Model: Model-Based Policy Optimization” | 2019, NeurIPS 32 | [NeurIPS](https://proceedings.neurips.cc/paper/2019/hash/5faf461eff3099671ad63c6f3f094f7f-Abstract.html) | 模型误差与 rollout 使用边界 |
| 13 | Hafner et al., “Learning Latent Dynamics for Planning from Pixels” | 2019, ICML 36 | [PMLR](https://proceedings.mlr.press/v97/hafner19a.html) | latent dynamics 与规划 |
| 14 | Hafner et al., “Dream to Control: Learning Behaviors by Latent Imagination” | 2020, ICLR | [Google Research](https://research.google/pubs/dream-to-control-learning-behaviors-by-latent-imagination/) | 学习世界模型中的行为与想象 |
| 15 | Schrittwieser et al., “Mastering Atari, Go, chess and shogi by planning with a learned model” | 2020, *Nature* | [Nature DOI](https://doi.org/10.1038/s41586-020-03051-4) | learned model 与 tree-based planning |
| 16 | Hafner et al., “Mastering Diverse Control Tasks through World Models” | 2025, *Nature* 640 | [Nature](https://doi.org/10.1038/s41586-025-08744-2) | 跨任务世界模型；本文不声称达到其任务规模 |
| 17 | Nagabandi et al., “Learning to Adapt in Dynamic, Real-World Environments Through Meta-Reinforcement Learning” | 2019, ICLR | [OpenReview](https://openreview.net/pdf/4ac2c9a8d05224872f7c9b5ff9b81384148492f8.pdf) | 基于近期数据的快速动力学适应 |
| 18 | Gospodinov et al., “Adaptive World Models: Learning Behaviors by Latent Imagination Under Non-Stationarity” | 2024, NeurIPS 38 | [OpenReview](https://openreview.net/forum?id=VMIbgzRw78) | 非平稳环境下的 latent world-model adaptation |
| 19 | Chen et al., “Policy-Driven World Model Adaptation for Robust Offline Model-based Reinforcement Learning” | 2026, ICML 43 | [PMLR](https://proceedings.mlr.press/v306/chen26fl.html) | 2026 年的世界模型适应与策略反馈 |
| 20 | Nishimoto & Matsubara, “Object-Centric World Models for Causality-Aware Reinforcement Learning” | 2026, AAAI 40(29) | [AAAI official page](https://ojs.aaai.org/index.php/AAAI/article/view/39642); [DOI](https://doi.org/10.1609/aaai.v40i29.39642) | 2026 年正式发表的对象中心世界模型与因果感知 RL |
| 21 | Peng et al., “From Observations to Events: Event-Aware World Models for Reinforcement Learning” | 2026, ICLR | [ICLR 2026](https://proceedings.iclr.cc/paper_files/paper/2026/hash/fc09b26b85ab3abb2832bd555a2e4215-Abstract-Conference.html) | 事件表征与结构变化泛化 |
| 22 | Zhang et al., “Mixture-of-World Models: Scaling Multi-Task Reinforcement Learning with Modular Latent Dynamics” | 2026, ICLR | [ICLR 2026](https://proceedings.iclr.cc/paper_files/paper/2026/hash/33b47b3d2441a17b95344cd635f3dd01-Abstract-Conference.html) | 模块化 latent dynamics；与本文模块化假设相关但任务不同 |
| 23 | Qin, Jiang & Zhu, “Learning to Adapt: In-Context Learning Beyond Stationarity” | 2026, ICLR | [ICLR 2026](https://proceedings.iclr.cc/paper_files/paper/2026/hash/8c1df8153bc1b1366fe27f0785e5fdd4-Abstract-Conference.html) | 非平稳关系下的上下文适应 |
| 24 | Steland, “Online Detection of Changes in Moment-Based Projections: When to Retrain Deep Learners or Update Portfolios?” | 2026, *JMLR* 27 | [JMLR PDF](https://www.jmlr.org/papers/volume27/23-0274/23-0274.pdf) | 高维非平稳数据的变化检测与更新决策 |
| 25 | Orujlu et al., “Causal Process Models: Reframing Dynamic Causal Graph Discovery as a Reinforcement Learning Problem” | 2026, CLeaR, PMLR 323 | [PMLR](https://proceedings.mlr.press/v323/orujlu26a.html) | 动态、稀疏因果图与 RL 的结合 |
| 26 | Kekić et al., “Learning Nonlinear Causal Reductions to Explain Reinforcement Learning Policies” | 2026, ICLR | [ICLR 2026](https://proceedings.iclr.cc/paper_files/paper/2026/hash/c01dfe01b97aadc10fc16a201faa80d8-Abstract-Conference.html); [MPI-IS record](https://is.mpg.de/publications/kekicetal26) | RL 策略的因果解释；与本文诊断目标不同 |
| 27 | Zhao et al., “Curious Causality-Seeking Agents in Open-ended Worlds” | 2025, NeurIPS 38 | [NeurIPS](https://papers.nips.cc/paper_files/paper/2025/hash/e21c92a1661709c3caf21fdd958bac99-Abstract-Conference.html) | meta-causal graph 与主动干预探索 |
| 28 | Gama et al., “A Survey on Concept Drift Adaptation” | 2014, *ACM Computing Surveys* | [ACM DOI](https://doi.org/10.1145/2523813) | 概念漂移、检测与适应的综述 |
| 29 | Peters, Bühlmann & Meinshausen, “Causal Inference by Using Invariant Prediction: Identification and Confidence Intervals” | 2016, *JRSS Series B* | [Oxford Academic](https://academic.oup.com/jrsssb/article/78/5/947/7040653); [DOI](https://doi.org/10.1111/rssb.12167) | 跨环境不变性与因果推断；本文不满足其识别条件 |
| 30 | Ahuja et al., “Invariant Risk Minimization Games” | 2020, ICML 37 | [PMLR](https://proceedings.mlr.press/v119/ahuja20a.html) | 不变预测与 OOD 泛化；作为概念背景而非实验基线 |
| 31 | Khemakhem et al., “Variational Autoencoders and Nonlinear ICA: A Unifying Framework” | 2020, AISTATS 23 | [PMLR](https://proceedings.mlr.press/v108/khemakhem20a.html) | 表征可识别性与辅助变量 |
| 32 | Zheng et al., “DAGs with NO TEARS: Continuous Optimization for Structure Learning” | 2018, NeurIPS 31 | [NeurIPS](https://proceedings.neurips.cc/paper/2018/hash/e347c51419ffb23ca3fd5050202f9c3d-Abstract.html) | 连续化结构学习；本文没有把 gate 当作 DAG 识别 |
| 33 | Pamfil et al., “DYNOTEARS: Structure Learning from Time-Series Data” | 2020, AISTATS 23 | [PMLR](https://proceedings.mlr.press/v108/pamfil20a.html) | 动态图结构学习的代表性方法 |
| 34 | Runge et al., “Detecting and Quantifying Causal Associations in Large Nonlinear Time Series Datasets” | 2019, *Science Advances* | [Science Advances DOI](https://doi.org/10.1126/sciadv.aau4996); [PubMed](https://pubmed.ncbi.nlm.nih.gov/31807692/) | PCMCI 与非线性时间序列因果发现 |
| 35 | Brouillard et al., “Differentiable Causal Discovery from Interventional Data” | 2020, NeurIPS 33 | [NeurIPS](https://proceedings.neurips.cc/paper/2020/hash/f8b7aa3a0d349d9562b424160ad18612-Abstract.html) | 干预数据与因果结构学习；本文不做该类识别实验 |
| 36 | Louizos, Welling & Kingma, “Learning Sparse Neural Networks through L0 Regularization” | 2018, ICLR | [OpenReview](https://openreview.net/forum?id=H1Y8hhg0b) | Hard-Concrete 稀疏门控的出处 |
| 37 | Maddison, Mnih & Teh, “The Concrete Distribution: A Continuous Relaxation of Discrete Random Variables” | 2017, ICLR | [OpenReview](https://openreview.net/forum?id=S1jE5L5gl); [Oxford repository](https://ora.ox.ac.uk/objects/uuid%3A5635eaad-c1bf-4f13-8832-034b90c0023a) | Concrete/Gumbel 连续松弛 |
| 38 | Kipf et al., “Neural Relational Inference for Interacting Systems” | 2018, ICML 35 | [PMLR](https://proceedings.mlr.press/v80/kipf18a.html) | 关系结构与动力学联合建模 |

## 使用边界

- 这 38 篇不是“本文超过的 38 个 baseline”。其中大部分用于问题背景、方法谱系和限制条件。
- 2026 年条目 19–26 均已在 ICML、ICLR、AAAI、CLeaR 或 JMLR 的正式页面核验；不保留仅有预印本版本的条目。
- 参考文献数量增加后，正文需要保留文内引用；不能只扩充列表而不说明每组工作与本文的关系。
- Moerland survey 采用 2023 年 *Foundations and Trends in Machine Learning* 正式出版版本，不再引用 arXiv 版本。
